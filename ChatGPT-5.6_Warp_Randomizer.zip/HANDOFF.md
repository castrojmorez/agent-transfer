# GLM Warp Randomizer — recovery handoff

CURRENT: consult `docs/active-work.md` before the historical entries below.
C11B-2 source-aware interception passes 14/14 ARM tests in both proof modes.
Ruleset 2 intentionally rejects ruleset-1 saves. Enabled/disabled normal links,
full host tests and sanitizer tests pass. See the active-work file and
`docs/c11b-source-gate-checkpoint.md` for reproduction and evidence limits.
Next graphical checks: `docs/c11b-mgba-manual-test.md`. No playable-preset claim.

## Historical checkpoint notes

Latest update: **C11B-1 source/trigger reconciliation**, 2026-09-08.
Read `docs/c11b-reconciliation-checkpoint.md` first for the next action.
The audit finds five active synthetic-trigger mismatches and three unintended
source exposures in C11A's destination-only hook. C11A's tests remain scoped
evidence, not target participation approval. No runtime/data identities changed.
Next implement a source-aware participant/signature gate and normalization,
with host and ARM coverage before interactive gameplay. C11B remains open.

Checkpoint: **C11A automated gate passed — versioned Algorithm-5 save identity,
asynchronous Continue reconstruction, reset cleanup, ordinary static-warp
interception and normal links verified**, 2026-09-07.
Read this file before changing the project. It is also included in
GLM_Random_Warp_Port.zip. The ZIP is the source/data/test bundle; this standalone
file alone cannot rebuild the project. No prior conversation or surviving
workspace is required when both are attached.

## Owner intent and working agreement

The user has asked the assistant to take over development of an in-game warp
randomizer for **RHH pokeemerald-expansion 1.17.0**, revising the supplied GLM
prototype where justified. Continue useful implementation autonomously; deliver
an updated durable ZIP and this handoff after major or semi-major progress.
Do not claim background work after returning a checkpoint. Update the handoff
before ending a substantial work session, especially if limits are approaching.

The user's important correction: unknown progression requirements may be
intentionally left unmodeled. Generation must not rely on such connections;
this does not mean the player can never traverse them. Composite IDs ending
`_1` are legitimate rule identifiers, distinct from exported capabilities.
Do not label WEATHER_INSTITUTE or the suffix convention a bug without evidence.

## Current result and its limits

**ARM-tested Algorithm-4 bank loader plus C11A's C9C-exact, disabled-by-default
Algorithm-5 new-game/save/Continue and ordinary-event warp integration. Both
proof modes and normal links pass, but target data and graphical power-cycle/
walking coverage remain open. This is not a playable or verified full-game
randomizer.**
Algorithm 3 accepted 68/68 complete reference-model seeds on their first
attempt, with independent Python checks of actual emitted mappings and
metadata replay. Seeds: 0–63, 255, 256, 65535, 4294967295; budget eight attempts.
The original eight-seed subset also passes. Core tests: 16 cases, all pass
normally and under ASan/UBSan. Fixed proof adapter passes host stub tests both
on and off. In C4, normal target ROMs build with the proof enabled and disabled;
ten tests per mode pass on actual ARM code in the bundled headless mGBA,
including emulated flash save/load. No interactive walking, full emulator
power-cycle/Continue, or hardware observation exists.

In C5, the real portable Algorithm-3 core and full reference graph compiled in
the target test ROM. Seed 0 produced the expected 532 records and the combined
suite passed 11/11. A 47,388-byte `WrWork` allocated from the nearly empty game
heap, left 68,356 contiguous bytes, was freed exactly, and the persistent
16,436-byte `WrActive` still resolved mappings. The constructor itself consumed
644,772,173 64-cycle ticks: 2,459.61 target seconds, or about 41 minutes. The
memory lifetime is viable only at a controlled allocation point; current
Algorithm 3 is categorically unsuitable for synchronous target integration.

C6A tested the bounded alternative without changing production code. It
generated 32 Algorithm-3 layouts offline; 32/32 passed independent validation
on their first attempt and all landing tables were unique. Sharing 532 packed
three-byte triggers and storing only three-byte landings plus one CRC32 per
layout requires 52,796 bytes. A 256-layout projection is 411,196 bytes. The
decision was to implement a 32-layout portable bank proof next.

C6B now provides that compiler and loader. Schema 1 stores the same 52,796-byte
packed payload, binds its complete content and selector contract to bank SHA-256
`4bd3884b6bea588af31006e9952320a0716860aed59d575b16b8156c110e8fc4`,
and assigns Algorithm ID 4 with ruleset 1. All 32 rows are selectable and have
distinct loaded-table digests. Representative seed replay, lookup, CRC
corruption, algorithm/ruleset/fingerprint mismatch, invalid descriptor and
valid-last failure behavior pass normally and under ASan/UBSan. The complete
existing host suite also passes.

C6C staged those exact inputs in the pinned target test build and passed the
combined 11/11 ARM tests. Seed 0 selected row 14 and reproduced host digest
`afc54651`. Selected-row CRC plus copying/publishing 532 records took 11,957
64-cycle ticks: 45.612 ms or 2.724 frames. Relative to the ten-test baseline,
the actual test link added 61,893 allocated ROM-section bytes including harness
overhead and exactly 16,436 EWRAM bytes; 18,996 EWRAM bytes remained. Algorithm
4 uses no `WrWork`. Bank-aware save decode, production hooks, new-game UI and
gameplay validation remain unimplemented.

The optional MiMo optimized-GLM submission was inspected, host-smoked and ARM
compiled but not merged. Its adjacency/bitset/reverse-reachability ideas are
useful for a future current-model Algorithm-5 prototype. The submitted core is
for a different GLM API/model, has 48,884 bytes static BSS and a 1,780-byte
largest compiler-reported ARM frame, lacks the baseline/independent validator
needed to reproduce its byte-identity claim, and advertises an early escape
check that is called only during final validation. See
docs/mimo-optimization-assessment.md. **The bank is a frozen fallback, not the
intended final on-demand randomizer.**
The two MiMo inputs are not redistributed in the project ZIP; their hashes and
measured findings are sufficient for planning. Ask the user to reattach them
only if the original supplied code needs renewed inspection.

C7A built a separate current-model host candidate rather than merging that
submission. It samples without replacement and scores at most four legal
partners per selected source, retaining Algorithm-3 closure, directed repair
and final validation semantics. Over the recorded 68 seeds it accepted 68/68,
66 on attempt zero and two on attempt one; every output replayed byte-identically
and passed the independent Python validator. Comparable single-generation host
time fell from 105.115 seconds for unchanged Algorithm 3 to 4.615 seconds,
22.78x in the final shared-source run. Candidate-path trial scoring fell from 4,284,175 eligible partners to
71,399 sampled trials. Synthetic candidate checks pass normally and with
ASan/UBSan, and expected failures expose no records.

This is evidence, not a new runtime algorithm. The prototype has no public/save
identity, changes no production code and still uses the 47,388-byte target-ABI
`WrWork`. See docs/c7a-feasibility.md and reports/c7a-*.

C7B compiled the exact shared cap-4 scheduler with the unchanged core and graph
in the pinned target test ROM. The combined suite passed 11/11. Seed 0 matched
host digest `aa8b08fd` and took 17,599,359 64-cycle ticks: 67.136 seconds or
4,009.879 frames. That is 36.636x faster than Algorithm 3 on ARM. Seed 42's
first attempt returned `WR_NO_PARTNER`; its second matched host digest
`4c5a43e2` and brought total time to 34,462,850 ticks: 131.465 seconds or
7,852.096 frames. Both are unacceptable blocking durations, so Algorithm ID 5
remains unassigned and synchronous integration is rejected.

The controlled heap lifetime again allocated the 47,388-byte workspace from a
115,760-byte free block, left 68,356 bytes and restored exactly. The test table
is 16,436 EWRAM bytes. The exact combined core+scheduler object has 7,500 bytes
of text and a 316-byte largest compiler-reported own frame; runtime stack
high-water remains unmeasured. See docs/c7b-arm-checkpoint.md and
reports/engine-proof/c7b-*.

C7C preserves that exact scheduler/output policy while replacing node-sized
closure state with generated SCC transitive-closure bitsets. The reference
graph collapses from 879 nodes to 400 unconditional components represented by
13 words; the generated index also contains 608 active-node indices and 90
cross-component conditional edges. All 68 recorded seeds succeeded with exactly
the same layouts, accepted attempts and rejection state as C7A; deterministic
replays and the independent validator passed. Five synthetic methods (27
executions), including capacity failure, pass normally and under ASan/UBSan.

The exact C7C target test passes 11/11. Seed 0 takes 9,969,798 64-cycle ticks
(38.032 seconds, 2,271.542 frames); seed 42's two attempts take 19,699,591 ticks
(75.148 seconds, 4,488.401 frames). These are 1.765x and 1.749x faster than C7B,
but remain unacceptable synchronously. Target workspace falls to 10,944 bytes,
36,444 bytes/76.906% below C7B, and leaves a 104,800-byte contiguous heap block;
allocation state restores exactly. The index adds 45,294 bytes of read-only
object data and the combined experimental object has 9,696 bytes of text.

C7 is therefore complete with compact-memory feasibility established and
blocking generation rejected. Algorithm ID 5 remains unassigned. No production
API, save hook, runtime selection or UI changed. See
docs/c7c-scc-checkpoint.md, reports/c7c-* and reports/engine-proof/c7c-*.

C8A retains the same cap-4 choices but starts each trial from the committed
zero-capability fixed point and propagates only components introduced by the
temporary pair or a newly granted capability. The generated event index groups
active nodes and conditional edges by component/capability; reverse traversal
uses a temporary destination bucket for the current pairing. This preserves the
early-stage safety semantics that a final-capability-only check would miss.

All 68 recorded layouts, attempts and rejection results exactly match C7A/C7C;
all replay deterministically and pass the independent validator. Five synthetic
methods (27 executions) pass normally and under ASan/UBSan. The pinned ARM
combined suite passes 11/11 and matches the same seed digests. Seed 0 takes
6,273,289 64-cycle ticks (23.931 seconds, 1,429.321 frames); seed 42's two
attempts take 11,919,509 ticks (45.469 seconds, 2,715.769 frames). These are
1.589x and 1.653x faster than C7C, but remain unacceptable synchronously.

The target workspace is 13,776 bytes—2,832 above C7C for queues/buckets, still
33,612 bytes/70.929% below C7B—and the heap restores exactly. The experimental
object has 11,356 bytes of text and 49,182 bytes of generated read-only data.
Algorithm ID 5 remains unassigned. C8B must reduce or reuse the unchanged
1,020–2,039 complete trial evaluations. See docs/c8a-event-checkpoint.md,
reports/c8a-* and reports/engine-proof/c8a-*.

C8B isolates partner-trial caps one through four on that same event-driven
engine. Cap one failed all 68 standard seeds; cap two succeeded only 23/68.
Cap three and cap four both succeeded 68/68, while cap four exactly reproduced
C8A for every seed. All 272 standard runs replayed deterministically and all
159 successful layouts independently validated. Six synthetic methods (30
executions) pass normally and under ASan/UBSan. Selected cap three then passed
1,024/1,024 consecutive stress seeds, with 803 first-attempt successes and at
most five attempts.

The cap-three ARM suite passes 11/11. Seed 0 takes 5,718,093 64-cycle ticks
(21.813 seconds, 1,302.824 frames); seed 42's two attempts take 9,442,690 ticks
(36.021 seconds, 2,151.445 frames). These are only 1.097x and 1.262x faster than
C8A. Across the standard corpus, extra retries leave cap three with only 2.53%
fewer complete trial states than cap four. Trial-cap tuning is therefore
exhausted as a route to synchronous real-time generation.

The workspace remains 13,776 bytes and restores exactly; the persistent table
remains 16,436 bytes. C8B is test-only, Algorithm ID 5 remained unassigned and
Algorithm 4 remained the frozen fallback. This result defined C8C's bounded
indexed-state experiment. See docs/c8b-trial-volume-checkpoint.md,
reports/c8b-* and reports/engine-proof/c8b-*.

C8C preserves C8B cap three exactly while replacing repeated full alias scans
with generated representative slices and maintaining reverse-warp destination
buckets incrementally across committed and temporary pairs. All 68 standard
layouts, attempts, rejection outcomes and trial counts exactly match C8B; every
replay and independent validation passes. The 1,024-seed stress run is also
1,024/1,024 exactly equal to C8B, deterministic and independently valid. Seven
synthetic methods (31 executions), including separate component and
representative capacity failures, pass normally and under ASan/UBSan.

The pinned ARM suite passes 11/11. Seed 0 takes 2,857,246 64-cycle ticks
(10.900 seconds, 651.002 frames); seed 42's two attempts take 4,216,672 ticks
(16.085 seconds, 960.736 frames). These are 2.001x and 2.239x faster than C8B.
The workspace remains 13,776 bytes and restores exactly; the persistent table
remains 16,436 bytes.

C8C removes roughly 112.9 million pair-scan visits and 99.8 million
reverse-rebuild visits from the standard host corpus. About 60.9 million
canonical-representative iterations remain, so C9A should test compact
free/reached/home representative bitsets and popcount scoring. Use two seconds
as the provisional synchronous budget. If C9A does not produce another major
ARM gain, stop optimizing this constructor and choose asynchronous generation,
a larger bank or a different architecture. C8 is complete; Algorithm ID 5
remains unassigned and Algorithm 4 remains the frozen fallback. See
docs/c8c-indexed-state-checkpoint.md, reports/c8c-* and
reports/engine-proof/c8c-*.

C9A preserves C8C exactly while replacing the remaining broad endpoint scans
with 16-word free/reached/home representative sets. Generated sparse
component-to-representative slices keep those sets synchronized; source and
partner iteration remains in increasing representative ordinal so every seeded
choice is byte-identical to C8C. Trial scoring uses intersections/popcounts.
All 68 standard layouts and the 1,024-seed stress corpus exactly match C8C,
replay deterministically and independently validate. Seven synthetic methods
(31 executions) pass normally and under ASan/UBSan.

The pinned ARM suite passes 11/11. Seed 0 takes 1,994,526 64-cycle ticks
(7.609 seconds, 454.437 frames); seed 42's two attempts take 2,452,812 ticks
(9.357 seconds, 558.854 frames). These are 1.433x and 1.719x faster than C8C.
The target workspace is 14,224 bytes, 448 bytes above C8C, and restores the heap
exactly; the persistent table remains 16,436 bytes.

Across the standard corpus, C8C's 60,914,176 representative scan visits become
7,692,873 candidate/repair set-bit visits plus 1,903,568 set/score word
operations. This is another material architectural gain, but the result remains
3.80x–4.68x above the provisional two-second budget. C9B should first profile
selection, closure, repair, scoring and final validation separately on ARM,
then attempt one safe trial-state reuse or prefilter only if it exposes a
multi-fold opportunity. Do not return to trial-cap or endpoint-scan tuning.
Algorithm ID 5 remains unassigned and Algorithm 4 remains the frozen fallback.
See docs/c9a-representative-bitset-checkpoint.md, reports/c9a-* and
reports/engine-proof/c9a-*.

C9B profiles a fixed cost that survived the constructor optimizations: the
successful path called `wr_graph_check` once before construction and again from
`wr_emit`. It retains the complete fail-closed entry validation, then uses an
otherwise identical post-validation emitter without the redundant second graph
scan. All 68 standard records, attempts, rejection outcomes and work counters
exactly match C9A; every replay and independent validation passes. The
1,024-seed stress run is likewise 1,024/1,024 exact, deterministic and
independently valid. Seven synthetic methods (31 executions) pass normally and
under ASan/UBSan.

The pinned ARM suite passes 11/11. Seed 0 takes 1,568,055 64-cycle ticks
(5.982 seconds, 357.269 frames); seed 42's two attempts take 2,026,342 ticks
(7.730 seconds, 461.686 frames). These are 1.272x and 1.210x faster than C9A.
The isolated remaining graph check costs 421,408 ticks (1.608 seconds) and the
post-check emitter 139,629 ticks (0.533 seconds). Subtracting both from the total
still leaves a diagnostic lower bound of 3.841–5.590 seconds; publication
cleanup alone cannot meet two seconds.

The target workspace remains 14,224 bytes and restores the heap exactly; the
persistent table remains 16,436 bytes. This result led to C9C's final bounded
reference-specialization experiment. See
docs/c9b-validated-emission-checkpoint.md, reports/c9b-* and
reports/engine-proof/c9b-*.

C9C generates one already ordered emission node for each of the 532 unique
active triggers (608 aliases), rejecting conflicting shared-trigger
representatives at compile time. Its cold path performs full graph/index
validation; its warm embedded-reference path reuses one successful immutable
approval. All 68 standard results and every work counter exactly match C9A/C9B,
and the 1,024-seed stress set is 1,024/1,024 exact, deterministic and
independently valid.

The pinned ARM suite passes 11/11. Cold seed 0/42 time is 5.439/7.159 seconds;
warm time is 3.807/5.527 seconds. The separately reported one-time approval is
1.632 seconds. Workspace stays 14,224 bytes, the persistent table stays 16,436
bytes and the controlled heap restores exactly. The warm constructor still
blocks for 227–330 frames, so incremental synchronous optimization of this
scheduler is closed. Next prototype its proven state machine as frame-sliced
asynchronous work with bounded frame time, progress, cancellation and safe
failure cleanup, or select a different constructor. Async will improve
responsiveness, not reduce total CPU work by itself. Algorithm ID 5 remains
unassigned; Algorithm 4 remains the frozen fallback. See
docs/c9c-cold-warm-checkpoint.md, reports/c9c-* and
reports/engine-proof/c9c-*.

C10A moves C9C's nested-loop locals into a resumable session. Each cooperative
quantum performs attempt initialization, source selection, one partner trial,
pair commit, indexed emission or final validation. Advance batch boundaries do
not affect RNG order. All 68 standard and 1,024 stress results exactly match
C9C; cancellation exposes no records, and a fresh begin in the same workspace
reproduces the exact layout. Five synthetic methods pass normally and under
ASan/UBSan.

The pinned ARM suite passes 11/11. A one-quantum loop completes seed 0 in
1,046,478 ticks (3.992 seconds) and seed 42 in 1,539,049 ticks (5.871 seconds),
only 4.9–6.2% slower than synchronous warm C9C. Attempt init, selection, commit
and emission are below one frame in the measured cases. The worst partner trial
is 7,040 ticks (1.604 frames), and final validation is 14,842 ticks (3.382
frames), so C10A is not yet one-frame safe. C10B must split trial propagation,
repair and final validation internally and use a margin below the 4,389-tick
theoretical frame limit.

The target session is 136 bytes; combined with the 14,224-byte work buffer,
resumable state is 14,360 bytes. The persistent table remains 16,436 bytes and
the controlled heap restores exactly. No callback, progress UI, user-facing
cancellation or save identity exists. Algorithm ID 5 remains unassigned and
Algorithm 4 remains the frozen fallback. See docs/c10a-cooperative-checkpoint.md,
reports/c10a-* and reports/engine-proof/c10a-*.

C10B splits the two C10A overruns without changing the frozen C9C policy.
Partner-pair forward/reverse closure, capability rounds, scoring, repair and
final validation now retain their queue/word cursors in a 156-byte target
session. One queued component is the propagation quantum. RNG and queue order,
retry behavior, short-circuit decisions, records and all C9C work counters are
exact across alternate advancement schedules. Normal and ASan/UBSan synthetic
tests pass. All 68 standard and 1,024 stress seeds match C9C and independently
validate; stress succeeds 1,024/1,024, with 803 first attempts and at most five
attempts.

The pinned ARM suite passes 11/11. The worst isolated step is now source
selection at 2,383 ticks (0.543 frame), down from C10A's 14,842-tick (3.382
frame) final validation. Trial microsteps peak at 399 ticks and validation at
533. Attempt init, commit and emission remain below one frame. The observed
ceiling has 2,006 ticks of nominal frame headroom, but that is not yet a safe
production callback budget because normal rendering/audio/input load was not
present.

Conservative one-component dispatch raises total target time: seed 0 takes
1,545,020 ticks (5.894 seconds) and seed 42 takes 2,217,409 ticks (8.459
seconds), 1.476x and 1.441x C10A. C10C should group cheap microsteps under a
timer-governed callback budget; one step per frame is unsuitable. Workspace
remains 14,224 bytes, combined transient state is 14,380 bytes, and the heap
restores exactly. No production callback, progress UI, save restoration or
user-facing cancellation exists. Algorithm ID 5 remains unassigned and
Algorithm 4 remains the frozen fallback. See
docs/c10b-frame-bounded-checkpoint.md, reports/c10b-* and
reports/engine-proof/c10b-*.

C10C adds a lifecycle adapter and actual engine task around C10B. Each callback
admits as many microsteps as fit conservatively inside a 3,200-tick allowance,
using phase bounds of 700/2,600/700/500/1,900/800 ticks for init, selection,
trial, commit, emission and validation. The job exposes retry-aware monotonic
progress on a 0–1,000 scale and an immutable view for a future screen. It
invalidates before start, processes deferred cancellation on the next callback,
publishes only after final validation, and releases exactly once on success,
failure, cancellation or publication failure.

Normal and ASan/UBSan lifecycle suites pass. Five budget/tick schedules preserve
exact outputs and counters. All 68 standard and 1,024 stress seeds remain exact
to C9C and independently validate; stress is 1,024/1,024 successful, 803 on
attempt zero and at most five attempts. Host failure tests cover invalid budget,
constructor failure and a simulated publish failure; each remains invalid and
releases once.

The pinned ARM suite passes 11/11. With a second deterministic 2,048-iteration
task running each scheduled frame, seed 0 completes in 685 callbacks and seed
42 in 1,102—about 11.4 and 18.4 seconds at 60 Hz. A callback processes up to
181/184 microsteps. The worst generator callback is 2,962 ticks (0.675 frame),
and the worst entire task frame is 3,869/4,389 ticks (0.882 frame), leaving 520
ticks of measured headroom. Progress never regresses. Cancellation requested
after frame 32 completes on frame 33 at progress 124, publishes nothing and
releases once.

The job is 200 target bytes and includes the 156-byte session; workspace plus
job is 14,424 transient bytes. The 316-byte test engine state is explicitly in
EWRAM, avoiding the target's nearly full IWRAM. All heap paths restore exactly.
The one-time immutable approval remains separate at 430,345 ticks (1.642
seconds). The competing task is synthetic rather than a rendered/audio/input
screen, so C10D must prove the real flow and production allocation point before
Algorithm 5/save identity. Algorithm 4 remains the frozen fallback. See
docs/c10c-budgeted-task-checkpoint.md, reports/c10c-* and
reports/engine-proof/c10c-*.

C10D replaces C10C's synthetic competitor with an actual target window and
main-callback lifecycle. The screen draws static text, a semantic progress bar
plus 60-frame activity pulse, an eight-slot attempt limit and terminal state.
It requests sound effects, runs normal tasks/sprites/text/palette work, and uses
the standard VBlank path for OAM, sprite copies, palette, queued DMA and
`m4aSoundMain`. Timer 3 measures the scheduler without stealing audio's timers.
B reaches cancellation through `JOY_NEW`; headless tests inject the edge, while
an unpatched graphical test ROM reads `REG_KEYINPUT` directly.

The naive first screen combined generation, immediate text layout and a full
8,960-byte refresh, producing roughly 10,000-tick frames. The corrected design
uses a 2,800-tick generator allowance, puts rendering on separate frames and
copies only affected tile rectangles. Both proof modes then pass 11/11 under
bundled mGBA. Seed 0/42 preserve digests `d2f14b80`/`3d354fa7` and complete in
883/1,264 frames (14.7/21.1 seconds at 60 Hz). The worst generator callback is
2,366 ticks. The worst measured main-plus-VBlank/audio frame is 4,079/4,389
ticks (0.929 frame), leaving 310 ticks with zero missed deadlines. Cancellation
finishes on frame 33, publishes nothing and releases once.

The workspace allocates after window initialization: the screen/window uses
11,040 heap bytes and workspace plus allocator metadata 14,240. Workspace is
released before screen teardown and entry heap totals/largest block restore
exactly. C10D screen state is 388 EWRAM bytes, only 72 linked bytes above C10C;
the persistent active table remains 16,436 bytes. Immutable approval runs before
screen creation. Algorithm ID 5 remains zero/unassigned.

The available automated mGBA is headless, so the project owner ran the short
graphical complement on 2026-09-07. All seven checklist observations passed:
readable/unclipped text, activity motion while progress was flat, seed 42's
attempt change, clean audio, two `WORLD READY` results, physical B cancellation
only on run three, and no blank screen, corruption, pause or crash. The supplied
log matches exact digests and step counts, records zero deadline misses and ends
in `PASS`; its worst interactive active frame is 4,209/4,389 ticks. Treat this
as user-observed evidence, not independent Codex observation; mGBA version and
host platform were not recorded. The builder
`tools/audit/build_c10d_interactive.py` emits a graphical test ROM after a
headless preflight. Do not include ROM bytes in the handoff. Read
`docs/c10d-rendered-mgba-checkpoint.md` and
`reports/engine-proof/c10d-human-graphical.*`.

C10E moves that exact C10D/C9C path into `src/warp_rando_runtime.c` and gates
it behind `OW_WARP_RANDO_NEW_GAME`, which defaults to false. Boot performs
immutable approval after `InitHeap` and before visible callbacks. The existing
`CB2_NewGame` becomes a wrapper: success tears the screen down and invokes the
original body, while cancellation or any failure returns to
`CB2_InitTitleScreen`. There is no silent ordinary-topology fallback. Workspace
allocation remains after window initialization, publication remains last, and
all owned resources are released exactly once.

Both fixed-proof modes pass 12/12 ARM tests. Seed 0/42 retain exact C9C digests
`d2f14b80`/`3d354fa7` and finish in 901/1,289 screen frames. The worst generator
callback is 2,361 ticks; the worst active main-plus-preceding-VBlank frame is
4,088/4,389 ticks, leaving 301 ticks with no missed deadlines. B cancellation,
injected workspace allocation failure and injected publication failure all
leave no valid table and select the abort callback. Heap totals restore exactly.

Enabled and disabled normal ROMs both link. Enabling C10E adds 16,852 EWRAM
bytes (16,436 active table plus 416 runtime state), zero IWRAM and 107,412 ROM
bytes, leaving 18,876 EWRAM bytes. A runtime system-stack canary patterns 3,932
bytes and observes 1,528 bytes high-water with 2,404 bytes untouched margin in
the ARM test path. The owner then completed both quickstart paths in Windows
mGBA 0.10.5 from a WSL Ubuntu 22.04 build. Success resumed play and physical B
cancelled safely. Both submitted lines record one missed deadline and 1,796
bytes stack margin; preserve that timing discrepancy. Read
`docs/c10e-production-checkpoint.md` and
`reports/engine-proof/c10e-human-graphical.*`.

C11A assigns Algorithm ID 5/ruleset 1 to this exact asynchronous constructor.
It appends an explicitly encoded 64-byte `WRSV` identity to SaveBlock3: version,
size, seed, algorithm, ruleset, 32-byte reference fingerprint, successful
attempt, ready state and CRC32. New Game writes it only after generation and
save initialization. Continue validates every compatibility field, regenerates
asynchronously, and publishes only if the successful attempt matches. Missing,
corrupt or incompatible metadata returns to title without a valid table.

The production bridge resolves only ordinary static `SetupWarp` destinations.
Mapped group, map and warp indices are checked against generated counts from
the pinned target and the destination map header before dereference. Script,
dynamic, Dive, fall, Escape, Teleport, whiteout and other exceptional paths stay
vanilla. Both proof modes pass 13/13: target flash save/load, runtime reset,
same Algorithm-5 attempt/digest, actual `SetupWarp` interception, reset cleanup,
and CRC/version/ruleset/fingerprint/attempt rejection. Enabled and disabled
normal ROMs link; C11A's enabled delta is 16,964 EWRAM, zero IWRAM and 108,744
ROM bytes, leaving 18,764 EWRAM bytes. Read
`docs/c11a-save-restore-checkpoint.md` and
`reports/engine-proof/c11a-probe.json`.

The model is reference-only. Known target drift: 12 destination disagreements,
one absent reference endpoint, 1,729 target-only warp events, two geometry
changes on matched annotated endpoints, and 13 excluded vanilla transitions
with unmodeled destinations. Do not certify these as harmless or excluded
without map/script evidence. Goal-node reachability is not champion defeat.

## What caused the failures and what was fixed

The original GLM code had one-way remap emission, 8-bit group truncation,
an eight-slot array read with nine prerequisites, weak validation, unimplemented
return reservations, unknown requirements opened as fixed edges, and publication
of rejected tables. These were repaired in the earlier portable rewrite; the
finding ledger is docs/revision-notes.md.

That rewrite's algorithm 2 still failed the complete reference batch: 52 trap
rejections and 12 exhausted-frontier failures across 64 attempts. Its heuristic
spent exits on progression leaves, ignored intermediate return failures, and
could pair isolated endpoints into closed sinks. Fifty completed candidates
remained trapped even after capability closure; two only violated early-stage
safety. Weather/Flash counterfactuals did not fix the batch.

Algorithm 3 recomputes the first unsafe capability stage, repairs reachable
unsafe regions through endpoints with directed routes home, scores actual free
canonical frontier gain, and rejects trials that strand unsafe vertices away
from every remaining free exit. Publication still uses the strict validator.
No universal Escape/Fly/Dig/Rope/whiteout action was invented. See
**docs/constructor-checkpoint.md** for the exact strategy and evidence.

On unchanged algorithm-2 data, algorithm 3 passed 8/8 (seed 2 needed the second
attempt and replayed successfully). That isolates the constructor repair from
the separate conservative-default change. Historical reports are retained, and
an isolated rollback script reproduces them exactly without replacing current
working files. Do not run the historical diagnostics directly on algorithm 3.

C5 found a different target-only failure: Algorithm 3 repeatedly scores each
remaining partner by rebuilding partial destinations and recomputing graph and
capability closure. Across roughly 256 pair choices, this produces tens of
thousands of full-graph trial evaluations. Desktop runtime concealed the cost;
the ARM7 measurement was about 41 minutes. Merely yielding the same work over
frames does not solve it. The on-device path must avoid that work; C6B does so
with a prevalidated bank under a separate algorithm ID.

C5 also corrected the C4 size audit. `target_resources.py` had compiled its
standalone size object without the target's `-mabi=apcs-gnu` flag, so
`WrRecord` appeared as 6 bytes instead of 8 and each 2,048-record buffer was
understated by 4,096 bytes. Correct sizes are `WrWork` 47,388, `WrActive`
16,436, and both 63,824 bytes. C4's normal-ROM link numbers and executable test
results remain valid.

## Decisions to preserve

* Unknown requirements default to unavailable, with diagnostics. The importer
  declares ungrantable capabilities; the normalized compiler rejects undeclared
  references. Optional strict audit mode is `unknown_requirement_policy: error`.
* Default aliases are empty. WEATHER_INSTITUTE and HOENN_FLASH_1 are ungrantable.
  An explicit Flash alias is supported as a deliberate behavioral change, not
  an established correction. Raw upstream JSON files remain unchanged.
* The historical author's comment verifies the fallback policy, not the intent
  of every individual unresolved name. Real game traversal may be more liberal.
* The graph has fixed root, repeatable directed travel, permanent capabilities,
  AND prerequisites/OR rules and explicit goals. Every reachable vertex must
  return to the root at **every** capability stage. This is stronger than merely
  finding one completion route. Changing it is a separate ruleset decision.
* This port supports capability prerequisites as well as location prerequisites.
  That differs from the inspected Java location-only updater; see the Strength
  discussion in docs/failure-diagnosis.md. Do not assert exact Java parity.
* Coupled pairs emit both directions and all physical aliases; indices are
  16-bit with sentinel 65535. Never repurpose physical IDs as proxy triggers.
  Engine lookup matches requested destination triples, not source warp IDs.
* Dedicated deterministic RNG; algorithm ID **3**, ruleset ID **1**, normalized
  data SHA-256 included in identity. Metadata is 56-byte WR02 envelope with
  algorithm field, accepted attempt and CRC32. Algorithm-2 metadata is rejected.
* Failure invalidates the active table. Do not count vanilla fallback as success
  or silently change topology when a randomized save cannot regenerate.
* Bank schema 1 uses algorithm ID **4**, ruleset ID **1**, 32 layouts and the
  frozen C6A mixer. Its identity data is the complete bank fingerprint. The
  selected row is derived from the preserved player seed and is CRC-checked.
  Algorithm 3 remains the offline bank builder; do not call it on-device.
* The current graph-specific `wr_decode` rejects Algorithm-4 metadata. Do not
  claim restart compatibility until a bank-aware restore path is implemented
  and target-tested.
* Keep Algorithm 4 and bank schema 1 frozen as the tested fallback. A proper
  on-demand replacement must use a new identity (provisionally Algorithm 5)
  after current-model validation, memory bounds and direct ARM timing. Do not
  merge the supplied MiMo implementation wholesale or claim its older-model
  byte equivalence applies to this project.

## Recover and reproduce

Extract GLM_Random_Warp_Port.zip and work from its GLM_Random_Warp_Port directory.
Python 3.10+, C99 `cc`, make, Git and GNU patch are sufficient for host work.
The recorded environment used Python 3.12.13 and GCC 13.3.0. No pip/npm downloads.

```sh
make test
make sanitize
make data
make seeds
make bank
make c10b
make c10c
# Bash range expansion:
python3 tools/audit/seed_batch.py --output reports/seed-sweep.json --seeds {0..63} 255 256 65535 4294967295
python3 tools/audit/reproduce_algorithm2.py
```

LeakSanitizer process inspection was unavailable, so its check is explicitly
disabled in the harness; ASan/UBSan remain active. No leak-check claim.
reports/manifest.json hashes all packaged files except itself. Seed reports
record core/input hashes and emitted-record digests; timing varies by host.

Fetch upstream checkouts when needed, outside the package directory:

```sh
python3 tools/audit/fetch_sources.py ../sources
python3 tools/audit/drift.py data/reference/Warps.json ../sources/target ../sources/speedchoice reports
python3 tools/audit/make_proof_patch.py ../sources/target build/proof.patch
cmp patches/expansion-1.17.0-proof.patch build/proof.patch
git -C ../sources/target apply --check "$PWD/patches/expansion-1.17.0-proof.patch"
```

Exact commits (also in PROVENANCE.md and fetch_sources.py):

| Input | Commit |
|---|---|
| KittyPBoxx/upr-speedchoice-ex-gen9 | 5abfca86134872dbb3c54fa48e5920b6549cfb69 |
| KittyPBoxx/pokeemerald-ex-speedchoice-maprando-gen9 | f539267677ec3686c7f22bae2a63dc6f1a5267e9 |
| rh-hideout/pokeemerald-expansion, expansion/1.17.0 | e8bd1cd7b03fc032ea37e3ecd38b379b5d01a1e7 |
| KittyPBoxx/Emerald-Ex-Map-Rando, historical comment | f0966a668d3e7a7e937a519365cb1391d4a174a4 |

Historical source: dist/Randomiser/Flags.json.js, comment lines 56–69;
reports/historical-policy.json records its whole-file hash. The original upload
hash is 9a618fc6110ed1a4d44da53ba7912cf9403e7c87eb1f6229bb95dc29afdc9c59.
The diagnosed algorithm-2 archive hash was
3baec095956577b54ad0e3626e5b657e4eb35c193a58f663220d8219353522b1.
Neither old archive is needed for the included rollback reproduction.

## File map

* src/warp_rando.c and include/warp_rando.h: Algorithm-3 offline constructor.
* src/warp_bank.c and include/warp_bank.h: Algorithm-4 schema-1 loader.
* data/reference-bank.h and reports/reference-bank.json: generated bank and identity evidence.
* tools/warprandogen/: reference import and deterministic C-array compiler.
* data/reference/: unchanged four pinned JSON inputs; overrides.json records
  current policy; reference-normalized.json and reference-graph.h are generated.
* tests/harness.c and validate.py: actual-core harness and independent acceptance.
* tools/experiments/c7a_candidate.c, c7a_candidate_core.inc and c7a_baseline.c:
  shared bounded scheduler, host harness and unchanged Algorithm-3 control; no runtime API.
* tests/c7a_test.py and tools/audit/c7a_*.py: C7A synthetic, corpus, timing and
  checked-report reproduction.
* tools/experiments/c7c_candidate.c and c7c_candidate_core.inc,
  tools/warprandogen/compile_closure.py and data/reference-closure.h: C7C
  graph-sized SCC experiment and deterministic generated index; no runtime API.
* tests/c7c_test.py and tools/audit/c7c_*.py: C7C synthetic, equivalence, timing,
  ARM and checked-report reproduction.
* tools/experiments/c8a_candidate.c and c8a_candidate_core.inc,
  tools/experiments/candidate_benchmark.c, compile_event_index.py and
  data/reference-event-index.h: C8A event-driven delta experiment; no runtime API.
* tests/c8a_test.py and tools/audit/c8a_*.py: C8A synthetic, equivalence, timing,
  ARM and checked-report reproduction.
* tools/experiments/c8b_candidate.c and c8b_candidate_core.inc,
  compile_c8b_index.py and data/reference-c8b-event-index.h: isolated C8B
  cap-policy experiment; no runtime API.
* tests/c8b_test.py and tools/audit/c8b_*.py: C8B synthetic, cap sweep,
  1,024-seed stress, ARM and checked-report reproduction.
* tools/experiments/c8c_candidate.c and c8c_candidate_core.inc,
  compile_c8c_index.py and data/reference-c8c-event-index.h: indexed
  representative/reverse-state experiment; no runtime API.
* tests/c8c_test.py and tools/audit/c8c_*.py: C8C synthetic, exact equivalence,
  1,024-seed stress, ARM and checked-report reproduction.
* tools/experiments/c9a_candidate.c and c9a_candidate_core.inc,
  compile_c9a_index.py and data/reference-c9a-event-index.h: compact
  free/reached/home representative-set experiment; no runtime API.
* tests/c9a_test.py and tools/audit/c9a_*.py: C9A synthetic, exact equivalence,
  1,024-seed stress, ARM and checked-report reproduction.
* tools/experiments/c9b_candidate.c and c9b_candidate_core.inc,
  compile_c9b_index.py and data/reference-c9b-event-index.h: validated-emission
  experiment; no runtime API.
* tests/c9b_test.py and tools/audit/c9b_*.py: C9B synthetic, exact equivalence,
  1,024-seed stress, ARM phase timing and checked-report reproduction.
* tools/experiments/c9c_candidate.c and c9c_candidate_core.inc,
  compile_c9c_index.py and data/reference-c9c-event-index.h: cold/warm
  immutable approval and sorted indexed-emission experiment; no runtime API.
* tests/c9c_test.py and tools/audit/c9c_*.py: C9C synthetic, exact equivalence,
  1,024-seed stress, cold/warm ARM timing and checked-report reproduction.
* tools/experiments/c10a_candidate.c and c10a_candidate_core.inc: cooperative
  C9C state machine with explicit cancellation; no runtime API.
* tests/c10a_test.py and tools/audit/c10a_*.py: schedule independence,
  cancellation/restart, 1,024-seed equivalence and ARM maximum-phase evidence.
* tools/experiments/c10b_candidate.c and c10b_candidate_core.inc: internally
  resumable C9C trial/repair/final-validation state machine; no runtime API.
* tests/c10b_test.py and tools/audit/c10b_*.py: microphase schedule independence,
  cancellation/restart, 1,024-seed equivalence and one-frame ARM evidence.
* tools/experiments/c10c_candidate.c and c10c_scheduler_core.inc: timer-budgeted
  lifecycle adapter, progress view, cancellation and publish/cleanup hooks.
* tests/c10c_test.py and tools/audit/c10c_*.py: callback schedule independence,
  failure lifecycle, 1,024-seed equivalence and loaded engine-task evidence.
* patches/c10e-production.patch, patches/production/include/* and
  patches/production/src/warp_rando_runtime.c: disabled-by-default production
  new-game integration, boot approval, screen lifecycle and stack canary.
* patches/engine-tests/warp_rando_c10e.c and tools/audit/c10e_probe_report.py:
  dual-mode production runtime/failure tests and checked link/resource report.
* reports/seed-sweep.json: current 68-seed evidence; algorithm3-original-data-seeds.json:
  constructor-only comparison; algorithm2/: preserved historical evidence.
* patches/expansion-1.17.0-proof.patch: disabled-by-default fixed Oldale mapping.
  patches/engine-tests/ contains the ARM tests and reproduction guide;
  reports/engine-proof/ contains per-mode results, hashes, target sizes and the
  C5 generator log/checked reports.
* tools/audit/prepare_target_toolchain.py, build_engine_proof.py and
  target_resources.py: checksum-pinned local dependencies, target builds/tests,
  target-ABI size and static-frame measurements. generator_probe_report.py
  validates the raw generator result.
* docs/generator-lifetime-checkpoint.md: C5 memory, ABI and timing decision.
  docs/precomputed-bank-feasibility.md: C6A bank measurements and decision.
  docs/bank-loader-checkpoint.md: C6B format, loader tests and limits.
  docs/bank-arm-checkpoint.md: C6C ARM timing/resources and bank conclusion.
  docs/mimo-optimization-assessment.md: supplied optimization assessment and Algorithm-5 path.
  docs/c7a-feasibility.md: bounded candidate design, host evidence and C7B gate.
  docs/c7b-arm-checkpoint.md: exact ARM timing/resources and rejection decision.
  docs/c7c-scc-checkpoint.md: compact closure design, exact equivalence, ARM
  timing/memory and final C7 disposition.
  docs/c8a-event-checkpoint.md: event-driven delta design, ARM result and C8B gate.
  docs/c8b-trial-volume-checkpoint.md: cap sweep, stress result, ARM timing and
  C8C architecture gate.
  docs/c8c-indexed-state-checkpoint.md: indexed alias/reverse-state design,
  ARM result and C9A gate.
  docs/c9a-representative-bitset-checkpoint.md: compact endpoint-set design,
  ARM result and C9B profiling gate.
  docs/c9b-validated-emission-checkpoint.md: duplicate validation diagnosis,
  ARM result and C9C specialization gate.
  docs/c9c-cold-warm-checkpoint.md: final synchronous specialization result and
  asynchronous-next decision.
  docs/c10a-cooperative-checkpoint.md: cooperative architecture, exactness and
  the C10B internal-slicing gate.
  docs/c10b-frame-bounded-checkpoint.md: exact internal slicing, ARM one-frame
  ceiling, total-work tradeoff and C10C callback gate.
  docs/c10c-budgeted-task-checkpoint.md: budgeted engine task, monotonic
  progress, cancellation, loaded-frame timing and C10D screen gate.
  docs/c10d-rendered-mgba-checkpoint.md: rendered main/VBlank/audio/input flow,
  allocation evidence and remaining production gate.
  docs/c10d-mgba-manual-test.md: completed graphical mGBA and physical-input
  checklist, provenance and repeat instructions.
  docs/c10e-production-checkpoint.md: production wrapper, fail-closed paths,
  normal-link resources, stack result and diagnosed integration failures.
  docs/c10e-mgba-manual-test.md: completed owner-observed normal-ROM
  success/cancel checklist and retained deadline discrepancy.
  docs/c11a-save-restore-checkpoint.md: versioned Algorithm-5 identity,
  Continue reconstruction, event interception and failure/resource evidence.
  docs/runtime-contract.md, ruleset.md and next-steps.md cover integration,
  gameplay assumptions and remaining work.

## C4 engine, C5 generator, C6C bank, C7 and C8 evidence

Read docs/engine-proof-checkpoint.md and patches/engine-tests/README.md.
The latter provides the full Linux amd64 dependency bootstrap and target build
commands. The ARM GCC version is 13.2.1 20231009, Ubuntu package
15:13.2.rel1-2. Twelve dependency packages are checksum-pinned in
reports/target-toolchain-packages.json; they are extracted locally, never
installed globally. The bootstrap was exercised under a second prefix and
reproduced the then-current measurements. C5 found that the standalone size
probe in those measurements omitted the target ABI flag; the bootstrap itself
and C4 executable results are unaffected.

The target includes a runnable headless mGBA binary. Its source pin and binary
hash are in reports/engine-proof/emulator.json. Tests call the actual SetupWarp
through a TESTING-only bridge, then WarpIntoMap, collision and flash functions.
The bridge is absent from normal ROMs. All ten tests pass with the proof off
and on. House1's native exit is (3,8), House2's (3,7); the corrected House2 tile
(3,6) is passable and outside warp events. Door animations remain unobserved.
The flash test restores the map header after a real flash save/load; it is not
a complete emulator restart or Continue-callback test.

Build setup fixes: use patches/build-without-dev-fd.patch for the two upstream
process-substitution pipelines; this appends the same assembler suffix through
ordinary pipes. The delivered build script avoids Hydra's hardcoded /tmp by
running the same emulator sequentially with files in the checkout. It checks
the declared pass count. The reduced test build includes test_test_runner.c,
which is explicitly named by the target linker script. One original test
expected House1 row 7; this was corrected from target map data after the emulator
returned the correct row 8. The production fixed mapping was unchanged.

C5's `--generator-probe` mode stages exact copies of the portable core/header,
the full generated graph, and `warp_rando_generator.c`. The 11-test target run,
raw log and checked JSON are under reports/engine-proof/. Read
docs/generator-lifetime-checkpoint.md before making a runtime design decision.

C6C's `--bank-probe` mode stages exact copies of the Algorithm-4 loader, bank,
header and lookup support. Its one additional test covers load/replay/lookup and
the corruption, identity, invalid-descriptor and invalidation paths. The raw
`WRBANK` log, baseline and bank resource reports, and checked result are under
reports/engine-proof/bank-*; read docs/bank-arm-checkpoint.md.

C7B's `--c7a-probe` mode stages exact copies of the unchanged core, full graph,
shared experimental scheduler and ARM harness. Its one additional test times
seeds 0 and 42, verifies host mapping digests, allocation/release and valid-last
copying. The raw `WRC7B` log, target resources and checked report are under
reports/engine-proof/c7b-*; read docs/c7b-arm-checkpoint.md.

C7C's `--c7c-probe` mode stages the exact graph, generated SCC closure index,
compact experimental core and ARM harness. It times the same seeds/digests and
checks the smaller heap allocation/restoration. Raw and checked evidence is
under reports/engine-proof/c7c-*; read docs/c7c-scc-checkpoint.md.

C8A's `--c8a-probe` mode stages the generated event index, delta core and ARM
harness. It times the same seeds/digests and checks the compact heap lifetime.
Raw and checked evidence is under reports/engine-proof/c8a-*; read
docs/c8a-event-checkpoint.md.

C8B's `--c8b-probe` mode stages the isolated cap-three core/index and ARM
harness. It checks the changed host digests, timing and the same compact heap
lifetime. Raw and checked evidence is under reports/engine-proof/c8b-*; read
docs/c8b-trial-volume-checkpoint.md.

C8C's `--c8c-probe` mode stages the indexed representative/alias data,
incremental reverse-state core and ARM harness. It checks the unchanged C8B
host digests, timing and compact heap lifetime. Raw and checked evidence is
under reports/engine-proof/c8c-*; read
docs/c8c-indexed-state-checkpoint.md.

C9A's `--c9a-probe` mode stages the representative ordinal/component slices,
compact bitset core and ARM harness. It checks unchanged C8C host digests,
timing and the 14,224-byte heap lifetime. Raw and checked evidence is under
reports/engine-proof/c9a-*; read
docs/c9a-representative-bitset-checkpoint.md.

C9B's `--c9b-probe` mode stages the validated-emission core and measures total
generation plus standalone graph-check and post-check emission costs. It checks
unchanged C9A host digests/counters and the same compact heap lifetime. Raw and
checked evidence is under reports/engine-proof/c9b-*; read
docs/c9b-validated-emission-checkpoint.md.

C9C's `--c9c-probe` mode stages the cold/warm indexed-emission core. It checks
unchanged C9A/C9B digests/counters, reports immutable approval separately and
restores the compact heap exactly. Raw and checked evidence is under
reports/engine-proof/c9c-*; read docs/c9c-cold-warm-checkpoint.md.

C10A's `--c10a-probe` mode stages the cooperative wrapper over C9C. It times a
one-quantum loop and the maximum isolated cost of each phase, checks exact host
digests, cancellation and heap restoration. Raw and checked evidence is under
reports/engine-proof/c10a-*; read docs/c10a-cooperative-checkpoint.md.

C10B's `--c10b-probe` mode stages internally resumable trial, repair and final
validation paths. It checks exact seed digests, cancellation and heap
restoration, then times total work and every isolated logical group. Raw and
checked evidence is under reports/engine-proof/c10b-*; read
docs/c10b-frame-bounded-checkpoint.md.

C10C's `--c10c-probe` mode runs the C10B session through an actual engine task
under a 3,200-tick admission budget while a second task supplies deterministic
CPU load. It checks exact digests, monotonic progress, deferred cancellation,
success-only publication, heap restoration, callback maxima and whole task
frames. Raw and checked evidence is under reports/engine-proof/c10c-*; read
docs/c10c-budgeted-task-checkpoint.md.

C10D's `--c10d-probe` mode runs the exact generator behind a real target
window/main callback and normal VBlank/audio work, using separate render frames
and a 2,800-tick generator allowance. It checks exact digests, VRAM transfer,
progress/activity rendering, attempt change, terminal states, B cancellation,
publication, staged allocation/cleanup and full-frame deadlines in both proof
modes. Raw and checked evidence is under reports/engine-proof/c10d-*; read
docs/c10d-rendered-mgba-checkpoint.md.

C10E's `--c10e-probe` mode stages the production config/runtime itself and
runs two ARM cases covering exact seed 0/42 output, screen timing, B
cancellation, allocation failure, publication failure, callbacks, publication,
cleanup and the runtime stack canary. It passes 12/12 in both proof modes. The
separate report checks enabled and disabled normal links and their EWRAM/IWRAM/
ROM delta. Raw and checked evidence is under `reports/engine-proof/c10e-*` and
`reports/c10e-verification.json`; read `docs/c10e-production-checkpoint.md`.

C11A's `--c11a-probe` mode additionally stages the identity codec, target map
counts and save/restore/interception harness after the C11A production patch.
Three ARM cases cover flash persistence plus reconstruction, actual target
event interception, reset cleanup and incompatible/corrupt metadata. It passes
13/13 in both proof modes. `tools/audit/c11a_probe_report.py` checks those logs
and the enabled/disabled normal-link resource pair. Raw and checked evidence is
under `reports/engine-proof/c11a-*`; read
`docs/c11a-save-restore-checkpoint.md`.

## Immediate next action and remaining gates

C11B-1 has now narrowed the first implementation task: add source-event
participation/signature validation and synthetic-trigger normalization before
runtime lookup. See `reports/c11b-reconciliation.json` for exact affected
sources. Do not simply replace reference triggers with target destinations.

C11B should reconcile the reference annotations with the pinned target and
produce explicit target-approved traversal/progression data. Do not promote the
current reference graph: 12 destination disagreements, one absent endpoint,
1,729 target-only events, two geometry changes and 13 unmodeled excluded
transitions remain.

Then observe a real graphical power-cycle/Continue and representative walking
round trips, including grouped exits and save/reload. Recheck frame and stack
behavior during restore; the accepted C10E success and cancellation runs each
recorded one deadline miss. The C11A normal link leaves 18,764 EWRAM bytes.

Audit state-dependent Escape, scripts, dynamic warps, Dive/fall, Teleport,
whiteout and direct assignments before extending interception. Progression
accommodations, options/version migration, worst-case retry behavior and actual
champion/credits completion remain open. Keep Algorithm 4 unchanged as the fast
fallback and do not claim a playable preset until those gates pass.

## Checkpoint maintenance

For the next substantial milestone, update this file and STATUS.md with final
behavior, exact tests, remaining risks and next action. Preserve historical
reports under their algorithm/checkpoint identity; never present stale results
as current. If changing any rollback-patched production file, refresh
patches/algorithm2-reproduction.patch and verify baseline hashes again.

Package with `python3 tools/package.py /absolute/output/GLM_Random_Warp_Port.zip`.
The packager deliberately whitelists files and omits build/temp/cache content.
Verify a fresh extraction, then save the ZIP and a standalone HANDOFF.md as
durable deliverables. Do not rely on scratch paths surviving or on this chat
being available to the next instance.
