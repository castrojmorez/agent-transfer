#include "warp_rando_source.h"

static int key_compare(const struct WrKey *a, const struct WrKey *b)
{
    if (a->group != b->group) return (int)a->group - b->group;
    if (a->map != b->map) return (int)a->map - b->map;
    return (int)a->warp - b->warp;
}

int wr_source_normalize(const struct WrSourceRoute *routes, size_t count,
                        const struct WrKey *source, const struct WrKey *requested,
                        uint16_t x, uint16_t y, uint8_t elevation,
                        struct WrKey *out)
{
    size_t lo = 0, hi = count;
    const struct WrSourceRoute *row;
    if (!routes || !source || !requested || !out) return 0;
    while (lo < hi) {
        size_t mid = lo + (hi - lo) / 2;
        if (key_compare(&routes[mid].source, source) < 0) lo = mid + 1;
        else hi = mid;
    }
    if (lo == count) return 0;
    row = &routes[lo];
    if (key_compare(&row->source, source)
     || key_compare(&row->expected, requested)
     || row->x != x || row->y != y || row->elevation != elevation) return 0;
    *out = row->trigger;
    return 1;
}
