#include "warp_rando_identity.h"
#include <string.h>

#define WR_IDENTITY_SAVE_CRC_OFFSET 60u

static void put16(uint8_t *p, uint16_t value)
{
    p[0] = (uint8_t)value;
    p[1] = (uint8_t)(value >> 8);
}

static void put32(uint8_t *p, uint32_t value)
{
    p[0] = (uint8_t)value;
    p[1] = (uint8_t)(value >> 8);
    p[2] = (uint8_t)(value >> 16);
    p[3] = (uint8_t)(value >> 24);
}

static uint16_t get16(const uint8_t *p)
{
    return (uint16_t)(p[0] | ((uint16_t)p[1] << 8));
}

static uint32_t get32(const uint8_t *p)
{
    return (uint32_t)p[0] | ((uint32_t)p[1] << 8)
         | ((uint32_t)p[2] << 16) | ((uint32_t)p[3] << 24);
}

static uint32_t crc32(const uint8_t *p, size_t size)
{
    uint32_t crc = UINT32_MAX;
    size_t i;
    unsigned bit;

    for (i = 0; i < size; i++)
    {
        crc ^= p[i];
        for (bit = 0; bit < 8; bit++)
            crc = (crc >> 1) ^ (0xedb88320u & (0u - (crc & 1u)));
    }
    return ~crc;
}

int wr_identity_save_encode(const struct WrActive *active,
                            uint8_t out[WR_IDENTITY_SAVE_BYTES])
{
    if (active == NULL || out == NULL || !active->valid)
        return WR_BAD_IDENTITY;

    memset(out, 0, WR_IDENTITY_SAVE_BYTES);
    memcpy(out, "WRSV", 4);
    put16(out + 4, WR_IDENTITY_SAVE_VERSION);
    put16(out + 6, WR_IDENTITY_SAVE_BYTES);
    put32(out + 8, active->identity.seed);
    put32(out + 12, active->identity.algorithm);
    put32(out + 16, active->identity.ruleset);
    memcpy(out + 20, active->identity.data, sizeof(active->identity.data));
    put16(out + 52, active->attempt);
    out[54] = WR_IDENTITY_SAVE_READY;
    put32(out + WR_IDENTITY_SAVE_CRC_OFFSET,
          crc32(out, WR_IDENTITY_SAVE_CRC_OFFSET));
    return WR_OK;
}

int wr_identity_save_decode(const uint8_t in[WR_IDENTITY_SAVE_BYTES],
                            uint32_t expected_algorithm,
                            uint32_t expected_ruleset,
                            const uint8_t expected_fingerprint[32],
                            struct WrIdentity *identity,
                            uint16_t *attempt)
{
    struct WrIdentity candidate;

    if (in == NULL || expected_fingerprint == NULL || identity == NULL
     || attempt == NULL || memcmp(in, "WRSV", 4)
     || get16(in + 4) != WR_IDENTITY_SAVE_VERSION
     || get16(in + 6) != WR_IDENTITY_SAVE_BYTES
     || in[54] != WR_IDENTITY_SAVE_READY || in[55] || in[56] || in[57]
     || in[58] || in[59]
     || crc32(in, WR_IDENTITY_SAVE_CRC_OFFSET)
        != get32(in + WR_IDENTITY_SAVE_CRC_OFFSET))
        return WR_BAD_IDENTITY;

    candidate.seed = get32(in + 8);
    candidate.algorithm = get32(in + 12);
    candidate.ruleset = get32(in + 16);
    memcpy(candidate.data, in + 20, sizeof(candidate.data));
    if (candidate.algorithm != expected_algorithm
     || candidate.ruleset != expected_ruleset
     || memcmp(candidate.data, expected_fingerprint, sizeof(candidate.data)))
        return WR_BAD_IDENTITY;

    *identity = candidate;
    *attempt = get16(in + 52);
    return WR_OK;
}
