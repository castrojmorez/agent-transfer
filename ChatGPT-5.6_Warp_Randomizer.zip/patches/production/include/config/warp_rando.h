#ifndef GUARD_CONFIG_WARP_RANDO_H
#define GUARD_CONFIG_WARP_RANDO_H

// C11A opt-in production lifecycle. Disabled builds retain the original
// new-game/Continue paths and do not run immutable-reference approval at boot.
#define OW_WARP_RANDO_NEW_GAME FALSE

// Temporary new-game seed source. C11A persists it in the versioned Algorithm-5
// identity, but a player-facing seed-selection design remains future work.
#define OW_WARP_RANDO_SEED 0u

// SaveBlock3 reserves this append-only envelope only in opt-in builds.
#define OW_WARP_RANDO_SAVE_BYTES 64u

#endif // GUARD_CONFIG_WARP_RANDO_H
