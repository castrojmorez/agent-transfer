#ifndef GUARD_WARP_RANDO_RUNTIME_H
#define GUARD_WARP_RANDO_RUNTIME_H

#include "global.h"
#include "main.h"
#include "warp_rando.h"
#include "warp_rando_identity.h"

#define WARP_RANDO_FRAME_TICKS 4389u
#define WARP_RANDO_BUDGET_TICKS 2800u
#define WARP_RANDO_CANCELLED_RESULT 101
#define WARP_RANDO_ALGORITHM 5u
#define WARP_RANDO_RULESET 2u

struct WarpRandoRuntimeMetrics
{
    u32 frames;
    u32 callbacks;
    u32 maxCallbackTicks;
    u32 maxMainTicks;
    u32 maxVBlankToMainTicks;
    u32 maxActiveTicks;
    u32 deadlineMisses;
    u32 renderUpdates;
    u32 audioRequests;
    u32 invalidations;
    u32 publishes;
    u32 releases;
    u32 progressRegressions;
    u32 terminalRenders;
    u32 steps;
    u32 partnerTrials;
    u16 progress;
    u8 successfulAttempt;
    int result;
};

// Called once after InitHeap and before visible callbacks when the opt-in path
// is enabled. Approval is immutable-data validation, not seed generation.
bool8 WarpRando_ApproveReference(void);
bool8 WarpRando_IsReferenceApproved(void);

// Starts the rendered asynchronous new-game screen. On success, completion is
// selected; cancellation or any failure selects abort. A FALSE return means
// screen ownership could not be established and the caller must fail closed.
bool8 WarpRando_StartNewGame(u32 seed, MainCallback completion, MainCallback abort);
bool8 WarpRando_StartContinue(const u8 save[WR_IDENTITY_SAVE_BYTES],
                              MainCallback completion, MainCallback abort);
bool8 WarpRando_WriteSave(u8 save[WR_IDENTITY_SAVE_BYTES]);
bool8 WarpRando_IsGenerationActive(void);
const struct WrActive *WarpRando_GetActive(void);
void WarpRando_GetMetrics(struct WarpRandoRuntimeMetrics *out);

// Ordinary event-warp interception. Scripted/dynamic/exceptional setters do
// not call this function. Inputs are the requested destination triple.
bool8 WarpRando_ResolveWarp(s8 sourceGroup, s8 sourceMap, s8 sourceWarp,
                           u16 x, u16 y, u8 elevation,
                           s8 *mapGroup, s8 *mapNum, s8 *warpId);

// Development canary for the system stack. It never writes above the current
// frame and reports the lowest remaining patterned address as free margin.
void WarpRando_InitStackCanary(void);
u32 WarpRando_GetStackHighWater(void);
u32 WarpRando_GetStackMargin(void);

#ifdef TESTING
enum WarpRandoTestFailure
{
    WARP_RANDO_TEST_FAIL_NONE,
    WARP_RANDO_TEST_FAIL_WORK_ALLOC,
    WARP_RANDO_TEST_FAIL_PUBLISH,
};
void WarpRando_TestReset(void);
void WarpRando_TestForceFailure(enum WarpRandoTestFailure failure);
#endif

#endif // GUARD_WARP_RANDO_RUNTIME_H
