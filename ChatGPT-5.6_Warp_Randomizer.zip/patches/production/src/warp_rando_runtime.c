#include "global.h"
#include "config/warp_rando.h"
#include "warp_rando_runtime.h"
#include <string.h>

#if OW_WARP_RANDO_NEW_GAME

STATIC_ASSERT(OW_WARP_RANDO_SAVE_BYTES == WR_IDENTITY_SAVE_BYTES,
              WarpRandoSaveSizeMismatch);

#include "bg.h"
#include "gpu_regs.h"
#include "malloc.h"
#include "menu.h"
#include "palette.h"
#include "sound.h"
#include "sprite.h"
#include "task.h"
#include "text.h"
#include "text_window.h"
#include "window.h"
#include "constants/rgb.h"
#include "constants/songs.h"
#include "warp_reference_graph.h"
#include "warp_rando_source_routes.h"

// These are staged as .inc files so the exact C9C/C10B static helpers remain
// in one translation unit, as in the measured C10D target harness.
#include "warp_rando_core.inc.c"
#include "c9c_candidate_core.inc"
#include "warp_reference_c9c_event_index.h"
#include "c10b_candidate_core.inc"
#include "c10c_scheduler_core.inc"

#define WARP_RANDO_BAR_WIDTH 200
#define WARP_RANDO_TERMINAL_FRAMES 60
#define WARP_RANDO_STACK_PATTERN 0xA5
#define WARP_RANDO_STACK_GUARD 64
#define WARP_RANDO_SYSTEM_STACK_TOP ((u8 *)(IWRAM_END - 0x1C0))

enum { WIN_STATUS };

static const struct BgTemplate sBgTemplates[] =
{
    {
        .bg = 0,
        .charBaseIndex = 2,
        .mapBaseIndex = 31,
        .screenSize = 0,
        .paletteMode = 0,
        .priority = 0,
        .baseTile = 0,
    },
};

static const struct WindowTemplate sWindowTemplates[] =
{
    [WIN_STATUS] = {
        .bg = 0,
        .tilemapLeft = 1,
        .tilemapTop = 5,
        .width = 28,
        .height = 10,
        .paletteNum = 14,
        .baseBlock = 20,
    },
    DUMMY_WIN_TEMPLATE
};

static const u8 sTextTitle[] = _("BUILDING RANDOMIZED WORLD");
static const u8 sTextAttempt[] = _("ATTEMPT / LIMIT");
static const u8 sTextCancel[] = _("B: CANCEL");
static const u8 sTextComplete[] = _("WORLD READY");
static const u8 sTextCancelled[] = _("GENERATION CANCELLED");
static const u8 sTextFailed[] = _("GENERATION FAILED");

struct WarpRandoClock
{
    u16 base;
};

struct WarpRandoScreen
{
    struct C10cJob job;
    struct C10cView pendingView;
    struct C9cStats stats;
    struct C9cWork *work;
    MainCallback completion;
    MainCallback abort;
    struct WarpRandoRuntimeMetrics metrics;
    struct WrIdentity identity;
    u16 lastProgress;
    u16 renderedProgress;
    u16 terminalFrames;
    u16 vblankEntry;
    u16 expectedAttempt;
    u8 lastAttempt;
    u8 taskId;
    bool8 restoring;
    bool8 jobDone;
    bool8 renderPending;
    bool8 terminalDrawn;
    bool8 vblankSeen;
    bool8 initialized;
};

struct WarpRandoStackCanary
{
    u8 *start;
    u8 *end;
    bool8 initialized;
};

extern u8 __iwram_bss_end[];

EWRAM_DATA static struct WrActive sActive = {0};
EWRAM_DATA static struct WarpRandoScreen sScreen = {0};
EWRAM_DATA static struct WarpRandoStackCanary sStackCanary = {0};
EWRAM_DATA static bool8 sReferenceApproved = FALSE;
#ifdef TESTING
EWRAM_DATA static enum WarpRandoTestFailure sForcedFailure = WARP_RANDO_TEST_FAIL_NONE;
#endif

static void Timer3Start(void)
{
    REG_TM3CNT_H = 0;
    REG_TM3CNT_L = 0;
    REG_TM3CNT_H = TIMER_ENABLE | TIMER_64CLK;
}

static u16 Timer3Read(void)
{
    return REG_TM3CNT_L;
}

static void Timer3Stop(void)
{
    REG_TM3CNT_H = 0;
    REG_TM3CNT_L = 0;
}

static u32 Elapsed(void *context)
{
    const struct WarpRandoClock *clock = context;
    return (u16)(Timer3Read() - clock->base);
}

static void Invalidate(void *context)
{
    struct WarpRandoScreen *screen = context;
    wr_invalidate(&sActive);
    screen->metrics.invalidations++;
}

static int Publish(void *context, const struct C10bSession *session)
{
    struct WarpRandoScreen *screen = context;
#ifdef TESTING
    if (sForcedFailure == WARP_RANDO_TEST_FAIL_PUBLISH)
        return WR_BAD_DATA;
#endif
    if (session->seed != screen->identity.seed
     || (screen->restoring
      && session->successful_attempt != screen->expectedAttempt))
        return WR_BAD_IDENTITY;
    memcpy(sActive.records, session->work->candidate,
           session->count * sizeof(*session->work->candidate));
    sActive.identity = screen->identity;
    sActive.count = session->count;
    sActive.attempt = session->successful_attempt;
    sActive.valid = TRUE;
    screen->metrics.publishes++;
    return WR_OK;
}

static void Release(void *context, struct C9cWork *work)
{
    struct WarpRandoScreen *screen = context;
    if (work != NULL)
        Free(work);
    screen->work = NULL;
    screen->metrics.releases++;
}

static void VBlankCB_WarpRando(void)
{
    // Timer 3 is armed at the end of each main callback. Subtracting this
    // entry stamp excludes idle time before VBlank while retaining the
    // engine's common DMA/audio tail through the next main callback.
    sScreen.vblankEntry = Timer3Read();
    sScreen.vblankSeen = TRUE;
    LoadOam();
    ProcessSpriteCopyRequests();
    TransferPlttBuffer();
}

static void DrawStatus(const struct C10cView *view)
{
    u16 filled = (u32)view->progress * WARP_RANDO_BAR_WIDTH / C10C_PROGRESS_MAX;
    u16 pulse = (sScreen.metrics.frames / 60u) % 25u;

    FillWindowPixelRect(WIN_STATUS, PIXEL_FILL(1), 8, 27, WARP_RANDO_BAR_WIDTH, 9);
    FillWindowPixelRect(WIN_STATUS, PIXEL_FILL(4), 8, 27, filled, 9);
    if (view->progress < C10C_PROGRESS_MAX && pulse * 8u >= filled)
        FillWindowPixelRect(WIN_STATUS, PIXEL_FILL(3), 8 + pulse * 8u, 27, 6, 9);
    CopyWindowRectToVram(WIN_STATUS, COPYWIN_GFX, 1, 3, 25, 2);
    if (view->attempt != sScreen.lastAttempt)
    {
        u8 i;
        FillWindowPixelRect(WIN_STATUS, PIXEL_FILL(1), 8, 54, WARP_RANDO_BAR_WIDTH, 10);
        for (i = 0; i < view->retries; i++)
            FillWindowPixelRect(WIN_STATUS,
                                PIXEL_FILL(i + 1 == view->attempt ? 4 : 2),
                                8 + i * 14, 55, 10, 8);
        CopyWindowRectToVram(WIN_STATUS, COPYWIN_GFX, 1, 6, 25, 2);
    }
    sScreen.renderedProgress = view->progress;
    sScreen.lastAttempt = view->attempt;
    sScreen.metrics.renderUpdates++;
}

static void DrawTerminal(int result)
{
    const u8 *text = result == WR_OK ? sTextComplete
                   : result == C10B_CANCELLED ? sTextCancelled : sTextFailed;
    FillWindowPixelRect(WIN_STATUS, PIXEL_FILL(1), 8, 66, WARP_RANDO_BAR_WIDTH, 12);
    AddTextPrinterParameterized(WIN_STATUS, FONT_SMALL, text,
                                8, 66, TEXT_SKIP_DRAW, NULL);
    CopyWindowRectToVram(WIN_STATUS, COPYWIN_GFX, 1, 8, 25, 2);
    sScreen.metrics.terminalRenders++;
}

static bool8 InitGraphics(void)
{
    SetVBlankCallback(NULL);
    SetGpuReg(REG_OFFSET_DISPCNT, 0);
    DmaFill16(3, 0, VRAM, VRAM_SIZE);
    DmaFill32(3, 0, OAM, OAM_SIZE);
    DmaFill16(3, 0, PLTT, PLTT_SIZE);
    ResetSpriteData();
    ResetPaletteFade();
    ResetBgsAndClearDma3BusyFlags(0);
    InitBgsFromTemplates(0, sBgTemplates, ARRAY_COUNT(sBgTemplates));
    if (!InitWindows(sWindowTemplates))
        return FALSE;
    DeactivateAllTextPrinters();
    FillBgTilemapBufferRect_Palette0(0, 0, 0, 0,
                                     DISPLAY_TILE_WIDTH, DISPLAY_TILE_HEIGHT);
    LoadUserWindowBorderGfx(0, 1, BG_PLTT_ID(13));
    Menu_LoadStdPalAt(BG_PLTT_ID(14));
    FillWindowPixelBuffer(WIN_STATUS, PIXEL_FILL(1));
    DrawStdFrameWithCustomTileAndPalette(WIN_STATUS, FALSE, 1, 13);
    AddTextPrinterParameterized(WIN_STATUS, FONT_SMALL, sTextTitle,
                                8, 5, TEXT_SKIP_DRAW, NULL);
    AddTextPrinterParameterized(WIN_STATUS, FONT_SMALL, sTextAttempt,
                                8, 42, TEXT_SKIP_DRAW, NULL);
    AddTextPrinterParameterized(WIN_STATUS, FONT_SMALL, sTextCancel,
                                8, 66, TEXT_SKIP_DRAW, NULL);
    PutWindowTilemap(WIN_STATUS);
    CopyWindowToVram(WIN_STATUS, COPYWIN_FULL);
    SetBackdropFromColor(RGB_BLACK);
    SetGpuReg(REG_OFFSET_DISPCNT,
              DISPCNT_MODE_0 | DISPCNT_OBJ_1D_MAP | DISPCNT_BG0_ON);
    SetGpuReg(REG_OFFSET_BLDCNT, 0);
    ShowBg(0);
    SetVBlankCallback(VBlankCB_WarpRando);
    return TRUE;
}

static void Task_Generate(u8 taskId)
{
    struct WarpRandoClock clock;
    u32 ticks;

    clock.base = Timer3Read();
    sScreen.metrics.result = c10c_pump(&sScreen.job, Elapsed, &clock);
    ticks = (u16)(Timer3Read() - clock.base);
    sScreen.metrics.callbacks++;
    if (ticks > sScreen.metrics.maxCallbackTicks)
        sScreen.metrics.maxCallbackTicks = ticks;
    if (sScreen.metrics.result != C10B_PENDING)
    {
        sScreen.jobDone = TRUE;
        DestroyTask(taskId);
    }
}

static void FinishScreen(void)
{
    MainCallback next = sScreen.metrics.result == WR_OK
                      ? sScreen.completion : sScreen.abort;

    DebugPrintf("WRC10ERUNTIME result=%d frames=%d callbacks=%d callback_max=%d main_max=%d active_max=%d deadline=%d publishes=%d releases=%d valid=%d algorithm=%d stack_high_water=%d stack_margin=%d",
                sScreen.metrics.result, (s32)sScreen.metrics.frames,
                (s32)sScreen.metrics.callbacks,
                (s32)sScreen.metrics.maxCallbackTicks,
                (s32)sScreen.metrics.maxMainTicks,
                (s32)sScreen.metrics.maxActiveTicks,
                (s32)sScreen.metrics.deadlineMisses,
                (s32)sScreen.metrics.publishes,
                (s32)sScreen.metrics.releases,
                sActive.valid, (s32)sActive.identity.algorithm,
                (s32)WarpRando_GetStackHighWater(),
                (s32)WarpRando_GetStackMargin());

    Timer3Stop();
    ResetTasks();
    SetVBlankCallback(NULL);
    FreeAllWindowBuffers();
    HideBg(0);
    SetGpuReg(REG_OFFSET_DISPCNT, 0);
    sScreen.initialized = FALSE;
    SetMainCallback2(next);
}

static void CB2_WarpRando(void)
{
    struct C10cView view;
    u32 before = gMain.vblankCounter1;
    u32 vblankTicks = 0;
    u32 mainTicks;

    if (sScreen.vblankSeen)
    {
        vblankTicks = (u16)(Timer3Read() - sScreen.vblankEntry);
        if (vblankTicks > sScreen.metrics.maxVBlankToMainTicks)
            sScreen.metrics.maxVBlankToMainTicks = vblankTicks;
    }
    Timer3Stop();
    Timer3Start();

    if (!sScreen.jobDone && JOY_NEW(B_BUTTON))
        c10c_request_cancel(&sScreen.job);
    if (sScreen.jobDone)
    {
        if (!sScreen.terminalDrawn)
        {
            DrawTerminal(sScreen.metrics.result);
            sScreen.terminalDrawn = TRUE;
        }
        else if (++sScreen.terminalFrames >= WARP_RANDO_TERMINAL_FRAMES)
        {
            Timer3Stop();
            FinishScreen();
            return;
        }
    }
    else if (sScreen.renderPending)
    {
        DrawStatus(&sScreen.pendingView);
        sScreen.renderPending = FALSE;
    }
    else
    {
        RunTasks();
        c10c_snapshot(&sScreen.job, &view);
        if (view.progress < sScreen.lastProgress)
            sScreen.metrics.progressRegressions++;
        sScreen.lastProgress = view.progress;
        if (view.progress >= sScreen.renderedProgress + 10
         || view.attempt != sScreen.lastAttempt
         || (sScreen.metrics.frames % 60) == 0
         || sScreen.metrics.frames == 0)
        {
            sScreen.pendingView = view;
            sScreen.renderPending = TRUE;
        }
    }
    if ((sScreen.metrics.frames % 180) == 0)
    {
        PlaySE(SE_SELECT);
        sScreen.metrics.audioRequests++;
    }
    AnimateSprites();
    BuildOamBuffer();
    RunTextPrinters();
    UpdatePaletteFade();

    mainTicks = Timer3Read();
    Timer3Stop();
    if (mainTicks > sScreen.metrics.maxMainTicks)
        sScreen.metrics.maxMainTicks = mainTicks;
    if (mainTicks + vblankTicks > sScreen.metrics.maxActiveTicks)
        sScreen.metrics.maxActiveTicks = mainTicks + vblankTicks;
    if (gMain.vblankCounter1 != before)
    {
        sScreen.metrics.deadlineMisses++;
        sScreen.vblankSeen = FALSE;
    }
    sScreen.metrics.frames++;
    Timer3Start();
}

bool8 WarpRando_ApproveReference(void)
{
    sReferenceApproved = c9c_validate_reference(&wr_graph, &c9c_index) == WR_OK;
    return sReferenceApproved;
}

bool8 WarpRando_IsReferenceApproved(void)
{
    return sReferenceApproved;
}

static bool8 Start(const struct WrIdentity *identity, bool8 restoring,
                   u16 expectedAttempt, MainCallback completion,
                   MainCallback abort)
{
    struct C10cHooks hooks;

    if (identity == NULL || completion == NULL || abort == NULL
     || sScreen.initialized)
        return FALSE;
    memset(&sScreen, 0, sizeof(sScreen));
    sScreen.identity = *identity;
    sScreen.restoring = restoring;
    sScreen.expectedAttempt = expectedAttempt;
    sScreen.completion = completion;
    sScreen.abort = abort;
    sScreen.lastAttempt = 0xFF;
    sScreen.renderPending = TRUE;
    sScreen.metrics.result = C10B_PENDING;
    ResetTasks();
    if (!InitGraphics())
    {
        Invalidate(&sScreen);
        FreeAllWindowBuffers();
        return FALSE;
    }
    sScreen.initialized = TRUE;
    Timer3Start();
    if (!sReferenceApproved)
    {
        Invalidate(&sScreen);
        sScreen.metrics.result = WR_BAD_DATA;
        sScreen.jobDone = TRUE;
        SetMainCallback2(CB2_WarpRando);
        return TRUE;
    }
#ifdef TESTING
    if (sForcedFailure != WARP_RANDO_TEST_FAIL_WORK_ALLOC)
#endif
        sScreen.work = AllocZeroedUnchecked(sizeof(*sScreen.work));
    if (sScreen.work == NULL)
    {
        Invalidate(&sScreen);
        sScreen.metrics.result = WR_BAD_DATA;
        sScreen.jobDone = TRUE;
        SetMainCallback2(CB2_WarpRando);
        return TRUE;
    }
    hooks.invalidate = Invalidate;
    hooks.publish = Publish;
    hooks.release = Release;
    hooks.context = &sScreen;
    sScreen.metrics.result = c10c_begin_prevalidated(&sScreen.job,
        &wr_graph, &c9c_index, identity->seed, 3, 8,
        WARP_RANDO_BUDGET_TICKS,
        sScreen.work, &sScreen.stats, &hooks);
    if (sScreen.metrics.result != C10B_PENDING)
    {
        sScreen.jobDone = TRUE;
        SetMainCallback2(CB2_WarpRando);
        return TRUE;
    }
    c10c_snapshot(&sScreen.job, &sScreen.pendingView);
    sScreen.taskId = CreateTask(Task_Generate, 0);
    if (sScreen.taskId == TASK_NONE)
    {
        sScreen.metrics.result = c10c_cancel(&sScreen.job);
        sScreen.jobDone = TRUE;
    }
    SetMainCallback2(CB2_WarpRando);
    return TRUE;
}

bool8 WarpRando_StartNewGame(u32 seed, MainCallback completion, MainCallback abort)
{
    struct WrIdentity identity;

    memset(&identity, 0, sizeof(identity));
    identity.seed = seed;
    identity.algorithm = WARP_RANDO_ALGORITHM;
    identity.ruleset = WARP_RANDO_RULESET;
    memcpy(identity.data, wr_graph.fingerprint, sizeof(identity.data));
    return Start(&identity, FALSE, 0, completion, abort);
}

bool8 WarpRando_StartContinue(const u8 save[WR_IDENTITY_SAVE_BYTES],
                              MainCallback completion, MainCallback abort)
{
    struct WrIdentity identity;
    u16 attempt;

    if (sScreen.initialized)
        return FALSE;
    if (wr_identity_save_decode(save, WARP_RANDO_ALGORITHM,
                                WARP_RANDO_RULESET, wr_graph.fingerprint,
                                &identity, &attempt) != WR_OK)
    {
        wr_invalidate(&sActive);
        return FALSE;
    }
    return Start(&identity, TRUE, attempt, completion, abort);
}

bool8 WarpRando_WriteSave(u8 save[WR_IDENTITY_SAVE_BYTES])
{
    return wr_identity_save_encode(&sActive, save) == WR_OK;
}

bool8 WarpRando_IsGenerationActive(void)
{
    return sScreen.initialized;
}

const struct WrActive *WarpRando_GetActive(void)
{
    return &sActive;
}

void WarpRando_GetMetrics(struct WarpRandoRuntimeMetrics *out)
{
    if (out == NULL)
        return;
    *out = sScreen.metrics;
    out->steps = sScreen.job.generation.steps;
    out->partnerTrials = sScreen.stats.partner_trials;
    out->progress = sScreen.job.progress;
    out->successfulAttempt = sScreen.job.generation.successful_attempt;
}

bool8 WarpRando_ResolveWarp(s8 sourceGroup, s8 sourceMap, s8 sourceWarp,
                           u16 x, u16 y, u8 elevation,
                           s8 *mapGroup, s8 *mapNum, s8 *warpId)
{
    struct WrKey requested;
    struct WrKey source;
    int result;

    if (mapGroup == NULL || mapNum == NULL || warpId == NULL
     || *mapGroup < 0 || *mapNum < 0 || *warpId < 0
     || sourceGroup < 0 || sourceMap < 0 || sourceWarp < 0)
        return FALSE;
    source.group = sourceGroup;
    source.map = sourceMap;
    source.warp = sourceWarp;
    requested.group = (u8)*mapGroup;
    requested.map = (u8)*mapNum;
    requested.warp = (u8)*warpId;
    if (!wr_source_normalize(gWarpRandoSourceRoutes, WARP_RANDO_SOURCE_ROUTE_COUNT,
                             &source, &requested, x, y, elevation, &requested))
        return FALSE;
    result = wr_lookup(&sActive, &sActive.identity, &requested);
    if (result != 1)
        return FALSE;
    *mapGroup = (s8)requested.group;
    *mapNum = (s8)requested.map;
    *warpId = (s8)requested.warp;
    return TRUE;
}

__attribute__((noinline)) void WarpRando_InitStackCanary(void)
{
    volatile u8 *cursor;
    u8 *frame = __builtin_frame_address(0);
    u8 *end = frame - WARP_RANDO_STACK_GUARD;

    sStackCanary.start = __iwram_bss_end;
    sStackCanary.end = end;
    sStackCanary.initialized = FALSE;
    if (sStackCanary.start >= end || end > WARP_RANDO_SYSTEM_STACK_TOP)
        return;
    for (cursor = sStackCanary.start; cursor < end; cursor++)
        *cursor = WARP_RANDO_STACK_PATTERN;
    sStackCanary.initialized = TRUE;
}

static u8 *StackLowWater(void)
{
    volatile u8 *cursor;
    if (!sStackCanary.initialized)
        return WARP_RANDO_SYSTEM_STACK_TOP;
    for (cursor = sStackCanary.start; cursor < sStackCanary.end; cursor++)
        if (*cursor != WARP_RANDO_STACK_PATTERN)
            return (u8 *)cursor;
    return sStackCanary.end;
}

u32 WarpRando_GetStackHighWater(void)
{
    return WARP_RANDO_SYSTEM_STACK_TOP - StackLowWater();
}

u32 WarpRando_GetStackMargin(void)
{
    return StackLowWater() - sStackCanary.start;
}

#ifdef TESTING
void WarpRando_TestReset(void)
{
    if (sScreen.initialized)
    {
        if (!sScreen.job.finalized && sScreen.work != NULL)
            c10c_cancel(&sScreen.job);
        FinishScreen();
    }
    memset(&sScreen, 0, sizeof(sScreen));
    memset(&sActive, 0, sizeof(sActive));
    sForcedFailure = WARP_RANDO_TEST_FAIL_NONE;
}

void WarpRando_TestForceFailure(enum WarpRandoTestFailure failure)
{
    sForcedFailure = failure;
}
#endif

#else // OW_WARP_RANDO_NEW_GAME

bool8 WarpRando_ApproveReference(void) { return FALSE; }
bool8 WarpRando_IsReferenceApproved(void) { return FALSE; }
bool8 WarpRando_StartNewGame(u32 seed, MainCallback completion, MainCallback abort)
{
    (void)seed;
    (void)completion;
    (void)abort;
    return FALSE;
}
bool8 WarpRando_StartContinue(const u8 save[WR_IDENTITY_SAVE_BYTES],
                              MainCallback completion, MainCallback abort)
{
    (void)save;
    (void)completion;
    (void)abort;
    return FALSE;
}
bool8 WarpRando_WriteSave(u8 save[WR_IDENTITY_SAVE_BYTES])
{
    (void)save;
    return FALSE;
}
bool8 WarpRando_IsGenerationActive(void) { return FALSE; }
const struct WrActive *WarpRando_GetActive(void) { return NULL; }
void WarpRando_GetMetrics(struct WarpRandoRuntimeMetrics *out)
{
    if (out != NULL)
        memset(out, 0, sizeof(*out));
}
bool8 WarpRando_ResolveWarp(s8 sourceGroup, s8 sourceMap, s8 sourceWarp,
                           u16 x, u16 y, u8 elevation,
                           s8 *mapGroup, s8 *mapNum, s8 *warpId)
{
    (void)sourceGroup;
    (void)sourceMap;
    (void)sourceWarp;
    (void)x;
    (void)y;
    (void)elevation;
    (void)mapGroup;
    (void)mapNum;
    (void)warpId;
    return FALSE;
}
void WarpRando_InitStackCanary(void) {}
u32 WarpRando_GetStackHighWater(void) { return 0; }
u32 WarpRando_GetStackMargin(void) { return 0; }
#ifdef TESTING
void WarpRando_TestReset(void) {}
void WarpRando_TestForceFailure(enum WarpRandoTestFailure failure) { (void)failure; }
#endif

#endif // OW_WARP_RANDO_NEW_GAME
