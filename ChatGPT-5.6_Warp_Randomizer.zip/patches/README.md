# Fixed-table expansion 1.17.0 integration proof

Status: normal ROM builds and ten base ARM engine tests per mode pass against
`e8bd1cd7b03fc032ea37e3ecd38b379b5d01a1e7`, with the proof enabled and disabled.
The host stub tests also pass. Actual flash save/load and collision checks run
in headless mGBA. Interactive movement, complete restart/Continue and hardware
remain unverified. The later C11A suite passes 13/13 in both modes and adds
versioned save restoration plus ordinary static-warp interception. See
engine-tests/README.md for executable reproduction.

## Current C11B source-aware extension

Apply `c11b-production.patch` after the proof, C10E and C11A patches below.
The current `--c11b-probe` (also `--c11a-probe` for compatibility) stages the
consolidated 14-test save/restore/source-gate suite. It additionally copies
`include/warp_rando_source.h`, `src/warp_rando_source.c`, and
`data/target-source-routes.h` (as target `include/warp_rando_source_routes.h`).
It verifies the generated table against the pinned target before building.
The current runtime uses Algorithm 5/ruleset 2; old ruleset-1 saves are rejected.
Use `tools/audit/build_runtime_interactive.py` and the C11B graphical checklist
for an experimental normal ROM. Historical C10E/C11A probes are not frozen
reproduction environments; use their earlier snapshots for exact reproduction.

## C10E opt-in production new-game wrapper

`c10e-production.patch` is a separate, disabled-by-default integration patch.
Apply it after `expansion-1.17.0-proof.patch`, then copy
`production/include/config/warp_rando.h`,
`production/include/warp_rando_runtime.h` and
`production/src/warp_rando_runtime.c` into the matching target paths. The ARM
probe stages the exact generated C9C index/core inputs automatically.

With `OW_WARP_RANDO_NEW_GAME` false, new game takes the original direct path
and no active table is linked. With it true, boot approves immutable data and
`CB2_NewGame` runs the asynchronous screen; only success resumes the original
new-game body. Cancellation or failure returns to title without silently
starting an unrandomized topology. In the historical C10E checkpoint the active
table was not yet wired to warp resolution or SaveBlock persistence. See
`docs/c10e-production-checkpoint.md` and `docs/c10e-mgba-manual-test.md`.

## C11A save/restore and ordinary-event integration

Apply `c11a-production.patch` after C10E. In addition to the C10E files, copy:

- `include/warp_rando.h` to target `include/warp_rando.h`
- `include/warp_rando_identity.h` to target `include/warp_rando_identity.h`
- `src/warp_rando_identity.c` to target `src/warp_rando_identity.c`
- `data/target-expansion-1.17.0-map-counts.h` to target
  `include/warp_rando_target_map_counts.h`

The C11A probe stages those plus the exact reference graph/index and C9C/C10B/
C10C implementation inputs automatically. `OW_WARP_RANDO_NEW_GAME` still
defaults false. When enabled, C11A appends a 64-byte SaveBlock3 identity,
assigns Algorithm 5/ruleset 1, reconstructs the active table asynchronously on
Continue, and intercepts only ordinary static event warps. It validates mapped
group/map/warp bounds before dereference and fails closed to title on missing,
corrupt or incompatible metadata. This is not a target-approved playable
randomizer dataset; see `docs/c11a-save-restore-checkpoint.md`.

From the handoff directory, after fetching sources as described in README:

```sh
python3 tools/audit/make_proof_patch.py ../sources/target build/proof.patch
cmp patches/expansion-1.17.0-proof.patch build/proof.patch
git -C ../sources/target apply --check "$PWD/patches/expansion-1.17.0-proof.patch"
git -C ../sources/target apply "$PWD/patches/expansion-1.17.0-proof.patch"
```

Follow the pinned target's INSTALL.md, or use the local checksum-pinned
bootstrap in engine-tests/README.md, to prepare the toolchain. Set
WR_PROOF_ENABLED to 1 in the **target** include/warp_rando_proof.h; then build
using the target's documented command. It defaults to zero. The target Makefile
already discovers new src/*.c files. No JSON generation is required for this
fixed mapping. Do not copy the reference graph/core into the target as though
that were a finished integration.

## Expected observable cases

Target map order establishes Oldale=(0,10), House1=(2,0), House2=(2,1).
The experiment pairs outside House1 with inside House2, and outside House2 with
inside House1. Both indoor exit tiles are aliases.

| Source event(s) | Requested destination | Expected landing |
|---|---|---|
| Oldale warp 0 | 2,0,0 | 2,1,0 (House2), then experimental coordinates (3,6) |
| House2 warps 0 and 1 | 0,10,1 | 0,10,0 (outside House1) |
| Oldale warp 1 | 2,1,0 | 2,0,0 (House1), default warp-event coordinates |
| House1 warps 0 and 1 | 0,10,0 | 0,10,1 (outside House2) |
| Oldale center/mart | Original | Original |
| Different source requesting a listed destination | Listed triple | Original; source-context gate rejects it |

Walk both round trips and both aliases. Observe (3,6) for House2 and confirm it
is walkable and does not retrigger a warp. Headless target checks confirm (3,6) is passable and outside warp events;
its behavior through full door animations is still unobserved. Save inside, restart and exit; the fixed
table is constant. Flash save/load is tested, but a full emulator restart and
Continue callback remain open.
Build disabled and confirm ordinary behavior; no byte-identical ROM claim.

## Hook coverage and follow-up state

`SetupWarp` knows the actual event and requested destination. The patch calls
WrProof_Resolve there only for ordinary non-Trainer-Hill, non-dynamic events.
The rewritten triple is used for SetWarpDestinationToMapWarp, UpdateEscapeWarp's
pending destination, and the redirected destination-header inspection.
The original non-proof branch is retained, including its existing use of
warpEventId in a destination array access; that preexisting code deserves a
separate upstream review and is not silently changed for every game here.

Queued correction is applied immediately **after SetPlayerCoordsFromWarp in
WarpIntoMap**, so coordinate initialization cannot overwrite it. It clears on
consumption, mismatch, new game, Continue, ordinary destination setup and the
listed dynamic/escape/whiteout/Teleport/Dive/fall bypass setters. Script setters
are not remapped by this proof. Loading a save does not reapply a pending fix.

| Path | Proof behavior / outstanding audit |
|---|---|
| Ordinary eligible event | Redirected using source context plus requested triple |
| Grouped indoor exit | Both event indices accepted with same requested trigger |
| Ambiguous shared trigger from another source | Left unchanged; no numeric proxy synthesis |
| Script warp/coordinate warp | Fixed/original, no source-event lookup |
| MAP_DYNAMIC and Trainer Hill | Excluded from experiment |
| Dive, fall, Dig/Rope, Teleport, whiteout | Original travel; pending correction reset in common bypass setters |
| Continue/restart | Original saved destination; correction cleared; fixed table needs no seed save |
| Map connections and exceptional direct assignments | No remapping; full engine coverage unverified |

The broader runtime will need audited normalization for scripts and ambiguous
reference proxy tokens, real arrival corrections, game-state repairs and save
integration. A small proof makes those obligations observable; it does not
claim that one central hook safely covers every transition.
