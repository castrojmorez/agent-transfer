#include "global.h"
#include "test/test.h"
#include "test_runner.h"
#include "constants/maps.h"
#include "fieldmap.h"
#include "load_save.h"
#include "main.h"
#include "malloc.h"
#include "overworld.h"
#include "save.h"
#include "warp_rando_runtime.h"
#include "warp_rando_target_map_counts.h"
#include "warp_reference_graph.h"
#include "warp_rando_source_routes.h"

struct HeapStats
{
    u32 freeBytes;
    u32 largestFree;
};

struct RunResult
{
    struct WarpRandoRuntimeMetrics metrics;
    struct HeapStats before;
    struct HeapStats after;
    u32 digest;
    u32 frames;
    u8 completionCalls;
    u8 abortCalls;
    u8 activeValid;
    u32 activeAlgorithm;
    u16 activeAttempt;
};

static u8 sCompletionCalls;
static u8 sAbortCalls;
static MainCallback sReturnCallback;
EWRAM_DATA static struct WrActive sEnvelopeSource = {0};

void WrProof_TestSetupWarp(s8 warpId, struct MapPosition *position);

static struct HeapStats MeasureHeap(void)
{
    struct HeapStats result = {0};
    const struct MemBlock *head = HeapHead();
    const struct MemBlock *block = head;
    do
    {
        if (!block->allocated)
        {
            result.freeBytes += block->size;
            if (block->size > result.largestFree)
                result.largestFree = block->size;
        }
        block = block->next;
    } while (block != head);
    return result;
}

static u32 HashActive(const struct WrActive *active)
{
    u32 hash = 2166136261u;
    u16 i;
    u8 bytes[6];
    u8 j;
    for (i = 0; i < active->count; i++)
    {
        bytes[0] = active->records[i].trigger.group;
        bytes[1] = active->records[i].trigger.map;
        bytes[2] = active->records[i].trigger.warp;
        bytes[3] = active->records[i].landing.group;
        bytes[4] = active->records[i].landing.map;
        bytes[5] = active->records[i].landing.warp;
        for (j = 0; j < ARRAY_COUNT(bytes); j++)
            hash = (hash ^ bytes[j]) * 16777619u;
    }
    return hash;
}

static void Completion(void)
{
    sCompletionCalls++;
    SetMainCallback2(sReturnCallback);
}

static void Abort(void)
{
    sAbortCalls++;
    SetMainCallback2(sReturnCallback);
}

static struct RunResult FinishRun(void)
{
    struct RunResult result = {0};
    const struct WrActive *active;
    u32 guard = 0;

    while (WarpRando_IsGenerationActive() && guard++ < 16000)
    {
        VBlankIntrWait();
        gMain.newKeys = 0;
        gMain.callback2();
    }
    EXPECT(guard < 16000);
    if (gMain.callback2 != NULL)
        gMain.callback2();
    WarpRando_GetMetrics(&result.metrics);
    active = WarpRando_GetActive();
    result.digest = HashActive(active);
    result.activeValid = active->valid;
    result.activeAlgorithm = active->identity.algorithm;
    result.activeAttempt = active->attempt;
    result.completionCalls = sCompletionCalls;
    result.abortCalls = sAbortCalls;
    result.frames = guard;
    result.after = MeasureHeap();
    return result;
}

static void BeginRun(void)
{
    sCompletionCalls = 0;
    sAbortCalls = 0;
    sReturnCallback = gMain.callback2;
}

static struct RunResult RunNew(u32 seed)
{
    struct RunResult result;
    WarpRando_TestReset();
    if (!WarpRando_IsReferenceApproved())
        EXPECT(WarpRando_ApproveReference());
    BeginRun();
    result.before = MeasureHeap();
    EXPECT(WarpRando_StartNewGame(seed, Completion, Abort));
    {
        struct RunResult finished = FinishRun();
        finished.before = result.before;
        return finished;
    }
}

static struct RunResult RunContinue(const u8 save[WR_IDENTITY_SAVE_BYTES])
{
    struct RunResult result;
    BeginRun();
    result.before = MeasureHeap();
    EXPECT(WarpRando_StartContinue(save, Completion, Abort));
    {
        struct RunResult finished = FinishRun();
        finished.before = result.before;
        return finished;
    }
}

static u32 Crc32(const u8 *data, u32 size)
{
    u32 crc = UINT32_MAX;
    u32 i;
    u8 bit;
    for (i = 0; i < size; i++)
    {
        crc ^= data[i];
        for (bit = 0; bit < 8; bit++)
            crc = (crc >> 1) ^ (0xedb88320u & (0u - (crc & 1u)));
    }
    return ~crc;
}

static void FixCrc(u8 save[WR_IDENTITY_SAVE_BYTES])
{
    u32 crc = Crc32(save, 60);
    save[60] = (u8)crc;
    save[61] = (u8)(crc >> 8);
    save[62] = (u8)(crc >> 16);
    save[63] = (u8)(crc >> 24);
}

static bool8 ExerciseEngineInterception(void)
{
    const struct WrActive *active = WarpRando_GetActive();
    u16 record;
    u8 group;
    u8 map;

    for (record = 0; record < active->count; record++)
    {
        const struct WrRecord *row = &active->records[record];
        if (row->landing.group >= MAP_GROUPS_COUNT
         || row->landing.map >= gWarpRandoTargetMapCounts[row->landing.group])
            continue;
        {
            const struct MapHeader *landing = Overworld_GetMapHeaderByGroupAndId(
                row->landing.group, row->landing.map);
            if (row->landing.warp >= landing->events->warpCount)
                continue;
        }
        for (group = 0; group < MAP_GROUPS_COUNT; group++)
        {
            for (map = 0; map < gWarpRandoTargetMapCounts[group]; map++)
            {
                const struct MapHeader *source =
                    Overworld_GetMapHeaderByGroupAndId(group, map);
                u8 warp;
                if ((group == 0 && map == 10)
                 || (group == 2 && (map == 0 || map == 1)))
                    continue;
                for (warp = 0; warp < source->events->warpCount; warp++)
                {
                    const struct WarpEvent *event = &source->events->warps[warp];
                    struct MapPosition position;
                    s8 checkGroup = event->mapGroup;
                    s8 checkMap = event->mapNum;
                    s8 checkWarp = event->warpId;
                    if (event->mapGroup != row->trigger.group
                     || event->mapNum != row->trigger.map
                     || event->warpId != row->trigger.warp
                     || event->mapNum == MAP_NUM(MAP_DYNAMIC))
                        continue;
                    if (!WarpRando_ResolveWarp(group, map, warp,
                            event->x, event->y, event->elevation,
                            &checkGroup, &checkMap, &checkWarp))
                        continue;
                    gSaveBlock1Ptr->location.mapGroup = group;
                    gSaveBlock1Ptr->location.mapNum = map;
                    gSaveBlock1Ptr->location.warpId = warp;
                    gMapHeader = *source;
                    position.x = event->x + MAP_OFFSET;
                    position.y = event->y + MAP_OFFSET;
                    position.elevation = event->elevation;
                    WrProof_TestSetupWarp(warp, &position);
                    WarpIntoMap();
                    EXPECT_EQ(gSaveBlock1Ptr->location.mapGroup,
                              row->landing.group);
                    EXPECT_EQ(gSaveBlock1Ptr->location.mapNum,
                              row->landing.map);
                    EXPECT_EQ(gSaveBlock1Ptr->location.warpId,
                              row->landing.warp);
                    return TRUE;
                }
            }
        }
    }
    return FALSE;
}

TEST("WarpC11A: versioned flash identity restores deterministic Algorithm 5 table")
{
    struct RunResult generated = RunNew(42);
    struct RunResult restored;
    u8 saved[WR_IDENTITY_SAVE_BYTES];

    EXPECT_EQ(generated.metrics.result, WR_OK);
    EXPECT(generated.activeValid);
    EXPECT_EQ(generated.activeAlgorithm, WARP_RANDO_ALGORITHM);
    EXPECT_EQ(generated.activeAttempt, 1);
    EXPECT_EQ(generated.digest, 0x3d354fa7u);
    EXPECT_EQ(generated.before.freeBytes, generated.after.freeBytes);
    EXPECT_EQ(generated.before.largestFree, generated.after.largestFree);
    EXPECT(WarpRando_WriteSave(saved));
    memcpy(gSaveBlock3Ptr->warpRando, saved, sizeof(saved));

    Save_ResetSaveCounters();
    EXPECT_EQ(TrySavingData(SAVE_NORMAL), SAVE_STATUS_OK);
    memset(gSaveBlock3Ptr->warpRando, 0, sizeof(saved));
    EXPECT_EQ(LoadGameSave(SAVE_NORMAL), SAVE_STATUS_OK);
    EXPECT_EQ(memcmp(gSaveBlock3Ptr->warpRando, saved, sizeof(saved)), 0);

    WarpRando_TestReset();
    EXPECT(!WarpRando_GetActive()->valid);
    restored = RunContinue(gSaveBlock3Ptr->warpRando);
    EXPECT_EQ(restored.metrics.result, WR_OK);
    EXPECT(restored.activeValid);
    EXPECT_EQ(restored.activeAlgorithm, WARP_RANDO_ALGORITHM);
    EXPECT_EQ(restored.activeAttempt, generated.activeAttempt);
    EXPECT_EQ(restored.digest, generated.digest);
    EXPECT_EQ(restored.completionCalls, 1);
    EXPECT_EQ(restored.abortCalls, 0);
    EXPECT_EQ(restored.before.freeBytes, restored.after.freeBytes);
    EXPECT_EQ(restored.before.largestFree, restored.after.largestFree);
    EXPECT(ExerciseEngineInterception());

    Test_MgbaPrintf("WRC11AREST result=%d algorithm=%d attempt=%d digest_decimal=%d frames=%d flash=1 intercept=1 heap_before=%d heap_after=%d",
                    restored.metrics.result, (s32)restored.activeAlgorithm,
                    restored.activeAttempt, (s32)restored.digest,
                    (s32)restored.frames, (s32)restored.before.freeBytes,
                    (s32)restored.after.freeBytes);
}

static void CheckEngineRoute(struct WrKey sourceKey, bool8 allowed)
{
    const struct MapHeader *header = Overworld_GetMapHeaderByGroupAndId(
        sourceKey.group, sourceKey.map);
    const struct WarpEvent *event = &header->events->warps[sourceKey.warp];
    struct MapPosition position;
    s8 group = event->mapGroup, map = event->mapNum, warp = event->warpId;
    EXPECT_EQ(WarpRando_ResolveWarp(sourceKey.group, sourceKey.map, sourceKey.warp,
                event->x, event->y, event->elevation, &group, &map, &warp), allowed);
    gSaveBlock1Ptr->location.mapGroup = sourceKey.group;
    gSaveBlock1Ptr->location.mapNum = sourceKey.map;
    gSaveBlock1Ptr->location.warpId = sourceKey.warp;
    gMapHeader = *header;
    position.x = event->x + MAP_OFFSET;
    position.y = event->y + MAP_OFFSET;
    position.elevation = event->elevation;
    WrProof_TestSetupWarp(sourceKey.warp, &position);
    WarpIntoMap();
    EXPECT_EQ(gSaveBlock1Ptr->location.mapGroup, group);
    EXPECT_EQ(gSaveBlock1Ptr->location.mapNum, map);
    EXPECT_EQ(gSaveBlock1Ptr->location.warpId, warp);
}

TEST("WarpC11B: source signatures normalize five routes and exclude unintended events")
{
    static const struct WrKey denied[] = {{13,8,0}, {13,8,1}, {24,33,2}};
    struct RunResult generated = RunNew(0);
    u16 i, normalized = 0;
    u8 save[WR_IDENTITY_SAVE_BYTES];
    EXPECT_EQ(generated.metrics.result, WR_OK);
    EXPECT_EQ(generated.activeAlgorithm, 5);
    EXPECT_EQ(WARP_RANDO_RULESET, 2);
    for (i = 0; i < WARP_RANDO_SOURCE_ROUTE_COUNT; i++)
    {
        const struct WrSourceRoute *row = &gWarpRandoSourceRoutes[i];
        struct WrKey token = row->expected;
        s8 group = row->expected.group, map = row->expected.map, warp = row->expected.warp;
        EXPECT(wr_source_normalize(gWarpRandoSourceRoutes, WARP_RANDO_SOURCE_ROUTE_COUNT,
            &row->source, &row->expected, row->x, row->y, row->elevation, &token));
        EXPECT_EQ(token.group, row->trigger.group);
        EXPECT_EQ(token.map, row->trigger.map);
        EXPECT_EQ(token.warp, row->trigger.warp);
        EXPECT(!WarpRando_ResolveWarp(row->source.group, row->source.map, row->source.warp,
            row->x ^ 1, row->y, row->elevation, &group, &map, &warp));
        EXPECT_EQ(group, row->expected.group);
        EXPECT_EQ(map, row->expected.map);
        EXPECT_EQ(warp, row->expected.warp);
        if (row->expected.group != token.group || row->expected.map != token.map
         || row->expected.warp != token.warp)
        {
            struct WrKey landing = token;
            const struct WrActive *active = WarpRando_GetActive();
            EXPECT_EQ(wr_lookup(active, &active->identity, &landing), 1);
            EXPECT(WarpRando_ResolveWarp(row->source.group, row->source.map, row->source.warp,
                row->x, row->y, row->elevation, &group, &map, &warp));
            EXPECT_EQ(group, landing.group);
            EXPECT_EQ(map, landing.map);
            EXPECT_EQ(warp, landing.warp);
            CheckEngineRoute(row->source, TRUE);
            normalized++;
        }
    }
    for (i = 0; i < ARRAY_COUNT(denied); i++)
        CheckEngineRoute(denied[i], FALSE);
    EXPECT_EQ(normalized, 5);
    EXPECT(WarpRando_WriteSave(save));
    save[16] = 1; // Previous C11A ruleset, with a valid CRC.
    FixCrc(save);
    EXPECT(!WarpRando_StartContinue(save, Completion, Abort));
    EXPECT(!WarpRando_GetActive()->valid);
    Test_MgbaPrintf("WRC11BSOURCE routes=%d normalized=%d excluded=3 stale=608 ruleset=%d old_save_rejected=1 digest_decimal=%d",
        WARP_RANDO_SOURCE_ROUTE_COUNT, normalized, WARP_RANDO_RULESET, (s32)generated.digest);
}

static void MakeSave(u32 seed, u16 attempt,
                     u8 saved[WR_IDENTITY_SAVE_BYTES])
{
    memset(&sEnvelopeSource, 0, sizeof(sEnvelopeSource));
    sEnvelopeSource.identity.seed = seed;
    sEnvelopeSource.identity.algorithm = WARP_RANDO_ALGORITHM;
    sEnvelopeSource.identity.ruleset = WARP_RANDO_RULESET;
    memcpy(sEnvelopeSource.identity.data, wr_graph.fingerprint,
           sizeof(sEnvelopeSource.identity.data));
    sEnvelopeSource.attempt = attempt;
    sEnvelopeSource.valid = TRUE;
    EXPECT_EQ(wr_identity_save_encode(&sEnvelopeSource, saved), WR_OK);
}

TEST("WarpC11A: reset during generation releases state")
{
    struct HeapStats beforeReset;
    struct HeapStats afterReset;
    u32 frame;

    WarpRando_TestReset();
    if (!WarpRando_IsReferenceApproved())
        EXPECT(WarpRando_ApproveReference());
    BeginRun();
    beforeReset = MeasureHeap();
    EXPECT(WarpRando_StartNewGame(17, Completion, Abort));
    for (frame = 0; frame < 12; frame++)
    {
        VBlankIntrWait();
        gMain.callback2();
    }
    EXPECT(WarpRando_IsGenerationActive());
    WarpRando_TestReset();
    afterReset = MeasureHeap();
    EXPECT(!WarpRando_IsGenerationActive());
    EXPECT(!WarpRando_GetActive()->valid);
    EXPECT_EQ(beforeReset.freeBytes, afterReset.freeBytes);
    EXPECT_EQ(beforeReset.largestFree, afterReset.largestFree);

    Test_MgbaPrintf("WRC11ARESET active=%d heap_before=%d heap_after=%d",
                    WarpRando_GetActive()->valid,
                    (s32)beforeReset.freeBytes, (s32)afterReset.freeBytes);
}

TEST("WarpC11A: incompatible metadata and attempt mismatch fail closed")
{
    struct RunResult mismatch;
    u8 saved[WR_IDENTITY_SAVE_BYTES];
    u8 changed[WR_IDENTITY_SAVE_BYTES];

    WarpRando_TestReset();
    if (!WarpRando_IsReferenceApproved())
        EXPECT(WarpRando_ApproveReference());
    MakeSave(0, 0, saved);

    memcpy(changed, saved, sizeof(changed));
    changed[20] ^= 1;
    EXPECT(!WarpRando_StartContinue(changed, Completion, Abort));
    EXPECT(!WarpRando_GetActive()->valid);

    memcpy(changed, saved, sizeof(changed));
    changed[4]++;
    FixCrc(changed);
    EXPECT(!WarpRando_StartContinue(changed, Completion, Abort));
    memcpy(changed, saved, sizeof(changed));
    changed[16]++;
    FixCrc(changed);
    EXPECT(!WarpRando_StartContinue(changed, Completion, Abort));
    memcpy(changed, saved, sizeof(changed));
    changed[20] ^= 1;
    FixCrc(changed);
    EXPECT(!WarpRando_StartContinue(changed, Completion, Abort));

    MakeSave(0, 1, changed);
    mismatch = RunContinue(changed);
    EXPECT_EQ(mismatch.metrics.result, WR_BAD_IDENTITY);
    EXPECT(!mismatch.activeValid);
    EXPECT_EQ(mismatch.completionCalls, 0);
    EXPECT_EQ(mismatch.abortCalls, 1);
    EXPECT_EQ(mismatch.before.freeBytes, mismatch.after.freeBytes);
    EXPECT_EQ(mismatch.before.largestFree, mismatch.after.largestFree);

    Test_MgbaPrintf("WRC11AFAIL corrupt=1 version=1 ruleset=1 fingerprint=1 attempt_result=%d active=%d heap_before=%d heap_after=%d",
                    mismatch.metrics.result, WarpRando_GetActive()->valid,
                    (s32)mismatch.before.freeBytes,
                    (s32)mismatch.after.freeBytes);
}
