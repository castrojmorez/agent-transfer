#include "global.h"
#include "test/test.h"
#include "test_runner.h"
#include "main.h"
#include "malloc.h"
#include "warp_rando_runtime.h"

struct HeapStats
{
    u32 freeBytes;
    u32 largestFree;
};

struct RunResult
{
    struct WarpRandoRuntimeMetrics metrics;
    struct HeapStats before;
    struct HeapStats after;
    u32 digest;
    u32 outerFrames;
    u8 completionCalls;
    u8 abortCalls;
    u8 activeValid;
    u32 activeAlgorithm;
};

static u8 sCompletionCalls;
static u8 sAbortCalls;
static MainCallback sReturnCallback;

static struct HeapStats MeasureHeap(void)
{
    struct HeapStats result = {0};
    const struct MemBlock *head = HeapHead();
    const struct MemBlock *block = head;

    do
    {
        if (!block->allocated)
        {
            result.freeBytes += block->size;
            if (block->size > result.largestFree)
                result.largestFree = block->size;
        }
        block = block->next;
    } while (block != head);
    return result;
}

static u32 HashByte(u32 hash, u8 value)
{
    return (hash ^ value) * 16777619u;
}

static u32 HashActive(const struct WrActive *active)
{
    u32 hash = 2166136261u;
    u16 i;

    for (i = 0; i < active->count; i++)
    {
        const struct WrRecord *record = &active->records[i];
        hash = HashByte(hash, record->trigger.group);
        hash = HashByte(hash, record->trigger.map);
        hash = HashByte(hash, record->trigger.warp);
        hash = HashByte(hash, record->landing.group);
        hash = HashByte(hash, record->landing.map);
        hash = HashByte(hash, record->landing.warp);
    }
    return hash;
}

static void Completion(void)
{
    sCompletionCalls++;
    SetMainCallback2(sReturnCallback);
}

static void Abort(void)
{
    sAbortCalls++;
    SetMainCallback2(sReturnCallback);
}

static struct RunResult Run(u32 seed, u32 cancelFrame,
                            enum WarpRandoTestFailure failure)
{
    struct RunResult result = {0};
    const struct WrActive *active;
    u32 guard = 0;

    WarpRando_TestReset();
    WarpRando_TestForceFailure(failure);
    sCompletionCalls = 0;
    sAbortCalls = 0;
    sReturnCallback = gMain.callback2;
    if (!WarpRando_IsReferenceApproved())
        EXPECT(WarpRando_ApproveReference());
    result.before = MeasureHeap();
    EXPECT(WarpRando_StartNewGame(seed, Completion, Abort));
    while (WarpRando_IsGenerationActive() && guard++ < 16000)
    {
        VBlankIntrWait();
        gMain.newKeys = cancelFrame != 0 && guard == cancelFrame ? B_BUTTON : 0;
        gMain.callback2();
    }
    gMain.newKeys = 0;
    result.outerFrames = guard;
    EXPECT(guard < 16000);
    if (gMain.callback2 != NULL)
        gMain.callback2();
    WarpRando_GetMetrics(&result.metrics);
    active = WarpRando_GetActive();
    result.digest = HashActive(active);
    result.activeValid = active->valid;
    result.activeAlgorithm = active->identity.algorithm;
    result.completionCalls = sCompletionCalls;
    result.abortCalls = sAbortCalls;
    result.after = MeasureHeap();
    return result;
}

TEST("WarpC10E: production new-game success, cancellation, and allocation failure are bounded")
{
    struct RunResult seed0;
    struct RunResult seed42;
    struct RunResult cancelled;
    struct RunResult allocFailure;
    u32 stackHighWater;
    u32 stackMargin;
    WarpRando_InitStackCanary();
    seed0 = Run(0, 0, WARP_RANDO_TEST_FAIL_NONE);
    seed42 = Run(42, 0, WARP_RANDO_TEST_FAIL_NONE);
    cancelled = Run(0, 32, WARP_RANDO_TEST_FAIL_NONE);
    allocFailure = Run(0, 0, WARP_RANDO_TEST_FAIL_WORK_ALLOC);
    stackHighWater = WarpRando_GetStackHighWater();
    stackMargin = WarpRando_GetStackMargin();
    EXPECT_EQ(seed0.metrics.result, WR_OK);
    EXPECT_EQ(seed42.metrics.result, WR_OK);
    EXPECT_EQ(seed0.digest, 0xd2f14b80u);
    EXPECT_EQ(seed42.digest, 0x3d354fa7u);
    EXPECT_EQ(seed0.metrics.steps, 66274);
    EXPECT_EQ(seed42.metrics.steps, 94230);
    EXPECT_EQ(seed0.metrics.successfulAttempt, 0);
    EXPECT_EQ(seed42.metrics.successfulAttempt, 1);
    EXPECT(seed0.activeValid);
    EXPECT(seed42.activeValid);
    EXPECT_EQ(seed0.activeAlgorithm, WARP_RANDO_ALGORITHM);
    EXPECT_EQ(seed42.activeAlgorithm, WARP_RANDO_ALGORITHM);
    EXPECT_EQ(seed0.completionCalls, 1);
    EXPECT_EQ(seed42.completionCalls, 1);
    EXPECT_EQ(seed0.abortCalls, 0);
    EXPECT_EQ(seed42.abortCalls, 0);

    EXPECT_EQ(cancelled.metrics.result, WARP_RANDO_CANCELLED_RESULT);
    EXPECT_EQ(cancelled.completionCalls, 0);
    EXPECT_EQ(cancelled.abortCalls, 1);
    EXPECT_EQ(cancelled.metrics.publishes, 0);
    EXPECT_EQ(cancelled.metrics.releases, 1);
    EXPECT(!cancelled.activeValid);

    EXPECT_EQ(allocFailure.metrics.result, WR_BAD_DATA);
    EXPECT_EQ(allocFailure.completionCalls, 0);
    EXPECT_EQ(allocFailure.abortCalls, 1);
    EXPECT_EQ(allocFailure.metrics.publishes, 0);
    EXPECT_EQ(allocFailure.metrics.releases, 0);
    EXPECT(!allocFailure.activeValid);

    Test_MgbaPrintf("WRC10EDIAG active0=%d active42=%d active_cancel=%d main0=%d vblank0=%d callback0=%d",
                    (s32)seed0.metrics.maxActiveTicks,
                    (s32)seed42.metrics.maxActiveTicks,
                    (s32)cancelled.metrics.maxActiveTicks,
                    (s32)seed0.metrics.maxMainTicks,
                    (s32)seed0.metrics.maxVBlankToMainTicks,
                    (s32)seed0.metrics.maxCallbackTicks);

    EXPECT_EQ(seed0.metrics.progressRegressions, 0);
    EXPECT_EQ(seed42.metrics.progressRegressions, 0);
    EXPECT_EQ(seed0.metrics.deadlineMisses, 0);
    EXPECT_EQ(seed42.metrics.deadlineMisses, 0);
    EXPECT_EQ(cancelled.metrics.deadlineMisses, 0);
    EXPECT(seed0.metrics.maxCallbackTicks <= WARP_RANDO_BUDGET_TICKS);
    EXPECT(seed42.metrics.maxCallbackTicks <= WARP_RANDO_BUDGET_TICKS);
    EXPECT(cancelled.metrics.maxCallbackTicks <= WARP_RANDO_BUDGET_TICKS);
    EXPECT(seed0.metrics.maxActiveTicks < WARP_RANDO_FRAME_TICKS);
    EXPECT(seed42.metrics.maxActiveTicks < WARP_RANDO_FRAME_TICKS);
    EXPECT(cancelled.metrics.maxActiveTicks < WARP_RANDO_FRAME_TICKS);
    EXPECT_EQ(seed0.metrics.terminalRenders, 1);
    EXPECT_EQ(seed42.metrics.terminalRenders, 1);
    EXPECT_EQ(cancelled.metrics.terminalRenders, 1);
    EXPECT_EQ(allocFailure.metrics.terminalRenders, 1);

    EXPECT_EQ(seed0.before.freeBytes, seed0.after.freeBytes);
    EXPECT_EQ(seed42.before.freeBytes, seed42.after.freeBytes);
    EXPECT_EQ(cancelled.before.freeBytes, cancelled.after.freeBytes);
    EXPECT_EQ(allocFailure.before.freeBytes, allocFailure.after.freeBytes);
    EXPECT_EQ(seed0.before.largestFree, seed0.after.largestFree);
    EXPECT_EQ(seed42.before.largestFree, seed42.after.largestFree);
    EXPECT_EQ(cancelled.before.largestFree, cancelled.after.largestFree);
    EXPECT_EQ(allocFailure.before.largestFree, allocFailure.after.largestFree);
    EXPECT(stackHighWater > 0);
    EXPECT(stackMargin >= 512);

    Test_MgbaPrintf("WRC10E0 frames0=%d callbacks0=%d callback_max0=%d main_max0=%d vblank_main_max0=%d active_max0=%d deadline0=%d digest0_decimal=%d steps0=%d terminal0=%d completion0=%d",
                    (s32)seed0.metrics.frames, (s32)seed0.metrics.callbacks,
                    (s32)seed0.metrics.maxCallbackTicks, (s32)seed0.metrics.maxMainTicks,
                    (s32)seed0.metrics.maxVBlankToMainTicks, (s32)seed0.metrics.maxActiveTicks,
                    (s32)seed0.metrics.deadlineMisses, (s32)seed0.digest,
                    (s32)seed0.metrics.steps, (s32)seed0.metrics.terminalRenders,
                    seed0.completionCalls);
    Test_MgbaPrintf("WRC10E42 frames42=%d callbacks42=%d callback_max42=%d main_max42=%d vblank_main_max42=%d active_max42=%d deadline42=%d digest42_decimal=%d steps42=%d attempt42=%d terminal42=%d completion42=%d",
                    (s32)seed42.metrics.frames, (s32)seed42.metrics.callbacks,
                    (s32)seed42.metrics.maxCallbackTicks, (s32)seed42.metrics.maxMainTicks,
                    (s32)seed42.metrics.maxVBlankToMainTicks, (s32)seed42.metrics.maxActiveTicks,
                    (s32)seed42.metrics.deadlineMisses, (s32)seed42.digest,
                    (s32)seed42.metrics.steps, seed42.metrics.successfulAttempt,
                    (s32)seed42.metrics.terminalRenders, seed42.completionCalls);
    Test_MgbaPrintf("WRC10ECANCEL frames_cancel=%d result_cancel=%d publishes_cancel=%d releases_cancel=%d valid_cancel=%d abort_cancel=%d deadline_cancel=%d",
                    (s32)cancelled.metrics.frames, cancelled.metrics.result,
                    (s32)cancelled.metrics.publishes, (s32)cancelled.metrics.releases,
                    cancelled.activeValid, cancelled.abortCalls,
                    (s32)cancelled.metrics.deadlineMisses);
    Test_MgbaPrintf("WRC10EALLOC alloc_result=%d alloc_release=%d alloc_abort=%d",
                    allocFailure.metrics.result, (s32)allocFailure.metrics.releases,
                    allocFailure.abortCalls);
    Test_MgbaPrintf("WRC10ESTACK high_water=%d margin=%d active_size=%d screen_size=%d heap_before=%d heap_after=%d algorithm=%d",
                    (s32)stackHighWater, (s32)stackMargin,
                    sizeof(struct WrActive), sizeof(struct WarpRandoRuntimeMetrics),
                    (s32)seed0.before.freeBytes, (s32)seed0.after.freeBytes,
                    (s32)seed0.activeAlgorithm);
}

TEST("WarpC10E: production publication failure is fail-closed")
{
    struct RunResult publishFailure = Run(0, 0, WARP_RANDO_TEST_FAIL_PUBLISH);

    EXPECT_EQ(publishFailure.metrics.result, WR_BAD_DATA);
    EXPECT_EQ(publishFailure.completionCalls, 0);
    EXPECT_EQ(publishFailure.abortCalls, 1);
    EXPECT_EQ(publishFailure.metrics.publishes, 0);
    EXPECT_EQ(publishFailure.metrics.releases, 1);
    EXPECT(!publishFailure.activeValid);
    EXPECT_EQ(publishFailure.metrics.progressRegressions, 0);
    EXPECT_EQ(publishFailure.metrics.deadlineMisses, 0);
    EXPECT(publishFailure.metrics.maxCallbackTicks <= WARP_RANDO_BUDGET_TICKS);
    EXPECT(publishFailure.metrics.maxActiveTicks < WARP_RANDO_FRAME_TICKS);
    EXPECT_EQ(publishFailure.metrics.terminalRenders, 1);
    EXPECT_EQ(publishFailure.before.freeBytes, publishFailure.after.freeBytes);
    EXPECT_EQ(publishFailure.before.largestFree, publishFailure.after.largestFree);

    Test_MgbaPrintf("WRC10EPUBLISH publish_result=%d publish_publish=%d publish_release=%d publish_abort=%d active_max_publish=%d deadline_publish=%d",
                    publishFailure.metrics.result,
                    (s32)publishFailure.metrics.publishes,
                    (s32)publishFailure.metrics.releases,
                    publishFailure.abortCalls,
                    (s32)publishFailure.metrics.maxActiveTicks,
                    (s32)publishFailure.metrics.deadlineMisses);
}
