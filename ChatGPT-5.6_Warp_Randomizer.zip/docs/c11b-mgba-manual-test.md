# C11B experimental graphical checks — not yet executed

This is a controlled static-warp experiment, not a progression-approved preset.
Map graphics and terrain remain vanilla; participating entrances change destinations.
Special transitions remain outside this checkpoint. Automated source checks do not
prove safe landing, return routes, or game completion.

## Build

Use the pinned expansion target with the existing proof/build patches and the
C10E, C11A, then C11B production patches applied in order. See patches/README.md.

```sh
KEEP_TEMPS=1 python3 tools/audit/build_runtime_interactive.py \
  ../sources/target ../proof-tools/prefix ../c11b-experimental.gba --seed 0
```

This runs the 14-test ARM preflight, then builds a normal ROM with proof mode off.
The old build_c10e_interactive.py entry point forwards to this current builder;
historical C10E requires the earlier project snapshot.

## Fresh save and physical walking

1. Back up existing battery saves. Use a new ROM basename and a fresh save, not
   a save state. Ruleset-1 C11A saves are intentionally rejected by ruleset 2.
2. Start New Game, or use SELECT quickstart. Record the WORLD READY runtime line.
   The diagnostic prefix remains WRC10ERUNTIME; the algorithm should now be 5.
3. Walk with ordinary directional inputs. Record each source map/entrance and
   arrival map/tile, animation, and whether control returns without immediately
   retriggering a warp. Test returning where possible. Save before exploring.
4. Cover grouped/multiple-tile entrances if reachable. Mark unreachable cases
   untested. If stuck, stop and restore your backed-up test save; do not interpret
   successful generation as evidence of a beatable world.

## Power-cycle and Continue

1. Make an in-game battery save at a controllable location after observing a route.
2. Fully close mGBA, reopen the same ROM and choose Continue. Do not load a state.
3. Record regeneration output, saved location, and whether that same entrance
   still leads to the same destination after regeneration.
4. Repeat from a battery save, pressing physical B during Continue generation.
   Confirm return to title with no active world; retry Continue and confirm that
   the saved game still loads and reproduces the same route.

Report mGBA version/platform, build seed, runtime lines, tested routes, and any
landing, animation, return, or control issues. A deadline=1 line is a timing flag
to investigate, not an automatic performance pass. These checks remain pending
until a graphical run is reported; headless test results do not substitute for them.
