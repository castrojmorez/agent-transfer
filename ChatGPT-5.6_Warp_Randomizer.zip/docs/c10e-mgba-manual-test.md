# C10E production-path graphical mGBA test

This checks the opt-in screen through the normal `CB2_NewGame` wrapper. It is
not a save-compatibility or gameplay-completion test, and the C10E build's
generated table is intentionally not connected to target warp interception.

## Recorded result

The project owner completed both quickstart runs in Windows mGBA 0.10.5 using
a target built under WSL Ubuntu 22.04. `WORLD READY` resumed playable ordinary
startup, and physical B produced `GENERATION CANCELLED` and returned safely.
No visual, audio, or playability problem was reported. The exact submitted
lines are preserved in `reports/engine-proof/c10e-human-graphical.log`.

Both lines report one missed deadline (`deadline=1`) and active maxima of 5,757
and 5,782 ticks, above the nominal 4,389-tick frame. This does not match the
zero-miss expectation below. The owner explicitly accepted the functional gate
and approved C11A; the timing discrepancy remains recorded. Stack high-water
was 2,152 bytes with 1,796 bytes positive margin in both runs.

## Build

Apply `patches/c10e-production.patch` after the fixed proof patches, then use
the same pinned target and local toolchain as the engine tests:

```sh
python3 tools/audit/build_c10e_interactive.py \
  ../proof-target ../proof-tools/prefix build/c10e-seed0.gba --seed 0
```

The builder first runs both C10E ARM tests, then emits a normal (non-test) ROM
with the opt-in configuration enabled. Open it in graphical mGBA without
fast-forward for the observation pass. Debug builds print one
`WRC10ERUNTIME` line when the screen exits.

## Success run

1. At the title screen, press SELECT for the target's built-in quickstart, or
   complete New Game and Birch's introduction normally.
2. Confirm the C10E loading screen appears before the truck/new-game map.
3. Do not press B. Confirm progress/activity and audio remain responsive,
   `WORLD READY` appears once, and normal new-game startup resumes after the
   one-second terminal hold.
4. Copy the `WRC10ERUNTIME` log line. It should report result 0, one publish,
   one release, valid 1, algorithm 0, deadline 0 and a positive stack margin.

## Cancellation run

Restart the ROM, enter New Game again, and press B while generation is active.
Confirm `GENERATION CANCELLED` appears and the ROM returns to the title screen
instead of entering an ordinary unrandomized game. The log should report result
101, publishes 0, releases 1, valid 0 and deadline 0.

Record mGBA version/platform, both log lines, and any visual/audio failure.
Algorithm 5 was unassigned in C10E; algorithm 0 in these historical lines is
intentional.
