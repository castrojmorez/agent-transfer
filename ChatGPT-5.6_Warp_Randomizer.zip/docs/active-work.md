# Active work recovery — C11B source-aware integration

Status: source-aware ARM gate passed in both modes (14/14 each).
Normal enabled/disabled links pass. The validated final report is
`reports/engine-proof/c11b-source-gate.json`; full checkpoint notes are in
`docs/c11b-source-gate-checkpoint.md`. Full host test and sanitizer suites pass.
Enabled-minus-disabled allocation is 16,964 EWRAM bytes, zero IWRAM bytes and
121,280 ROM bytes. Both release images omit the test bridge. Local target was
left disabled after measurement; the interactive builder enables it explicitly.

Implemented portable source normalization, a generated 608-event source table,
source-aware runtime API and target patch `c11b-production.patch` (after C11A).
Runtime ruleset is now 2 because physical interception semantics changed;
Algorithm 5 constructor/table output remains unchanged. Old ruleset-1 saves
are rejected. Eight C11B tests pass normally and with ASan/UBSan.

Implemented `patches/engine-tests/warp_rando_c11a.c` normalization and exclusion
coverage through the real SetupWarp path. Run the current regression suite
using `--c11b-probe` (alias of the consolidated save/restore suite).
Stage config/core/source header/data with that builder. The local target
checkout already has the C11B call-site change. Use KEEP_TEMPS=1 if needed.
Do not overwrite historical c11a logs; new logs belong under c11b-*.

No gameplay-ready claim. Source gating is not collision/progression approval.
Next graphical checklist: `docs/c11b-mgba-manual-test.md`.
