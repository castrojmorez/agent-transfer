# Runtime contract, revision 4

The graph compiler is a build-time tool; the delivered portable C core
generates each seed itself. Revision 4 adds C11B source signatures and ruleset 2
to C11A's versioned Algorithm-5 save identity and target interception boundary.

* Physical endpoint: a source warp event, indexed in the target map's warp array.
* Logical endpoint: the representative of a declared physical group. All graph
  indices are uint16_t; 65535 means absent. Groups are never truncated.
* Trigger: the **requested destination triple** after an explicitly audited
  normalization. It is not the source event triple.
* Landing: a real destination endpoint (the partner representative).
* Fixed travel: directed edges retained independently of pairing participation.
* Escape: an explicit directed edge with an explicit capability prerequisite.

For each pair A/B, emit vanillaDestination(member(A)) -> B and
vanillaDestination(member(B)) -> A. Equivalent records deduplicate; contradictory
records reject the candidate. Group membership must be coherent. Participating
and excluded endpoints sharing a trigger are rejected at data compilation because
a destination-only hook could otherwise redirect an excluded event.

Concrete fixture (deliberately synthetic, not a claim about Emerald coordinates):
A=(1,0,0), alias A1=(1,0,1), both request (2,0,0).
B=(3,0,0), alias B1=(3,0,1), both request (4,0,0).
Emit exactly (2,0,0)->(3,0,0) and (4,0,0)->(1,0,0).
Entering A or A1 lands at B; entering B or B1 lands at A. Looking up A's own
triple does nothing. If C also requests (2,0,0) but is paired with D, emission
rejects the conflicting destinations rather than choosing one.

Unlisted transitions and invalid/inactive state leave the caller's requested
triple unchanged. That is vanilla fallback; a self-destination is not fallback.
Odd participation pools are rejected, with no implicit sink or self-pair.

Reference source: WarpRandomizationState.getRemappings derives trigger sets from
source-group `to` fields. Speedchoice InterceptWarp normalizes some ambiguous
requested destinations using player position. Numeric proxy IDs in Warps.json
are trigger tokens, not proof that the target has corresponding landing events.
The target audit reports all disagreements; the reference-only graph must not be
installed as an expansion 1.17.0 gameplay dataset.

Algorithm 5/ruleset 2 uses the exact C9C/C10B cooperative constructor and the
C11B source gate. Ruleset 1 is the historical destination-only C11A integration
and is rejected on Continue. Before looking up a trigger, the target hook must
match source group/map/event, literal destination, x/y and elevation against the
pinned 608-event source table. Five audited rows normalize to distinct reference
tokens; unknown or mismatched source signatures leave the destination unchanged.
This gate does not establish collision safety or progression correctness.
Its persisted identity is the explicit 64-byte `WRSV` version-1 envelope:
seed, algorithm, ruleset, 32-byte reference fingerprint, successful attempt,
ready state and CRC32. Save bytes are little-endian and never a raw C struct.
Continue must reject any incompatible or corrupt envelope, regenerate through
the asynchronous screen, and publish only if the successful attempt matches.
No stale table or silent unrandomized continuation is permitted.

The C11A production hook is limited to ordinary static event destinations in
`SetupWarp`. The resolved group/map/warp is validated against pinned target
group sizes and the destination map's warp count before dereference. Other
transition families retain vanilla behavior until separately audited.

The base supplied target patch is a **fixed-table event proof**, disabled by default.
It gates lookup to four declared source groups and uses destination triggers
inside that gate. It does not attach the unapproved full reference graph to every
SetWarpDestination call. Script, dynamic, coordinate, Trainer Hill, Dive, fall,
escape and whiteout behavior is described in patches/README.md. The separate,
also-disabled-by-default C11A patch adds save restoration and the narrow runtime
event hook without making the reference data target-approved.
