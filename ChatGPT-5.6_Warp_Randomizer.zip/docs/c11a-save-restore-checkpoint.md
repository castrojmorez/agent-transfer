# C11A save, restoration and interception checkpoint

## Decision

C11A passes its automated ARM gate on the pinned expansion 1.17.0 target at
`e8bd1cd7b03fc032ea37e3ecd38b379b5d01a1e7`. Algorithm ID 5 now identifies
the exact C9C/C10B asynchronous constructor with ruleset 1. A 64-byte versioned
identity is persisted in appended SaveBlock3 storage, Continue regenerates and
publishes the same table asynchronously, and ordinary static event warps use
the active mapping only after target bounds validation.

This is still not a supported playable preset. The reference graph has known
target drift, non-event transitions are intentionally not intercepted, and no
interactive full power-cycle/Continue or long-form completion run exists.
Algorithm 4 remains frozen as the precomputed fallback.

## Save and restore contract

The save envelope is encoded explicitly; compiler struct layout is never
persisted.

| Offset | Bytes | Field |
|---:|---:|---|
| 0 | 4 | `WRSV` magic |
| 4 | 2 | format version (`1`) |
| 6 | 2 | envelope size (`64`) |
| 8 | 4 | seed |
| 12 | 4 | algorithm (`5`) |
| 16 | 4 | ruleset (`1`) |
| 20 | 32 | reference fingerprint |
| 52 | 2 | successful generation attempt |
| 54 | 1 | ready state |
| 55 | 5 | reserved zero bytes |
| 60 | 4 | CRC32 over bytes 0–59 |

All multibyte values are little-endian. Continue accepts the record only when
magic, version, size, ready state, reserved bytes, CRC, algorithm, ruleset and
fingerprint match. It then runs the same asynchronous generator and publishes
only if the regenerated successful attempt also matches. Any failure leaves no
valid active table and returns the production flow to the title screen.

New Game writes the identity only after generation succeeds and
`NewGameInitData` has initialized the save blocks. Reset during generation
cancels and releases the temporary workspace without publishing. The active
532-record table is reconstructed, not stored in flash.

## Interception boundary

The integration is deliberately narrow. `SetupWarp` submits the requested
destination triple to `WarpRando_ResolveWarp` for ordinary, non-Trainer-Hill
static events. Before dereferencing the mapped destination, the target bridge
checks map-group count, the generated pinned per-group map count, and landing
warp count. Invalid or inactive mappings leave the original destination intact.

Script and coordinate setters, MAP_DYNAMIC, Trainer Hill, Dive, fall, Escape,
Teleport, whiteout, connections and exceptional direct assignments remain on
their existing engine paths. The earlier fixed Oldale proof remains available
as a fallback after the runtime lookup and retains its own arrival correction;
randomized mappings do not inherit that proof-only coordinate correction.

## Automated result

Both proof-disabled and proof-enabled target suites pass 13/13 under bundled
headless mGBA. Seed 42 and its flash-restored Continue path both publish
Algorithm 5, attempt 1, and digest `3d354fa7` (decimal 1,026,903,975). The test
uses the target flash routines, resets runtime state, regenerates, compares the
active table, and drives the actual static `SetupWarp` bridge to a dynamically
located valid event/landing pair.

The reset test cancels after 12 screen frames and restores the heap from and to
115,760 free bytes. CRC corruption, format-version mismatch, ruleset mismatch,
fingerprint mismatch and successful-attempt mismatch all fail closed; the
attempt mismatch ends with `WR_BAD_IDENTITY` (11), no active table, one abort,
and exact heap restoration.

The enabled and disabled normal ROMs both link:

| Resource | Disabled | Enabled | Delta |
|---|---:|---:|---:|
| EWRAM static | 226,416 | 243,380 | +16,964 |
| EWRAM unallocated | 35,728 | 18,764 | -16,964 |
| IWRAM static | 28,376 | 28,376 | 0 |
| ROM static | 26,752,444 | 26,861,188 | +108,744 |
| ROM unallocated | 6,801,988 | 6,693,244 | -108,744 |

The checked machine-readable record is
`reports/engine-proof/c11a-probe.json`; the two target logs and resource
reports share the `c11a-` prefix.

## Integration corrections made during C11A

- The target does not expose a production `MAP_GROUP_COUNT` helper. A generated
  header now pins all 75 group sizes from the exact target's
  `data/maps/map_groups.json` and is staged with the runtime.
- Copying staged inputs on every retry changed mtimes and rebuilt the entire
  target. The proof builder now copies only when bytes differ, which makes
  restored-toolchain retries practical without changing build results.
- The first negative harness placed a 16,436-byte `WrActive` on the GBA stack
  and crashed. Test scratch state now lives explicitly in EWRAM; production
  code was unaffected.
- One combined negative test approached the outer runner watchdog. Reset and
  incompatible-metadata cases are separate tests with the same assertions.

## Reproduction

Apply `expansion-1.17.0-proof.patch`, `c10e-production.patch`, then
`c11a-production.patch`. Copy the production runtime/config files plus
`include/warp_rando.h`, `include/warp_rando_identity.h`,
`src/warp_rando_identity.c`, the C9C/C10B/C10C staged inputs, the reference
headers, and `data/target-expansion-1.17.0-map-counts.h` to the target paths
listed in `patches/README.md`. Then run:

```sh
python3 tools/audit/build_engine_proof.py ../proof-target ../proof-tools/prefix \
  --mode 0 --c11a-probe --log reports/engine-proof/c11a-mode0.log
python3 tools/audit/build_engine_proof.py ../proof-target ../proof-tools/prefix \
  --mode 1 --c11a-probe --log reports/engine-proof/c11a-mode1.log
python3 tools/audit/c11a_probe_report.py \
  reports/engine-proof/c11a-mode0.log \
  reports/engine-proof/c11a-mode1.log \
  reports/engine-proof/c11a-enabled-resources.json \
  reports/engine-proof/c11a-disabled-resources.json \
  reports/engine-proof/c11a-rom-enabled.log \
  reports/engine-proof/c11a-rom-disabled.log \
  reports/engine-proof/c11a-probe.json
```

## Next gate

C11B should replace the reference-only gameplay assumptions with explicit
target-approved traversal and progression data, then run a graphical full
power-cycle/Continue, physical walking through representative paired/grouped
warps, save/reload, mismatch handling and longer play. The broader transition
types should be included only after their semantics and arrival handling are
audited.
