# C11B-1: target source/trigger reconciliation

Recorded 2026-09-08. This is the first C11B checkpoint, not C11B completion.
C11A's passing save/restore tests remain valid within their tested scope; they
do not establish that the destination-only hook respects target participation.

## Findings

The fresh pinned-target audit reproduces 879 reference nodes, 2,607 target
events, 1,729 target-only events, one absent source and 12 destination
mismatches. Five mismatches affect active participants. All five reference
triggers are synthetic keys, not real target landing events.

| Active source | Target request | Reference lookup token |
|---|---|---|
| E,24,24,14 | E,24,24,12 | E,24,24,52 |
| E,24,24,21 | E,24,24,12 | E,24,24,51 |
| E,24,24,23 | E,24,24,17 | E,24,24,50 |
| E,24,25,9 | E,24,24,4 | E,24,24,53 |
| E,24,31,3 | E,24,27,1 | E,24,27,50 |

Replacing reference tokens with literal target destinations would collapse
distinct logical groups and can redirect excluded sources. The audit detects
five shared-destination conflict buckets (not five individual faulty events).
Grouped aliases with a common representative do not count as conflicts.

Three nonparticipating sources currently enter C11A's active reference-trigger
namespace: unannotated sources E,13,8,0 and E,13,8,1 request E,0,5,0; excluded
source E,24,33,2 requests E,24,27,1. With a generated active table, the
destination-only lookup can redirect these too. Bounds validation does not
prevent this participation error. These are static exposure findings, not
observed player-walking failures.

The missing Sootopolis source E,0,7,13 is inactive. That does not justify
deleting it: fixed edges and progression rules still require separate review.
The seven inactive destination mismatches likewise remain open. Previously
reported geometry and progression discrepancies are not closed by this audit.

## Implemented

`tools/audit/c11b_reconcile.py` joins normalized participation and representatives
to actual target source events. It rejects an incorrect target commit or dirty
map data, records all target map input hashes, classifies mismatches, detects
cross-group/mixed-participation collisions and inventories target-only maps.
It writes a separate report and never mutates reference data, fingerprints,
Algorithm 4 or production runtime code.

Six synthetic tests cover grouped aliases, cross-group collisions, target-only
and excluded-source exposure, missing sources/synthetic tokens and invalid
representatives. They are part of `make test`.

Reproduce from the project root:

```sh
python3 tests/c11b_test.py
python3 tools/audit/c11b_reconcile.py ../sources/target reports/c11b-reconciliation.json
```

## Next implementation gate

Add a source-aware adapter keyed by source group/map/event. Require an approved
participant and verify its expected literal target destination before mapping
to the reference trigger token. Deny unknown/excluded sources and stale event
signatures. Preserve the emitted table and seeded output while testing all five
normalizations and all three exclusions in host and ARM tests. Keep this
separate from approval of landing geometry and progression semantics.

Do not enable the reference-only runtime as a playable preset. C11B still needs
that adapter, geometry/traversal/progression reconciliation and interactive
power-cycle/Continue and walking coverage.
