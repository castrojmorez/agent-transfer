# C10E opt-in production integration checkpoint

## Decision

C10E passes its automated production-integration gate. The exact C10D/C9C
generator now lives in a production source module and can be entered from a
disabled-by-default `CB2_NewGame` wrapper. Both proof modes pass 12/12 ARM
tests in bundled mGBA, and normal ROMs link with the option enabled and
disabled.

The project owner subsequently completed the graphical normal-ROM success and
physical-B cancellation paths in Windows mGBA 0.10.5. Both behaved correctly,
so the owner closed C10E and approved C11A. Each submitted runtime line also
records one missed deadline; that discrepancy is retained in
`reports/engine-proof/c10e-human-graphical.json`. C10E itself did not assign
Algorithm ID 5 or connect the active table to saves/warps.

## Production lifecycle

`OW_WARP_RANDO_NEW_GAME` defaults to `FALSE`. When enabled:

1. `AgbMain` initializes the heap and approves the immutable graph/index before
   any visible main callback runs.
2. The existing Birch/quickstart flow reaches a wrapper at `CB2_NewGame`.
3. The wrapper creates the C10D screen and only then allocates the 14,224-byte
   workspace.
4. Successful generation publishes the 532-record table last, holds
   `WORLD READY` for 60 frames, tears down the screen, and invokes the original
   `CB2_NewGame` body.
5. B cancellation, allocation failure, generation failure, or publication
   failure leaves the table invalid, releases every allocation exactly once,
   and returns to `CB2_InitTitleScreen`.

There is no silent fallback into an ordinary unrandomized new game. With the
option disabled, the wrapper compiles to the original direct path and no
`WrActive` storage is linked.

## Automated ARM result

The target is `pokeemerald-expansion` 1.17.0 at
`e8bd1cd7b03fc032ea37e3ecd38b379b5d01a1e7`.

| Measurement | Seed 0 | Seed 42 |
|---|---:|---:|
| Screen frames | 901 | 1,289 |
| Generator callbacks | 827 | 1,198 |
| Maximum generator callback | 2,361 ticks | 2,323 ticks |
| Maximum main callback | 3,485 ticks | 3,521 ticks |
| Maximum preceding VBlank contribution | 579 ticks | 602 ticks |
| Maximum active frame | 4,064 ticks | 4,088 ticks |
| Nominal frame budget | 4,389 ticks | 4,389 ticks |
| Deadline misses | 0 | 0 |
| Exact digest | `d2f14b80` | `3d354fa7` |
| Generator steps | 66,274 | 94,230 |

The worst measured frame leaves 301 ticks of headroom. Cancellation completes
on frame 92 with result 101, no publication, one release, an invalid table, and
the abort callback. Injected allocation and publication failures also remain
invalid and take the abort callback; the publication failure releases once.
The controlled heap begins and ends with 115,760 free bytes.

The runtime canary patterned 3,932 bytes between static IWRAM and the system
stack. Its ARM tests observed 1,528 bytes high-water and 2,404 bytes untouched
margin. This is direct runtime evidence with the normal link's static IWRAM
floor, but the graphical normal-ROM path must still emit its own
`WRC10ERUNTIME` line.

## Normal-link resources

| Resource | Disabled | Enabled | Delta |
|---|---:|---:|---:|
| EWRAM static | 226,416 | 243,268 | +16,852 |
| EWRAM unallocated | 35,728 | 18,876 | -16,852 |
| IWRAM static | 28,376 | 28,376 | 0 |
| IWRAM unallocated | 4,392 | 4,392 | 0 |
| ROM static | 26,752,444 | 26,859,856 | +107,412 |
| ROM unallocated | 6,801,988 | 6,694,576 | -107,412 |

The enabled EWRAM delta is the 16,436-byte active table plus 416 bytes of
runtime screen/canary state. The temporary workspace remains a heap allocation.

## Integration failures found and corrected

- A staged core file used an `.inc` suffix, so the target dependency scanner
  treated C as assembly and failed on `<string.h>`. The staged name is now
  `.inc.c`.
- The restored workspace lacked the locally prepared newlib link. Re-running
  the checksum-pinned toolchain bootstrap restored the expected target build;
  no source change was needed.
- The first production timer included a stale main/VBlank interval and reported
  a false 7,982-tick frame. Arming at the end of main and subtracting the
  VBlank-entry stamp made the measurement match C10D's frame boundary.
- The first test callbacks replaced the test runner callback with `NULL`.
  Assertions completed, but the outer watchdog reported `TIMEOUT`. Restoring
  the saved caller callback fixed the lifecycle defect.
- The five-path test was split into two ARM cases to keep each case comfortably
  within the harness watchdog window.

These were staging, instrumentation, and test-lifecycle failures. They did not
change seeded generator output.

## Reproduction

After applying `patches/expansion-1.17.0-proof.patch`, apply
`patches/c10e-production.patch`, then run:

```sh
python3 tools/audit/build_engine_proof.py ../proof-target ../proof-tools/prefix \
  --mode 0 --c10e-probe --log reports/engine-proof/c10e-mode0.log
python3 tools/audit/build_engine_proof.py ../proof-target ../proof-tools/prefix \
  --mode 1 --c10e-probe --log reports/engine-proof/c10e-mode1.log
python3 tools/audit/c10e_probe_report.py \
  reports/engine-proof/c10e-mode0.log \
  reports/engine-proof/c10e-mode1.log \
  reports/engine-proof/c10e-enabled-resources.json \
  reports/engine-proof/c10e-disabled-resources.json \
  reports/engine-proof/c10e-rom-enabled.log \
  reports/engine-proof/c10e-rom-disabled.log \
  reports/engine-proof/c10e-probe.json
```

The completed graphical record and exact runtime lines are in
`reports/engine-proof/c10e-human-graphical.*`. To repeat it, build the enabled
normal ROM with `tools/audit/build_c10e_interactive.py` and follow
`docs/c10e-mgba-manual-test.md`. ROM bytes are not distributed.

## Next gate

C11A now defines the versioned Algorithm-5 identity, deterministic asynchronous
Continue reconstruction and ordinary static-warp interception. See
`docs/c11a-save-restore-checkpoint.md`. Algorithm 4 remains the frozen fast
fallback; target-data approval and interactive C11 power-cycle/walking coverage
are the next gate.
