# C11B-2 — source-aware static-warp integration

The C11B-1 audit exposed ambiguity in C11A's destination-only lookup. The
runtime now checks the physical source before consulting the unchanged
Algorithm-5 remapping table. Full C11B remains open.

## Implementation

`compile_source_routes.py` generates 608 sorted participant signatures from
the pinned expansion map data and frozen normalized graph. Each signature
contains the source group/map/event, literal destination and event x/y/elevation.
The compiler requires the pinned commit and clean map inputs; the ARM staging
step checks deterministic generated output before building.

The five audited synthetic destinations are normalized only for their exact
source signatures. Unknown, excluded or mismatched events retain their original
destination. The real SetupWarp call site supplies source context. Destination
bounds checks remain in place. No new mutable runtime state is introduced.

Algorithm 5 table generation is unchanged. Ruleset 2 identifies the changed
physical semantics; ruleset-1 saves are deliberately rejected, not migrated.
The 64-byte WRSV envelope and format version remain unchanged.

## Verified evidence

- `make test` and `make sanitize` pass, including eight C11B test methods.
- Host C checks cover every signature and destination/x/y/elevation mismatch,
  plus unknown/excluded sources and invalid inputs, preserving rejected output.
- Both ARM proof modes pass 14/14 combined tests. All 608 normalizations and
  wrong-x rejections are checked in ARM code. The five normalized sources and
  three denied sources also exercise actual SetupWarp and WarpIntoMap.
- The combined suite retains flash identity, reconstruction, cancellation/reset,
  corruption/version/fingerprint failure checks and exact heap restoration.
- Old ruleset-1 metadata with a valid recomputed CRC is rejected.
- The graphical builder's headless preflight and enabled normal ROM link pass.
- The disabled normal ROM also links. Enabled-minus-disabled allocation is
  16,964 EWRAM bytes, zero IWRAM bytes and 121,280 ROM bytes; enabled EWRAM
  headroom is 18,764 bytes. Both normal links omit the test bridge.
- The C11B delta patch applies cleanly after C11A on the verification worktree.

Exact ARM markers, resource measurements and normal-link evidence are in
`reports/engine-proof/c11b-*`; `docs/active-work.md` records final verification
status. The marker's `stale=608` means wrong-x rejection coverage, not 608
graphical walking tests. `WRC11AFAIL ruleset=1` is a successful rejection-test
flag; the actual current identity is `WRC11BSOURCE ruleset=2`.

## Reproduction and simplification

After the ordered production patches, run `build_engine_proof.py` with
`--c11b-probe --mode 0` and again with `--mode 1`. The alias uses the existing
save/restore suite rather than a copied C11B staging pipeline. The report tool
similarly adds `--source-aware` to `c11a_probe_report.py`.

Use `build_runtime_interactive.py` for the current experimental ROM. The old
C10E builder is a compatibility wrapper with a historical-version warning.
Unchanged configuration headers are no longer rewritten on every build retry.

The cached toolchain restoration utility repaired missing newlib/pkg-config
links during this checkpoint. No additional dependency downloads were needed.

## Still unverified

Run `c11b-mgba-manual-test.md` with a fresh battery save. No graphical C11B
power-cycle, Continue, walking, grouped exit or animation result is claimed.
Source matching does not prove landing safety, progression, safe return,
special-transition handling, or champion completion. The remaining data drift
and progression questions are listed in `next-steps.md`. Default remains off.
