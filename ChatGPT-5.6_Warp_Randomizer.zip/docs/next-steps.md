# Remaining work after the C11B source-aware gate

C11B-2 source-aware participation/signature checks and synthetic-trigger
normalization now pass host and ARM tests, preserving Algorithm-5 table output.
Ruleset 2 identifies the changed physical interception semantics. Next perform
the controlled `c11b-mgba-manual-test.md` checks; full C11B data approval remains
open. Historical C11A logs remain unchanged, not evidence for the new gate.

1. C11B: resolve target data drift—12 destination disagreements, one absent
   endpoint, two matched-endpoint geometry changes, 1,729 target-only events
   and 13 unmodeled excluded transitions. Produce explicit target-approved
   traversal and progression data rather than promoting the reference graph.
2. Observe walking round trips, grouped exits and the full power-cycle/Continue
   path in an interactive emulator. The headless tests verify target warp
   functions, Algorithm-5 flash identity/reconstruction and interception, but
   not animations or reboot. Recheck interactive frame/stack behavior: the
   accepted C10E manual runs each recorded one deadline miss.
3. Audit HMs/badges, items, bikes, transport, scripted gates and state-dependent
   Escape. Preserve conservative unknown requirements unless a grant is
   justified. Any changed return guarantee is a separate ruleset decision.
4. Extend interception only after auditing scripts, dynamic warps, Dive, fall,
   Escape, Teleport, whiteout, connections and exceptional direct assignments.
5. Measure final ROM/RAM/stack and worst-case retries. Test scripts, dynamic
   warps, Dive/fall/escape, whiteout, restart, options/version mismatch and actual
   champion defeat/credits. Declare a supported playable preset only afterward.

Keep HANDOFF.md and STATUS.md current. Save a durable ZIP and standalone handoff
after each substantial checkpoint, preserving historical evidence under its
checkpoint/algorithm identity. See patches/engine-tests/README.md to reproduce
the C4 engine checks, C5 full-reference generator probe, C6C bank probe, C7B
bounded-candidate probe, C7C SCC/bitset probe, C8A event-driven probe, C8B
trial-volume probe, C8C indexed-state probe, C9A representative-bitset probe,
C9B validated-emission, C9C cold/warm indexed-emission, C10A cooperative
maximum-quantum, C10B frame-bounded microstep, C10C budgeted-task, C10E
production and C11A save/restore/interception probes. C11A passes 13/13 in both
proof modes and both normal links; its graphical power-cycle/walking complement
and target-data approval are the next gate.
