# C10D graphical mGBA manual test

This is the human-observation complement to the automated headless mGBA test.
It does not install the randomizer into a normal game ROM.

## Recorded result

The project owner completed the checklist on 2026-09-07 and reported all seven
items passing. The submitted mGBA-window log also reports the exact seed 0 and
seed 42 digests and step counts, seed 42 attempt 1, zero deadline misses,
success-only publication, one cancellation release, restored heap state and the
ROM test `PASS` marker. The physical B press cancelled only the third run.

This is user-observed evidence; Codex did not independently watch the graphical
session. The submitted record did not include the mGBA version or host platform.
Its normalized log and checked provenance are preserved in
`reports/engine-proof/c10d-human-graphical.*`.

## Build

Use the same pinned and patched target checkout and local prefix described in
`patches/engine-tests/README.md`:

```sh
python3 tools/audit/build_c10d_interactive.py \
  ../proof-target ../proof-tools/prefix build/c10d-interactive.gba
```

The builder runs the headless C10D preflight first. Open the resulting ROM in a
graphical mGBA release. Do not fast-forward for the observation pass.

## Expected sequence

1. The fixed WarpProof tests pass quickly.
2. Seed 0 shows `BUILDING RANDOMIZED WORLD`, a progress/activity bar, eight
   attempt slots and `B: CANCEL`, then `WORLD READY` after roughly 15 seconds.
3. Seed 42 repeats the flow for roughly 21 seconds. Its highlighted attempt
   slot advances once before completion.
4. The third run is the cancellation case. Press and release B while the
   loading screen is active. It should display `GENERATION CANCELLED` promptly
   and the test should pass.

## Record

For a repeat run, record mGBA version/platform and whether each item passes:

- text is readable and not clipped;
- the activity pulse moves even when the progress fill is temporarily flat;
- seed 42 visibly advances the attempt indicator;
- audio plays without obvious breakup;
- both success runs reach `WORLD READY`;
- physical B cancels only the third run;
- no blank screen, visible corruption, pause or emulator crash occurs.

If possible, attach one screenshot from a running seed and one from the
cancelled state. A failure should include the approximate frame/time, mGBA
version, platform and whether fast-forward, rewind or unusual audio settings
were enabled.

The recorded clean visual pass closes C10D's manual acceptance gate. It is not
save compatibility or full-game completion evidence. Algorithm 5 remains
unassigned.
