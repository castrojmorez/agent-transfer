# C10D rendered mGBA checkpoint

## Decision

C10D passes the automated rendered-lifecycle gate in the bundled headless
mGBA, in both proof modes, and the project owner subsequently passed the full
graphical/physical-input checklist in mGBA. The exact C9C generator runs from an engine main
callback behind an actual window, progress/activity display, attempt-limit
indicator, terminal messages, sound effects, normal VBlank transfers and
deferred B-button cancellation.

This remains test-only: the screen is not wired into a normal new-game path.
Algorithm 5 remains unassigned.

## Integration result

The first implementation combined generation, immediate text layout and a
full 8,960-byte window refresh. Although generation stayed below its budget,
those frames took about 10,000 ticks and missed VBlank. The corrected design:

- lowers the generator allowance from 3,200 to 2,800 ticks;
- gives UI transfers their own scheduled frame;
- updates only affected window rectangles;
- pre-renders static text and represents the attempt limit as eight slots;
- adds a 60-frame activity pulse when semantic progress is unchanged;
- uses Timer 3 for measurement, leaving Timers 0 and 1 to audio.

That failure was a screen-integration scheduling defect, not a generator
correctness failure. It is retained here because it establishes why render
work cannot simply be appended to the C10C callback.

## mGBA results

The pinned target is `pokeemerald-expansion` 1.17.0 at
`e8bd1cd7b03fc032ea37e3ecd38b379b5d01a1e7`. Both proof-disabled and
proof-enabled builds pass 11/11 tests under the bundled `mgba-rom-test`.

| Measurement | Seed 0 | Seed 42 |
|---|---:|---:|
| Scheduled screen frames | 883 | 1,264 |
| Approximate duration at 60 Hz | 14.717 s | 21.067 s |
| Generator callbacks | 867 | 1,230 |
| Maximum generator callback | 2,362 ticks | 2,366 ticks |
| Maximum main callback | 3,494 ticks | 3,532 ticks |
| Maximum main + preceding VBlank | 3,959 ticks | 4,051 ticks |
| UI progress/activity updates | 15 | 33 |
| Sound-effect requests | 5 | 8 |
| Missed VBlank deadlines | 0 | 0 |

The cancellation path is the worst measured active frame at 4,079 of 4,389
ticks (0.929 frame), leaving 310 ticks of measured headroom. It receives B on
frame 32, completes on frame 33, publishes no table and releases once.

The 310-tick margin is narrow. C10D proves this test screen can meet the frame
deadline in the measured cases; it does not justify adding more work without
remeasurement.

## Rendering, audio and input evidence

The screen uses the target's real window/text/background APIs. Main-callback
work runs tasks, sprites, OAM construction, text printers and palette fade.
The registered VBlank callback loads OAM, processes sprite copies and transfers
the palette. The engine's common VBlank path processes queued DMA and calls
`m4aSoundMain`; periodic `SE_SELECT` requests keep audio work live.

The test compares the final window pixel buffer to the destination character
VRAM after a VBlank flush. Progress never regresses, activity remains visible
when attempt-zero semantic progress is flat, retrying seed 42 highlights the
new attempt, and each terminal state is rendered once.

In headless mode, B is injected into `gMain.newKeys` and consumed through the
ordinary `JOY_NEW(B_BUTTON)` path. In an unpatched graphical test ROM, the same
source reads `REG_KEYINPUT` and derives a real new-key edge for the cancellation
run.

## Allocation and cleanup

The 14,224-byte workspace is allocated after the window system is initialized
and before the generator task is created. Measured heap changes are:

- screen/window heap: 11,040 bytes;
- workspace plus allocator metadata: 14,240 bytes;
- workspace released before screen teardown;
- all window allocations released at teardown;
- final free bytes and largest block exactly match entry.

The target job remains 200 bytes and the persistent active table 16,436 bytes.
The C10D screen state is explicit EWRAM and measures 388 bytes, only 72 bytes
more linked EWRAM than C10C. The test image leaves 18,608 EWRAM bytes. The
resource report's 252-byte IWRAM figure includes the high persistent section
and is not a stack measurement; runtime stack high-water remains open.

The immutable graph/index approval is performed before screen creation. That
avoids a frozen 1.6-second screen, but its eventual production boot hook is not
yet installed.

## Manual graphical mGBA check

Run `tools/audit/build_c10d_interactive.py` to build a non-headless test ROM.
See `docs/c10d-mgba-manual-test.md`. The builder first runs the automated
headless acceptance test, then emits the original unpatched test ELF as a GBA
ROM. ROM bytes are intentionally not included in the handoff.

On 2026-09-07, the project owner reported all seven manual items passing:
readable/unclipped text, a moving activity pulse, seed 42 attempt-slot change,
clean audio, `WORLD READY` for both success runs, physical B cancellation only
on the third run, and no blank screen, corruption, pause or crash.

The attached graphical-run log is consistent with that report. It reproduces
the exact success digests and work counts, records attempt 1 for seed 42, keeps
all deadline counters at zero, publishes nothing on cancellation, releases once,
restores the heap and ends in `PASS`. Its worst recorded active frame is 4,209
of 4,389 ticks, leaving 180 ticks. Human input moved cancellation to frame 86;
that timing is not an invariant. The observer did not include mGBA version or
host platform. See `reports/engine-proof/c10d-human-graphical.json`.

## Remaining gates

1. Wire the screen into a production opt-in new-game path rather than the test
   runner.
2. Canary-measure runtime stack high-water in the final production link.
3. Define Algorithm 5 save identity and exercise save/reload, reset during
   generation, version mismatch and corruption recovery.
4. Continue target-world traversal/progression validation.

Algorithm 4 remains the frozen fast fallback.

## Reproduction

```sh
python3 tools/audit/build_engine_proof.py TARGET PREFIX --mode 0 \
  --c10d-probe --log reports/engine-proof/c10d-mode0.log
python3 tools/audit/build_engine_proof.py TARGET PREFIX --mode 1 \
  --c10d-probe --log reports/engine-proof/c10d-mode1.log
python3 tools/audit/target_resources.py TARGET/pokeemerald-test.elf PREFIX \
  reports/engine-proof/c10d-resources.json
python3 tools/audit/c10d_probe_report.py TARGET PREFIX \
  reports/engine-proof/c10d-mode0.log reports/engine-proof/c10d-mode1.log \
  TARGET/pokeemerald-test.elf reports/engine-proof/c6c-baseline-resources.json \
  reports/engine-proof/c10c-resources.json \
  reports/engine-proof/c10d-resources.json \
  reports/engine-proof/c10d-probe.json
```
