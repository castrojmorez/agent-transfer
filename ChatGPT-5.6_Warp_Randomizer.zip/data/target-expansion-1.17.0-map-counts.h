#ifndef GUARD_WARP_RANDO_TARGET_MAP_COUNTS_H
#define GUARD_WARP_RANDO_TARGET_MAP_COUNTS_H

/* Generated from pokeemerald-expansion 1.17.0 at
 * e8bd1cd7b03fc032ea37e3ecd38b379b5d01a1e7, data/maps/map_groups.json.
 * This bounds-checks reference landings before any gMapGroups indexing. */
static const u8 gWarpRandoTargetMapCounts[] =
{
    57, 5, 5, 6, 7, 8, 9, 7, 7, 14, 8, 17, 10, 23, 13, 15, 15, 2, 2,
    2, 3, 1, 1, 1, 108, 61, 89, 2, 1, 13, 1, 1, 3, 1, 5, 123, 60, 62,
    4, 6, 8, 10, 6, 8, 20, 10, 8, 2, 10, 4, 2, 2, 1, 1, 1, 2, 2, 3,
    2, 3, 2, 1, 1, 6, 5, 5, 8, 8, 5, 5, 1, 1, 1, 2, 1,
};

#endif
