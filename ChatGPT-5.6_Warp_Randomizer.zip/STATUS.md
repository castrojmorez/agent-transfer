# Evidence-scoped status — C11B source-aware gate

Latest: C11B-2 source-aware gating passes eight host tests (also ASan/UBSan)
and the combined 14-test ARM suite in both modes. Five normalized routes and
three excluded sources exercise the real engine hook. All 608 source signatures
are checked. Ruleset 2 rejects C11A saves; graphical and progression checks
remain open. See `docs/active-work.md` for current normal-link/report status.

## Historical evidence, scoped to each checkpoint

**The fixed Oldale engine proof and full reference constructor execute on ARM,
but this is not a verified full-game randomizer. The proposed workspace lifetime
passes at controlled test startup; Algorithm 3 takes about 41 target minutes and
is rejected for synchronous integration.**

**Algorithm 4's exact 32-layout schema-1 bank and loader now pass on ARM:
45.612 ms for selected-row CRC plus 532-record publication, without `WrWork`.
It is a viable fallback, not the intended final on-demand randomizer.**

**The exact C7A cap-4 candidate now passes on ARM and is 36.636x faster than
Algorithm 3 for seed 0, but still blocks for 67.136 seconds; retrying seed 42
takes 131.465 seconds. Algorithm ID 5 remains unassigned.**

**C7C preserves all 68 recorded C7A layouts with an SCC/bitset closure and
reduces target workspace from 47,388 to 10,944 bytes. ARM time improves to
38.032 seconds for seed 0 and 75.148 seconds for retrying seed 42—still
unacceptable synchronously. C7 is closed without assigning Algorithm ID 5.**

**C8A adds event-driven delta propagation and still exactly matches all 68 C7A
layouts. ARM time falls to 23.931 seconds for seed 0 and 45.469 seconds for
retrying seed 42, with a 13,776-byte workspace. This remains too slow;
Algorithm ID 5 stayed unassigned and the result led to C8B's cap sweep.**

**C8B finds cap three is the lowest reliable trial policy: 68/68 standard and
1,024/1,024 stress seeds pass with deterministic replay and independent
validation. ARM time is still 21.813 seconds for seed 0 and 36.021 seconds for
retrying seed 42. Trial-cap tuning is exhausted; Algorithm ID 5 remained
unassigned and that result led to C8C's indexed-state experiment.**

**C8C preserves that cap-three policy exactly while indexing representative
aliases and maintaining reverse-warp buckets incrementally. It matches C8B for
68/68 standard and 1,024/1,024 stress seeds. ARM time falls to 10.900 seconds
for seed 0 and 16.085 seconds for retrying seed 42, with the same 13,776-byte
workspace. C8 is complete; Algorithm ID 5 remains unassigned and C9A must test
indexed frontier/free-set maintenance against the remaining endpoint scans.**

**C9A preserves C8C exactly while maintaining compact free/reached/home
representative bitsets. It matches C8C for 68/68 standard and 1,024/1,024 stress
seeds. ARM time falls to 7.609 seconds for seed 0 and 9.357 seconds for retrying
seed 42, with a 14,224-byte workspace and exact heap restoration. The gain is
material but still misses the provisional two-second budget by 3.8x–4.7x.
Algorithm ID 5 remains unassigned; C9B must profile and reduce trial-state
propagation or trigger an architecture/product reassessment.**

**C9B finds and removes a redundant second validation of the immutable graph
from successful emission while retaining the entry validation. It exactly
matches every C9A record and work counter over 68 standard and 1,024 stress
seeds. ARM time falls to 5.982 seconds for seed 0 and 7.730 seconds for seed 42;
workspace remains 14,224 bytes and the heap restores exactly. A standalone
graph check costs 1.608 seconds and post-check emission 0.533 seconds, but even
excluding both leaves 3.841–5.590 seconds. Algorithm ID 5 remains unassigned;
this result led to C9C's final bounded reference-specialization gate.**

**C9C replaces runtime alias discovery/de-duplication/sorting with 532 generated
ordered records and separates cold validation from warm immutable-reference
generation. It remains exact over 68 standard and 1,024 stress seeds. ARM cold
time is 5.439–7.159 seconds; warm time is 3.807–5.527 seconds, with a separately
reported 1.632-second approval. The warm constructor still misses the two-second
budget, so incremental synchronous optimization of this scheduler is closed.
Next: frame-sliced asynchronous execution or a different constructor. Algorithm
ID 5 remains unassigned.**

**C10A makes the exact C9C scheduler cooperative. All 68 standard and 1,024
stress seeds remain exact across different advance budgets; cancellation
publishes nothing and restart reuses the workspace safely. ARM total time is
3.992–5.871 seconds, only 4.9–6.2% above C9C. Most phases are sub-frame, but a
worst partner trial takes 1.604 frames and final validation takes 3.382 frames.
C10B must split those two propagation paths before a one-frame callback budget
or UI integration can be claimed. Algorithm ID 5 remains unassigned.**

**C10B makes partner-trial propagation, repair and final validation internally
resumable while preserving exact C9C queue/RNG/counter behavior. All 68 standard
and 1,024 stress seeds remain exact across alternate schedules. The ARM suite
passes 11/11; the worst isolated step is 2,383 ticks (0.543 frame), down from
14,842 ticks in C10A. Total time rises to 5.894–8.459 seconds because the
one-component quantum is conservative. Next: integrate a timer-budgeted engine
callback and lifecycle/UI proof. Algorithm ID 5 remains unassigned.**

**C10C runs C10B through an actual engine task with a 3,200-tick admission
budget, retry-aware monotonic progress, next-callback cancellation,
success-only publication and exactly-once cleanup. All 68 standard and 1,024
stress seeds remain exact under alternate schedules. The ARM suite passes
11/11. Under a second 2,048-iteration task, the worst callback is 2,962 ticks
and worst whole task frame 3,869/4,389 ticks. Seed 0/42 take 685/1,102 frames
(about 11.4/18.4 seconds at 60 Hz). C10D must repeat this in a real rendered
loading/input flow and prove the production allocation point. Algorithm ID 5
remains unassigned.**

**C10D runs that exact generator behind a real engine window and main callback,
with throttled progress/activity rendering, attempt slots, sound requests,
normal VBlank DMA/audio work and B cancellation through `JOY_NEW`. Both proof
modes pass 11/11 in bundled mGBA. Seed 0/42 take 883/1,264 screen frames
(14.7/21.1 seconds); the worst generator callback is 2,366 ticks and worst
measured main-plus-VBlank frame is 4,079/4,389 ticks, leaving 310 ticks and no
missed VBlank deadlines. The workspace allocates after window initialization,
releases before screen teardown and the heap restores exactly. The available
runner is headless, and the project owner completed its graphical complement in
mGBA: all seven observations passed, including readable rendering, activity and
attempt motion, clean audio, both success terminals and physical B cancellation
only on run three. The submitted log retains the exact success digests/work
counts, zero deadline misses, lifecycle invariants and `PASS`; its worst active
frame was 4,209/4,389 ticks. This is user-observed, not independently watched by
Codex, and mGBA version/platform were not recorded. Production new-game/save
wiring, stack high-water and Algorithm 5 identity remain open.**

**C10E installs that exact lifecycle in a disabled-by-default production
`CB2_NewGame` wrapper. Both proof modes pass 12/12 ARM tests and enabled and
disabled normal ROMs link. Seed 0/42 retain exact C9C digests; the worst active
frame is 4,088/4,389 ticks with zero deadline misses. Cancellation, allocation
failure and publication failure all return to title with no valid table and no
silent ordinary-game fallback. The enabled normal link costs 16,852 EWRAM
bytes, no IWRAM and 107,412 ROM bytes, leaving 18,876 EWRAM bytes. A runtime
canary observes 1,528 bytes stack high-water with 2,404 bytes margin in the ARM
test path. The owner completed the Windows mGBA 0.10.5 graphical success/cancel
check and approved C11A; both functional paths passed, while each submitted
runtime line recorded one missed deadline and 1,796 bytes positive stack
margin.**

**C11A assigns Algorithm 5/ruleset 1 and adds a 64-byte explicit, checksummed
SaveBlock3 identity. Continue regenerates asynchronously and publishes only
when version, algorithm, ruleset, reference fingerprint and successful attempt
all match. Ordinary static `SetupWarp` events use the active table after target
group/map/warp bounds checks. Both proof modes pass 13/13: actual flash save,
runtime reset, same digest `3d354fa7`, target interception, reset cleanup and
CRC/version/ruleset/fingerprint/attempt failures. Enabled and disabled normal
ROMs link; the delta is 16,964 EWRAM, no IWRAM and 108,744 ROM bytes, leaving
18,764 EWRAM bytes. Interactive power-cycle/walking and target-data approval
remain open; no playable preset is claimed.**

| Area | Current evidence | Remaining gate |
|---|---|---|
| Inputs | Four exact source pins, raw hashes, historical fallback comment and checksum-pinned ARM dependencies | Target gameplay interpretation and unresolved-name intent |
| Portable data/core | Algorithm 3: 16 regressions and ASan/UBSan pass; 68/68 reference seeds accepted with independent validation | Keep as offline bank builder; reference-model acceptance is not target playability |
| Fixed engine proof | Both normal ROM modes build; 10/10 ARM tests pass in each mode under headless mGBA | Player-controlled walking, animations, full restart/Continue |
| Full generator on ARM | Seed 0 emits the expected 532-record mapping; combined suite 11/11 passes | Current 2,459.61-second runtime is unusable; reduce total work before yielding/integration |
| Precomputed bank | 32/32 independently validated layouts; Algorithm-4 host tests pass; ARM combined suite 11/11; 45.612 ms load; 61,893-byte test-link ROM delta; exact 16,436-byte EWRAM delta | Bank-aware restore, production hook/link measurement and new-game UI; retain as fallback while Algorithm 5 is investigated |
| Heap lifetime | 47,388-byte `WrWork` allocates from a controlled 115,760-byte free block, leaves 68,356 contiguous, restores exactly, and `WrActive` remains usable | Prove intended new-game heap state and explicit allocation failure path |
| Resources | C11A enabled normal link adds 16,964 EWRAM and 108,744 ROM, no IWRAM; leaves 18,764 EWRAM and 6,693,244 ROM bytes | Recheck stack/frame behavior in the graphical restore path and after target-data changes |
| On-demand follow-up | C11A dual modes pass 13/13; flash identity, deterministic Continue reconstruction, target event interception and incompatibility paths pass; enabled/disabled normal ROMs link | Graphical power-cycle/Continue, walking, and target-approved data |
| Workspace | C11A allocates 14,224-byte work during generation/restore and releases exactly; persistent table remains 16,436 bytes | Remeasure interactive restore and worst-case retries |
| Recovery | C10E manual record plus C11A production patch/runtime/codec, dual-mode logs, normal-link reports, checked JSON and standalone handoff | C11B target data and interactive coverage |

C4's standalone struct-size figures were low because its audit omitted
`-mabi=apcs-gnu`; each large buffer was understated by 4,096 bytes. The audit is
fixed. Both buffers total 63,824 target bytes and cannot be additional globals;
persisting only `WrActive` would leave 19,288 bytes in the current normal link.
The largest compiler-reported own core frame is 316 bytes, not a runtime stack
high-water measurement.

Unknown requirements remain unavailable to the solver and reported. Both
WEATHER_INSTITUTE and HOENN_FLASH_1 are ungrantable by default; no automatic
alias. The fallback is conservative solver policy, not proof that every token
or physical route is intentionally blocked.

Target-data blockers remain: 12 destination mismatches, one absent reference
endpoint, 1,729 target-only events, two geometry changes on matched annotated
endpoints and 13 unmodeled excluded vanilla transitions. The fixed proof and
reference-model generator do not validate champion completion.

Current C5 evidence is under `reports/engine-proof/generator-*`; C6A/B evidence
is preserved, while C6C results are `reports/engine-proof/bank-*`,
`docs/bank-arm-checkpoint.md` and `docs/mimo-optimization-assessment.md`.
Historical algorithm-2 failures remain
under `reports/algorithm2/`; C3 construction and C4 engine evidence retain their
checkpoint identities. Read HANDOFF.md first when resuming.
C7A evidence is in `docs/c7a-feasibility.md`; C7B ARM evidence is in
`docs/c7b-arm-checkpoint.md`; final C7C evidence is in
`docs/c7c-scc-checkpoint.md`, `reports/c7c-*` and `reports/engine-proof/c7c-*`.
C8A evidence is in `docs/c8a-event-checkpoint.md`, `reports/c8a-*` and
`reports/engine-proof/c8a-*`.
C8B evidence is in `docs/c8b-trial-volume-checkpoint.md`, `reports/c8b-*`
and `reports/engine-proof/c8b-*`.
C8C evidence is in `docs/c8c-indexed-state-checkpoint.md`, `reports/c8c-*`
and `reports/engine-proof/c8c-*`.
C9A evidence is in `docs/c9a-representative-bitset-checkpoint.md`,
`reports/c9a-*` and `reports/engine-proof/c9a-*`.
C9B evidence is in `docs/c9b-validated-emission-checkpoint.md`,
`reports/c9b-*` and `reports/engine-proof/c9b-*`.
C9C evidence is in `docs/c9c-cold-warm-checkpoint.md`, `reports/c9c-*` and
`reports/engine-proof/c9c-*`.
C10A evidence is in `docs/c10a-cooperative-checkpoint.md`, `reports/c10a-*`
and `reports/engine-proof/c10a-*`.
C10B evidence is in `docs/c10b-frame-bounded-checkpoint.md`, `reports/c10b-*`
and `reports/engine-proof/c10b-*`.
C10C evidence is in `docs/c10c-budgeted-task-checkpoint.md`, `reports/c10c-*`
and `reports/engine-proof/c10c-*`.
C10D evidence is in `docs/c10d-rendered-mgba-checkpoint.md`,
`docs/c10d-mgba-manual-test.md` and `reports/engine-proof/c10d-*`, including
the owner-observed `c10d-human-graphical.*` record.
C10E evidence is in `docs/c10e-production-checkpoint.md`,
`docs/c10e-mgba-manual-test.md`, `reports/c10e-verification.json` and
`reports/engine-proof/c10e-*`.
C11A evidence is in `docs/c11a-save-restore-checkpoint.md` and
`reports/engine-proof/c11a-*`.
