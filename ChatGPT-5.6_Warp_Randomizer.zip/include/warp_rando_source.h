#ifndef WARP_RANDO_SOURCE_H
#define WARP_RANDO_SOURCE_H
#include "warp_rando.h"

struct WrSourceRoute {
    struct WrKey source, expected, trigger;
    uint16_t x, y;
    uint8_t elevation;
};

/* Sorted, immutable build-time routes. No match leaves output unchanged. */
int wr_source_normalize(const struct WrSourceRoute *routes, size_t count,
                        const struct WrKey *source, const struct WrKey *requested,
                        uint16_t x, uint16_t y, uint8_t elevation,
                        struct WrKey *out);
#endif
