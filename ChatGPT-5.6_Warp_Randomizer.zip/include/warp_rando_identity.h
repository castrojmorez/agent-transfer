#ifndef WARP_RANDO_IDENTITY_H
#define WARP_RANDO_IDENTITY_H

#include "warp_rando.h"

#define WR_IDENTITY_SAVE_BYTES 64u
#define WR_IDENTITY_SAVE_VERSION 1u
#define WR_IDENTITY_SAVE_READY 1u

/*
 * Versioned, fixed-width save envelope. Multi-byte fields are little-endian;
 * callers must not persist the compiler's struct layout directly.
 */
int wr_identity_save_encode(const struct WrActive *active,
                            uint8_t out[WR_IDENTITY_SAVE_BYTES]);
int wr_identity_save_decode(const uint8_t in[WR_IDENTITY_SAVE_BYTES],
                            uint32_t expected_algorithm,
                            uint32_t expected_ruleset,
                            const uint8_t expected_fingerprint[32],
                            struct WrIdentity *identity,
                            uint16_t *attempt);

#endif
