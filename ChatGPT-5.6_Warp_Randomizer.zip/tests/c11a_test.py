#!/usr/bin/env python3
"""C11A versioned save-identity envelope tests."""
import json
import os
import pathlib
import subprocess
import tempfile
import unittest

ROOT = pathlib.Path(__file__).resolve().parents[1]


class C11AIdentity(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.temp = tempfile.TemporaryDirectory()
        cls.exe = pathlib.Path(cls.temp.name) / "save-identity"
        command = [
            os.environ.get("CC", "cc"), "-std=c99", "-Wall", "-Wextra",
            "-Werror", "-pedantic", "-O1", "-g", "-I" + str(ROOT / "include"),
            str(ROOT / "src/warp_rando_identity.c"),
            str(ROOT / "tests/save_identity_harness.c"), "-o", str(cls.exe),
        ]
        if os.environ.get("SANITIZE") == "1":
            command[1:1] = ["-fsanitize=address,undefined",
                            "-fno-omit-frame-pointer", "-fno-pie", "-no-pie"]
        subprocess.run(command, check=True)

    @classmethod
    def tearDownClass(cls):
        cls.temp.cleanup()

    def invoke(self, mode):
        run = subprocess.run([str(self.exe), mode], text=True,
                             capture_output=True, check=True)
        return json.loads(run.stdout)

    def test_round_trip_is_explicit_and_fixed_width(self):
        row = self.invoke("roundtrip")
        self.assertEqual(row, {"result": 0, "seed": 0xFEDCBA98,
                               "algorithm": 5, "ruleset": 1,
                               "attempt": 7, "bytes": 64})

    def test_invalid_active_state_cannot_be_serialized(self):
        self.assertEqual(self.invoke("invalid_active")["result"], 11)

    def test_corruption_and_semantic_mismatches_are_rejected(self):
        for mode in ("corrupt", "version", "size", "state", "reserved",
                     "algorithm", "ruleset", "fingerprint"):
            with self.subTest(mode=mode):
                self.assertEqual(self.invoke(mode)["result"], 11)


if __name__ == "__main__":
    unittest.main(verbosity=2)
