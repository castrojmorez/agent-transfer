#include "warp_rando_identity.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

/* This harness allocates no heap. Keep the documented restricted-runtime
 * LeakSanitizer opt-out while retaining ASan bounds and UBSan checks. */
int __lsan_is_turned_off(void) { return 1; }

static uint32_t crc32(const uint8_t *p, size_t size)
{
    uint32_t crc = UINT32_MAX;
    size_t i;
    unsigned bit;
    for (i = 0; i < size; i++)
    {
        crc ^= p[i];
        for (bit = 0; bit < 8; bit++)
            crc = (crc >> 1) ^ (0xedb88320u & (0u - (crc & 1u)));
    }
    return ~crc;
}

static void put32(uint8_t *p, uint32_t value)
{
    p[0] = (uint8_t)value;
    p[1] = (uint8_t)(value >> 8);
    p[2] = (uint8_t)(value >> 16);
    p[3] = (uint8_t)(value >> 24);
}

int main(int argc, char **argv)
{
    const char *mode = argc > 1 ? argv[1] : "roundtrip";
    struct WrActive active = {0};
    struct WrIdentity decoded = {0};
    uint8_t saved[WR_IDENTITY_SAVE_BYTES];
    uint8_t fingerprint[32];
    uint16_t attempt = 0;
    unsigned i;
    int result;

    for (i = 0; i < sizeof(fingerprint); i++)
        fingerprint[i] = (uint8_t)(i * 7u + 3u);
    active.identity.seed = 0xfedcba98u;
    active.identity.algorithm = 5;
    active.identity.ruleset = 1;
    memcpy(active.identity.data, fingerprint, sizeof(fingerprint));
    active.attempt = 7;
    active.count = 1;
    active.valid = 1;
    if (wr_identity_save_encode(&active, saved) != WR_OK)
        return 2;

    if (!strcmp(mode, "invalid_active"))
    {
        active.valid = 0;
        result = wr_identity_save_encode(&active, saved);
    }
    else
    {
        if (!strcmp(mode, "corrupt"))
            saved[20] ^= 1;
        else if (!strcmp(mode, "version"))
            saved[4]++;
        else if (!strcmp(mode, "size"))
            saved[6]--;
        else if (!strcmp(mode, "state"))
            saved[54]++;
        else if (!strcmp(mode, "reserved"))
            saved[58] = 1;
        else if (!strcmp(mode, "algorithm"))
            put32(saved + 12, 4);
        else if (!strcmp(mode, "ruleset"))
            put32(saved + 16, 2);
        else if (!strcmp(mode, "fingerprint"))
            saved[20] ^= 1;
        else if (strcmp(mode, "roundtrip"))
            return 3;
        if (strcmp(mode, "corrupt"))
            put32(saved + 60, crc32(saved, 60));
        result = wr_identity_save_decode(saved, 5, 1, fingerprint,
                                         &decoded, &attempt);
    }

    printf("{\"result\":%d,\"seed\":%u,\"algorithm\":%u,"
           "\"ruleset\":%u,\"attempt\":%u,\"bytes\":%u}\n",
           result, decoded.seed, decoded.algorithm, decoded.ruleset, attempt,
           (unsigned)sizeof(saved));
    return 0;
}
