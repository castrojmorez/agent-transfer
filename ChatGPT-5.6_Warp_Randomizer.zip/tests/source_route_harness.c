#include "warp_rando_source.h"
#include "target-source-routes.h"
#include <assert.h>
#include <stdio.h>

int __lsan_is_turned_off(void) { return 1; }
static int same(struct WrKey a, struct WrKey b)
{ return a.group == b.group && a.map == b.map && a.warp == b.warp; }

int main(void)
{
    size_t i;
    unsigned normalized = 0;
    struct WrKey sentinel = {127,127,127};
    const struct WrKey denied[] = {{13,8,0},{13,8,1},{24,33,2},{127,127,127}};
    for (i = 0; i < WARP_RANDO_SOURCE_ROUTE_COUNT; i++) {
        const struct WrSourceRoute *row = &gWarpRandoSourceRoutes[i];
        struct WrKey out = sentinel, changed = row->expected;
        assert(wr_source_normalize(gWarpRandoSourceRoutes, WARP_RANDO_SOURCE_ROUTE_COUNT,
            &row->source, &row->expected, row->x, row->y, row->elevation, &out));
        assert(same(out, row->trigger));
        normalized += !same(row->expected, row->trigger);
        out = sentinel;
        changed.warp ^= 1;
        assert(!wr_source_normalize(gWarpRandoSourceRoutes, WARP_RANDO_SOURCE_ROUTE_COUNT,
            &row->source, &changed, row->x, row->y, row->elevation, &out));
        assert(same(out, sentinel));
        assert(!wr_source_normalize(gWarpRandoSourceRoutes, WARP_RANDO_SOURCE_ROUTE_COUNT,
            &row->source, &row->expected, row->x ^ 1, row->y, row->elevation, &out));
        assert(!wr_source_normalize(gWarpRandoSourceRoutes, WARP_RANDO_SOURCE_ROUTE_COUNT,
            &row->source, &row->expected, row->x, row->y ^ 1, row->elevation, &out));
        assert(!wr_source_normalize(gWarpRandoSourceRoutes, WARP_RANDO_SOURCE_ROUTE_COUNT,
            &row->source, &row->expected, row->x, row->y, row->elevation ^ 1, &out));
        assert(same(out, sentinel));
    }
    for (i = 0; i < sizeof(denied) / sizeof(*denied); i++) {
        struct WrKey out = sentinel;
        assert(!wr_source_normalize(gWarpRandoSourceRoutes, WARP_RANDO_SOURCE_ROUTE_COUNT,
            &denied[i], &sentinel, 0, 0, 0, &out));
        assert(same(out, sentinel));
    }
    assert(!wr_source_normalize(NULL, 1, &sentinel, &sentinel, 0, 0, 0, &sentinel));
    assert(!wr_source_normalize(gWarpRandoSourceRoutes, 0, &sentinel, &sentinel, 0, 0, 0, &sentinel));
    assert(normalized == 5);
    printf("source_routes=%u normalized=%u denied=4 signatures=pass\n",
           (unsigned)WARP_RANDO_SOURCE_ROUTE_COUNT, normalized);
    return 0;
}
