#!/usr/bin/env python3
"""Synthetic regression coverage for target reconciliation, without game assets."""
import pathlib
import sys
import unittest
import os
import subprocess
import tempfile

sys.path.insert(0, str(pathlib.Path(__file__).resolve().parents[1] / 'tools/audit'))
from c11b_reconcile import reconcile
from compile_source_routes import build_routes


def node(name, rep=None, active=True, trigger=(0, 0, 0)):
    return dict(name=name, rep=rep or name, active=active, trigger=trigger)


def event(to='E,0,0,0'):
    return dict(to=to, map='MAP_TEST')


class Reconciliation(unittest.TestCase):
    def test_compiled_routes_and_failure_signatures(self):
        root = pathlib.Path(__file__).resolve().parents[1]
        with tempfile.TemporaryDirectory() as tmp:
            exe = str(pathlib.Path(tmp) / 'source-routes')
            flags = ['-fsanitize=address,undefined', '-fno-pie', '-no-pie'] if os.environ.get('SANITIZE') == '1' else []
            subprocess.run([os.environ.get('CC', 'cc'), '-std=c99', '-Wall', '-Wextra',
                            '-Werror', '-O1', *flags, '-I' + str(root / 'include'),
                            '-I' + str(root / 'data'), str(root / 'src/warp_rando_source.c'),
                            str(root / 'tests/source_route_harness.c'), '-o', exe], check=True)
            output = subprocess.check_output([exe], text=True)
            self.assertIn('source_routes=608 normalized=5 denied=4 signatures=pass', output)

    def test_route_compiler_rejects_missing_active_source(self):
        with self.assertRaises(ValueError):
            build_routes([node('E,0,0,0')], {})

    def test_group_aliases_are_not_conflicts(self):
        result = reconcile([node('a'), node('b', rep='a')],
                           {'a': event(), 'b': event()})
        self.assertEqual(result['shared_trigger_conflicts'], [])

    def test_distinct_groups_sharing_destination_are_conflicts(self):
        result = reconcile([node('a'), node('b')], {'a': event(), 'b': event()})
        self.assertTrue(result['shared_trigger_conflicts'][0]['cross_group'])

    def test_target_only_source_can_enter_active_trigger_namespace(self):
        result = reconcile([node('a')], {'a': event(), 'unknown': event()})
        self.assertTrue(result['shared_trigger_conflicts'][0]['mixed_participation'])
        self.assertEqual(result['unintended_source_exposures'][0]['source'], 'unknown')

    def test_inactive_sources_are_exposures_too(self):
        result = reconcile([node('a'), node('b', active=False)],
                           {'a': event(), 'b': event()})
        self.assertEqual(result['counts']['unintended_source_exposures'], 1)

    def test_missing_and_synthetic_trigger_are_retained(self):
        result = reconcile([node('a', trigger=(24, 24, 52)), node('missing')],
                           {'a': event()})
        self.assertEqual(result['counts']['missing_sources'], 1)
        self.assertFalse(result['destination_mismatches'][0]['reference_trigger_is_target_endpoint'])

    def test_invalid_representative_is_rejected(self):
        with self.assertRaises(ValueError):
            reconcile([node('a', rep='missing')], {})


if __name__ == '__main__':
    unittest.main(verbosity=2)
