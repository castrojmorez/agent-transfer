#!/usr/bin/env python3
"""Validate C10E dual-mode logs and enabled/disabled normal-link resources."""
import argparse
import hashlib
import json
import pathlib
import re

p = argparse.ArgumentParser(description=__doc__)
p.add_argument("mode0")
p.add_argument("mode1")
p.add_argument("enabled_resources")
p.add_argument("disabled_resources")
p.add_argument("enabled_rom_log")
p.add_argument("disabled_rom_log")
p.add_argument("output")
a = p.parse_args()


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def parse_log(path):
    text = path.read_text()
    metrics = {}
    for marker in ("WRC10E0 ", "WRC10E42 ", "WRC10ECANCEL ",
                   "WRC10EALLOC ", "WRC10EPUBLISH ", "WRC10ESTACK "):
        match = re.search(r"GBA Debug: " + marker + r"([^\r\n]+)", text)
        if not match:
            raise SystemExit(f"missing {marker.strip()} in {path}")
        metrics.update({key: int(value)
                        for key, value in re.findall(r"(\w+)=(-?\d+)", match.group(1))})
    passes = text.count("GBA Debug: :P")
    if passes != 12:
        raise SystemExit(f"unexpected pass count {passes}/12 in {path}")
    return metrics, passes


mode0 = pathlib.Path(a.mode0)
mode1 = pathlib.Path(a.mode1)
enabled_path = pathlib.Path(a.enabled_resources)
disabled_path = pathlib.Path(a.disabled_resources)
enabled_log = pathlib.Path(a.enabled_rom_log)
disabled_log = pathlib.Path(a.disabled_rom_log)
m0, passes0 = parse_log(mode0)
m1, passes1 = parse_log(mode1)
if m0 != m1:
    raise SystemExit("C10E metrics differ between proof modes")

expected = {
    "digest0_decimal": -755938432,
    "digest42_decimal": 1026903975,
    "steps0": 66274,
    "steps42": 94230,
    "attempt42": 1,
    "completion0": 1,
    "completion42": 1,
    "result_cancel": 101,
    "publishes_cancel": 0,
    "releases_cancel": 1,
    "valid_cancel": 0,
    "abort_cancel": 1,
    "alloc_result": 1,
    "alloc_release": 0,
    "alloc_abort": 1,
    "publish_result": 1,
    "publish_publish": 0,
    "publish_release": 1,
    "publish_abort": 1,
    "deadline0": 0,
    "deadline42": 0,
    "deadline_cancel": 0,
    "deadline_publish": 0,
    "algorithm": 0,
    "active_size": 16436,
    "heap_before": 115760,
    "heap_after": 115760,
}
for key, value in expected.items():
    if m0.get(key) != value:
        raise SystemExit(f"unexpected {key}: {m0.get(key)} != {value}")
if max(m0["callback_max0"], m0["callback_max42"]) > 2800:
    raise SystemExit("generator callback exceeds C10E admission budget")
if max(m0["active_max0"], m0["active_max42"],
       m0["active_max_publish"]) >= 4389:
    raise SystemExit("C10E active frame exceeds nominal frame")
if m0["margin"] < 512:
    raise SystemExit("C10E stack canary margin below acceptance floor")

enabled = json.loads(enabled_path.read_text())
disabled = json.loads(disabled_path.read_text())
delta = {region: enabled["regions"][region]["static_span_bytes"]
                 - disabled["regions"][region]["static_span_bytes"]
         for region in ("EWRAM", "IWRAM", "ROM")}
screen_state = delta["EWRAM"] - m0["active_size"]
if delta["EWRAM"] != 16852 or delta["IWRAM"] != 0 or screen_state != 416:
    raise SystemExit(f"unexpected linked resource delta: {delta}, screen={screen_state}")

report = {
    "checkpoint": "C10E",
    "decision": "opt-in production new-game wrapper passes automated ARM gate; graphical normal-ROM success/cancellation observation remains",
    "scope": "C10D-exact cooperative generator moved into a production source module and gated at CB2_NewGame, with boot approval, fail-closed callbacks, normal-link resource comparison and system-stack canary",
    "target_commit": "e8bd1cd7b03fc032ea37e3ecd38b379b5d01a1e7",
    "modes": {
        "proof_disabled_passes": passes0,
        "proof_enabled_passes": passes1,
        "normal_rom_enabled_build": "pass",
        "normal_rom_disabled_build": "pass",
    },
    "metrics": m0,
    "correctness": {
        "seed0_exact_c9c": True,
        "seed42_exact_c9c": True,
        "seed0_digest": "d2f14b80",
        "seed42_digest": "3d354fa7",
        "proof_modes_identical": True,
    },
    "production_lifecycle": {
        "compile_time_opt_in_default": False,
        "hook": "CB2_NewGame wrapper after Birch/quickstart and before original field initialization",
        "immutable_approval": "AgbMain after InitHeap and before visible main callbacks",
        "success_callback": "original CB2_NewGame body",
        "cancel_or_failure_callback": "CB2_InitTitleScreen",
        "silent_unrandomized_fallback": False,
        "terminal_hold_frames": 60,
        "workspace_allocation": "after window initialization",
        "workspace_release": "before window teardown",
    },
    "timing": {
        "generator_budget_ticks": 2800,
        "nominal_frame_ticks": 4389,
        "worst_generator_callback_ticks": max(m0["callback_max0"], m0["callback_max42"]),
        "worst_active_ticks": max(m0["active_max0"], m0["active_max42"], m0["active_max_publish"]),
        "minimum_headroom_ticks": 4389 - max(m0["active_max0"], m0["active_max42"], m0["active_max_publish"]),
        "missed_deadlines": 0,
    },
    "stack_canary": {
        "test_link_high_water_bytes": m0["high_water"],
        "test_link_margin_bytes": m0["margin"],
        "patterned_span_bytes": m0["high_water"] + m0["margin"],
        "normal_link_iwram_static_span_bytes": enabled["regions"]["IWRAM"]["static_span_bytes"],
        "normal_link_iwram_unallocated_bytes": enabled["regions"]["IWRAM"]["unallocated_bytes"],
        "interpretation": "The canary executes target ARM runtime code with the same normal-link IWRAM static floor, but the final graphical CB2_NewGame path still needs its emitted WRC10ERUNTIME observation.",
    },
    "normal_link_delta": {
        "enabled_minus_disabled_ewram_bytes": delta["EWRAM"],
        "active_table_bytes": m0["active_size"],
        "runtime_screen_canary_state_bytes": screen_state,
        "enabled_minus_disabled_iwram_bytes": delta["IWRAM"],
        "enabled_minus_disabled_rom_bytes": delta["ROM"],
        "enabled_unallocated_ewram_bytes": enabled["regions"]["EWRAM"]["unallocated_bytes"],
        "enabled_unallocated_rom_bytes": enabled["regions"]["ROM"]["unallocated_bytes"],
    },
    "failure_paths": {
        "cancellation": "invalid, no publication, one release, abort callback",
        "workspace_allocation_failure": "invalid, no publication, no release of absent allocation, abort callback",
        "publication_failure": "invalid, no publication, one release, abort callback",
    },
    "identity": {
        "published_test_value": 0,
        "algorithm5_assigned": False,
        "seed_source": "temporary compile-time C10E integration option",
    },
    "evidence": {
        "mode0_log_sha256": sha(mode0),
        "mode1_log_sha256": sha(mode1),
        "enabled_resources_sha256": sha(enabled_path),
        "disabled_resources_sha256": sha(disabled_path),
        "enabled_rom_build_log_sha256": sha(enabled_log),
        "disabled_rom_build_log_sha256": sha(disabled_log),
        "enabled_elf_sha256": enabled["elf_sha256"],
        "disabled_elf_sha256": disabled["elf_sha256"],
    },
    "evidence_limits": [
        "The normal ROM links with the production wrapper enabled, but automated tests call the production runtime API with controlled callbacks rather than navigating Birch/quickstart.",
        "The final graphical success and cancellation paths, including their WRC10ERUNTIME stack lines, require the short manual mGBA checklist.",
        "The generated active table is not yet wired into target warp interception or SaveBlock persistence.",
        "Algorithm 5 remains unassigned and the compile-time seed is not the final seed UI or save contract.",
        "Target-world completion remains unproven."
    ],
    "next": "run the C10E normal-ROM graphical checklist, then design versioned save identity and active-table restore/interception",
}

out = pathlib.Path(a.output)
out.write_text(json.dumps(report, indent=2) + "\n")
print(json.dumps(report, indent=2))
