#!/usr/bin/env python3
"""Validate C11A dual-mode logs and enabled/disabled normal-link resources."""
import argparse
import hashlib
import json
import pathlib
import re

p = argparse.ArgumentParser(description=__doc__)
p.add_argument("mode0")
p.add_argument("mode1")
p.add_argument("enabled_resources")
p.add_argument("disabled_resources")
p.add_argument("enabled_rom_log")
p.add_argument("disabled_rom_log")
p.add_argument("output")
p.add_argument('--source-aware', action='store_true', help='validate current C11B source-gated suite')
a = p.parse_args()


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def parse_log(path):
    text = path.read_text()
    metrics = {}
    for marker in ("WRC11AREST ", "WRC11ARESET ", "WRC11AFAIL "):
        match = re.search(r"GBA Debug: " + marker + r"([^\r\n]+)", text)
        if not match:
            raise SystemExit(f"missing {marker.strip()} in {path}")
        metrics.update({key: int(value)
                        for key, value in re.findall(r"(\w+)=(-?\d+)", match.group(1))})
    passes = text.count("GBA Debug: :P")
    required = 14 if a.source_aware else 13
    if passes != required or 'GBA Debug: :F' in text:
        raise SystemExit(f"unexpected pass count/failure {passes}/{required} in {path}")
    return metrics, passes


mode0 = pathlib.Path(a.mode0)
mode1 = pathlib.Path(a.mode1)
enabled_path = pathlib.Path(a.enabled_resources)
disabled_path = pathlib.Path(a.disabled_resources)
enabled_log = pathlib.Path(a.enabled_rom_log)
disabled_log = pathlib.Path(a.disabled_rom_log)
m0, passes0 = parse_log(mode0)
m1, passes1 = parse_log(mode1)
if m0 != m1:
    raise SystemExit("C11A metrics differ between proof modes")

expected = {
    "result": 0,
    "algorithm": 5,
    "attempt": 1,
    "digest_decimal": 1026903975,
    "flash": 1,
    "intercept": 1,
    "active": 0,
    "corrupt": 1,
    "version": 1,
    "ruleset": 1,
    "fingerprint": 1,
    "attempt_result": 11,
    "heap_before": 115760,
    "heap_after": 115760,
}
for key, value in expected.items():
    if m0.get(key) != value:
        raise SystemExit(f"unexpected {key}: {m0.get(key)} != {value}")

enabled = json.loads(enabled_path.read_text())
disabled = json.loads(disabled_path.read_text())
delta = {region: enabled["regions"][region]["static_span_bytes"]
                 - disabled["regions"][region]["static_span_bytes"]
         for region in ("EWRAM", "IWRAM", "ROM")}
if delta["EWRAM"] != 16964 or delta["IWRAM"] != 0:
    raise SystemExit(f"unexpected linked resource delta: {delta}")

report = {
    "checkpoint": "C11B-2" if a.source_aware else "C11A",
    "decision": "versioned Algorithm-5 save identity, asynchronous Continue reconstruction, reset cleanup and ordinary static-warp interception pass the automated ARM gate",
    "target_commit": "e8bd1cd7b03fc032ea37e3ecd38b379b5d01a1e7",
    "modes": {
        "proof_disabled_passes": passes0,
        "proof_enabled_passes": passes1,
        "normal_rom_enabled_build": "pass",
        "normal_rom_disabled_build": "pass",
    },
    "metrics": m0,
    "save_contract": {
        "bytes": 64,
        "format_version": 1,
        "algorithm": 5,
        "ruleset": 2 if a.source_aware else 1,
        "encoding": "explicit little-endian fields plus CRC32; no compiler struct layout",
        "persisted": ["seed", "algorithm", "ruleset", "reference fingerprint", "successful attempt", "ready state"],
        "restore": "regenerate asynchronously and publish only when the successful attempt matches",
        "failure_policy": "return to title with no valid active table",
    },
    "interception": {
        "path": "ordinary static event warps handled by SetupWarp",
        "target_validation": "group, map and landing warp bounds checked before target dereference",
        "other_transitions": "dynamic/script/Dive/fall/Escape and other non-SetupWarp paths remain vanilla",
    },
    "normal_link_delta": {
        "enabled_minus_disabled_ewram_bytes": delta["EWRAM"],
        "enabled_minus_disabled_iwram_bytes": delta["IWRAM"],
        "enabled_minus_disabled_rom_bytes": delta["ROM"],
        "enabled_unallocated_ewram_bytes": enabled["regions"]["EWRAM"]["unallocated_bytes"],
        "enabled_unallocated_iwram_bytes": enabled["regions"]["IWRAM"]["unallocated_bytes"],
        "enabled_unallocated_rom_bytes": enabled["regions"]["ROM"]["unallocated_bytes"],
    },
    "evidence": {
        "mode0_log_sha256": sha(mode0),
        "mode1_log_sha256": sha(mode1),
        "enabled_resources_sha256": sha(enabled_path),
        "disabled_resources_sha256": sha(disabled_path),
        "enabled_rom_build_log_sha256": sha(enabled_log),
        "disabled_rom_build_log_sha256": sha(disabled_log),
        "enabled_elf_sha256": enabled["elf_sha256"],
        "disabled_elf_sha256": disabled["elf_sha256"],
    },
    "evidence_limits": [
        "No graphical full power-cycle/Continue walkthrough has been observed for C11A.",
        "Interception is intentionally limited to ordinary static event warps.",
        "The reference graph still has known target-data drift and is not approved as a playable preset.",
        "Champion completion and long-form gameplay remain unproven.",
    ],
    "next": "C11B: target-approved traversal/progression data and interactive power-cycle/Continue and walking coverage",
}

if a.source_aware:
    source_metrics = []
    for path in (mode0, mode1):
        match = re.search(r'GBA Debug: WRC11BSOURCE ([^\r\n]+)', path.read_text())
        if not match:
            raise SystemExit('missing WRC11BSOURCE in ' + str(path))
        source_metrics.append({k: int(v) for k, v in re.findall(r'(\w+)=(-?\d+)', match[1])})
    wanted = dict(routes=608, normalized=5, excluded=3, stale=608,
                  ruleset=2, old_save_rejected=1, digest_decimal=-755938432)
    if source_metrics != [wanted, wanted]:
        raise SystemExit('source gate evidence differs from expected: ' + str(source_metrics))
    report['source_gate'] = wanted
    report['evidence_limits'][0] = 'No graphical full power-cycle/Continue or physical walking coverage has been observed for C11B.'
    report['decision'] = 'source-aware static-warp gate and normalization pass ARM regression; full C11B gameplay approval remains open'
    report['interception']['source_validation'] = '608 participants; exact source triple, destination and x/y/elevation; five synthetic normalizations'
    report['next'] = 'graphical power-cycle/Continue and landing/progression reconciliation; not a playable preset'
    report['evidence']['source_routes_sha256'] = sha(pathlib.Path(__file__).resolve().parents[2] / 'data/target-source-routes.h')

out = pathlib.Path(a.output)
out.write_text(json.dumps(report, indent=2) + "\n")
print(json.dumps(report, indent=2))
