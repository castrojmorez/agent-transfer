#!/usr/bin/env python3
"""Audit reference participation against literal target events; never rewrite data."""
import argparse
import collections
import hashlib
import json
import pathlib
import subprocess

from drift import load_maps

PIN = 'e8bd1cd7b03fc032ea37e3ecd38b379b5d01a1e7'


def reconcile(nodes, events):
    by_name = {n['name']: n for n in nodes}
    if len(by_name) != len(nodes):
        raise ValueError('duplicate node name')
    for node in nodes:
        if node['rep'] not in by_name:
            raise ValueError('missing representative: ' + node['rep'])
    missing = []
    mismatches = []
    buckets = collections.defaultdict(list)
    for key, event in sorted(events.items()):
        node = by_name.get(key)
        buckets[event['to']].append({
            'source': key,
            'reference_present': node is not None,
            'active': bool(node and node['active']),
            'representative': node['rep'] if node else None,
        })
    for node in nodes:
        key = node['name']
        expected = 'E,' + ','.join(map(str, node['trigger']))
        if key not in events:
            missing.append({'source': key, 'active': node['active'],
                            'representative': node['rep']})
        elif expected != events[key]['to']:
            mismatches.append({
                'source': key, 'map': events[key]['map'],
                'active': node['active'], 'representative': node['rep'],
                'reference_trigger': expected, 'target_trigger': events[key]['to'],
                'reference_trigger_is_target_endpoint': expected in events,
                'decision': 'OPEN: source-context normalization or explicit regrouping required',
            })
    conflicts = []
    for trigger, sources in sorted(buckets.items()):
        active = [s for s in sources if s['active']]
        if not active:
            continue
        reps = sorted({s['representative'] for s in active})
        other = [s for s in sources if not s['active']]
        if len(reps) > 1 or other:
            conflicts.append({'target_trigger': trigger,
                              'active_representatives': reps,
                              'cross_group': len(reps) > 1,
                              'mixed_participation': bool(other),
                              'sources': sources})
    # C11A performs destination-only lookup over reference trigger keys. Even an
    # unannotated/inactive source can accidentally enter that lookup namespace.
    active_triggers = {'E,' + ','.join(map(str, n['trigger']))
                       for n in nodes if n['active']}
    unintended = [{'target_trigger': trigger, 'source': s['source'],
                   'reference_present': s['reference_present']}
                  for trigger, sources in sorted(buckets.items())
                  if trigger in active_triggers
                  for s in sources if not s['active']]
    return {
        'counts': {'reference_nodes': len(nodes), 'target_events': len(events),
                   'target_only': len(set(events) - set(by_name)),
                   'missing_sources': len(missing),
                   'destination_mismatches': len(mismatches),
                   'active_destination_mismatches': sum(r['active'] for r in mismatches),
                   'shared_trigger_conflicts': len(conflicts),
                   'unintended_source_exposures': len(unintended)},
        'missing_sources': missing, 'destination_mismatches': mismatches,
        'shared_trigger_conflicts': conflicts,
        'unintended_source_exposures': unintended,
        'target_only_by_map': dict(sorted(collections.Counter(
            e['map'] for k, e in events.items() if k not in by_name).items())),
    }


def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('target', type=pathlib.Path)
    p.add_argument('output', type=pathlib.Path)
    a = p.parse_args()
    commit = subprocess.check_output(['git', '-C', str(a.target),
                                      'rev-parse', 'HEAD'], text=True).strip()
    if commit != PIN:
        p.error('target must be pinned expansion 1.17.0')
    # Source changes are legitimate in the integration checkout; map data is not.
    changed = subprocess.check_output(['git', '-C', str(a.target), 'status',
                                       '--porcelain', '--', 'data/maps'], text=True)
    if changed.strip():
        p.error('target map data differs from the pinned checkout')
    root = pathlib.Path(__file__).resolve().parents[2]
    graph_path = root / 'data/reference-normalized.json'
    graph = json.loads(graph_path.read_text())
    events, hashes = load_maps(a.target)
    report = reconcile(graph['nodes'], events)
    report.update(checkpoint='C11B-1', target_commit=commit,
                  scope='Static source/destination reconciliation only; not collision, script or progression approval',
                  graph_sha256=hashlib.sha256(graph_path.read_bytes()).hexdigest(),
                  target_map_hashes=hashes,
                  decision='Do not enable the reference-only runtime as a playable preset')
    a.output.parent.mkdir(parents=True, exist_ok=True)
    a.output.write_text(json.dumps(report, indent=2) + '\n')
    print(json.dumps(report['counts'], indent=2))


if __name__ == '__main__':
    main()
