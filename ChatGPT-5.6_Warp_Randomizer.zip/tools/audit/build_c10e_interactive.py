#!/usr/bin/env python3
"""Compatibility entry point; builds the CURRENT runtime, not historical C10E."""
import pathlib
import runpy
import sys

print("This entry point now builds experimental C11B, not historical C10E. "
      "Use a fresh save and docs/c11b-mgba-manual-test.md.", file=sys.stderr)
runpy.run_path(str(pathlib.Path(__file__).with_name("build_runtime_interactive.py")),
              run_name="__main__")
