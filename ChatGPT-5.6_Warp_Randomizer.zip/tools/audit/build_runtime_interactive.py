#!/usr/bin/env python3
"""Build the experimental current runtime ROM after its ARM preflight."""
import argparse
import json
import pathlib
import re
import subprocess
import sys

ROOT = pathlib.Path(__file__).resolve().parents[2]

p = argparse.ArgumentParser(description=__doc__)
p.add_argument("target")
p.add_argument("prefix")
p.add_argument("output")
p.add_argument("--seed", type=lambda value: int(value, 0), default=0)
p.add_argument("--jobs", type=int, default=4)
a = p.parse_args()
target = pathlib.Path(a.target).resolve()
prefix = pathlib.Path(a.prefix).resolve()
output = pathlib.Path(a.output).resolve()
if output.suffix.lower() != ".gba":
    p.error("output must end in .gba")
if not 0 <= a.seed <= 0xFFFFFFFF:
    p.error("seed must fit in u32")
if a.jobs < 1:
    p.error("jobs must be positive")

build = ROOT / "build/runtime-interactive"
build.mkdir(parents=True, exist_ok=True)
preflight_log = build / "headless-preflight.log"
rom_log = build / "normal-rom-build.log"
base = [
    sys.executable,
    str(ROOT / "tools/audit/build_engine_proof.py"),
    str(target),
    str(prefix),
    "--mode", "0",
    "--jobs", str(a.jobs),
]
subprocess.run(base + ["--c11b-probe", "--log", str(preflight_log)], check=True)

config = target / "include/config/warp_rando.h"
text = config.read_text()
text, count = re.subn(r"#define OW_WARP_RANDO_SEED \d+u",
                      f"#define OW_WARP_RANDO_SEED {a.seed}u", text)
if count != 1:
    p.error("unexpected C10E seed definition")
if config.read_text() != text:
    config.write_text(text)
subprocess.run(base + ["--rom", "--log", str(rom_log)], check=True)

output.parent.mkdir(parents=True, exist_ok=True)
objcopy = prefix / "usr/bin/arm-none-eabi-objcopy"
subprocess.run([str(objcopy), "-O", "binary",
                str(target / "pokeemerald.elf"), str(output)], check=True)
print(json.dumps({
    "output": str(output),
    "bytes": output.stat().st_size,
    "seed": a.seed,
    "preflight_log": str(preflight_log),
    "rom_build_log": str(rom_log),
    "instructions": "Experimental ruleset 2; use a fresh save and docs/c11b-mgba-manual-test.md. Not progression-approved.",
}))
