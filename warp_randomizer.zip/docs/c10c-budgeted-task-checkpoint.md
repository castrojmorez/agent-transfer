# C10C budgeted engine-task checkpoint

## Decision

C10C passes the test-only task/lifecycle gate. The exact C9C policy now runs
through an actual engine task with a 3,200-tick generation allowance. Under a
second deterministic task performing 2,048 update iterations every frame, the
worst measured complete task frame is 3,869 of 4,389 timer ticks (0.882 frame).

The next checkpoint may build a real loading screen/input flow and prove the
allocation point. C10C does not assign Algorithm 5, change saves, replace
Algorithm 4, or claim a playable randomizer.

## Scheduler and lifecycle

`c10c_scheduler_core.inc` wraps the C10B session with:

- a timer-governed callback pump;
- conservative phase-admission bounds;
- retry-aware monotonic progress on a 0–1,000 scale;
- an immutable status/view snapshot for a future UI;
- deferred cancellation processed by the next callback;
- invalidation before work begins;
- success-only publication after final validation;
- exactly-once release on success, failure, cancellation, or publication
  failure.

The admission bounds are 700 ticks for initialization, 2,600 for selection,
700 for trial/repair, 500 for commit, 1,900 for emission, and 800 for final
validation. A new microstep starts only when its bound fits within the remaining
3,200-tick allowance. The ARM probe, rather than those constants alone, is the
evidence that the implemented callback stayed within budget.

Progress combines the attempt ordinal and committed-pair count. The stored
value is a maximum, so rejection and attempt reinitialization cannot move it
backward. It is a stable presentation contract, not an estimate of remaining
CPU time.

## Correctness and failure behavior

- 68/68 reference seeds match C9C records, results, attempts, RNG-dependent
  choices and all work counters under a selected and alternate callback
  schedule.
- 1,024/1,024 stress seeds match C9C and independently validate; 803 succeed
  on attempt zero and the maximum is five attempts.
- Normal and ASan/UBSan lifecycle suites pass. They cover five budget/tick
  schedules, aliases, capability rounds, retries, cancellation/restart,
  invalid budgets, generation failures and a simulated publication failure.
- Every successful host run invalidates once, publishes once and releases once.
  All failure/cancellation cases publish zero records and release once.
- Target seeds 0 and 42 retain record digests `d2f14b80` and `3d354fa7`, C10B
  microstep counts 66,274 and 94,230, and attempt ordinals zero and one.

## ARM task timing

The headless probe uses pinned `pokeemerald-expansion`
`e8bd1cd7b03fc032ea37e3ecd38b379b5d01a1e7`. Timer ticks are 64 CPU cycles;
one nominal frame is 4,389 ticks.

| Measurement | Seed 0 | Seed 42 |
|---|---:|---:|
| Task callbacks / scheduled frames | 685 | 1,102 |
| Approximate duration at 60 Hz | 11.417 s | 18.367 s |
| Callback CPU ticks total | 1,592,448 | 2,283,745 |
| Callback CPU seconds total | 6.075 s | 8.712 s |
| Maximum generator callback | 2,822 ticks | 2,962 ticks |
| Maximum microsteps in one callback | 181 | 184 |
| Maximum full loaded task frame | 3,729 ticks | 3,869 ticks |

Across success and cancellation, the worst generator callback is 2,962 ticks
(0.675 frame) and the worst frame including task dispatch plus synthetic load
is 3,869 ticks (0.882 frame), leaving 520 ticks of measured headroom.

Cancellation requested after frame 32 completes on frame 33 at progress 124.
It publishes nothing and releases the workspace exactly once.

The competing task is a deterministic CPU load, not a rendered new-game screen
with VBlank, DMA, audio and real input contention. C10D must repeat the bound in
that actual screen environment. C10C demonstrates responsive scheduling, not
instant completion: seed 42 remains an approximately 18-second loading flow at
60 callbacks per second under this budget.

The one-time immutable graph/index approval is still outside the task and costs
430,345 ticks (1.642 seconds). Its boot/loading placement remains unresolved.

## Memory and identity

- C9C/C10B workspace: 14,224 transient heap bytes;
- C10B generation session: 156 bytes within the job;
- complete C10C job: 200 bytes;
- workspace plus job: 14,424 bytes;
- active table: 16,436 bytes;
- test engine state placed explicitly in EWRAM: 316 bytes;
- test build remaining EWRAM/IWRAM: 18,680 / 252 bytes;
- all tested heap paths restore the original 115,760 free bytes;
- test-published algorithm value: zero/unassigned.

The test-link EWRAM delta is 16,752 bytes: active table plus test scheduler
state. It is not a production link measurement. Runtime stack high-water is
still unmeasured.

## Incidental build recovery

The first target build failed before compiling C10C because the scratch
toolchain's newlib include link had disappeared, producing `string.h` failures
in unrelated engine files. Re-running the checksum-pinned
`prepare_target_toolchain.py` restored the expected prefix. The unchanged C10C
probe then built and passed. This is the same environmental recovery previously
seen at C6C and C10A, not a randomizer defect.

## Next checkpoint

C10D should add a test-only new-game/loading screen using the C10C view:

1. render monotonic progress, attempt/retry state and terminal errors;
2. route actual button input into deferred cancellation;
3. run the task with normal VBlank/audio/render callbacks and remeasure every
   full frame;
4. establish the real new-game heap allocation and cleanup point;
5. decide where immutable approval occurs;
6. keep publication after final validation and leave Algorithm 5/save identity
   unassigned until the complete flow passes restart/restoration tests.

Algorithm 4 remains the frozen fast fallback.

## Reproduction

```sh
make c10c
SANITIZE=1 python3 tests/c10c_test.py
python3 tools/audit/build_engine_proof.py TARGET PREFIX --mode 1 \
  --c10c-probe --log reports/engine-proof/c10c-mode1.log
python3 tools/audit/target_resources.py TARGET/pokeemerald-test.elf PREFIX \
  reports/engine-proof/c10c-resources.json
python3 tools/audit/c10c_probe_report.py TARGET PREFIX \
  reports/engine-proof/c10c-mode1.log TARGET/pokeemerald-test.elf \
  reports/engine-proof/c6c-baseline-resources.json \
  reports/engine-proof/c10c-resources.json reports/engine-proof/c10c-probe.json
```

Evidence is in `reports/c10c-*` and `reports/engine-proof/c10c-*`.
