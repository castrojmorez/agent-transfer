# Runtime contract, revision 2

This contract precedes the replacement implementation. The graph compiler is a
build-time tool; the delivered portable C core generates each seed itself.

* Physical endpoint: a source warp event, indexed in the target map's warp array.
* Logical endpoint: the representative of a declared physical group. All graph
  indices are uint16_t; 65535 means absent. Groups are never truncated.
* Trigger: the **requested destination triple** after an explicitly audited
  normalization. It is not the source event triple.
* Landing: a real destination endpoint (the partner representative).
* Fixed travel: directed edges retained independently of pairing participation.
* Escape: an explicit directed edge with an explicit capability prerequisite.

For each pair A/B, emit vanillaDestination(member(A)) -> B and
vanillaDestination(member(B)) -> A. Equivalent records deduplicate; contradictory
records reject the candidate. Group membership must be coherent. Participating
and excluded endpoints sharing a trigger are rejected at data compilation because
a destination-only hook could otherwise redirect an excluded event.

Concrete fixture (deliberately synthetic, not a claim about Emerald coordinates):
A=(1,0,0), alias A1=(1,0,1), both request (2,0,0).
B=(3,0,0), alias B1=(3,0,1), both request (4,0,0).
Emit exactly (2,0,0)->(3,0,0) and (4,0,0)->(1,0,0).
Entering A or A1 lands at B; entering B or B1 lands at A. Looking up A's own
triple does nothing. If C also requests (2,0,0) but is paired with D, emission
rejects the conflicting destinations rather than choosing one.

Unlisted transitions and invalid/inactive state leave the caller's requested
triple unchanged. That is vanilla fallback; a self-destination is not fallback.
Odd participation pools are rejected, with no implicit sink or self-pair.

Reference source: WarpRandomizationState.getRemappings derives trigger sets from
source-group `to` fields. Speedchoice InterceptWarp normalizes some ambiguous
requested destinations using player position. Numeric proxy IDs in Warps.json
are trigger tokens, not proof that the target has corresponding landing events.
The target audit reports all disagreements; the reference-only graph must not be
installed as an expansion 1.17.0 gameplay dataset.

The supplied target patch is a **fixed-table event proof**, disabled by default.
It gates lookup to four declared source groups and uses destination triggers
inside that gate. It does not attach the unapproved full reference graph to every
SetWarpDestination call. Script, dynamic, coordinate, Trainer Hill, Dive, fall,
escape, whiteout and Continue behavior is described in patches/README.md.
