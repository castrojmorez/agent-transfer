# C10A cooperative-generation checkpoint

## Decision

C10A proves that the exact C9C scheduler can be suspended and resumed with
small overhead. The cooperative architecture is viable, but its first coarse
partition is **not yet safe for a one-frame callback budget**: a worst observed
partner-trial quantum takes 1.604 frames and final validation takes 3.382
frames on ARM.

Continue to C10B by making propagation within trial evaluation and final
validation resumable. Preserve exact seeded order and measure the maximum
single callback under normal engine activity before adding UI or assigning
Algorithm ID 5. Algorithm 4 remains the fast fallback.

## State-machine contract

`C10aSession` holds all locals that previously lived across C9C's nested loops.
One quantum performs one of six phases:

1. attempt initialization and initial closure;
2. source/partner candidate selection;
3. one partner trial and score;
4. accepted-pair commit;
5. indexed emission; or
6. final validation.

Calls may advance by any number of quanta. Changing call boundaries does not
change RNG consumption or layout output. Cancellation transitions to a terminal
status, exposes zero records and permits a fresh begin using the same workspace.
Only a successful final validation exposes the 532 candidate records.

The warm entry point assumes the immutable C9C graph/index pair was approved
once. The checked entry point retains complete C9C validation. Callers must keep
the graph, index, work buffer and stats storage alive for the session lifetime.

## Correctness and host evidence

All 68 standard seeds exactly match C9C for records, attempts, rejection state
and every recorded work counter. Each seed was replayed with different advance
budgets drawn from 1, 2, 7, 31 and 65,535 quanta; every accepted result passed
the independent Python validator. The 1,024-seed stress corpus is 1,024/1,024
exact and independently valid, retaining 803 first-attempt successes and a
five-attempt maximum.

Five synthetic methods pass normally and under ASan/UBSan. They cover schedule
independence, aliases, retries, explicit failures, invalid bounds, cancellation,
zero publication and restart in the same workspace.

Seed 0 requires 1,281 coarse quanta and seed 42 requires 2,547. The maximum in
the standard corpus is 3,823 and in the stress corpus is 6,370. These counts do
not imply one frame per quantum; a production callback should execute bounded
internal work until its cycle budget is nearly exhausted.

The 680-generation host benchmark adds 6.4–13.5% depending on advance batching;
the one-quantum run adds 8.1%. The digest is identical for every batch size.

## ARM measurement

The exact sources passed the pinned expansion/1.17.0 suite 11/11 in headless
mGBA. Total timing repeatedly calls the one-quantum advance loop without frame
waits. Approval is measured separately.

| Seed | Attempts | Quanta | Total seconds | Total frames | Overhead vs C9C warm |
|---:|---:|---:|---:|---:|---:|
| 0 | 1 | 1,281 | 3.992 | 238.432 | 4.9% |
| 42 | 2 | 2,547 | 5.871 | 350.661 | 6.2% |

Maximum isolated phase cost:

| Phase | Worst ticks | Worst frames | C10B disposition |
|---|---:|---:|---|
| Attempt init | 550 | 0.125 | Already below one frame |
| Select | 2,377 | 0.542 | Already below one frame |
| Partner trial | 7,040 | 1.604 | Split closure/repair propagation |
| Commit | 322 | 0.073 | Already below one frame |
| Emit | 1,685 | 0.384 | Already below one frame |
| Final validate | 14,842 | 3.382 | Split closure and goal scan |

One timer tick is 64 CPU cycles and one frame is 4,389 ticks. These isolated
measurements do not include rendering/audio contention. A production safety
margin must therefore be below the theoretical full-frame limit.

## Memory and boundary

The target session is 136 bytes. Together with C9C's 14,224-byte work buffer,
resumable state is 14,360 bytes; the persistent active table remains 16,436
bytes. The controlled heap allocation/restoration is unchanged. The candidate
object has 13,948 text bytes and 59,710 read-only bytes. Runtime stack
high-water remains unmeasured.

C10A remains test-only. It has no engine callback, progress UI, user-facing
cancellation, save identity, production hook or Algorithm-5 assignment. Async
improves responsiveness but does not reduce the roughly 4–6 seconds of total
CPU work measured here.

## Reproduction

```sh
make c10a
SANITIZE=1 python3 tests/c10a_test.py
python3 tools/audit/build_engine_proof.py TARGET PREFIX --mode 1 \
  --c10a-probe --log reports/engine-proof/c10a-mode1.log
python3 tools/audit/target_resources.py TARGET/pokeemerald-test.elf PREFIX \
  reports/engine-proof/c10a-resources.json
python3 tools/audit/c10a_probe_report.py TARGET PREFIX \
  reports/engine-proof/c10a-mode1.log TARGET/pokeemerald-test.elf \
  reports/engine-proof/c6c-baseline-resources.json \
  reports/engine-proof/c10a-resources.json reports/engine-proof/c10a-probe.json
```

Evidence is in `reports/c10a-*` and `reports/engine-proof/c10a-*`.
