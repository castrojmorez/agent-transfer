# Supported scope and assumption-to-behavior matrix

Only `synthetic monotone coupled mode`, ruleset ID 1, is supported by the tested
core. It has one fixed root; repeatable directed fixed travel; permanent
capabilities with AND prerequisites and alternative OR derivations; explicit
required objectives; and no consumable resources. A layout passes only if each
reachable location can return to the root at every capability stage. Odd pools
and forbidden needs-return/no-return pairs are rejected. No implicit escape,
whiteout, save reload, Fly, Dig or Rope is assumed.

The initial full-game **proposed** preset is in-order progression using the
reference's full level<=10 annotations with extra deadends removed. It is an
audit input, not a supported playable preset. The annotations and actual game
behavior must be reconciled before a target-approved data fingerprint exists.

| Assumption | Required target behavior / evidence | Current disposition |
|---|---|---|
| Gym order and HMs | Badge battles and HM acquisitions enforce the in-order composite prerequisites, not just access to the gym doorway | Reference rules preserved; target battle/script audit open |
| Progression items | Cut, Flash, Rock Smash, Strength, Goggles, keys, Magma Emblem at modeled locations; repeated access sufficient | Location reachability is only an abstraction; interactions unverified |
| Bikes | Either both are permanently obtainable or bike gates are modeled explicitly | No free-bike assumption certified; open |
| Transport | Briney, ferries, cable car, Dive, Fly and dynamic warps model actual availability/destinations | No implicit edges; audit target scripts and fixed travel |
| Tutorial/root | Start physically at the declared Oldale root with necessary controls and party state | Core fixes a root; engine start relocation/setup unimplemented |
| Story simplification | Mode-gated Norman, tutorial, Slateport, weather institute, Kecleon, villain events, League locks | Old blanket flag writes removed; no target state mutations installed |
| Weather institute | Audit real traversal before deciding whether a grant is appropriate | Unavailable to the solver; no assertion of physical blockage or per-name intent |
| Flash naming | Rule IDs and exported capabilities are different namespaces | HOENN_FLASH_1 remains ungrantable by default; an explicit alias is supported only as a deliberate ruleset change |
| Excluded warps | Fixed travel still exists where needed | Reference-only fixed edges retained when resolvable; 13 unresolved travel records listed |
| Escape availability | Repeatable action with explicit source, destination and prerequisite | Generic directed edges supported/tested; real-game actions unimplemented |
| Participation | Whole coherent groups; ignored/removeable/extraDeadend out; mixed trigger collisions excluded together | Importer records decisions; target-only endpoints remain open |
| Victory | League rooms and Steven reference key locations reachable; actual champion defeat/credits requirements separate | Core checks explicit graph goals, not Hall of Fame/credits |
| Irreversibility | No consumed keys, mutually exclusive scripts, temporary restrictions or one-time resources in model | Must simplify with verified mode behavior or model explicitly |
| Disabling/reloading | Mode state and topology identity cannot change silently mid-save | Portable identity/CRC exists; target save policy open, new saves only proposed |

No toggle is supplied that claims to undo story mutations. The fixed engine
proof changes only the stated Oldale warp experiment and carries no full-game
progression guarantee.
