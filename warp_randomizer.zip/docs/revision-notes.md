# Finding-by-finding ledger

Original source evidence refers to the five archived files whose hashes are in
PROVENANCE.md. All findings were rechecked; the input archive hash matches the
brief. The earlier implementation and contradictory paste guides have been
superseded, rather than retained as competing current code.

| Finding | Source evidence / disposition | Verification / remaining limitation |
|---|---|---|
| P0-1 one-way remap emission | Original BuildRemapTable emits only warpEdges.from and its aliases although BFS traverses both directions. Replaced with involution check and both-side emission. | Reciprocal/grouped/duplicate/conflicting/corrupted reverse fixtures; Python validates emitted table. |
| P0-2 narrow groups | Original compiler casts representatives and members to uint8_t, runtime casts i to u8. Confirmed 144 emitted main-group references >255; E,8,0,1 is index 842. All current indices use uint16_t/65535. | 902-node case crosses 255/256 and 841/842. Importer reports 143 distinct non-representative members >255; that statistic differs because original declarations include a redundant self-reference. |
| P0-3 ninth prerequisite OOB | Original arrays are eight long but conditionCount retains nine. Replaced with validated flattened requirements. | Withholding ninth blocks Waterfall; deleting it changes acceptance; restored ninth passes ASan/UBSan. |
| P0-4 overstated validation | Original ValidateInOrder checks key locations using generation flags. Replaced with fresh emitted-table acceptance and separately implemented Python validator. | Self-lock, disconnected goal, staged chain, alternative derivation, corruption tests. Full target progression still open. |
| P0-5 unused escape state | mustLinkHome was selected but homePaths/homePathsComputed did not implement the promised route. Removed reservations; reverse directed traversal checks safety. | Trap, available/unavailable escape and unsafe item-collection tests. Real-game escape integration open. |
| P0-6 unknown becomes fixed | Original compiler degrades unknown edge flags to fixed. Importer declares unresolved tokens ungrantable and reports them; normalized compiler rejects undeclared capabilities. | WEATHER_INSTITUTE and HOENN_FLASH_1 unavailable by default; explicit alias and strict audit mode tested. |
| P0-7 rejected active table | Original builds remaps before acceptance and intercepts after failed generation without a success guard. New active.valid set only after validation. | Failed publication, zero/exhausted retries, stale options/data identity, restart tests; caller keeps destination unchanged. |
| P1-1 arrivals/proxies | Original correction function empty. Reference proxy logic exists in random_warps.c. | Tiny patch exercises grouped aliases, source-context ambiguity gating and one queued absolute correction; host-tested and C4 ARM/headless-engine tested in both modes. Interactive animation/restart and full proxy/offset table open. |
| P1-2 incomplete state fixes | Original copied some flags/vars but omitted script branches and applied fixes only for unique remap hits. | Broad writes removed. Ruleset matrix identifies missing target behavior; full progression integration remains open. |
| P1-3 integration/lifecycle/resources | Old snippets not an applied build. Save init declaration ordering was invalid as written; no measured buffer/linker/save budget. | New self-contained portable header/build/test path, applicable fixed proof patch, explicit EWRAM for proof state. Full generator placement/SaveBlock3/linker/build/timing remains open. |
| Component removal | Original PickRoot and DoNextMapping shifted boundary indices without removing corresponding vertex ranges; could merge/stale component ranges. | Removed that representation. Generator recomputes reachability, cannot promote unreachable nodes. No-source fixture and full batch record failures. |
| Empty candidate division | Original component branch can sample `% effectiveReachableCount` without a universal zero-source guard. | Explicit no-source/no-partner failures before RNG selection. |
| Unknown/malformed input | Original silently skips missing node references, accepts malformed IDs as zeros, treats Boolean false as true, truncates groups. | Strict references/triples/Boolean validation; false reference edges remain closed and reported. Group relation components use documented normalization. |
| Unsupported completion and performance claims | No prior test harness, drift scripts or target build artifacts in ZIP. | Claims withdrawn; included commands/reports define scope. No percent-complete estimate. |

The design deliberately does not resurrect the entire old algorithm with minor
patches. The replacement narrows the claimed guarantee, makes unsafe data fail,
and gives the next implementer one current executable core and one separate
engine proof. See STATUS.md for checkpoint exits that remain unmet.

Algorithm 3 also repairs the replacement constructor's directed-return and
frontier omissions; see constructor-checkpoint.md and the preserved algorithm-2
causal investigation. The historical fallback policy is now source-verified.
