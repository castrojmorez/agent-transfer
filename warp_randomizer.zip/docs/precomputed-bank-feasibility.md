# C6A: precomputed mapping-bank feasibility — 2026-09-04

This deliberately short checkpoint evaluates a bounded alternative to the
41-minute on-device constructor. It changes no production code, save metadata,
or algorithm identity.

## Measured experiment

`tools/audit/precomputed_bank.py` compiled the unchanged Algorithm-3 host core,
generated source seeds 0 through 31 with a one-attempt budget, and passed every
emitted table through the independent Python validator.

| Result | Measurement |
|---|---:|
| Accepted layouts | 32/32, all first attempt |
| Unique landing layouts | 32/32 |
| Records per layout | 532 |
| Shared packed triggers | 1,596 bytes |
| Packed landings for 32 layouts | 51,072 bytes |
| One CRC32 per layout | 128 bytes |
| Total packed array payload | 52,796 bytes |
| Host experiment time | 67.01 seconds |

The representation stores each trigger once as three bytes. Each layout stores
only one three-byte landing per record. This avoids the target ABI's 8-byte
`WrRecord` padding in ROM. The 52,796-byte payload is about 0.78% of the enabled
normal ROM's measured 6,801,620-byte headroom.

| Layout count | Packed payload |
|---:|---:|
| 16 | 27,196 bytes |
| 32 | 52,796 bytes |
| 64 | 103,996 bytes |
| 128 | 206,396 bytes |
| 256 | 411,196 bytes |

Small descriptor/alignment code and the loader are not included in those
payload figures. They should be measured by the eventual target link.

## Seed selection contract under evaluation

The proposed player seed is mixed with a fixed 32-bit integer mixer, then
masked by `bank_count - 1`; bank sizes must be powers of two. Across player
seeds 0 through 65,535 and 32 layouts, the measured occupancy was 1,971 to
2,129 seeds per layout. The source seeds used to build layouts are build-time
provenance and are not the player-facing seed.

The save identity must bind all of these inputs:

* player seed;
* new algorithm ID;
* ruleset ID;
* bank format/version, count, mixer, and complete bank fingerprint.

The selected index is derived, not stored in the current `attempt` field.
Different player seeds intentionally may select the same topology. That finite
variety is the principal product tradeoff.

## Proposed runtime behavior

1. Invalidate `WrActive`.
2. Derive the layout index from the seed.
3. Verify the selected ROM row's CRC and the compiled bank identity.
4. Copy 532 shared trigger/selected landing triples into `WrActive`.
5. Set identity, count, attempt zero, then publish `valid` last.

This path needs the 16,436-byte persistent target-ABI `WrActive` but no
47,388-byte construction workspace. It replaces unbounded graph search with one
CRC and one fixed-size copy. Target timing has not been measured, and the bank
does not solve reference-versus-target gameplay drift.

## Decision

Carry a **32-layout bank** into the next portable implementation proof. It is
large enough to test selection, identity, corruption, deterministic replay and
atomic publication while remaining cheap to generate and package. Treat 64,
128 and 256 as later product choices, not requirements for the proof.

Algorithm ID 4 is a candidate but is **not assigned in C6A**. Assign it only
when the bank compiler and portable loader exist, their format is frozen, and
negative tests pass. Keep Algorithm 3 available for offline bank construction;
do not call it on-device.

The next bounded checkpoint, C6B, should implement the 32-layout header compiler
and portable loader with host tests only. Defer the ARM rebuild/timing run to a
separate C6C checkpoint so recovery artifacts can be saved between them.

Machine-readable measurements and per-layout hashes are in
`reports/precomputed-bank-feasibility.json`.
