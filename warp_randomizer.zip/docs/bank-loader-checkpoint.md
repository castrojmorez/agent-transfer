# C6B: portable precomputed-bank loader — 2026-09-04

This checkpoint implements the bounded host-only follow-up selected in C6A.
It freezes the first bank format and assigns **Algorithm ID 4**. It does not
modify Algorithm 3, build the target ROM, allocate save sectors, or establish
that the reference layouts are playable in the target game.

## Frozen schema 1 contract

| Field | Value |
|---|---:|
| Algorithm identity | 4 |
| Ruleset identity | 1 |
| Layouts | 32 |
| Records per layout | 532 |
| Shared packed triggers | 1,596 bytes |
| Packed landings | 51,072 bytes |
| Row CRC32 values | 128 bytes |
| Total packed payload | 52,796 bytes |
| Bank SHA-256 | `4bd3884b6bea588af31006e9952320a0716860aed59d575b16b8156c110e8fc4` |

The bank fingerprint covers a schema marker, Algorithm ID, layout and record
counts, the exact selector description, all packed triggers, all packed
landings, and every little-endian row CRC. The selected row's CRC covers each
record as its three trigger bytes followed by its three landing bytes.

Player seeds use the C6A mixer: add `0x9e3779b9`, xor-shift 16 and multiply by
`0x85ebca6b`, xor-shift 13 and multiply by `0xc2b2ae35`, xor-shift 16, then mask
by `layout_count - 1`. Counts must be powers of two from 2 through 256. Source
seeds 0 through 31 are offline provenance, not player-facing seed values.

## Compiler and loader behavior

`tools/warprandogen/compile_bank.py` runs the unchanged Algorithm-3 core with a
one-attempt budget for each source seed, independently validates every emitted
mapping, requires identical trigger order, and emits `data/reference-bank.h`
plus `reports/reference-bank.json`. The generated header has no timestamp or
workspace path. Rendering the same generated data twice is checked byte for
byte in-process; Algorithm 3's seed determinism remains covered separately.

`src/warp_bank.c` validates the descriptor and identity, derives the row,
checks its CRC, and copies packed byte triples into `WrActive`. It needs no
`WrWork`. Loading first invalidates any old table; after a successful check it
fills the records and identity, then writes `valid = 1` last. Corruption returns
result 12 (`WR_BANK_BAD_CRC`). Invalid descriptors return 1 and identity
mismatches return 11.

`WR_ALGORITHM` remains 3 in `warp_rando.h` because that file identifies the
offline constructor. Algorithm 4 is separately named `WR_BANK_ALGORITHM` in
`warp_bank.h`; it is the identity of the bank loader, not a silent change to
the generation algorithm.

## Host evidence

The dedicated suite proves:

* representative seeds 0, 1, 17, 65,535 and 4,294,967,295 replay exactly and
  match an independent Python implementation of the selector;
* all 32 indices are reachable and the 32 loaded record-table digests differ;
* lookup works after publication;
* selected-row CRC corruption, algorithm/ruleset/fingerprint mismatches and an
  invalid layout count all fail with the expected result and leave `valid=0`
  and `count=0`;
* the same checks pass with AddressSanitizer and UndefinedBehaviorSanitizer.

The complete existing host suite also passes: 16 portable-core regressions,
both proof-adapter modes, and the three bank test groups, normally and with the
applicable sanitizers. LeakSanitizer enumeration is disabled in the no-heap
harnesses because this restricted runtime cannot inspect `/proc`; ASan bounds
and UBSan remain enabled.

The only implementation-test failure during C6B was a Python harness method
named `run`, which unintentionally overrode `unittest.TestCase.run`. Renaming it
to `invoke` corrected the harness. The initial sanitizer invocation then hit
the already documented LeakSanitizer environment limitation; applying the same
no-heap opt-out used by the core harness allowed ASan/UBSan to run and pass.
Neither failure implicated the bank data or loader.

## Deliberate limits and next gate

The existing `wr_decode(graph, ...)` is Algorithm-3/graph-specific and rejects
Algorithm-4 metadata. `wr_encode` can serialize an active bank identity, but
there is no matching bank-aware restore API yet. This is explicit incomplete
integration, not a compatible save path.

C6C should compile the bank and loader into the pinned ARM target test ROM,
measure actual ROM contribution and load/CRC/copy time, and exercise the same
identity/corruption/publication paths on ARM. Only then should save restoration
and new-game integration be designed. Reference-versus-target data drift and
interactive gameplay gates remain unchanged.

**Follow-up:** C6C completed this gate: 11/11 ARM tests passed and the measured
CRC/copy/publication time was 45.612 ms. See `docs/bank-arm-checkpoint.md` and
`reports/engine-proof/bank-probe.json`.
