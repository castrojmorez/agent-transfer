# C8A event-driven delta closure checkpoint

## Decision

C8A validates event-driven delta propagation on the current reference model,
but still takes 23.9–45.5 seconds on ARM. **Do not assign Algorithm ID 5 or
integrate C8A synchronously.** Continue to C8B and attack trial volume/state
reuse; Algorithm 4 remains the usable frozen fallback.

## Design

The deterministic event-index compiler keeps C7C's 400 unconditional SCCs and
13-word forward/reverse closure rows, then adds component-grouped active nodes
and conditional edges grouped by source, destination and capability.

C8A starts every candidate trial from the already-closed committed
zero-capability state. It seeds only effects of the temporary pair, queues only
newly reached components, and follows dynamic and enabled conditional adjacency
from those deltas. Newly granted capabilities examine only their own grouped
edges. Reverse repair uses a temporary destination bucket for the current
partner relation. This preserves the critical early-stage rule: a trap before a
later capability grant is not hidden by evaluating only the final state.

The first event-queue draft was correct but re-queued the entire known closure
for every trial. The checked implementation removes that redundant work and
groups capability edges; this is the version measured below.

## Host correctness

For seeds 0–63, 255, 256, 65535 and 4294967295:

* 68/68 succeeded; 66 on attempt zero and two on attempt one.
* All 68 layouts, accepted attempts and rejection results exactly match C7A.
* All 68 process replays were byte-identical.
* All 68 emitted tables passed the independent Python validator.
* Five synthetic methods (27 executions), including fail-closed capacity,
  passed normally and under ASan/UBSan.

Comparable process wall time was 0.713 seconds for C8A versus 0.879 for C7C
(1.233x); JSON output and process launch are included. More importantly, the
68-seed run records 1,556,154 targeted active visits and 2,295,613 conditional
visits instead of C7C's repeated broad scans.

## ARM measurement

The exact generated graph/event index and C8A core were staged into the pinned
expansion/1.17.0 target test build. The ten fixed-engine tests plus C8A passed
11/11 in headless mGBA, and both layouts matched the C7A/C7C host digests.

| Seed | Attempts | Trial states | Ticks | Seconds | Frames | Speedup vs C7C |
|---:|---:|---:|---:|---:|---:|---:|
| 0 | 1 | 1,020 | 6,273,289 | 23.931 | 1,429.321 | 1.589x |
| 42 | 2 | 2,039 | 11,919,509 | 45.469 | 2,715.769 | 1.653x |

The timer covers construction, emission, final C validation and 532-record
publication. It excludes allocation/zero-fill and release. One timer tick is
64 CPU cycles; one GBA frame is 4,389 ticks.

The result confirms that closure traversal was a real bottleneck, but not the
only one. The unchanged cap-4 policy still performs four scored trial states for
most of roughly 256 pair choices; C8B must reduce or reuse those 1,020–2,039
evaluations rather than only making their graph propagation cheaper.

## Memory, ROM and stack evidence

The target-ABI workspace is 13,776 bytes: 2,832 bytes above C7C for the component
queue and reverse buckets, but still 33,612 bytes/70.929% below C7B. Allocation
from the controlled 115,760-byte block leaves 101,968 contiguous bytes and the
heap restores exactly. The persistent test table remains 16,436 EWRAM bytes.

The separately compiled experimental object contains 11,356 bytes of text and
49,182 bytes of generated read-only data. The harness-inclusive test link adds
88,769 allocated ROM-section bytes and 16,436 static EWRAM bytes versus the
ten-test baseline; this is not a production link measurement. The largest
compiler-reported own frame is 316 bytes in retained production validation;
C8A's entry frame is 168 bytes. Runtime stack high-water remains unmeasured.

## Boundary and reproduction

C8A is test-only. It has no public API, production hook, save decoder, UI or
Algorithm-5 identity. Headless reference-model acceptance does not establish
target-world completion, interactive walking, animation safety or a complete
power-cycle restore.

```sh
make c8a
SANITIZE=1 python3 tests/c8a_test.py
python3 tools/audit/build_engine_proof.py TARGET PREFIX --mode 1 \
  --c8a-probe --log reports/engine-proof/c8a-mode1.log
python3 tools/audit/target_resources.py TARGET/pokeemerald-test.elf PREFIX \
  reports/engine-proof/c8a-resources.json
python3 tools/audit/c8a_probe_report.py TARGET PREFIX \
  reports/engine-proof/c8a-mode1.log TARGET/pokeemerald-test.elf \
  reports/engine-proof/c6c-baseline-resources.json \
  reports/engine-proof/c8a-resources.json reports/engine-proof/c8a-probe.json
```

Host evidence is in `reports/c8a-feasibility.json` and
`reports/c8a-test-cases.json`; checked ARM evidence is under
`reports/engine-proof/c8a-*`.
