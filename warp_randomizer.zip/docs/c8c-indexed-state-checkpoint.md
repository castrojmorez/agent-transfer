# C8C indexed-state checkpoint

## Decision

C8C proves that indexed alias access and incrementally maintained reverse-warp
state are a material architectural improvement. It preserves the selected C8B
cap-three policy exactly and cuts ARM time roughly in half. **Do not assign
Algorithm ID 5 or integrate C8C yet:** 10.9–16.1 seconds is still too slow for a
synchronous new-game wait.

C8 is complete. Continue to C9A with one bounded indexed frontier/free-set
experiment aimed at the remaining canonical-endpoint scans. If that does not
produce another major gain, reassess the constructor and product policy rather
than continuing small optimizations. Algorithm 4 remains the frozen usable
fallback.

## Design

C8B repeatedly hid three broad scans inside each scored trial:

* Pair seeding scanned all 608 active aliases twice even though the selected
  representatives have at most three aliases each.
* Every reverse propagation rebuilt destination buckets from all 608 active
  aliases.
* Source, partner, score and repair loops scanned all 879 nodes even though
  only 512 canonical active representatives can participate.

The deterministic C8C index adds:

* the 512 active representative node indices;
* an offset slice for every representative; and
* 608 indices mapping each representative directly to its active aliases.

C8C walks only the two relevant alias slices when seeding a temporary pair. It
builds reverse dynamic-warp buckets once per construction attempt, temporarily
pushes a trial pair's alias edges, restores the prior bucket heads in reverse
order, and permanently inserts only the accepted pair. Capability, early-stage
trap, directed repair, scoring, emission and final validation semantics are
unchanged. Invalid/capacity-mismatched indexes fail before construction.

## Host correctness and work reduction

For seeds 0–63, 255, 256, 65535 and 4294967295:

* 68/68 succeeded with exactly the same layouts, attempts, rejection outcomes
  and trial counts as C8B cap three.
* All 68 replays were identical and all outputs passed the independent Python
  validator.
* The 1,024-seed stress run was also 1,024/1,024 exactly equal to C8B, replayed
  identically and independently validated. It retained 803 first-attempt
  successes and a five-attempt maximum.
* Seven synthetic methods (31 executions), including component,
  representative and trial-cap capacity failures, pass normally and under
  ASan/UBSan.

Across the standard corpus, the indexed core replaces:

| C8B broad work | Visits | C8C indexed work | Visits |
|---|---:|---|---:|
| Pair alias full scans | 112,863,040 | Relevant alias slices | 435,322 |
| Reverse-bucket rebuild scans | 99,781,920 | Incremental edge updates | 380,197 |
| All-node endpoint scans | 104,577,267 | Representative scans | 60,914,176 |

Comparable host process time improves 1.927x. The 680-generation in-process
benchmark produces the same digest and improves from 4.437 to 2.123 seconds,
a 2.091x speedup.

## ARM measurement

The exact C8C core, generated index and harness were staged in the pinned
expansion/1.17.0 target test build. The ten fixed-engine tests plus C8C passed
11/11 in headless mGBA, and both layouts matched the checked host digests.

| Seed | Attempts | Trial states | Ticks | Seconds | Frames | Speedup vs C8B |
|---:|---:|---:|---:|---:|---:|---:|
| 0 | 1 | 766 | 2,857,246 | 10.900 | 651.002 | 2.001x |
| 42 | 2 | 1,525 | 4,216,672 | 16.085 | 960.736 | 2.239x |

The timer covers construction, emission, final C validation and 532-record
publication. It excludes allocation/zero-fill and release. One timer tick is 64
CPU cycles; one GBA frame is 4,389 ticks.

This is the strongest post-C7 improvement and shows that the design was paying
for data-structure work rather than unavoidable solver semantics. It also makes
the remaining problem concrete: under a provisional two-second UX target, seed
0 still needs about 5.45x and the retrying seed about 8.04x. C9A must therefore
avoid maintaining or rescanning endpoint sets broadly; a small constant-factor
cleanup is insufficient.

## Memory, ROM and stack evidence

The target-ABI workspace remains 13,776 bytes and the persistent test table
remains 16,436 bytes. Allocation from the controlled 115,760-byte block leaves
101,968 contiguous bytes and restores the heap exactly.

The generated representative slices increase experimental read-only data from
49,182 to 53,182 object bytes. The separately compiled experimental object has
11,860 bytes of text. The harness-inclusive test link adds 93,709 allocated
ROM-section bytes and 16,436 static EWRAM bytes versus the ten-test baseline;
this is not a production link measurement. The largest compiler-reported own
frame is 316 bytes in retained validation; C8C's entry frame is 176 bytes.
Runtime stack high-water remains unmeasured.

## Boundary and reproduction

C8C is test-only. It has no public API, production hook, save decoder, UI or
Algorithm-5 identity. Reference-model acceptance does not establish
target-world completion, interactive walking, animation safety or a complete
power-cycle restore.

```sh
make c8c
SANITIZE=1 python3 tests/c8c_test.py
python3 tools/audit/build_engine_proof.py TARGET PREFIX --mode 1 \
  --c8c-probe --log reports/engine-proof/c8c-mode1.log
python3 tools/audit/target_resources.py TARGET/pokeemerald-test.elf PREFIX \
  reports/engine-proof/c8c-resources.json
python3 tools/audit/c8c_probe_report.py TARGET PREFIX \
  reports/engine-proof/c8c-mode1.log TARGET/pokeemerald-test.elf \
  reports/engine-proof/c6c-baseline-resources.json \
  reports/engine-proof/c8c-resources.json reports/engine-proof/c8c-probe.json
```

Host evidence is in `reports/c8c-feasibility.json` and
`reports/c8c-test-cases.json`; checked ARM evidence is under
`reports/engine-proof/c8c-*`.
