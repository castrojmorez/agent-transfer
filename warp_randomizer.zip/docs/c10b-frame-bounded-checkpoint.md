# C10B frame-bounded cooperative checkpoint

## Decision

C10B passes its narrow gate: the frozen C9C policy is still exact, and every
isolated generation microstep measured on the pinned ARM target fits within one
GBA frame. The worst measured step is 2,383 timer ticks (0.543 frame), down
from C10A's 14,842 ticks (3.382 frames).

This authorizes the next experiment: a real engine callback that advances work
under a measured per-frame budget and reports progress/cancellation. It does
not authorize Algorithm 5, a save identity, or replacement of Algorithm 4.

## What changed

C10A already made the top-level attempt, selection, trial, commit, emission,
and validation phases resumable. Its trial evaluation and final validation
still contained whole closure traversals. C10B replaces those two overruns
with persistent microphases:

- pair-induced forward and reverse queues;
- capability-conditioned forward and reverse queues;
- one-word scoring and repair setup;
- repair reverse propagation and trap comparison;
- final forward/reverse closure, grant rounds, and objective checks.

One queued component is processed per propagation microstep. Capability setup
is split by capability and scoring/repair setup by bitset word. Queue order,
short-circuit order, RNG calls, retry behavior, and every C9C work counter are
preserved. Reverse-call accounting is also preserved once per logical
propagation invocation, including empty queues.

Attempt initialization, source selection, committed-pair closure, and indexed
emission remain atomic because C10A had already measured each below one frame.
The unchanged source-selection phase is now the limiting step.

## Correctness evidence

- 68/68 reference seeds match C9C exactly under one selected and one alternate
  advancement schedule.
- 1,024/1,024 stress seeds match C9C exactly and independently validate.
- Stress results: 1,024 successes, 803 on the first attempt, maximum five
  attempts.
- Normal and ASan/UBSan synthetic suites pass. They cover alternate quanta,
  retry/failure cases, aliases, capability rounds, cancellation during
  microphases, and clean restart.
- Seed 0 and seed 42 retain C9C's target record digests `d2f14b80` and
  `3d354fa7`, attempts 0 and 1, and trial counts 766 and 1,525.

No evidence claim extends beyond the current reference model. Solver-invisible
connections remain unavailable for generation policy, not asserted physically
impossible in the game.

## ARM timing

The probe ran in headless mGBA against pinned `pokeemerald-expansion`
`e8bd1cd7b03fc032ea37e3ecd38b379b5d01a1e7`. The timer uses 64 CPU cycles per
tick; one nominal frame is 4,389 ticks.

| Isolated group maximum | Seed 0 | Seed 42 | Worst frames |
|---|---:|---:|---:|
| Attempt initialization | 538 | 500 | 0.123 |
| Source selection | 2,373 | 2,383 | 0.543 |
| Trial/repair microstep | 399 | 283 | 0.091 |
| Pair commit | 316 | 320 | 0.073 |
| Indexed emission | 1,670 | 1,669 | 0.380 |
| Final-validation microstep | 533 | 452 | 0.121 |

The observed ceiling leaves 2,006 ticks to the nominal frame boundary. That is
measurement headroom, not yet a production callback budget: the probe did not
run alongside normal rendering, audio, input, or other callbacks.

Total generation time rises because the conservative one-component quantum
adds state-machine dispatch:

| Seed | C10B total | C10A total | C10B/C10A |
|---|---:|---:|---:|
| 0 | 1,545,020 ticks / 5.894 s | 1,046,478 ticks | 1.476x |
| 42 | 2,217,409 ticks / 8.459 s | 1,539,049 ticks | 1.441x |

This is not the intended wall-clock UI schedule. C10C should advance multiple
cheap microsteps until a conservative timer budget is reached, while never
starting another step when the remaining allowance cannot cover the measured
worst case. The 46,185–167,429 standard-seed step range and 267,844-step stress
maximum make a fixed one-step-per-frame schedule unsuitable.

## Memory and identity

- target workspace: 14,224 bytes (unchanged from C10A/C9C);
- target session: 156 bytes (20 bytes above C10A);
- combined transient state: 14,380 bytes;
- allocator overhead: 16 bytes; heap restored exactly after release;
- test active table: 16,436 bytes;
- test-published algorithm byte: zero/unassigned.

The candidate remains test-only. There is no production callback, progress UI,
save restoration, user-facing cancellation, or Algorithm-5 assignment. Static
compiler frames are not runtime stack high-water measurements.

## Next checkpoint

C10C should integrate the C10B session into a test-only engine callback and
prove a conservative timer-governed work budget under representative engine
load. It should define monotonic progress, cancellation cleanup, publication
only after final validation, and failure/retry presentation. Algorithm 5 and
save migration remain deferred until that lifecycle is proven.

## Reproduction

```sh
make c10b
SANITIZE=1 python3 tests/c10b_test.py
python3 tools/audit/build_engine_proof.py TARGET PREFIX --mode 1 \
  --c10b-probe --log reports/engine-proof/c10b-mode1.log
python3 tools/audit/target_resources.py TARGET/pokeemerald-test.elf PREFIX \
  reports/engine-proof/c10b-resources.json
python3 tools/audit/c10b_probe_report.py TARGET PREFIX \
  reports/engine-proof/c10b-mode1.log TARGET/pokeemerald-test.elf \
  reports/engine-proof/c6c-baseline-resources.json \
  reports/engine-proof/c10b-resources.json reports/engine-proof/c10b-probe.json
```

Evidence is in `reports/c10b-*` and `reports/engine-proof/c10b-*`.
