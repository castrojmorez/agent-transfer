# C8B trial-volume checkpoint

## Decision

C8B selects a cap of three scored partners per source as the lowest reliable
tested policy, but the measured gain is too small to make trial-cap tuning a
route to synchronous real-time generation. **Do not assign Algorithm ID 5 or
integrate C8B.** Continue only with a qualitatively different C8C experiment
that reuses branch state or safely rejects candidates before a complete trial
evaluation. Algorithm 4 remains the frozen usable fallback.

## Experiment and policy boundary

C8B is isolated from C8A. It uses the same event-driven SCC/bitset closure and
the same strict construction, early-stage trap, repair, emission, final
validation and failure-invalidation semantics. The only experimental input is a
runtime partner-trial cap from one through four. Cap four is the exact C8A/C7A
control. Lower caps intentionally change deterministic layouts, so they are
candidate policies without a save identity rather than equivalence
optimizations.

Invalid caps fail with `WR_BAD_DATA` before any attempt. Expected failures
publish no records.

## Host results

The standard corpus is seeds 0–63, 255, 256, 65535 and 4294967295, with eight
whole-attempt retries per seed.

| Cap | Successes | First-attempt | Max attempts | Total trial states | Disposition |
|---:|---:|---:|---:|---:|---|
| 1 | 0/68 | 0 | 8 | 120,559 | Reject |
| 2 | 23/68 | 4 | 8 | 222,706 | Reject |
| 3 | 68/68 | 48 | 3 | 69,593 | Lowest viable |
| 4 | 68/68 | 66 | 2 | 71,399 | Exact C8A control |

All 272 cap/seed runs replayed deterministically. Every one of the 159
successful layouts passed the independent Python validator, and cap four
matched C8A exactly for all 68 seeds. Six synthetic methods (30 executions),
including invalid caps and fail-closed capacity, pass normally and under
ASan/UBSan.

Cap three also succeeded for 1,024/1,024 consecutive stress seeds; 803 succeeded
on the first attempt and the worst successful seed required five attempts.
Every stress result replayed identically and passed the independent validator.
This supports reliability on the present reference abstraction, not gameplay
completion.

Although cap three evaluates 25% fewer partners in a one-attempt construction,
its lower first-attempt rate erases most of the aggregate saving: the standard
corpus uses only 2.53% fewer trial states than cap four. Comparable host process
time improves by roughly 6–8%, with launch and JSON overhead included.

## ARM measurement

The exact cap-three core, generated index and harness were staged in the pinned
expansion/1.17.0 target test build. The ten fixed-engine tests plus C8B passed
11/11 in headless mGBA, and both mappings matched their independently validated
host digests.

| Seed | Attempts | Trial states | Ticks | Seconds | Frames | Speedup vs C8A |
|---:|---:|---:|---:|---:|---:|---:|
| 0 | 1 | 766 | 5,718,093 | 21.813 | 1,302.824 | 1.097x |
| 42 | 2 | 1,525 | 9,442,690 | 36.021 | 2,151.445 | 1.262x |

The timer covers construction, emission, final C validation and 532-record
publication. It excludes allocation/zero-fill and release. One timer tick is 64
CPU cycles; one GBA frame is 4,389 ticks.

Cap three is a valid bounded policy improvement, but 21.8–36.0 seconds remains
far outside a comfortable synchronous wait. Caps one and two cannot trade more
reliability for speed because they already fail the corpus. The remaining gap
therefore requires eliminating or sharing expensive scored states, changing
the construction architecture, or choosing an asynchronous/precomputed product
policy—not another cap decrement.

## Memory, ROM and stack evidence

The target-ABI workspace remains 13,776 bytes and the persistent test table
remains 16,436 bytes. Allocation from the controlled 115,760-byte block leaves
101,968 contiguous bytes and restores the heap exactly.

The separately compiled experimental object contains 11,312 bytes of text and
49,182 bytes of generated read-only data. The harness-inclusive test link adds
88,741 allocated ROM-section bytes and 16,436 static EWRAM bytes versus the
ten-test baseline; this is not a production link measurement. The largest
compiler-reported own frame is 316 bytes in retained validation; C8B's entry
frame is 172 bytes. Runtime stack high-water remains unmeasured.

## Boundary and reproduction

C8B is test-only. It has no public API, production hook, save decoder, UI or
Algorithm-5 identity. Reference-model acceptance does not establish
target-world completion, interactive walking, animation safety or a complete
power-cycle restore.

```sh
make c8b
SANITIZE=1 python3 tests/c8b_test.py
python3 tools/audit/build_engine_proof.py TARGET PREFIX --mode 1 \
  --c8b-probe --log reports/engine-proof/c8b-mode1.log
python3 tools/audit/target_resources.py TARGET/pokeemerald-test.elf PREFIX \
  reports/engine-proof/c8b-resources.json
python3 tools/audit/c8b_probe_report.py TARGET PREFIX \
  reports/engine-proof/c8b-mode1.log TARGET/pokeemerald-test.elf \
  reports/engine-proof/c6c-baseline-resources.json \
  reports/engine-proof/c8b-resources.json reports/engine-proof/c8b-probe.json
```

Host evidence is in `reports/c8b-feasibility.json` and
`reports/c8b-test-cases.json`; checked ARM evidence is under
`reports/engine-proof/c8b-*`.

