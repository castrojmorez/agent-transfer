# Constructor and conservative-policy checkpoint — 2026-09-04

Algorithm 3 passes the recorded complete reference-model sample. No target ROM
has been built or played. This checkpoint repairs host construction and records
the user's clarified fallback policy; it does not certify the reference model
against expansion 1.17.0 gameplay.

## What changed and why

The algorithm-2 constructor ignored intermediate unsafe-return state and
preferred item locations using a score that confused alias edges with useful
exits. It could pair two isolated endpoints into a closed sink, or spend every
reachable free endpoint before exposing another component. The original eight
seeds failed all 64 attempts (52 trap, 12 no-source). Full causal witnesses and
controlled counterfactuals are preserved under reports/algorithm2/.

Algorithm 3 performs these steps for each pair:

1. Recompute reachability and capabilities from the partial mapping, stopping
   at the first unsafe capability stage. Future capabilities cannot hide an
   earlier obligation.
2. If a reachable area cannot return, select a free endpoint in that area and
   consider partners that already have a directed route to the root. Otherwise
   select a reachable safe free endpoint to expand from.
3. Trial each legal partner and count actual reachable, unpaired canonical
   endpoints. Favor the largest remaining frontier; alias adjacency and
   progression labels do not receive heuristic bonuses.
4. Reject trials that empty the frontier prematurely, leave unsafe regions
   without a free safe endpoint, or strand any unsafe vertex away from every
   remaining free endpoint. The last check is a reverse multi-source traversal
   using current conditions and actual directed edges.
5. Commit the selected pair. At completion, emit both directions and aliases,
   then run the unchanged acceptance policy before publishing.

The solver does not import EscapePaths as special exceptions. Instead it checks
return obligations over all represented reachable vertices, which includes the
modeled situations those annotations identify. This does not cover missing
world data or unmodeled real-game actions. Greedy construction remains bounded
by explicit retries and can still fail on other graphs or seeds.

The C validator still checks every capability stage; the independent Python
validator is unchanged. No graph safety condition was weakened to obtain passes.
Tie selection remains deterministic using the dedicated RNG. Algorithm identity
is bumped from 2 to 3 because seed mappings change. Old metadata is rejected,
including when its CRC is valid. The save-envelope magic remains WR02: the
wire layout is unchanged and has a separate algorithm field.

## Data policy

The verified historical comment at the pinned legacy source says incomplete
flag modeling is conservative: generation does not rely on unmodeled
connections. It is not evidence that any particular typo-looking string was
intentional, and does not imply physical blockage in the game.

The importer now defaults to `unknown_requirement_policy: unavailable`:
unknown strings become declared capabilities with no grant, and are reported.
The normalized compiler continues rejecting undeclared capability references.
`error` is an optional strict audit policy. Explicit aliases remain supported,
but the default alias map is empty. WEATHER_INSTITUTE and HOENN_FLASH_1 are
both ungrantable; the legitimate composite rule IDs and exported flags are kept
separate. The prior Flash alias is no longer silently presented as a repair.

Capability-to-capability derivation is still supported by this port. That is
stronger than the inspected Java updater's location-only condition matching;
see failure-diagnosis.md for the Strength example. Current data is a declared
reference abstraction, not a byte-for-byte recreation of Java behavior.

## Executed evidence

| Check | Result |
|---|---|
| Algorithm 3, unchanged algorithm-2 data | 8/8 accepted; seed 2 required attempt 1 (second try), replay matched |
| Algorithm 3, conservative current defaults | 68/68 accepted on first attempt; seeds 0–63, 255, 256, 65535, 4294967295 |
| Independent emitted-table validation | All 68 accepted under the same strict every-stage return policy |
| Core regressions | 16 cases passed; includes six-seed frontier/directed-sink construction fixture |
| ASan/UBSan | Same 16 cases passed; LeakSanitizer disabled as documented |
| Fixed engine proof adapter | Host stub tests passed enabled and disabled; not target-built |
| Historical reproduction | Both algorithm-2 diagnosis reports reproduced byte-for-byte in isolated rollback |

Current fingerprint/counts are in reports/reference-import.json. There are
879 physical vertices, 698 canonical groups, 512 active canonical endpoints,
1,394 edges, 16 capabilities and 14 rules (maximum nine prerequisites).
Host workspace is 43,292 bytes (+2,048 scratch bytes); active table capacity is
12,340 bytes, metadata 56 bytes. Neither sizeof nor desktop runtime is a GBA
measurement. Each sample process includes full generation and metadata replay;
the implementation evaluates many trial closures synchronously. Target frame
budgeting and performance work are still required.

The original-data experiment isolates the constructor improvement from the
policy change. The broader sample checks current defaults; it is not exhaustive
coverage of all 32-bit seeds and says nothing about map tiles or event scripts.

## Next gate

Build and exercise the small fixed Oldale proof on the pinned target using an
ARM toolchain and emulator. Then reconcile the target map/progression data and
profile construction. Do not install the reference-only generator as a
supported playable mode based on this checkpoint alone.
