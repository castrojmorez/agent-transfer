# C7B bounded candidate on ARM

## Decision

The exact C7A cap-4 scheduler works on ARM and materially improves Algorithm 3,
but it is still too slow to block a new-game or menu path. **Do not assign
Algorithm ID 5 and do not integrate this candidate synchronously.** Algorithm 4
remains the usable frozen fallback.

C7B staged the unchanged production core, generated 879-node reference graph
and shared experimental scheduler into the pinned RHH expansion 1.17.0 test
build at `e8bd1cd7b03fc032ea37e3ecd38b379b5d01a1e7`. The existing ten engine
proofs plus the candidate test passed 11/11 in bundled headless mGBA.

## Measured results

The timer covers construction, emission, final C validation and copying 532
records into the persistent table. It excludes workspace allocation/zero-fill
and release. One tick is 64 CPU cycles; one GBA frame is 4,389 ticks.

| Seed | Attempts | Trial closures | State closures | Ticks | Seconds | Frames |
|---:|---:|---:|---:|---:|---:|---:|
| 0 | 1 | 1,020 | 1,276 | 17,599,359 | 67.136 | 4,009.879 |
| 42 | 2 | 2,039 | 2,550 | 34,462,850 | 131.465 | 7,852.096 |

Seed 42's first construction ended with `WR_NO_PARTNER`; the second succeeded.
Both ARM outputs matched the host FNV-1a digests (`aa8b08fd` and `4c5a43e2`).
Seed 0 is **36.636× faster** than C5's unchanged Algorithm-3 ARM measurement,
which took 644,772,173 ticks (2,459.61 seconds). That gain validates bounded
partner scoring, but 67–131 seconds remains unacceptable as blocking work.

## Memory, link and stack evidence

The candidate deliberately retains Algorithm 3's 47,388-byte target-ABI
`WrWork`. At controlled test start, allocation reduced the largest free heap
block from 115,760 to 68,356 bytes (16 bytes allocator overhead), and freeing it
restored the heap exactly. The persistent test table is 16,436 EWRAM bytes.

Relative to the ten-test C6C baseline, this test link added 35,845 allocated ROM
section bytes and exactly 16,436 static EWRAM bytes. The ROM figure includes the
test harness, graph and retained support and is therefore a conservative test
upper bound, not a production-link cost.

The separately compiled exact core+scheduler object has 7,500 bytes of `.text`.
Its largest compiler-reported own frame is 316 bytes in `closure_until`; the
candidate entry reports 120 bytes. These figures are not a call-chain,
interrupt-stack or runtime high-water measurement.

The published test identity deliberately uses algorithm value zero. It proves
valid-last record publication only; it is not a save-compatible runtime ID.

## Next design gate

C7C should retain cap-4 scheduling and prototype a graph-sized workspace plus a
materially cheaper closure implementation. The current reference graph has 879
nodes, 608 active nodes, 512 active representatives, 1,394 fixed edges and 16
capabilities, while `WrWork` reserves for 2,048 nodes and 256 capabilities.
Compact actual-size buffers can reduce memory, but timing requires fewer or
cheaper full traversals—incremental adjacency/reachability or compact bitsets,
measured host-first before another ARM run.

A resumable API alone would avoid one long frame but would still consume more
than a minute of total work; it is not the first fix. Preserve the strict final
validator, conservative unknown-requirement policy, deterministic retry
identity and failure-publication rules.

## Reproduction

```sh
python3 tools/audit/build_engine_proof.py TARGET PREFIX --mode 1 \
  --c7a-probe --log reports/engine-proof/c7b-mode1.log
python3 tools/audit/target_resources.py TARGET/pokeemerald-test.elf PREFIX \
  reports/engine-proof/c7b-resources.json
python3 tools/audit/c7b_probe_report.py TARGET PREFIX \
  reports/engine-proof/c7b-mode1.log TARGET/pokeemerald-test.elf \
  reports/engine-proof/c6c-baseline-resources.json \
  reports/engine-proof/c7b-resources.json \
  reports/engine-proof/c7b-probe.json
```

The raw log, linked-resource report and checked evidence are preserved under
`reports/engine-proof/c7b-*`.
