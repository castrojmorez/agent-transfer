# C7A bounded on-demand feasibility

## Decision

Continue this candidate to a bounded C7B ARM measurement, but **do not assign
Algorithm ID 5**. C7A changes no production constructor, bank, save identity or
target files. Algorithm 4 remains the frozen fallback.

The host-only candidate retains the current graph contract, Algorithm-3
first-unsafe-stage closure, directed repair test, final C validator and strict
independent Python validator. For each selected source it enumerates legal free
partners, samples without replacement using a partial Fisher-Yates shuffle, and
scores at most four. Eight complete construction attempts remain the outer
bound. Failed attempts never emit records.

This directly bounds the expensive work that made Algorithm 3 unusable:
Algorithm 3 scores every eligible partner with a fresh closure, while the C7A
candidate performs at most four trial closures per pair. The experiment lives
under `tools/experiments/`; it has no public API or save/replay identity.

## Evidence

Both candidates were compiled with GCC `-O2` and exercised as one construction,
emission and C validation per process over seeds 0–63, 255, 256, 65535 and
4294967295. Process launch and JSON output are included in both timings.

| Measurement | Algorithm 3 control | C7A cap 4 |
|---|---:|---:|
| Accepted by independent validator | 68/68 | 68/68 |
| First-attempt acceptances | 68 | 66 |
| Maximum attempts | 1 | 2 |
| Total host time | 105.115 s | 4.615 s |
| Median per seed | 1.537 s | 0.063 s |
| Maximum per seed | 1.872 s | 0.125 s |

The observed total-time speedup is **22.78×**. Along the candidate's own paths,
4,284,175 partners were eligible but only 71,399 were trial-scored, a **60.00×**
reduction in trial closures. The worst seed across accepted runs used 2,040
partner trials and 2,552 state closures because it consumed the second bounded
attempt.

Every one of the 68 outputs replayed byte-identically in a fresh process and
passed `tests/validate.py`. Four candidate-specific unittest groups produced 26
synthetic executions covering deterministic reciprocal pairing, grouped
aliases, the six-seed frontier/directed-sink fixture, odd pool, no source and no
legal partner. They pass normally and under ASan/UBSan. The three expected
failure executions emitted zero records. The unchanged production/bank suites
also remain mandatory.

## Resource and timing limits

This first prototype deliberately reuses `WrWork` to isolate the scheduling
change. It therefore consumes the same 43,292 host bytes and the already
measured **47,388 target-ABI bytes** as Algorithm 3. The largest compiler-reported
host frame is 352 bytes (`closure_until`); this is not an ARM stack high-water
measurement.

Dividing C5's 2,459.61-second seed-0 ARM result by the aggregate host speedup
gives roughly 105 seconds. That is only an inference: paths, retry behavior and
ARM instruction costs differ. It does show that a 22.78× host win is not enough
to assume synchronous playability.

C7B subsequently measured this exact policy on ARM: seed 0 took 67.136 seconds
and second-attempt seed 42 took 131.465 seconds. This confirms that target time
is excessive. See `docs/c7b-arm-checkpoint.md`. No MiMo source was merged.

## Reproduction

```sh
python3 tests/c7a_test.py
SANITIZE=1 python3 tests/c7a_test.py
python3 tools/audit/c7a_feasibility.py --caps 4
python3 tools/audit/c7a_baseline.py
python3 tools/audit/c7a_report.py
```

Checked evidence is in `reports/c7a-feasibility.json`,
`reports/c7a-algorithm3-baseline.json`, `reports/c7a-test-cases.json` and
`reports/c7a-verification.json`.
