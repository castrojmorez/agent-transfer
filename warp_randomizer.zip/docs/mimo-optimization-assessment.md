# MiMo optimized-GLM assessment — C6C

The user supplied `MiMo-GLM-Optimized.tar` and
`MiMo-GLM-Optimization.md` as optional input for a future true on-demand
randomizer. They were inspected and smoke-tested but are not bundled or merged.

| Artifact | SHA-256 |
|---|---|
| MiMo-GLM-Optimized.tar | `9100b37140f7318ff4ede31aa7d9ad6f7f159731cfbfd86b4ed42d0a2e8402c0` |
| MiMo-GLM-Optimization.md | `6eee3f02bb86eae24dfd9310e701f87ab512c5984c54fbbe73efea5c232714e7` |
| Supplied optimized core | `31adae641a9e8f0f00eb673407d62cb793683c5cc361ef67bec6690fa88a2e7c` |
| Supplied generated graph | `094497c2b8b60d167f3414bb5a6053c7e15d61f64917c2d9c59c69be243d882d` |

## What transferred conceptually

The useful ideas are adjacency-indexed graph traversal, direct counters instead
of repeated full scans, compact bitsets, reverse reachability for return tests,
and grouping validation queries that truly share the same withheld-capability
set. These should be evaluated against the current Algorithm-3 semantics and
independent validator when designing Algorithm 5.

## What did not transfer directly

This is not an optimization patch for the current project core. It uses the
older GLM-style 879-vertex schema, sfc32 RNG, level/dead-end parameters, goal
withholding model, root selection and static-global publication API. Its
“byte-identical” claim is therefore relative to an absent older baseline, not
to current Algorithm 3 or the 532-record bank. The archive has no independent
world-model validator or original core against which that claim can be
reproduced.

Local smoke results for the supplied code were positive but narrow:

* its same-seed determinism and rejected-publication checks passed;
* 100/100 supplied-model seeds accepted, in 1.124 host seconds including TSV
  output on this host; and
* a standalone ARM compile produced 7,716 bytes `.text`, 48,884 bytes `.bss`
  and 39,692 bytes `.rodata` (the graph is included in the core object).

The largest compiler-reported own ARM frame is 1,780 bytes in
`BuildAdjacencyLists`, caused primarily by a vertex-sized local edge-count
array. That is not acceptable without stack-budget evidence or moving the
scratch storage. The source header advertises an early escape-safety check, but
`CheckEscapeSafety` is called only from final `ValidateLayout`; the promised
construction-time early rejection is not present. Pair adjacency is rebuilt
after every pair, so its asymptotic and ARM-memory costs also need measurement.
The host-to-GBA multiplier in the supplied note is only an estimate; C5 showed
why direct target timing is mandatory.

These observations do not prove the supplied generator wrong. They mean its
correctness, memory lifetime and performance claims are insufficient for direct
adoption into this differently modeled project.

## Proposed Algorithm-5 path

Keep Algorithm 4 frozen as a safe fallback. Build a new host-first on-demand
constructor from the current graph contract and strict validator, borrowing
only individually justified optimization patterns. Before assigning ID 5 it
should:

1. preserve conservative unknown-requirement policy and staged return safety;
2. pass the current synthetic regressions and independent reference validator;
3. accept the recorded 68-seed corpus without exposing rejected candidates;
4. define bounded work/RAM and deterministic replay explicitly;
5. remove large automatic arrays and measure target ABI/static frames; and
6. meet a target-time budget on actual ARM before save or UI integration.

Output need not match Algorithm 3 byte-for-byte; a changed constructor should
have a new identity. The target data reconciliation remains necessary no matter
which constructor is used.

