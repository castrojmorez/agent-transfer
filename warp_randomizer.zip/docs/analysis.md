# Corrected architecture and implementation choices

Source-verified references below use the exact commits in PROVENANCE.md. The
original five-file handoff was a prototype, not a completed port. Its 100/500
seed claims, timings, byte-identical disabled build, save compatibility, and
completed implementation phases had no supplied reproducible evidence. They are
superseded by STATUS.md. Historical ancestry/backport claims are not re-certified.

## What to preserve from KittyPBoxx

The architecture separates graph annotations, layout construction, remap
emission, and game behavior. UPR loads Warps/Flags/KeyLocations/EscapePaths JSON;
its Java graph generator constructs coupled warp edges using reachable sources,
then prioritizes disconnected components, return paths, progression locations,
and remaining endpoints. Speedchoice supplies runtime lookup, source-position
proxy normalization, arrival corrections, mode initialization, escape behavior,
and script accommodations. Moving construction into C does not replace those
world-model obligations. A build-time JSON compiler remains compatible with
in-game seed generation: players do not run Python or Java per seed.

Source anchors: UPR `EmeraldExWarpRandomizer.{createState,doNextMapping,
getHomeLinkMapping,validateInOrderLogic}`, `WarpRandomizationState.getRemappings`;
Speedchoice `src/random_warps.c` and map-script `FLAG_MAP_RANDO` branches.

Emission uses source-group **vanilla destinations** as trigger keys. The Java
ROM writer in `emeraldex/EmeraldEXRomHandler.randomizeWarps` has `entrySize=8`
and `maxRemappings=632`. The C declaration has six s8 fields; that alone does
not establish a six-byte target array stride under its ARM ABI. The earlier
analysis's six-byte/8-byte statements were contradictory. This replacement
uses a C-owned table without binary ROM-offset patching. An external-writer
compatibility port would need an explicit target sizeof/stride assertion.

The upstream validator is not an oracle: its consecutive equality filters for
different condition names cannot both match. The pinned code also deserves
review for empty candidate selection and which graph receives edge removals.
This handoff does not claim those upstream branches were executed or fixed.

## Replacement core

The new build-time compiler uses Python's standard JSON parser rather than
vendoring json11. It rejects unresolved requirements and invalid indices;
requirements are flattened with offsets and counts. Rule IDs and exported
capabilities are distinct; multiple rules may grant one capability.

The core is portable C99, compiled directly by the host tests. Construction
recomputes fresh partial reachability and selects an unused reachable endpoint,
then prioritizes an unreachable progression/hub endpoint. It never pretends
unreachable leftovers are reached. The broken mutable component-boundary queue,
unused home-link reservations and unchecked fixed-capacity group arrays were
removed. This is a simpler constructive baseline, not a claim of faithfully
porting UPR's complete priority cascade or matching its seed outputs.

A canonical partner relation is an involution without self-pairs. Emission
expands both groups, rejects contradictory trigger aliases, and sorts records.
Acceptance reconstructs directed transitions **from those records**, validates
coverage and coupling, and computes capability closure from fresh state.
Fixed travel remains outside pairing participation. The graph has forward and
reverse adjacency arrays; no scan of every fixed edge for each dequeued vertex.

At every capability stage, all reachable vertices must be able to return to the
initial root. Capabilities are collected only from reachable, returning places.
This is a conservative sufficient condition in a repeatable monotone model:
it rejects layouts that could be safe only after collecting an item inside a
one-way region, and rejects optional early traps even if another item could
later make them escapable. It cannot prove script state, combat feasibility,
resources, coordinates, or story completion. Python's independent validator uses
its own sets and graph walks, and consumes emitted records, not C reachability
or construction state. Corrupted tables and self-lock fixtures must fail both.

## What the complete-data audit establishes

The actual reference has 879 physical nodes. Joining group_order/map order and
warp-array indices reproduces 878 common keys and 866 matching destinations.
There are 12 destination disagreements, one absent endpoint, and 1,729 target
warp events absent from the annotations. The latter are events, not maps; they
are not all certified exclusions. Two common annotated endpoints in Cave of
Origin have changed coordinates despite matching destinations. CSV rows and
map hashes accompany the counts.

Some differences are proxy trigger tokens; some look like annotation errors
(Oldale House1, museum, center and League records). They must not be dismissed
collectively as harmless arrival exceptions. Numeric key agreement does not
verify target identity, walkability, or progression equivalence. The audit
resolves canonical map names on both engines and exposes geometry; comparison
of collision tiles, elevations on arrival, scripts and conditional boundaries
remains open.

The reference importer produces 512 active canonical endpoints and keeps
excluded travel when its destination exists in the reference vertex set. It
reports rather than hides 13 excluded transitions to unmodeled destinations.
It retains WEATHER_INSTITUTE and HOENN_FLASH_1 as ungrantable requirements.
Unknown tokens default to unavailable with diagnostics; aliases require an
explicit override. This model is explicitly
reference-only and is not installed by the engine proof patch.

## Follow-up clarification

The complete batch failure causes and source-level interpretation of Weather/Flash
are now traced in failure-diagnosis.md. `_1` is a legitimate rule identifier;
only the exported capability is matched to connection strings by upstream.
The former Flash alias was an explicit behavior change and is now disabled
by default. The historical author comment confirms conservative fallback for
unmodeled requirements; per-token intent remains unproven. Neither disputed
condition caused the algorithm-2 failures in controlled experiments.

## Runtime publication and persistence

Only validated complete tables become active. Invalidating/rebuilding clears
active state first; exhausted retries leave lookup inactive and leave requested
destinations untouched. Seed zero is valid. A dedicated 32-bit LCG and stable
iteration order isolate layout generation from gameplay RNG.

Identity includes seed, algorithm version 3, ruleset 1 and SHA-256 of normalized
input. Retry j uses seed + 0x9e3779b9*j modulo 2^32. The 56-byte little-endian
metadata format includes the accepted zero-based attempt and CRC32. Host tests
replay a successful second attempt after encode/decode. Engine save allocation,
mode selection, mismatch UI and load lifecycle are still unimplemented. An
incompatible save must not silently switch a running randomized game to vanilla.

See constructor-checkpoint.md for the directed-return/frontier repair and current
seed evidence. Historical baseline results remain in reports/algorithm2/.
