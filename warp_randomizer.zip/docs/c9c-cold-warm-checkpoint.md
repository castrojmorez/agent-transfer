# C9C cold/warm indexed-emission checkpoint

## Decision

C9C completes the bounded incremental optimization of the current synchronous
scheduler. Generated trigger indexes and one-time immutable-reference approval
are exact, useful improvements, but the warm constructor still takes
3.807–5.527 seconds on ARM. That misses the provisional two-second blocking
budget, so further scan/publication micro-optimization is not justified.

The next on-demand prototype should make the proven C9C state machine
frame-sliced/asynchronous, with a cancellation/failure path and measured
per-frame budget. A genuinely different constructor remains an alternative.
Algorithm ID 5 stays unassigned; Algorithm 4 remains the frozen fast fallback.

## Change and safety boundary

The compiler emits one node for each sorted unique active trigger plus a
node-to-emission ordinal. The reference has 608 active aliases but 532 unique
records, so runtime emission no longer scans aliases, de-duplicates triggers or
insertion-sorts records. Compilation rejects a shared active trigger whose
nodes use different representatives. Cold generation still runs the complete
graph and generated-index checks. Warm generation is callable only after the
same immutable graph/index pair has been approved once.

This is reference specialization, not permission to skip validation for mutable
or caller-supplied graphs. Both paths retain pair validation, final objective
validation, retry identity, publish-last behavior and failure invalidation.

## Correctness

For seeds 0–63, 255, 256, 65535 and 4294967295, all 68 C9C records, attempts,
rejections and recorded constructor counters exactly match C9A/C9B. Every
replay is deterministic and every accepted layout passes the independent
Python validator. The 1,024-seed stress corpus is likewise 1,024/1,024 exact,
deterministic and independently valid, with 803 first-attempt successes and a
five-attempt maximum. Eight synthetic methods pass, including compile-time
rejection of conflicting shared-trigger representatives.

## ARM timing

The pinned expansion/1.17.0 combined suite passed 11/11 in headless mGBA.

| Seed | Attempts | Cold seconds | Warm seconds | Warm frames | Warm speedup vs C9B |
|---:|---:|---:|---:|---:|---:|
| 0 | 1 | 5.439 | 3.807 | 227.355 | 1.571x |
| 42 | 2 | 7.159 | 5.527 | 330.140 | 1.398x |

The reusable approval costs 427,825 64-cycle ticks (1.632 seconds). Cold and
warm numbers are reported separately; warm timing does not conceal that cost.
Timers cover generation and 532-record publication but exclude workspace
allocation/zero-fill and release.

The warm path is nearly 2x faster than C9A for seed 0, but still blocks for
hundreds of frames. Async work will not reduce these CPU totals by itself; it
can distribute them across frames, preserve responsiveness and expose progress.

## Resources and boundary

The target workspace remains 14,224 bytes and the persistent active table
remains 16,436 bytes. The controlled heap restores exactly. The candidate
object has 12,952 text bytes and 59,594 read-only bytes; the generated indexes
add ROM, not workspace. The harness-inclusive link delta is 102,377 allocated
ROM-section bytes and 16,436 static EWRAM bytes versus the ten-test baseline.
These are test-link measurements, not a production link.

C9C remains test-only: no production hook, save decoder, UI, cancellation,
progress display or Algorithm-5 identity exists. Reference-model acceptance is
not target-world completion.

## Reproduction

```sh
make c9c
SANITIZE=1 python3 tests/c9c_test.py
python3 tools/audit/build_engine_proof.py TARGET PREFIX --mode 1 \
  --c9c-probe --log reports/engine-proof/c9c-mode1.log
python3 tools/audit/target_resources.py TARGET/pokeemerald-test.elf PREFIX \
  reports/engine-proof/c9c-resources.json
python3 tools/audit/c9c_probe_report.py TARGET PREFIX \
  reports/engine-proof/c9c-mode1.log TARGET/pokeemerald-test.elf \
  reports/engine-proof/c6c-baseline-resources.json \
  reports/engine-proof/c9c-resources.json reports/engine-proof/c9c-probe.json
```

Host evidence is in `reports/c9c-feasibility.json` and
`reports/c9c-test-cases.json`; checked ARM evidence is under
`reports/engine-proof/c9c-*`.
