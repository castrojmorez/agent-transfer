# C6C: Algorithm-4 bank on ARM — 2026-09-04

C6C completes the three-part bank investigation. It stages byte-identical
copies of the C6B loader, generated bank and required lookup support in the
pinned **RHH pokeemerald-expansion 1.17.0** test build, then executes them as
ARM7TDMI code in the bundled headless mGBA. This is a test-only integration,
not an installed player-facing randomizer.

## Result

| Measurement | Result |
|---|---:|
| Target commit | `e8bd1cd7b03fc032ea37e3ecd38b379b5d01a1e7` |
| Combined ARM tests | 11/11 pass |
| Bank layouts | 32 |
| Records loaded | 532 |
| Seed 0 selected row | 14 |
| Loaded FNV-1a digest | `afc54651` |
| Loader timer | 11,957 ticks of 64 CPU cycles |
| Loader time | 45.612 ms |
| Loader frames | 2.724 |
| Persistent `WrActive` | 16,436 EWRAM bytes |
| Algorithm-4 workspace | 0 bytes |
| Packed bank payload | 52,796 ROM bytes |
| Test-link ROM-section delta | 61,893 bytes |

The timer begins immediately before `wr_bank_load` and stops immediately after
it. It therefore covers bank/identity checks, selected-row CRC, copying the 532
packed trigger/landing records, and valid-last publication. It excludes save
I/O, engine interception and UI work.

The 61,893-byte linked delta compares two actual pinned-target test ELFs: the
ten-test fixed-proof baseline and the same suite plus the bank test. It includes
the test harness and retained loader support, so it is a conservative upper
bound rather than a final production-hook footprint. The EWRAM delta is exactly
the 16,436-byte target-ABI active table. The test baseline had 35,432 bytes of
unallocated EWRAM and the bank build retained 18,996 bytes. C4's normal proof
ROM had comparable 35,724-byte headroom, but a final production link must still
be measured after real integration.

## Executed behavior

The ARM test proves that:

* the exact bank fingerprint creates Algorithm-4/ruleset-1 identity;
* seed 0 selects index 14 and reproduces the host record digest;
* a second load of the same seed reproduces the same digest;
* `wr_lookup` resolves a published mapping;
* selected-row CRC corruption returns 12;
* algorithm, ruleset and fingerprint mismatches return 11;
* an invalid non-power-of-two layout count returns 1; and
* every failure leaves `valid=0` and `count=0`.

The other ten passing cases are the prior target engine proof, including flash
save/load within the running emulator. Machine-checked evidence is in
`reports/engine-proof/bank-probe.json`; its raw log and before/after resource
reports are in the same directory.

## Incidental recovery failures

The first baseline rebuild failed before randomizer code compiled because the
local toolchain extraction had lost its newlib include symlink. Re-running the
checksum-pinned bootstrap restored `usr/lib/arm-none-eabi/include` to
`../../include/newlib`. The next attempt found the test worktree's Florges WAV
truncated to 10,240 bytes. Its clean pinned copy was 22,504 bytes with SHA-256
`a13bd3a6ff723c27b6d5e5b5233a9da55e71b588b30746a0006eeb2ad04140d0`;
restoring only that fixture allowed the unchanged baseline to pass 10/10.
These were environment/worktree failures, not loader failures.

## C6 conclusion

Algorithm 4 is fast enough for a startup/loading transition and avoids the
47,388-byte Algorithm-3 workspace. The bank therefore remains a viable bounded
fallback and integration scaffold. It is not the desired long-term randomizer:
only 32 topologies exist, several player seeds intentionally share a topology,
save restoration is not yet bank-aware, and the reference model has unresolved
target drift.

The next on-demand design must receive a new algorithm identity rather than
silently replacing Algorithm 4. See `docs/mimo-optimization-assessment.md` for
the newly supplied optimization input and the proposed Algorithm-5 direction.

