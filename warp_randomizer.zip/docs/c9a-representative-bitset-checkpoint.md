# C9A representative-bitset checkpoint

## Decision

C9A is successful as a bounded optimization: compact free/reached/home
representative bitsets preserve C8C exactly and produce another material ARM
gain. **Do not assign Algorithm ID 5 or integrate the candidate yet.** Seed 0
still takes 7.609 seconds and retrying seed 42 takes 9.357 seconds, respectively
3.80x and 4.68x above the provisional two-second synchronous budget.

Continue to C9B with phase-level constructor profiling and one bounded attempt
to reduce repeated trial-state propagation/repair. Candidate-cap tuning and
broad endpoint-scan cleanup are exhausted. If profiling does not expose a safe
multi-fold reduction, reassess synchronous construction in favor of an
asynchronous UX, a larger bank, or a different constructor. Algorithm 4 remains
the frozen usable fallback.

## Design

C8C still scanned 512 representatives for source selection, partner selection,
every trial score, and repair seeding. C9A adds deterministic generated data:

* a 16-word index over the 512 canonical active representatives;
* a node-to-representative-ordinal map;
* 401 component slice offsets; and
* 512 component-to-representative ordinal entries.

The workspace maintains free, reached and home representative bitsets, together
with the committed and best-trial copies required by the existing scheduler.
Component reachability updates synchronize these sets through the sparse
component slices. Source and partner lists iterate set bits in increasing
representative ordinal, preserving C8C's lexical candidate order and therefore
its seeded RNG choices. Trial scores use intersections and popcounts. Dynamic
pair buckets, capability closure, early trap rejection, directed repair,
emission and final validation are unchanged.

Invalid component/representative dimensions and inconsistent generated slices
fail before construction. The experiment remains private test code with no
production API, save decoder or runtime identity.

## Host correctness and work reduction

For seeds 0–63, 255, 256, 65535 and 4294967295:

* 68/68 succeeded with exactly the same records, attempts, rejection outcomes
  and trial counts as C8C cap three;
* every replay was identical and every output passed the independent Python
  validator; and
* the 1,024-seed stress run was 1,024/1,024 exactly equal to C8C, deterministic
  and independently valid, retaining 803 first-attempt successes and a
  five-attempt maximum.

Seven synthetic methods (31 executions) pass normally and under ASan/UBSan.
Across the standard corpus, 60,914,176 C8C representative scan visits become:

| C9A indexed operation | Count |
|---|---:|
| Candidate/repair set-bit visits | 7,692,873 |
| Source/partner/repair word operations | 790,080 |
| Trial-score word operations | 1,113,488 |
| Component-to-representative updates | 710,315 |

The 680-generation in-process benchmark produces the identical digest and
improves from 2.038 to 1.290 seconds, a 1.580x speedup. Host process timing is
noisier and improved 1.292x in the recorded run.

## ARM measurement

The exact C9A core, generated index and harness were staged in the pinned
expansion/1.17.0 target test build. The ten fixed-engine tests plus C9A passed
11/11 in headless mGBA, and both layouts matched the checked host digests.

| Seed | Attempts | Trial states | Ticks | Seconds | Frames | Speedup vs C8C |
|---:|---:|---:|---:|---:|---:|---:|
| 0 | 1 | 766 | 1,994,526 | 7.609 | 454.437 | 1.433x |
| 42 | 2 | 1,525 | 2,452,812 | 9.357 | 558.854 | 1.719x |

The timer covers construction, emission, final C validation and 532-record
publication. It excludes allocation/zero-fill and release. One timer tick is 64
CPU cycles; one GBA frame is 4,389 ticks.

## Memory, ROM and stack evidence

The target-ABI workspace is 14,224 bytes, 448 bytes above C8C for seven 16-word
representative sets. Allocation from the controlled 115,760-byte free block
leaves 101,520 contiguous bytes and restores the heap exactly. The persistent
test table remains 16,436 bytes.

The separately compiled candidate object has 12,568 bytes of text and 56,770
bytes of generated/read-only data. The harness-inclusive test link adds 98,205
allocated ROM-section bytes and 16,436 static EWRAM bytes versus the ten-test
baseline; this is not a production link measurement. The largest
compiler-reported own frame is 316 bytes in retained validation; C9A's entry
frame is 208 bytes. Runtime stack high-water remains unmeasured.

## Boundary and reproduction

C9A is test-only. Reference-model acceptance does not establish target-world
completion, interactive walking, animation safety or a complete power-cycle
restore.

```sh
make c9a
SANITIZE=1 python3 tests/c9a_test.py
python3 tools/audit/build_engine_proof.py TARGET PREFIX --mode 1 \
  --c9a-probe --log reports/engine-proof/c9a-mode1.log
python3 tools/audit/target_resources.py TARGET/pokeemerald-test.elf PREFIX \
  reports/engine-proof/c9a-resources.json
python3 tools/audit/c9a_probe_report.py TARGET PREFIX \
  reports/engine-proof/c9a-mode1.log TARGET/pokeemerald-test.elf \
  reports/engine-proof/c6c-baseline-resources.json \
  reports/engine-proof/c9a-resources.json reports/engine-proof/c9a-probe.json
```

Host evidence is in `reports/c9a-feasibility.json` and
`reports/c9a-test-cases.json`; checked ARM evidence is under
`reports/engine-proof/c9a-*`.
