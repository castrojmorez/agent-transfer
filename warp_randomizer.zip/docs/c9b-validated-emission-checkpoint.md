# C9B validated-emission checkpoint

## Decision

C9B removes a measured redundant whole-graph validation from the successful
emission path while retaining the fail-closed entry validation. It preserves
C9A exactly and produces a useful ARM gain, but **does not make synchronous
generation acceptable and does not justify Algorithm ID 5**.

Continue to C9C with one final bounded specialization experiment: keep a cold
path that validates the embedded graph/index, measure a warm reference-only
path that reuses that approval, and generate an already sorted unique-trigger
emission index. Report cold and warm costs separately. If the constructor still
cannot credibly reach the provisional two-second budget, stop incremental work
on this scheduler and choose an asynchronous UX, a larger bank or another
constructor. Algorithm 4 remains the frozen usable fallback.

## Profile and change

C9A called `wr_graph_check` before construction and `wr_emit` called it again
after a successful construction. The graph is immutable during the call. Host
function profiling identified the two checks as a major fixed cost. C9B retains
the first complete graph/index validation, then uses an otherwise identical
post-validation emitter containing the same partner, alias-conflict and stable
sort checks as `wr_emit` but no second graph scan.

The pinned ARM probe measures one standalone graph check at 421,408 ticks
(1.608 seconds) and the post-check emitter at 139,629 ticks (0.533 seconds).
C9A-to-C9B total time falls by 426,471 ticks for seed 0 and 426,470 for seed 42,
closely matching the isolated validation cost. Constructor and scoring counters
are unchanged.

## Correctness

For seeds 0–63, 255, 256, 65535 and 4294967295:

* 68/68 records, attempts, rejection outcomes and every recorded work counter
  exactly match C9A;
* every replay is identical and every output passes the independent Python
  validator; and
* the 1,024-seed stress run is 1,024/1,024 exactly equal to C9A, deterministic
  and independently valid, retaining 803 first-attempt successes and a
  five-attempt maximum.

Seven synthetic methods (31 executions) pass normally and under ASan/UBSan.
The 680-generation in-process benchmark produces the same digest and improves
from 1.553 to 1.199 seconds, a 1.295x speedup. Comparable process timing is
noisier and improved 1.448x in the recorded run.

## ARM measurement

The exact C9B core, generated index and harness were staged in the pinned
expansion/1.17.0 target test build. The ten fixed-engine tests plus C9B passed
11/11 in headless mGBA, and both layouts matched checked host digests.

| Seed | Attempts | Trial states | Ticks | Seconds | Frames | Speedup vs C9A |
|---:|---:|---:|---:|---:|---:|---:|
| 0 | 1 | 766 | 1,568,055 | 5.982 | 357.269 | 1.272x |
| 42 | 2 | 1,525 | 2,026,342 | 7.730 | 461.686 | 1.210x |

The timer covers the retained entry graph check, construction, emission, final
C validation and 532-record publication. It excludes allocation/zero-fill and
release. One timer tick is 64 CPU cycles; one GBA frame is 4,389 ticks.

Subtracting the separately measured remaining graph check and post-check
emission leaves 3.841 seconds for seed 0 and 5.590 seconds for seed 42. Those
figures are not a deliverable runtime—they are a lower-bound diagnostic. They
show that publication cleanup alone cannot meet two seconds; substantial
constructor work would still remain.

## Memory, ROM and stack evidence

The target-ABI workspace remains 14,224 bytes and allocation from the
controlled 115,760-byte block leaves 101,520 contiguous bytes. The heap restores
exactly. The persistent test table remains 16,436 bytes.

The separately compiled candidate object has 13,084 bytes of text and 56,770
bytes of generated/read-only data. The harness-inclusive test link adds 99,089
allocated ROM-section bytes and 16,436 static EWRAM bytes versus the ten-test
baseline; this is not a production link measurement. The largest
compiler-reported own frame is 316 bytes in retained validation; C9B's entry
frame is 216 bytes. Runtime stack high-water remains unmeasured.

## Boundary and reproduction

C9B is test-only. It has no public API, production hook, save decoder, UI or
Algorithm-5 identity. Reference-model acceptance does not establish target-world
completion, interactive walking, animation safety or a complete power-cycle
restore.

```sh
make c9b
SANITIZE=1 python3 tests/c9b_test.py
python3 tools/audit/build_engine_proof.py TARGET PREFIX --mode 1 \
  --c9b-probe --log reports/engine-proof/c9b-mode1.log
python3 tools/audit/target_resources.py TARGET/pokeemerald-test.elf PREFIX \
  reports/engine-proof/c9b-resources.json
python3 tools/audit/c9b_probe_report.py TARGET PREFIX \
  reports/engine-proof/c9b-mode1.log TARGET/pokeemerald-test.elf \
  reports/engine-proof/c6c-baseline-resources.json \
  reports/engine-proof/c9b-resources.json reports/engine-proof/c9b-probe.json
```

Host evidence is in `reports/c9b-feasibility.json` and
`reports/c9b-test-cases.json`; checked ARM evidence is under
`reports/engine-proof/c9b-*`.
