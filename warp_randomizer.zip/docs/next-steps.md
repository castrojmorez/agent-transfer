# Remaining work after C10D

1. Run the short graphical C10D checklist in mGBA: inspect text/activity/attempt
   rendering and press physical B during the third run. Attach results or
   screenshots to the checkpoint. Automated headless mGBA already checks VRAM,
   audio/VBlank execution, injected `JOY_NEW` cancellation and frame deadlines.
2. Integrate the C10D screen into an opt-in production new-game path. Keep the
   measured allocation after window initialization, put immutable approval at
   boot/loading rather than inside a visible callback, measure runtime stack
   high-water, and retain publish-last/fail-closed behavior.
3. Define Algorithm 5's versioned save identity and persistence representation.
   Test reset during generation, Continue, data/version mismatch, corruption
   and explicit fallback without silently changing topology. Do not assign the
   ID until these paths pass.
4. Observe walking round trips, grouped exits and the full power-cycle/Continue
   path in an interactive emulator. The headless tests verify target warp
   functions, collision and flash save/load, but not animations or reboot.
5. Resolve target data drift: 12 destination disagreements, one absent endpoint,
   two matched-endpoint geometry changes, 1,729 target-only events and 13
   unmodeled excluded transitions. Audit landing tiles and script boundaries;
   create explicit target-approved traversal and progression data.
6. Audit HMs/badges, items, bikes, transport, scripted gates and state-dependent
   Escape. Preserve conservative unknown requirements unless a grant is
   justified. Any changed return guarantee is a separate ruleset decision.
7. Measure final ROM/RAM/stack and worst-case retries. Test scripts, dynamic
   warps, Dive/fall/escape, whiteout, restart, options/version mismatch and actual
   champion defeat/credits. Declare a supported playable preset only afterward.

Keep HANDOFF.md and STATUS.md current. Save a durable ZIP and standalone handoff
after each substantial checkpoint, preserving historical evidence under its
checkpoint/algorithm identity. See patches/engine-tests/README.md to reproduce
the C4 engine checks, C5 full-reference generator probe, C6C bank probe, C7B
bounded-candidate probe, C7C SCC/bitset probe, C8A event-driven probe, C8B
trial-volume probe, C8C indexed-state probe, C9A representative-bitset probe,
C9B validated-emission, C9C cold/warm indexed-emission, C10A cooperative
maximum-quantum, C10B frame-bounded microstep and C10C budgeted-task probes.
The C10D rendered mGBA probe and manual builder/checklist are the current gate.
