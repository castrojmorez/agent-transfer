# Why the recorded seeds failed, and what the condition names mean

Historical diagnosis of algorithm 2. The current algorithm-3 repair is described
in constructor-checkpoint.md. Counts below refer to the preserved baseline,
not current performance. Reproduction rolls back code and data policy in an
isolated temporary copy; current production files are never overwritten.

## Conclusion

The 0/8 result primarily exposes omissions in this revision's simplified
constructor. It does not establish that WEATHER_INSTITUTE or the `_1` naming
convention is defective. All 64 candidate attempts were replayed:

| Observed result | Attempts | Cause |
|---|---:|---|
| Directed-return rejection | 52 | Pairing does not protect one-way-entry regions or implement EscapePaths return reservations. All 52 have a reachable sink containing an endpoint named in EscapePaths at the first unsafe stage. |
| No reachable unused source | 12 | Reachable doors are consumed by progression leaves before enough expandable regions are connected. Failure occurs after only 9–17 pairs. |

Of the 52 directed-return rejections, 50 still contain traps after the modeled
capability closure. Two (seed 17, zero-based attempts 2 and 5) eventually have
return paths and reachable goals, but contain traps earlier. The current
acceptance policy deliberately rejects those early optional traps. That is a
stricter guarantee than merely finding a completion route.

These are graph-model findings, not emulator-observed softlocks. Speedchoice
has an Escape menu action; its destination depends on indoor/outdoor state,
escapeWarp and lastHealLocation. This port has not implemented or modeled that
action. A graph that excludes it cannot certify or condemn the original game's
actual recoverability.

## Concrete return failure

Seed 0, attempt 0 pairs:

* E,24,81,2: Sky Pillar F5 center.
* E,9,1,0: Slateport shipyard F2 stairs.

The supplied annotations give neither endpoint an outgoing walking connection.
Their randomized exits therefore lead only to each other. The player can reach
Sky Pillar F6 right (E,24,82,0), then take its directed fixed connection into
F5 center. In the declared model, that enters a closed two-node component.
The report includes the complete path from the Oldale root.

This pair remains a reachable closed sink even when EVERY conditional edge is
opened. It is therefore not explained by the Weather Institute or Flash gate.
EscapePaths.json group 34 (zero-based) explicitly contains E,24,81,2 alone.
The reference data already identifies this return obligation. My replacement
constructor removed the original's incomplete reservation state without yet
implementing constructive return protection; a final reverse-reachability check
can detect that omission but cannot repair the layout.

The constructor currently calls closure but ignores its unsafe result while
building; source selection requires reached, not a proven route home. Its
partner compatibility check only handles the needs_return/no_return tags,
which are not a complete substitute for the EscapePaths obligations or directed
connectivity. Coupled endpoint pairs alone do not guarantee global return paths.

## Concrete frontier failure

Seed 0, attempt 2 stops after ten pairs:

| Reachable source | Assigned destination |
|---|---|
| Petalburg outside House1 | Lavaridge gym |
| Petalburg outside gym | Sootopolis outside gym |
| Petalburg outside center | Rustboro gym |
| Petalburg outside House2 | Fortree gym |
| Petalburg outside mart | Mt. Pyre summit |
| Oldale outside House1 | Sootopolis gym |
| Oldale outside House2 | Mauville gym |
| Oldale outside center | Granite Cave F1 entrance |
| Oldale outside mart | Granite Cave Steven room |
| Granite Cave F1 left ladder | Dewford gym |

There are 492 active canonical endpoints left unpaired, zero reachable unpaired
sources and 41 reachable physical nodes. The capability closure has granted
Flash, Magma Emblem and Unlock Slateport, but has not exposed another free exit.
This is not an iteration-limit failure or a missing remap record.

In construct(), an unreachable prerequisite location receives score 6 before
the optional hub bonus, whereas an ordinary unreachable hub gets 5. This puts
progression leaves ahead of the connections needed to keep construction alive.
The simplistic degree test also counts raw alias edges, which need not expose
another independent exit. Unlike upstream's component-first ordering, this
constructor does not preserve a free endpoint budget or explicitly connect
remaining components before consuming the frontier on leaves.

## Controlled experiments

Each regenerated-layout experiment used the same eight seeds and all eight
attempt numbers with the actual C constructor, changing only the stated graph
input. These are diagnostics, not gameplay presets.

| Input change | Trap | No source | Accepted |
|---|---:|---:|---:|
| Delivered baseline | 52 | 12 | 0 |
| Open WEATHER_INSTITUTE unconditionally | 52 | 12 | 0 |
| Keep Ancient Tomb Flash edge closed as upstream does | 52 | 12 | 0 |
| Open both disputed edges | 52 | 12 | 0 |
| Open every conditional edge | 62 | 0 | 2 |
| Omit retained excluded-vanilla edges (diagnostic only) | 52 | 12 | 0 |

Changing connectivity can change construction choices and RNG consumption, so
identical totals do not mean identical layouts. Weather-open retains only 15/64
baseline partner arrays; Flash-closed retains 42/64. A second experiment holds
ALL original partner arrays fixed and re-evaluates them independently:

| Same original partner arrays, changed validation graph | Outcome |
|---|---|
| Weather edge open | Same 52 traps and 12 empty frontiers |
| Flash edge closed | Same 52 traps and 12 empty frontiers |
| Every condition open | 50 complete mappings still trap, 2 pass; all 12 partial constructions regain at least one reachable unused endpoint |

The last row removes intended progression requirements and is not a fix. It
separates connectivity/return failures from progression-limited construction.

## `_1` is a legitimate rule identifier

Flags.json has two different name spaces:

* The outer object key identifies a derivation rule, such as HOENN_CUT_1.
* The inner `flag` field names the capability that the rule grants, such as
  HOENN_CUT.

WarpRandomizationState's constructor takes compositeFlags.values(), so the
outer keys do not become activated flags. updateConnections collects
FlagCondition.getFlag() and matches those strings against edge.getCondition().
There is no automatic suffix stripping or rule-key alias resolution.

| Outer rule ID | Exported capability | Connection text in Warps.json | Pinned upstream behavior |
|---|---|---|---|
| HOENN_CUT_1 | HOENN_CUT | HOENN_CUT | Names match |
| HOENN_ROCK_SMASH_1 | HOENN_ROCK_SMASH | HOENN_ROCK_SMASH | Names match |
| HOENN_STRENGTH_1 | HOENN_STRENGTH | HOENN_STRENGTH | Names match; prerequisite activation is a separate question |
| HOENN_FLASH_1 | HOENN_FLASH | HOENN_FLASH_1 | Export and edge text do not match; edge never activated |

Therefore the `_1` convention itself is not a bug. The observable Flash
mismatch is the use of a rule ID in a field otherwise matched to exported
capabilities. Whether that closed Ancient Tomb edge is intentional cannot be
established from naming alone. The algorithm-2 revision's explicit Flash alias changes
upstream behavior; it is a proposed ruleset choice, not proof of author intent.
Do not globally rename the rule keys or strip every suffix.

A separate source caveat: updateConnections tests prerequisites only against
markedFlagLocations, while the Strength rule also names HOENN_ROCK_SMASH.
Granted capabilities are not added to that location set. The replacement's
explicit capability chaining is a deliberate improvement, not a verbatim
upstream simulation. This is separate from `_1` naming and is not needed to
explain the observed 64 failures.

## WEATHER_INSTITUTE is a travel condition, but it has no provider

The user's intuition about its syntactic role is correct. It labels the
Route119 weather-institute exterior (E,0,34,0) -> Fortree center exterior
(E,0,4,0) walking edge, just as HOENN_SURF labels other conditional edges.
The reverse Fortree -> Route119 connection is unconditional.

Unlike Surf/Cut/etc., neither pinned compositeFlags table exports
WEATHER_INSTITUTE, and KeyLocations has no matching progression trigger.
Because upstream removes conditional edges initially and restores only those
whose capability is granted, this edge remains absent from the solver. It does
not become free travel, and it is not dynamically tied to the engine's
VAR_WEATHER_INSTITUTE_STATE merely because the names resemble each other.

Calling that absence an oversight was stronger than the evidence supports.
A conservative solver may intentionally omit a walk connection that the game
allows. Supporting that possibility, Speedchoice ApplyFixesForEveryWarp
explicitly hides the Team Aqua bridge blockers with
FLAG_HIDE_ROUTE_119_TEAM_AQUA. Source behavior is verified; the original author's
intent is not. This could be deliberate conservative modeling or stale/incomplete
annotation. No author statement establishing which is included in the input.

For the port, select a coherent policy:

1. Preserve upstream's conservative solver behavior by explicitly marking this
   edge excluded/never granted. The current blocked-capability override already
   has that operational effect.
2. If the target mode always removes the relevant progression blockers, audit
   the full crossing and model it as fixed travel alongside the verified
   mode-gated script change.
3. If target gameplay should require completing the institute, define a real
   grant rule and the corresponding modeled location/event. Do not infer such a
   rule merely from the string name.

None of those choices replaces the constructor repairs identified above.

## Repair order following the diagnosis

1. Preserve component-expanding exits before consuming them on progression
   leaves. Track new usable canonical exits, not just raw adjacency degree.
2. Enforce directed return obligations during construction. Use reverse paths
   to a safe anchor, protect the EscapePaths groups, and retain repair/backtrack
   capacity. Do not copy upstream generateHomePaths uncritically: it tests paths
   from root to candidate, which is not the same as candidate to root.
3. Decide and implement the actual target Escape action and its state-dependent
   destination model. Retain the strict validator until the chosen guarantee
   and escape semantics are explicit.
4. Resolve Weather/Flash as documented ruleset decisions, retaining distinct
   rule IDs and exported capabilities. Test the audited target behavior.

## Reproduction and source anchors

From the handoff root (Python, cc and GNU patch):

```sh
python3 tools/audit/reproduce_algorithm2.py
```

reports/algorithm2/failure-diagnosis.json includes every attempt, first-trap capability
stage, reachable sink components, witness path and unpaired frontier.
reports/algorithm2/fixed-mapping-counterfactuals.json isolates effects on identical
partner arrays and checks the permanent two-node witness. Raw diagnostic
candidate arrays are regenerated under build/diagnostics and are never active
runtime tables. The bundled report is independently reproducible.

Exact upstream pins remain those in PROVENANCE.md:

* UPR: warps/WarpRandomizationState.java constructor, updateConnections,
  selectEscapePathWarps, generateHomePaths; Flags.java; FlagCondition.java.
* UPR: emeraldex/EmeraldExWarpRandomizer.java createState, doNextMapping,
  getUnconnectedComponentMapping, getHomeLinkMapping.
* UPR: scripts/Warps.json, Flags.json, KeyLocations.json, EscapePaths.json.
* Speedchoice: src/random_warps.c ApplyFixesForEveryWarp and
  ApplyFixesForSpecialWarps; src/start_menu.c StartMenu_EscapeCallback and
  BuildNormalStartMenu; src/overworld.c UpdateEscapeWarp and
  SetWarpDestinationToEscapeWarp.

All conclusions about game recoverability remain source/model-scoped; no new
ROM build or emulator test was performed in this follow-up.

## Historical policy subsequently verified

The user's historical source was verified at commit
`f0966a668d3e7a7e937a519365cb1391d4a174a4`,
`dist/Randomiser/Flags.json.js`, comment lines 56–69. The author explicitly
describes incomplete flag modeling as a conservative generation policy.
Unmodeled connections remain unavailable to the solver so generation does not
rely on them. This establishes the fallback policy, not the intent of every
unresolved token and not physical blockage in the game. See
reports/historical-policy.json for the source hash.

Algorithm 3 defaults to that policy for all unresolved requirements, reports
them, and disables the speculative Flash alias. Explicit aliases and strict
audit errors remain supported. The normalized compiler still rejects undeclared
capabilities; the importer deliberately declares unresolved tokens without
grant rules. No unknown requirement becomes an unconditional connection.
