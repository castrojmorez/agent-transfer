# C5: target generator lifetime and timing — 2026-09-04

The proposed memory lifetime works at a controlled initialization point, but
the current Algorithm 3 is far too slow to run synchronously on the target.
This checkpoint is a measured rejection of that execution plan, not a full-game
integration.

## Executed target result

The target test build stages byte-identical copies of `src/warp_rando.c`,
`include/warp_rando.h`, and `data/reference-graph.h`. It compiles them with the
pinned expansion/1.17.0 game and runs them under the bundled headless mGBA.
Seed 0, algorithm 3, ruleset 1, and a one-attempt budget produced the same 532
records as the host evidence.

| Check | Result |
|---|---:|
| Existing fixed-engine cases | 10/10 passed |
| Full-reference generator case | 1/1 passed |
| Deterministic record FNV-1a | `0x36115947` |
| `WrWork`, target ABI | 47,388 bytes |
| `WrActive`, target ABI | 16,436 bytes |
| Heap free/largest before allocation | 115,760 / 115,760 bytes |
| Heap free/largest while workspace exists | 68,356 / 68,356 bytes |
| Heap free/largest after release | 115,760 / 115,760 bytes |
| Allocator overhead for workspace block | 16 bytes |
| Generator time | 644,772,173 ticks at 64 CPU cycles/tick |
| Derived target time | 2,459.610645 seconds; 146,906.396 frames |

The timer covers `wr_generate` and excludes heap allocation/zero-fill, release,
and output hashing. A GBA frame is exactly 4,389 of these timer ticks. The
constructor therefore takes about **41 minutes of target time** for this seed.
It completed in fast-forwarded headless emulation; that host wall time is not a
hardware performance measure.

After releasing `WrWork`, the test checks exact allocator restoration, the
active-table digest, and a real `wr_lookup`. Publication remains atomic and the
mapping stays usable. This validates the lifetime mechanics only in a nearly
empty test heap. It does not establish that a 47,404-byte allocation (workspace
plus allocator header) is available during arbitrary gameplay.

## C4 resource-audit correction

C4's standalone size probe omitted the target Makefile's
`-mabi=apcs-gnu` option. Under that ABI, each `WrKey`-only aggregate is rounded
differently: `WrRecord` is 8 bytes rather than 6. Because both large structures
contain 2,048 records, C4 understated each by exactly 4,096 bytes.

| Object | C4 reported | Correct target ABI |
|---|---:|---:|
| `WrRecord` | 6 | 8 |
| `WrWork` | 43,292 | 47,388 |
| `WrActive` | 12,340 | 16,436 |
| Both buffers | 55,632 | 63,824 |

`tools/audit/target_resources.py` now uses the target's ABI, architecture,
interworking, tuning, language, and optimization flags. A rebuilt enabled
normal ROM still uses 226,420 EWRAM bytes and leaves 35,724 unallocated. Both
buffers as additional globals would exceed that by 28,100 bytes. Persisting
only `WrActive` would leave 19,288 bytes before any other integration state.

The corrected audit also records compiler stack frames. The largest single
portable-core frame is 316 bytes in `closure_until`. This is not a call-chain,
interrupt-stack, or runtime high-water result; stack measurement remains open.

## Why timing failed

Algorithm 3 was designed first for construction correctness. For each of about
256 pair selections it can trial every remaining candidate. Each trial rebuilds
the partial destination state and performs graph/progression closure across 879
vertices and 1,394 directed edges. That repeated full-graph scoring is tolerable
on a desktop host (roughly 1.3 seconds in the recorded sweep) but pathological
on the ARM7TDMI.

Yielding the same work across frames would avoid a frozen UI but would still
take roughly 146,906 frames. The next constructor must reduce total work, not
merely become resumable.

## Decision and next gate

Accepted for later integration: one persistent active table plus a workspace
allocated and freed during a deliberately controlled phase, with allocation
failure explicit. Rejected: invoking current `wr_generate` synchronously in a
new-game or load callback.

C6 should prototype a materially cheaper deterministic constructor while
retaining the independent validator and conservative progression policy. Good
candidates are cached/incremental frontier scoring or a compact bank of
prevalidated mappings. Any algorithm change requires a new algorithm ID and
fresh host seed evidence before another target benchmark. A resumable API is
still desirable after the total work is reduced.

Machine-readable evidence is in `reports/engine-proof/generator-probe.json`,
`generator-probe-resources.json`, and `mode1-resources-c5.json`; the raw target
log is `generator-mode1.log`. Reproduction is documented in
`patches/engine-tests/README.md`.
