# C7C graph-sized SCC closure on ARM

## Decision

C7C completes the C7 investigation. The SCC/bitset design preserves every
recorded C7A layout and cuts temporary target workspace by 76.906%, but it still
blocks for 38–75 seconds on the measured seeds. **Do not assign Algorithm ID 5
or integrate C7C synchronously.** Keep Algorithm 4 as the usable fallback.

The result separates two questions that C7B left coupled: graph-sized memory is
viable, while repeated trial closure remains too expensive. C8 should retain
the compact workspace but replace repeated whole-component scans with an
event-driven frontier or otherwise eliminate most per-trial propagation work.

## Design and correctness

`compile_closure.py` deterministically collapses unconditional fixed travel into
400 strongly connected components for the 879-node reference graph. It emits
13-word forward and reverse transitive-closure bitsets, 608 active-node indices
and 90 cross-component conditional edges. Unknown requirements remain
unavailable; no Weather or Flash alias was introduced.

The experimental C7C scheduler keeps C7A's cap-4 partner order, retry mixer,
early capability-stage trap rule, repair test, final emission and validation.
Starting a trial from the cached zero-capability closure is essential: starting
from the final granted state can hide a trap that existed before a later
capability made it escapable.

Across seeds 0–63, 255, 256, 65535 and 4294967295:

* 68/68 succeeded; 66 on attempt zero and two on attempt one.
* 68/68 layouts exactly matched C7A, including accepted attempt and rejection.
* 68/68 process replays were byte-identical.
* 68/68 emitted tables passed the independent Python validator.
* Five synthetic test methods (27 executions) passed normally and under
  ASan/UBSan, including explicit fail-closed component capacity.

The first host benchmark exposed and corrected redundant closure-row ORs. The
corrected host run reduced the same-run C7A total from 1.745 to 0.822 seconds,
although process launch is included and ARM is the decision measurement.

## ARM measurement

The exact generated graph/index and experimental core were staged in the pinned
expansion/1.17.0 test build. Existing engine proofs plus C7C passed 11/11 in
headless mGBA. Both outputs matched C7A's host FNV-1a digests.

| Seed | Attempts | Trial states | Ticks | Seconds | Frames | Speedup vs C7B |
|---:|---:|---:|---:|---:|---:|---:|
| 0 | 1 | 1,020 | 9,969,798 | 38.032 | 2,271.542 | 1.765x |
| 42 | 2 | 2,039 | 19,699,591 | 75.148 | 4,488.401 | 1.749x |

The timer covers construction, emission, final C validation and 532-record
publication. It excludes workspace allocation/zero-fill and release. One tick
is 64 CPU cycles and one GBA frame is 4,389 ticks.

## Memory and code evidence

The target-ABI C7C workspace is 10,944 bytes, down 36,444 bytes from C7B's
47,388. Allocation from the controlled 115,760-byte free block left 104,800
contiguous bytes; the 16-byte allocator overhead and all heap metrics restored
exactly after release. The persistent test table remains 16,436 EWRAM bytes.

The separately compiled core/index object contains 9,696 bytes of text and
45,294 bytes of generated read-only closure data. The combined test link added
83,173 allocated ROM-section bytes and 16,436 static EWRAM bytes versus the
ten-test baseline; that is a conservative harness-inclusive delta, not a
production link. The largest compiler-reported own frame is 316 bytes from the
retained production validator; C7C's entry frame is 160 bytes. Neither is a
runtime stack high-water measurement.

## Remaining boundary

C7C is an experiment, not a runtime algorithm. It has no public API, production
hook, save decoder, UI or Algorithm-5 identity. The proof remains reference
model and headless: it does not establish target-world completion, interactive
walking, animation safety or full power-cycle restore.

## Reproduction

```sh
make c7c
SANITIZE=1 python3 tests/c7c_test.py
python3 tools/audit/build_engine_proof.py TARGET PREFIX --mode 1 \
  --c7c-probe --log reports/engine-proof/c7c-mode1.log
python3 tools/audit/target_resources.py TARGET/pokeemerald-test.elf PREFIX \
  reports/engine-proof/c7c-resources.json
python3 tools/audit/c7c_probe_report.py TARGET PREFIX \
  reports/engine-proof/c7c-mode1.log TARGET/pokeemerald-test.elf \
  reports/engine-proof/c6c-baseline-resources.json \
  reports/engine-proof/c7c-resources.json reports/engine-proof/c7c-probe.json
```

Checked host evidence is in `reports/c7c-feasibility.json` and
`reports/c7c-test-cases.json`; ARM evidence is under
`reports/engine-proof/c7c-*`.
