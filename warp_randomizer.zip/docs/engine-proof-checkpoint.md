# C4: ARM build and headless engine proof — 2026-09-04

> **C5 correction:** the C4 standalone struct-size probe omitted the target's
> `-mabi=apcs-gnu` flag. Correct target sizes are `WrWork` 47,388,
> `WrActive` 16,436, `WrRecord` 8, and both buffers 63,824 bytes. The normal-ROM
> linked allocations and all C4 execution results remain valid. See
> `generator-lifetime-checkpoint.md` for the corrected audit and target run.

The fixed Oldale mapping now builds as a normal target ROM and passes ten
ARM engine tests in headless mGBA, with the proof both enabled and disabled.
This advances beyond the earlier host stub tests. The full randomizer is still
not installed in the game, and interactive movement and power-cycle/Continue
behavior have not been observed.

## Executed result

| Check | Result |
|---|---|
| Pinned expansion/1.17.0 target | e8bd1cd7b03fc032ea37e3ecd38b379b5d01a1e7 |
| ARM compiler | GCC 13.2.1 20231009, Ubuntu package 15:13.2.rel1-2 |
| Proof disabled, normal ROM | Build/link succeeded |
| Proof enabled, normal ROM | Build/link succeeded |
| Proof disabled, target mGBA tests | 10/10 passed |
| Proof enabled, target mGBA tests | 10/10 passed |
| Actual flash save/load | Passed in both modes; restored interior/coordinates and exit mapping |
| House2 (3,6) | Target collision is zero; not a warp-event location |
| Reproduction patches | Reconstruct the exact built target files from the pinned revision |
| Local bootstrap recovery | Recreated dependencies under another prefix; ARM resource report identical |

The tests invoke the actual static SetupWarp through a TESTING-only bridge and
then the actual WarpIntoMap. They use compiled target map headers, collision
functions and flash routines. The bridge is absent from normal ROM symbols.
Raw logs, per-test outcomes, image hashes and measurements are under
reports/engine-proof/. Build and recovery commands are in
patches/engine-tests/README.md. No ROMs or dependency binaries are bundled.

## Issues encountered and corrected

These were build/test setup issues; the production fixed-mapping logic did not
need changing after the target tests.

* The environment had no ARM toolchain or package indexes. Package-manager
  downloads could not resolve packages, and its update process could not switch
  user identities here. Checksum-pinned Ubuntu packages were downloaded over
  HTTPS and extracted into a local prefix, with no system installation.
* Two upstream Makefile pipelines use /dev/fd via Bash process substitution.
  That path is unavailable here. A separate portability patch appends the same
  assembler suffix through an ordinary pipe group. Compile error propagation
  is preserved by pipefail and the group's conditional command.
* The reduced test build initially omitted test_test_runner.o, which the target
  linker script explicitly requires. The build recipe now includes that support
  file while filtering runtime execution to WarpProof tests.
* Hydra assumes a usable /tmp and failed before running tests. The delivered
  build script uses the same mGBA runner/settings sequentially with ordinary
  files inside the checkout. It verifies the expected pass count, so zero tests
  cannot be reported as success.
* One initial assertion wrongly expected House1's exit row to be 7. The engine
  returned 8, consistent with the pinned target map.json. House2's native exit
  row is 7. The assertion was corrected from map evidence; no engine behavior
  was changed to make it pass.

## RAM decision exposed by the normal link

The enabled proof uses 226,420 bytes of EWRAM, leaving **35,724 bytes**. IWRAM
allocation spans 28,376 bytes; ROM allocation spans 26,752,812 bytes. These are
linked allocation figures, not dynamic heap/stack peaks or frame timings.

ARM-compiled sizeof results for the current portable generator:

| Object | Bytes |
|---|---:|
| WrWork | 43,292 |
| WrActive | 12,340 |
| Both buffers | 55,632 |
| WrGraph descriptor | 80 |
| WrRecord | 6 |

Allocating both buffers as additional permanent EWRAM objects would exceed the
current unallocated span by **19,908 bytes**. The game's existing heap reserves
115,968 bytes inside its current allocation. That is capacity, not a measurement
of free heap at the proposed generation point.

Next, design and measure a temporary-workspace lifetime: for example, retain
the active table separately and allocate/release work from the existing heap at
a controlled initialization phase. A smaller graph-bound capacity is another
option. Neither is implemented or claimed safe by this checkpoint. Generation
must also yield between frames or otherwise meet a measured startup budget.
Do not simply add both current buffers as globals.

## Remaining evidence boundary

The save test writes and reads emulated flash, then restores the current map
header for the exit. It does not close/reopen the emulator, run the full
Continue callback, or exercise animations. Tile passability alone does not
certify all door animation and player movement paths. Interactive round trips,
full restart/Continue, exceptional transitions and hardware behavior remain
open. The reference graph still needs target map/progression reconciliation.

The algorithm-3 portable core and reference data are unchanged in C4. Its C3
68-seed acceptance evidence remains applicable to that same abstraction. The
new tests establish behavior of the small fixed engine proof only.
