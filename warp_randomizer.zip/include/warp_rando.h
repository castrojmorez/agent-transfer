#ifndef WARP_RANDO_H
#define WARP_RANDO_H
#include <stdint.h>
#include <stddef.h>
#define WR_NONE UINT16_MAX
#define WR_ALGORITHM 3u
#define WR_SAVE_BYTES 56u
#define WR_MAX_NODES 2048u
#define WR_MAX_CAPS 256u
#define WR_NEEDS_RETURN 1u
#define WR_NO_RETURN 2u
struct WrKey { uint8_t group, map, warp; };
struct WrNode { struct WrKey id, trigger; uint16_t rep; uint8_t active, tags; };
struct WrEdge { uint16_t to, cap; };
struct WrReq { uint16_t index; uint8_t capability; };
struct WrRule { uint16_t grant, offset, count; };
struct WrGraph {
    uint16_t n, caps, edge_count, rule_count, req_count, goal_count, root;
    const struct WrNode *nodes;
    const struct WrEdge *edges, *reverse_edges;
    const uint16_t *bounds, *reverse_bounds;
    const struct WrRule *rules;
    const struct WrReq *reqs;
    const uint16_t *goals;
    uint8_t fingerprint[32];
};
struct WrRecord { struct WrKey trigger, landing; };
struct WrIdentity { uint32_t seed, algorithm, ruleset; uint8_t data[32]; };
struct WrActive {
    struct WrIdentity identity;
    struct WrRecord records[WR_MAX_NODES];
    uint16_t count, attempt;
    uint8_t valid;
};
/* Caller-owned workspace. Place explicitly in EWRAM on target. No heap/RNG globals. */
struct WrWork {
    uint16_t partner[WR_MAX_NODES], destination[WR_MAX_NODES];
    uint16_t queue[WR_MAX_NODES], candidates[WR_MAX_NODES];
    uint16_t reverse_head[WR_MAX_NODES], reverse_next[WR_MAX_NODES];
    uint8_t reached[WR_MAX_NODES], home[WR_MAX_NODES], scratch[WR_MAX_NODES], caps[WR_MAX_CAPS];
    struct WrRecord candidate[WR_MAX_NODES];
    uint16_t attempts, rejection_counts[12], candidate_count;
};
enum WrResult { WR_OK, WR_BAD_DATA, WR_ODD_POOL, WR_NO_SOURCE,
    WR_NO_PARTNER, WR_BAD_PAIR, WR_CONFLICT, WR_COVERAGE, WR_TRAP,
    WR_OBJECTIVE, WR_RETRIES, WR_BAD_IDENTITY };
int wr_graph_check(const struct WrGraph *g);
int wr_emit(const struct WrGraph *g, const uint16_t *partner,
            struct WrRecord *out, uint16_t *count);
int wr_validate(const struct WrGraph *g, const struct WrRecord *table,
                uint16_t count, struct WrWork *w);
int wr_generate(const struct WrGraph *g, const struct WrIdentity *identity,
                uint16_t retries, struct WrActive *active, struct WrWork *work,
                int *last_rejection);
int wr_publish(const struct WrGraph *g, const struct WrIdentity *identity,
               const struct WrRecord *table, uint16_t count,
               struct WrActive *active, struct WrWork *work);
void wr_invalidate(struct WrActive *active);
/* Portable metadata only; target SaveBlock integration remains unimplemented. */
int wr_encode(const struct WrActive *active, uint8_t out[WR_SAVE_BYTES]);
int wr_decode(const struct WrGraph *graph, const uint8_t in[WR_SAVE_BYTES],
              struct WrIdentity *identity, uint16_t *attempt);
/* 1: remapped, 0: unchanged, -1: stale/inactive. */
int wr_lookup(const struct WrActive *active, const struct WrIdentity *identity,
              struct WrKey *requested);
#endif
