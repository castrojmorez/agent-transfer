#ifndef WARP_BANK_H
#define WARP_BANK_H
#include "warp_rando.h"

#define WR_BANK_ALGORITHM 4u
#define WR_BANK_RULESET 1u

enum WrBankResult { WR_BANK_BAD_CRC = 12 };

/* Packed byte triples keep ROM use independent of target struct padding. */
struct WrBank {
    uint16_t layout_count, record_count;
    const uint8_t *triggers;
    const uint8_t *landings;
    const uint32_t *row_crc32;
    uint8_t fingerprint[32];
};

uint16_t wr_bank_index(uint32_t seed, uint16_t layout_count);
int wr_bank_make_identity(const struct WrBank *bank, uint32_t seed,
                          struct WrIdentity *identity);
int wr_bank_load(const struct WrBank *bank, const struct WrIdentity *identity,
                 struct WrActive *active);

#endif
