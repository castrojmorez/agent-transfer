# Clean-directory reproduction

Extracted the proposed ZIP into a fresh directory containing only the declared
handoff files, then executed the README host commands in order. All passed.
Source audit commands used the three already-retrieved, exact pinned Git
checkouts via ../sources. The fetch helper's existing-checkout pin verification
path ran; fresh-network fetch by that helper was not repeated. The initial
source retrieval itself used successful Git clones and full commit verification.
No ARM toolchain or emulator run was represented by these commands.

| Command | Exit | Host seconds |
|---|---:|---:|
| `make test` | 0 | 5.089 |
| `make sanitize` | 0 | 16.263 |
| `make data` | 0 | 0.205 |
| `make seeds` | 0 | 1.705 |
| `python3 tools/audit/fetch_sources.py ../sources` | 0 | 0.045 |
| `python3 tools/audit/drift.py data/reference/Warps.json ../sources/target ../sources/speedchoice reports` | 0 | 0.196 |
| `python3 tools/audit/make_proof_patch.py ../sources/target build/proof.patch` | 0 | 0.053 |
| `cmp patches/expansion-1.17.0-proof.patch build/proof.patch` | 0 | 0.003 |
| `git -C ../sources/target apply --check "$PWD/patches/expansion-1.17.0-proof.patch"` | 0 | 0.003 |
| `python3 tools/audit/resources.py` | 0 | 0.082 |

Normalized JSON, generated C header, import report, complete drift CSV, drift
summary and map-input hashes were byte-identical after regeneration. Fixed proof
patch regeneration also matched byte-for-byte and git apply --check passed.
Host tests and sanitizers exercised the delivered core. Full reference seed
failures remain failures; successful command exit means the batch was recorded,
not that the generator produced accepted full-game layouts.
