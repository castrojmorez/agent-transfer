#!/usr/bin/env python3
"""C10C budget, lifecycle, progress, cancellation, and exactness tests."""
import hashlib,importlib.util,json,os,pathlib,subprocess,sys,tempfile,unittest
ROOT=pathlib.Path(__file__).resolve().parents[1];sys.path.insert(0,str(ROOT/'tests'))
from validate import validate

def load(name,path):
    spec=importlib.util.spec_from_file_location(name,path);module=importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module);return module
compiler=load('compiler',ROOT/'tools/warprandogen/compile.py')
index_compiler=load('index_compiler',ROOT/'tools/warprandogen/compile_c9c_index.py')
BASE_KEYS=('result','last_rejection','attempt','trial_cap','records','attempts','pairs',
 'eligible_partners','partner_trials','state_evaluations','forward_components',
 'reverse_components','repair_components','active_visits','conditional_visits','row_ors',
 'representative_bit_visits','pair_alias_visits','reverse_calls','reverse_edge_updates',
 'set_word_ops','score_word_ops','component_rep_updates','work_bytes')

def model(n=2,active=True):
    return {'schema':2,'description':'C10C synthetic fixture','capabilities':[],
      'nodes':[{'name':f'N{i:04}','id':[1,i//128,i%128],'trigger':[2,i//128,i%128],
       'rep':f'N{i:04}','active':active} for i in range(n)],'edges':[],'rules':[],
      'root':'N0000','goals':[f'N{n-1:04}']}
def edge(d,a,b,cap=None):d['edges'].append({'from':f'N{a:04}','to':f'N{b:04}','requires':cap})

class C10C(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.tmp=tempfile.TemporaryDirectory();cls.root=pathlib.Path(cls.tmp.name);cls.cache={};cls.results=[]
    @classmethod
    def tearDownClass(cls):
        (ROOT/'reports/c10c-test-cases.json').write_text(json.dumps(cls.results,indent=2)+'\n');cls.tmp.cleanup()
    def executables(self,d):
        graph=compiler.emit(d);index,meta=index_compiler.emit(d);digest=hashlib.sha256((graph+index).encode()).hexdigest();folder=self.root/digest
        if digest not in self.cache:
            folder.mkdir();(folder/'graph.h').write_text(graph);(folder/'reference-c9c-event-index.h').write_text(index)
            common=[os.environ.get('CC','cc'),'-std=c99','-Wall','-Wextra','-Werror','-pedantic','-O1','-g','-I'+str(ROOT/'include'),'-I'+str(folder)]
            if os.environ.get('SANITIZE')=='1':common[1:1]=['-fsanitize=address,undefined','-fno-omit-frame-pointer','-fno-pie','-no-pie']
            for name in ('c9c','c10c'):
                p=subprocess.run([*common,str(ROOT/f'tools/experiments/{name}_candidate.c'),'-o',str(folder/name)],capture_output=True,text=True)
                self.assertEqual(p.returncode,0,p.stderr)
            self.cache[digest]=(folder,meta)
        return self.cache[digest]
    def run_candidate(self,d,seed=0,cap=3,retries=8,budget=3200,cancel=0,restart=False,tick=37,publish=0,prior=False):
        folder,meta=self.executables(d);name='c9c' if prior else 'c10c';args=[str(folder/name),str(seed),str(cap),str(retries)]
        if not prior:args += [str(budget),str(cancel),str(int(restart)),str(tick),str(publish)]
        p=subprocess.run(args,capture_output=True,text=True);self.assertEqual(p.returncode,0,p.stdout+p.stderr)
        result=json.loads(p.stdout);self.results.append({'case':self.id().split('.')[-1],'seed':seed,'budget':budget,'tick':tick,
          'cancel':cancel,'result':result['result'],'callbacks':result.get('callbacks'),'records':len(result['records']),'components':meta['components']});return result
    def assert_exact(self,d,seed=0,retries=8):
        expected=self.run_candidate(d,seed=seed,retries=retries,prior=True)
        for budget,tick in ((2600,17),(2800,61),(3200,37),(3600,113),(4000,29)):
            result=self.run_candidate(d,seed=seed,retries=retries,budget=budget,tick=tick)
            self.assertTrue(all(result[k]==expected[k] for k in BASE_KEYS),(seed,budget,tick))
            self.assertEqual(result['progress'],1000);self.assertEqual(result['status'],2)
            self.assertEqual((result['published'],result['released'],result['active_valid']),(1,1,1))
            self.assertEqual((result['invalidations'],result['publishes'],result['releases']),(1,1,1))
            self.assertGreater(result['max_steps_per_callback'],1);validate(d,result['records'])
    def test_budget_schedules_are_exact(self):
        d=model(10)
        for a,b in ((0,1),(1,0),(2,3),(3,2),(2,4),(4,2),(2,5),(5,2),(6,7)):edge(d,a,b)
        d['goals']=[v['name'] for v in d['nodes']]
        for seed in (0,1,2,17,255,4294967295):self.assert_exact(d,seed)
    def test_retry_alias_capability_progress_contract(self):
        d=model(8);d['capabilities']=['KEY'];d['rules']=[{'grant':'KEY','requires':[{'location':'N0000'}]}]
        for member,rep in ((1,0),(3,2),(5,4),(7,6)):
            d['nodes'][member]['rep']=d['nodes'][rep]['name'];d['nodes'][member]['trigger']=d['nodes'][rep]['trigger'][:]
            edge(d,rep,member);edge(d,member,rep)
        edge(d,0,2,'KEY');edge(d,2,0,'KEY')
        for seed in (0,42,65535):self.assert_exact(d,seed)
    def test_cancel_cleans_without_publication_and_restart_is_exact(self):
        d=model(40)
        for node in range(1,40):edge(d,0,node);edge(d,node,0)
        for stop in (1,2,5):
            result=self.run_candidate(d,cancel=stop);self.assertEqual(result['result'],101)
            self.assertEqual(result['status'],4);self.assertFalse(result['records']);self.assertEqual(result['active_valid'],0)
            self.assertEqual((result['published'],result['released'],result['publishes'],result['releases']),(0,1,0,1))
            restarted=self.run_candidate(d,cancel=stop,restart=True);expected=self.run_candidate(d,prior=True)
            self.assertTrue(all(restarted[k]==expected[k] for k in BASE_KEYS));self.assertEqual(restarted['cancelled_once'],1)
            self.assertEqual((restarted['invalidations'],restarted['publishes'],restarted['releases']),(2,1,2))
    def test_publish_failure_is_fail_closed_and_released(self):
        result=self.run_candidate(model(),publish=1)
        self.assertEqual(result['result'],1);self.assertEqual(result['status'],3);self.assertFalse(result['records'])
        self.assertEqual((result['published'],result['released'],result['active_valid']),(0,1,0))
        self.assertEqual((result['publishes'],result['releases']),(1,1))
    def test_invalid_budget_and_generation_failures_cleanup(self):
        for budget in (0,2599,4001,65535):
            result=self.run_candidate(model(),budget=budget);self.assertEqual(result['result'],1)
            self.assertEqual((result['status'],result['published'],result['released'],result['active_valid']),(3,0,1,0))
        odd=self.run_candidate(model(3),retries=2);self.assertEqual(odd['result'],10)
        self.assertEqual((odd['status'],odd['published'],odd['released'],odd['active_valid']),(3,0,1,0))

if __name__=='__main__':unittest.main(verbosity=2)
