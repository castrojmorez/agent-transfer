#!/usr/bin/env python3
"""Synthetic checks for the graph-sized event-driven SCC/bitset C9C candidate."""
import hashlib,importlib.util,json,os,pathlib,subprocess,sys,tempfile,unittest
ROOT=pathlib.Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/'tests'))
from validate import validate

def load(name,path):
    spec=importlib.util.spec_from_file_location(name,path)
    module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module);return module
compiler=load('compiler',ROOT/'tools/warprandogen/compile.py')
event_compiler=load('event_compiler',ROOT/'tools/warprandogen/compile_c9c_index.py')

def model(n=2,active=True):
    return {'schema':2,'description':'C9C synthetic fixture','capabilities':[],
      'nodes':[{'name':f'N{i:04}','id':[1,i//128,i%128],
       'trigger':[2,i//128,i%128],'rep':f'N{i:04}','active':active} for i in range(n)],
      'edges':[],'rules':[],'root':'N0000','goals':[f'N{n-1:04}']}
def edge(d,a,b,cap=None):
    d['edges'].append({'from':f'N{a:04}','to':f'N{b:04}','requires':cap})

class C9C(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.tmp=tempfile.TemporaryDirectory();cls.root=pathlib.Path(cls.tmp.name);cls.cache={};cls.results=[]
    @classmethod
    def tearDownClass(cls):
        (ROOT/'reports/c9c-test-cases.json').write_text(json.dumps(cls.results,indent=2)+'\n')
        cls.tmp.cleanup()
    def run_candidate(self,d,seed=0,trial_cap=3,retries=8):
        graph=compiler.emit(d);event_index,meta=event_compiler.emit(d)
        digest=hashlib.sha256((graph+event_index).encode()).hexdigest();folder=self.root/digest
        if digest not in self.cache:
            folder.mkdir(exist_ok=True);(folder/'graph.h').write_text(graph);(folder/'reference-c9c-event-index.h').write_text(event_index)
            cmd=[os.environ.get('CC','cc'),'-std=c99','-Wall','-Wextra','-Werror','-pedantic','-O1','-g',
                 '-I'+str(ROOT/'include'),'-I'+str(folder),
                 str(ROOT/'tools/experiments/c9c_candidate.c'),'-o',str(folder/'run')]
            if os.environ.get('SANITIZE')=='1':
                cmd[1:1]=['-fsanitize=address,undefined','-fno-omit-frame-pointer','-fno-pie','-no-pie']
            p=subprocess.run(cmd,capture_output=True,text=True);self.assertEqual(p.returncode,0,p.stderr)
            self.cache[digest]=meta
        p=subprocess.run([str(folder/'run'),str(seed),str(trial_cap),str(retries)],capture_output=True,text=True)
        self.assertEqual(p.returncode,0,p.stdout+p.stderr);r=json.loads(p.stdout)
        self.results.append({'case':self.id().split('.')[-1],'seed':seed,'trial_cap':trial_cap,'result':r['result'],
          'last_rejection':r['last_rejection'],'attempts':r['attempts'],'records':len(r['records']),
          'components':self.cache[digest]['components']})
        return r
    def test_deterministic_reciprocal(self):
        d=model()
        for seed in [0,1,2,17,255,256,65535,4294967295]:
            a=self.run_candidate(d,seed);b=self.run_candidate(d,seed)
            self.assertEqual(a,b);self.assertEqual(a['result'],0);validate(d,a['records'])
    def test_frontier_and_directed_sink(self):
        d=model(10)
        for a,b in [(0,1),(1,0),(2,3),(3,2),(2,4),(4,2),(2,5),(5,2),(6,7)]:edge(d,a,b)
        d['goals']=[v['name'] for v in d['nodes']]
        for seed in [0,1,2,17,255,4294967295]:
            r=self.run_candidate(d,seed);self.assertEqual(r['result'],0,r);validate(d,r['records'])
    def test_grouped_aliases(self):
        d=model(4)
        for member,rep in [(1,0),(3,2)]:
            d['nodes'][member]['rep']=d['nodes'][rep]['name'];d['nodes'][member]['trigger']=d['nodes'][rep]['trigger'][:]
            edge(d,rep,member);edge(d,member,rep)
        r=self.run_candidate(d);self.assertEqual(r['result'],0,r);self.assertEqual(len(r['records']),2);validate(d,r['records'])
    def test_conflicting_trigger_representatives_rejected_at_compile_time(self):
        d=model(4);d['nodes'][1]['trigger']=d['nodes'][0]['trigger'][:]
        with self.assertRaisesRegex(ValueError,'multiple representatives'):event_compiler.emit(d)
    def test_explicit_failures_publish_no_records(self):
        odd=self.run_candidate(model(3),retries=2);self.assertEqual(odd['last_rejection'],2);self.assertFalse(odd['records'])
        no_source=model(4);no_source['nodes'][0]['active']=False;no_source['nodes'][1]['active']=False
        failed=self.run_candidate(no_source,retries=2);self.assertEqual(failed['last_rejection'],3);self.assertFalse(failed['records'])
        forbidden=model();forbidden['nodes'][0]['tags']=1;forbidden['nodes'][1]['tags']=2
        failed=self.run_candidate(forbidden,retries=2);self.assertEqual(failed['last_rejection'],4);self.assertFalse(failed['records'])
    def test_invalid_trial_caps_fail_closed(self):
        for cap in [0,5,65535]:
            failed=self.run_candidate(model(),trial_cap=cap,retries=2)
            self.assertEqual(failed['result'],1);self.assertEqual(failed['attempts'],0);self.assertFalse(failed['records'])
    def test_component_capacity_fails_closed(self):
        failed=self.run_candidate(model(402),retries=2)
        self.assertEqual(failed['result'],1);self.assertEqual(failed['attempts'],0);self.assertFalse(failed['records'])
    def test_representative_capacity_fails_closed(self):
        d=model(514)
        for i in range(0,514,2):edge(d,i,i+1);edge(d,i+1,i)
        failed=self.run_candidate(d,retries=2)
        self.assertEqual(failed['result'],1);self.assertEqual(failed['attempts'],0);self.assertFalse(failed['records'])

if __name__=='__main__':unittest.main(verbosity=2)
