#!/usr/bin/env python3
"""Synthetic and resumption-schedule checks for cooperative C10A."""
import hashlib,importlib.util,json,os,pathlib,subprocess,sys,tempfile,unittest
ROOT=pathlib.Path(__file__).resolve().parents[1];sys.path.insert(0,str(ROOT/'tests'))
from validate import validate

def load(name,path):
    spec=importlib.util.spec_from_file_location(name,path);module=importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module);return module
compiler=load('compiler',ROOT/'tools/warprandogen/compile.py')
index_compiler=load('index_compiler',ROOT/'tools/warprandogen/compile_c9c_index.py')
BASE_KEYS=('result','last_rejection','attempt','trial_cap','records','attempts','pairs',
 'eligible_partners','partner_trials','state_evaluations','forward_components',
 'reverse_components','repair_components','active_visits','conditional_visits','row_ors',
 'representative_bit_visits','pair_alias_visits','reverse_calls','reverse_edge_updates',
 'set_word_ops','score_word_ops','component_rep_updates','work_bytes')

def model(n=2,active=True):
    return {'schema':2,'description':'C10A synthetic fixture','capabilities':[],
      'nodes':[{'name':f'N{i:04}','id':[1,i//128,i%128],'trigger':[2,i//128,i%128],
       'rep':f'N{i:04}','active':active} for i in range(n)],'edges':[],'rules':[],
      'root':'N0000','goals':[f'N{n-1:04}']}
def edge(d,a,b,cap=None):d['edges'].append({'from':f'N{a:04}','to':f'N{b:04}','requires':cap})

class C10A(unittest.TestCase):
    @classmethod
    def setUpClass(cls):cls.tmp=tempfile.TemporaryDirectory();cls.root=pathlib.Path(cls.tmp.name);cls.cache={};cls.results=[]
    @classmethod
    def tearDownClass(cls):
        (ROOT/'reports/c10a-test-cases.json').write_text(json.dumps(cls.results,indent=2)+'\n');cls.tmp.cleanup()
    def executables(self,d):
        graph=compiler.emit(d);index,meta=index_compiler.emit(d);digest=hashlib.sha256((graph+index).encode()).hexdigest()
        folder=self.root/digest
        if digest not in self.cache:
            folder.mkdir();(folder/'graph.h').write_text(graph);(folder/'reference-c9c-event-index.h').write_text(index)
            common=[os.environ.get('CC','cc'),'-std=c99','-Wall','-Wextra','-Werror','-pedantic','-O1','-g',
                    '-I'+str(ROOT/'include'),'-I'+str(folder)]
            if os.environ.get('SANITIZE')=='1':common[1:1]=['-fsanitize=address,undefined','-fno-omit-frame-pointer','-fno-pie','-no-pie']
            for name in ('c9c','c10a'):
                p=subprocess.run([*common,str(ROOT/f'tools/experiments/{name}_candidate.c'),'-o',str(folder/name)],capture_output=True,text=True)
                self.assertEqual(p.returncode,0,p.stderr)
            self.cache[digest]=(folder,meta)
        return self.cache[digest]
    def run_candidate(self,d,seed=0,cap=3,retries=8,budget=1,cancel=0,restart=False,prior=False):
        folder,meta=self.executables(d);name='c9c' if prior else 'c10a';args=[str(folder/name),str(seed),str(cap),str(retries)]
        if not prior:args += [str(budget),str(cancel),str(int(restart))]
        p=subprocess.run(args,capture_output=True,text=True);self.assertEqual(p.returncode,0,p.stdout+p.stderr)
        result=json.loads(p.stdout);self.results.append({'case':self.id().split('.')[-1],'seed':seed,'budget':budget,
          'cancel':cancel,'result':result['result'],'steps':result.get('steps'),'records':len(result['records']),
          'components':meta['components']});return result
    def assert_exact(self,d,seed=0,retries=8):
        expected=self.run_candidate(d,seed=seed,retries=retries,prior=True)
        for budget in (1,2,7,31,65535):
            result=self.run_candidate(d,seed=seed,retries=retries,budget=budget)
            self.assertTrue(all(result[k]==expected[k] for k in BASE_KEYS),(seed,budget))
            self.assertEqual(result['steps'],sum(result[k] for k in ('trial_steps','select_steps','commit_steps','attempt_init_steps','emit_steps','validate_steps')))
            if not result['result']:validate(d,result['records'])
    def test_resumption_schedule_is_exact(self):
        d=model(10)
        for a,b in ((0,1),(1,0),(2,3),(3,2),(2,4),(4,2),(2,5),(5,2),(6,7)):edge(d,a,b)
        d['goals']=[v['name'] for v in d['nodes']]
        for seed in (0,1,2,17,255,4294967295):self.assert_exact(d,seed)
    def test_reference_like_retries_and_aliases(self):
        d=model(6)
        for member,rep in ((1,0),(3,2),(5,4)):
            d['nodes'][member]['rep']=d['nodes'][rep]['name'];d['nodes'][member]['trigger']=d['nodes'][rep]['trigger'][:]
            edge(d,rep,member);edge(d,member,rep)
        for seed in (0,42,65535):self.assert_exact(d,seed)
    def test_cancellation_exposes_no_records(self):
        d=model(40)
        for node in range(1,40):edge(d,0,node);edge(d,node,0)
        for stop in (1,2,5,20,100):
            result=self.run_candidate(d,cancel=stop);self.assertEqual(result['result'],101);self.assertFalse(result['records'])
            self.assertEqual(result['phase'],6)
            restarted=self.run_candidate(d,cancel=stop,restart=True);expected=self.run_candidate(d,prior=True)
            self.assertTrue(all(restarted[k]==expected[k] for k in BASE_KEYS));self.assertEqual(restarted['cancelled_once'],1)
        self.assert_exact(d)
    def test_failures_match_c9c(self):
        fixtures=[];fixtures.append(model(3))
        no_source=model(4);no_source['nodes'][0]['active']=False;no_source['nodes'][1]['active']=False;fixtures.append(no_source)
        forbidden=model();forbidden['nodes'][0]['tags']=1;forbidden['nodes'][1]['tags']=2;fixtures.append(forbidden)
        for d in fixtures:self.assert_exact(d,retries=2)
    def test_invalid_cap_and_zero_retries(self):
        for cap in (0,5,65535):
            a=self.run_candidate(model(),cap=cap,prior=True);b=self.run_candidate(model(),cap=cap)
            self.assertTrue(all(a[k]==b[k] for k in BASE_KEYS))
        a=self.run_candidate(model(),retries=0,prior=True);b=self.run_candidate(model(),retries=0)
        self.assertTrue(all(a[k]==b[k] for k in BASE_KEYS))

if __name__=='__main__':unittest.main(verbosity=2)
