# Meaning of the tests

`make test` compiles the delivered src/warp_rando.c for each diagnostic graph,
then checks actual emitted records with tests/validate.py. It also compiles the
exact fixed proof adapter in both switch modes using stub target types and the
Algorithm-4 bank loader against the generated 32-layout bank. `make sanitize`
repeats the core and bank suites with ASan + UBSan. LeakSanitizer is
disabled by the harness's __lsan_is_turned_off because it cannot enumerate this
restricted runtime's processes; the C core allocates no heap. This does not
disable ASan bounds/use checks or UBSan. `make seeds` uses the same C core on
the complete normalized reference dataset and records failures as failures.

Regression cases include >255/>800 group references; both groups' aliases;
deduplication and conflicts; missing/corrupt reverse records; explicit odd and
forbidden pairs; nine-condition mutation; unresolved requirements and explicit
alias; disconnected goals and self-locks; alternative derivations and staged
capabilities; one-way traps; available/unavailable escape; unsafe item
collection; fixed travel through exclusions; zero/exhausted retries; stale
options/data identity; serialized restart and successful retry replay.

The C acceptance code and Python validator do not share reachability state,
pairing decisions or graph-walk implementation. Python re-derives topology from
records and fresh capabilities. Shared normalized data is independently
reviewable, but it is still a world-model assumption. Passing synthetic tests
cannot certify the target game's scripts or physical arrivals.

Result enum: 0 OK, 1 bad data, 2 odd pool, 3 no reachable unused source,
4 no legal partner, 5 bad pair, 6 trigger conflict, 7 coverage error,
8 directed trap, 9 unreachable objective, 10 retries exhausted,
11 identity/version mismatch. The final-stage trap list may omit an earlier
stage trap that becomes escapable later; acceptance still rejects that early
unsafe traversal. Counts in seed-batch record every attempted candidate.
The bank loader additionally returns 12 for selected-row CRC corruption.

Follow-up diagnosis: diagnostic_driver.c includes the actual core in one
translation unit to expose private construction state. It is separate from
the publication harness and never publishes diagnostic rejected candidates.
Run tools/audit/reproduce_algorithm2.py to reproduce the historical 64 attempts
and counterfactuals in an isolated restored copy. Current seed evidence is in
reports/seed-batch.json and reports/seed-sweep.json. A directed sink/frontier
fixture checks the revised constructor across six seeds. The harness rejects
a valid-CRC metadata record carrying an obsolete algorithm version.

`tests/c7a_test.py` separately exercises the host-only bounded candidate. It
checks deterministic reciprocal pairing, grouped aliases, the six-seed
frontier/directed-sink fixture and explicit odd/no-source/no-partner failures.
Expected failures emit no records. Run it normally and with `SANITIZE=1`; it
does not assign a runtime algorithm identity or modify Algorithm 3.

`tests/c7c_test.py` applies the same behavioral fixtures to the graph-sized
SCC/bitset closure experiment and additionally proves that an oversized
component index fails closed before construction. `tools/audit/c7c_feasibility.py`
compares all 68 recorded C7C mappings byte-for-byte with C7A and independently
validates them. C7C is still experimental and assigns no runtime identity.

`tests/c8a_test.py` exercises the event-driven delta experiment against the
same fixtures and fail-closed capacity boundary. `c8a_feasibility.py` requires
all 68 mappings to match both C7A and C7C before independent validation and
deterministic replay. It remains test-only and assigns no runtime identity.

`tests/c8b_test.py` adds the isolated one-through-four trial-cap policy and
invalid-cap failure checks. `c8b_feasibility.py` requires deterministic replay
and independent validation, proves cap four exactly matches C8A over 68 seeds,
and stress-checks selected cap three over 1,024 consecutive seeds. It remains
test-only and assigns no runtime identity.

`tests/c8c_test.py` checks indexed representative slices and incremental
reverse-warp state against the same behavioral fixtures, including separate
component and representative capacity failures. `c8c_feasibility.py` requires
exact C8B cap-three layouts, attempts and rejection outcomes across 68 standard
and 1,024 stress seeds, with deterministic replay and independent validation.
C8C remains test-only and assigns no runtime identity.

`tests/c9a_test.py` checks the compact representative-set candidate, including
determinism, aliases and capacity failures. `c9a_feasibility.py` requires exact
C8C cap-three equivalence over 68 standard and 1,024 stress seeds, replay and
independent validation. C9A remains test-only and assigns no runtime identity.

`tests/c9b_test.py` checks the validated-emission candidate. The feasibility
gate requires every output and work counter to match C9A across 68 standard and
1,024 stress seeds, with replay and independent validation. C9B remains
test-only and assigns no runtime identity.

`tests/c9c_test.py` checks cold validation, generated unique-trigger emission
and compile-time rejection of conflicting shared-trigger representatives. The
feasibility gate requires exact C9A/C9B outputs and counters over the same 68
standard and 1,024 stress seeds and benchmarks cold and warm paths separately.
C9C remains test-only and assigns no runtime identity.

`tests/c10a_test.py` checks the cooperative C9C state machine across different
advance budgets. It covers exact records/counters, cancellation with zero
publication and restart using the same workspace. `c10a_feasibility.py` extends
that proof over 68 standard and 1,024 stress seeds. C10A remains test-only and
assigns no runtime identity.

`tests/c10b_test.py` checks exact resumption after splitting trial propagation,
repair and final validation into bounded microphases. It adds capability rounds
and cancellation during microphases; `c10b_feasibility.py` proves exact C9C
records and counters over 68 standard and 1,024 stress seeds. C10B remains
test-only and assigns no runtime identity.

`tests/c10c_test.py` checks the timer-budget admission policy and lifecycle
hooks across alternate schedules. It covers monotonic terminal progress,
cancellation/restart, invalid budgets, generation failure, publication failure,
success-only publication and exactly-once cleanup. `c10c_feasibility.py` extends
exact C9C records/counters and lifecycle invariants over 68 standard and 1,024
stress seeds. C10C remains test-only and assigns no runtime identity.

C10D does not introduce a new host generator. Its target-only harness reuses
the exact C10C core behind a rendered main/VBlank/audio/input lifecycle in
bundled mGBA. Both proof modes, checked target metrics and the optional
graphical builder are documented in `docs/c10d-rendered-mgba-checkpoint.md` and
`docs/c10d-mgba-manual-test.md`. Algorithm 5 remains unassigned.
