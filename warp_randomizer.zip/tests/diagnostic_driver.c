/* Test-only driver: include the actual delivered implementation in this TU to
 * inspect private construction state. No copied/reimplemented generator. */
#include "warp_rando.c"
#include "graph.h"
#include <stdio.h>
#include <stdlib.h>
static struct WrWork work;
static uint16_t saved_partner[WR_MAX_NODES];
int main(int argc,char **argv)
{
    uint32_t seed=argc>1?(uint32_t)strtoul(argv[1],0,0):0;
    uint16_t i,count=0;int construction,emission=-1,validation=-1;
    if(wr_graph_check(&wr_graph))return 2;
    construction=construct(&wr_graph,seed,&work);
    memcpy(saved_partner,work.partner,wr_graph.n*sizeof(uint16_t));
    if(!construction) {
        emission=wr_emit(&wr_graph,saved_partner,work.candidate,&count);
        if(!emission)validation=wr_validate(&wr_graph,work.candidate,count,&work);
    }
    printf("{\"construction\":%d,\"emission\":%d,\"validation\":%d,\"partner\":[",construction,emission,validation);
    for(i=0;i<wr_graph.n;i++)printf("%s%u",i?",":"",saved_partner[i]);
    printf("],\"records\":[");
    for(i=0;i<count;i++) {
        struct WrRecord *v=&work.candidate[i];
        printf("%s[%u,%u,%u,%u,%u,%u]",i?",":"",v->trigger.group,v->trigger.map,v->trigger.warp,v->landing.group,v->landing.map,v->landing.warp);
    }
    printf("]}\n");return 0;
}
