#!/usr/bin/env python3
"""Host unit checks for the exact proof adapter. Not an engine build."""
import pathlib,subprocess,tempfile
ROOT=pathlib.Path(__file__).resolve().parents[1]
shim='''#include <stdint.h>
typedef int8_t s8; typedef int16_t s16; typedef uint8_t bool8;
#define TRUE 1
#define FALSE 0
#define EWRAM_DATA
'''
harness=r'''
#include "warp_rando_proof.h"
#include <assert.h>
int main(void) {
    s8 g=2,m=0,w=0; s16 x=99,y=99;
    WrProof_Reset();
#if WR_PROOF_ENABLED
    assert(WrProof_Resolve(0,10,0,&g,&m,&w) && g==2 && m==1 && w==0);
    WrProof_QueueArrival(g,m,w);WrProof_Apply(g,m,w,&x,&y);assert(x==3 && y==6);
    x=y=99;WrProof_Apply(g,m,w,&x,&y);assert(x==99 && y==99);
    WrProof_QueueArrival(g,m,w);WrProof_Reset();WrProof_Apply(g,m,w,&x,&y);assert(x==99);
    WrProof_QueueArrival(g,m,w);WrProof_Apply(99,0,0,&x,&y);assert(x==99);
    WrProof_Apply(g,m,w,&x,&y);assert(x==99);
    for(s8 alias=0;alias<2;alias++) {
        g=0;m=10;w=1;assert(WrProof_Resolve(2,1,alias,&g,&m,&w) && w==0);
        g=0;m=10;w=0;assert(WrProof_Resolve(2,0,alias,&g,&m,&w) && w==1);
    }
    g=2;m=1;w=0;assert(WrProof_Resolve(0,10,1,&g,&m,&w) && m==0);
    g=2;m=0;w=0;assert(!WrProof_Resolve(99,99,0,&g,&m,&w) && g==2 && m==0 && w==0);
    g=2;m=0;w=1;assert(!WrProof_Resolve(0,10,0,&g,&m,&w) && w==1);
#else
    assert(!WrProof_Resolve(0,10,0,&g,&m,&w) && g==2 && m==0 && w==0);
    WrProof_QueueArrival(2,1,0);WrProof_Apply(2,1,0,&x,&y);assert(x==99 && y==99);
#endif
    return 0;
}
'''
with tempfile.TemporaryDirectory() as temp:
    p=pathlib.Path(temp);(p/'global.h').write_text(shim);(p/'test.c').write_text(harness)
    for mode in [0,1]:
        subprocess.run(['cc','-std=c99','-Wall','-Wextra','-Werror','-pedantic',f'-DWR_PROOF_ENABLED={mode}',
           '-I'+str(p),'-I'+str(ROOT/'patches/proof/include'),str(ROOT/'patches/proof/src/warp_rando_proof.c'),str(p/'test.c'),'-o',str(p/'test')],check=True)
        subprocess.run([str(p/'test')],check=True)
        print(f'Host proof adapter mode={mode}: PASS (stub types; not target-built)')
