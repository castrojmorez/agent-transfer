#include "warp_bank.h"
#include "reference-bank.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

static struct WrActive active;
/* This harness allocates no heap. LeakSanitizer cannot enumerate processes in
 * the restricted host; ASan bounds and UBSan checks remain enabled. */
int __lsan_is_turned_off(void) { return 1; }

static uint32_t digest(const struct WrActive *value)
{
    uint32_t hash=2166136261u;
    uint16_t i;
    unsigned j;
    for(i=0;i<value->count;i++) {
        uint8_t bytes[6]={value->records[i].trigger.group,
            value->records[i].trigger.map,value->records[i].trigger.warp,
            value->records[i].landing.group,value->records[i].landing.map,
            value->records[i].landing.warp};
        for(j=0;j<6;j++) { hash^=bytes[j];hash*=16777619u; }
    }
    return hash;
}

int main(int argc,char **argv)
{
    const char *mode=argc>1?argv[1]:"load";
    uint32_t seed=argc>2?(uint32_t)strtoul(argv[2],0,0):0;
    struct WrBank bank=wr_reference_bank;
    struct WrIdentity identity;
    uint32_t crcs[WR_REFERENCE_BANK_LAYOUTS];
    struct WrKey key={0,0,0};
    int result,lookup=-2;
    uint16_t index=wr_bank_index(seed,bank.layout_count);

    if(wr_bank_make_identity(&bank,seed,&identity)) return 2;
    if(!strcmp(mode,"bad_crc")) {
        memcpy(crcs,bank.row_crc32,sizeof(crcs));crcs[index]^=1u;bank.row_crc32=crcs;
    } else if(!strcmp(mode,"bad_algorithm")) identity.algorithm++;
    else if(!strcmp(mode,"bad_ruleset")) identity.ruleset++;
    else if(!strcmp(mode,"bad_fingerprint")) identity.data[0]^=1u;
    else if(!strcmp(mode,"bad_count")) bank.layout_count=3;
    else if(strcmp(mode,"load")) return 3;
    active.valid=1;active.count=7;
    result=wr_bank_load(&bank,&identity,&active);
    if(!result) {
        key=active.records[0].trigger;
        lookup=wr_lookup(&active,&identity,&key);
        if(lookup!=1 || memcmp(&key,&active.records[0].landing,sizeof(key))) return 4;
    }
    printf("{\"result\":%d,\"valid\":%u,\"count\":%u,\"attempt\":%u,"
           "\"index\":%u,\"digest\":%u,\"lookup\":%d,"
           "\"algorithm\":%u,\"ruleset\":%u}\n",
           result,active.valid,active.count,active.attempt,index,digest(&active),
           lookup,active.identity.algorithm,active.identity.ruleset);
    return 0;
}
