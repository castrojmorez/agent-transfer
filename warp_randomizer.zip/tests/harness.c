#include "warp_rando.h"
#include "graph.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
/* This harness uses no heap. LeakSanitizer cannot enumerate processes in the
 * restricted host; ASan bounds and UBSan checks remain enabled. */
int __lsan_is_turned_off(void) { return 1; }
static struct WrWork work;
static struct WrActive active, restored;
int main(int argc,char **argv)
{
    struct WrIdentity id; int r,last=0; uint16_t i;
    id.seed=argc>1?(uint32_t)strtoul(argv[1],0,0):0;
    id.algorithm=WR_ALGORITHM;id.ruleset=1;memcpy(id.data,wr_graph.fingerprint,32);
    if(argc>2 && !strcmp(argv[2],"validate")) {
        unsigned a,b,c,d,e,f,n=0;
        while(scanf("%u %u %u %u %u %u",&a,&b,&c,&d,&e,&f)==6) {
            if(n==WR_MAX_NODES || a>127 || b>127 || c>127 || d>127 || e>127 || f>127) return 3;
            work.candidate[n].trigger=(struct WrKey){a,b,c};work.candidate[n].landing=(struct WrKey){d,e,f};n++;
        }
        r=wr_publish(&wr_graph,&id,work.candidate,n,&active,&work);
    } else r=wr_generate(&wr_graph,&id,argc>2?(uint16_t)strtoul(argv[2],0,0):8,&active,&work,&last);
    printf("{\"result\":%d,\"last_rejection\":%d,\"active\":%u,\"attempt\":%u,\"records\":[",r,last,active.valid,active.attempt);
    for(i=0;i<active.count;i++) {
        const struct WrRecord *v=&active.records[i];
        printf("%s[%u,%u,%u,%u,%u,%u]",i?",":"",v->trigger.group,v->trigger.map,v->trigger.warp,v->landing.group,v->landing.map,v->landing.warp);
    }
    printf("],\"rejected_candidate\":[");
    if(r && !active.valid) for(i=0;i<work.candidate_count;i++) {
        const struct WrRecord *v=&work.candidate[i];
        printf("%s[%u,%u,%u,%u,%u,%u]",i?",":"",v->trigger.group,v->trigger.map,v->trigger.warp,v->landing.group,v->landing.map,v->landing.warp);
    }
    printf("],\"attempts\":%u,\"rejection_counts\":[",work.attempts);
    for(i=0;i<12;i++) printf("%s%u",i?",":"",work.rejection_counts[i]);
    printf("],\"trap_nodes\":[");
    if(last==WR_TRAP) {
        int comma=0;
        for(i=0;i<wr_graph.n;i++) if(work.reached[i] && !work.home[i]) {
            printf("%s%u",comma?",":"",i);comma=1;
        }
    }
    printf("],\"work_bytes\":%zu,\"active_bytes\":%zu}\n",sizeof(work),sizeof(active));
    if(!r && active.count) {
        uint8_t saved[WR_SAVE_BYTES];uint16_t saved_attempt;
        struct WrIdentity decoded;
        if(wr_encode(&active,saved) || wr_decode(&wr_graph,saved,&decoded,&saved_attempt)) return 10;
        if(wr_generate(&wr_graph,&decoded,(uint16_t)(saved_attempt+1),&restored,&work,&last)) return 11;
        if(restored.count!=active.count || restored.attempt!=active.attempt ||
           memcmp(restored.records,active.records,active.count*sizeof(active.records[0]))) return 12;
        /* Valid CRC with obsolete algorithm identity must still be rejected. */
        active.identity.algorithm--;
        if(wr_encode(&active,saved) || wr_decode(&wr_graph,saved,&decoded,&saved_attempt)!=WR_BAD_IDENTITY) return 14;
        active.identity.algorithm++;
        if(wr_encode(&active,saved)) return 15;
        saved[16]^=1;
        if(wr_decode(&wr_graph,saved,&decoded,&saved_attempt)!=WR_BAD_IDENTITY) return 13;
        struct WrKey k=active.records[0].trigger,old=k;
        if(wr_lookup(&active,&id,&k)!=1) return 4;
        id.ruleset++; k=old;
        if(wr_lookup(&active,&id,&k)!=-1 || memcmp(&k,&old,sizeof(k))) return 5;
        id.ruleset--; id.data[0]^=1;
        if(wr_lookup(&active,&id,&k)!=-1) return 6;
        id.data[0]^=1;
        if(wr_generate(&wr_graph,&id,0,&active,&work,&last)!=WR_RETRIES || active.valid || active.count) return 7;
        if(wr_lookup(&active,&id,&k)!=-1 || memcmp(&k,&old,sizeof(k))) return 8;
    } else if(r && (active.valid || active.count)) return 9;
    return 0;
}
