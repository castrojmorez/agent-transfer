#!/usr/bin/env python3
"""Host tests for the generated schema-1 mapping bank and Algorithm-4 loader."""
import json,os,pathlib,subprocess,tempfile,unittest

ROOT=pathlib.Path(__file__).resolve().parents[1]

def mix32(value):
    value=(value+0x9e3779b9)&0xffffffff
    value=((value^(value>>16))*0x85ebca6b)&0xffffffff
    value=((value^(value>>13))*0xc2b2ae35)&0xffffffff
    return (value^(value>>16))&0xffffffff

class BankSuite(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.temp=tempfile.TemporaryDirectory();cls.exe=pathlib.Path(cls.temp.name)/'bank'
        cmd=[os.environ.get('CC','cc'),'-std=c99','-Wall','-Wextra','-Werror','-pedantic','-O1','-g',
             '-I'+str(ROOT/'include'),'-I'+str(ROOT/'data'),
             str(ROOT/'src/warp_rando.c'),str(ROOT/'src/warp_bank.c'),
             str(ROOT/'tests/bank_harness.c'),'-o',str(cls.exe)]
        if os.environ.get('SANITIZE')=='1':
            cmd[1:1]=['-fsanitize=address,undefined','-fno-omit-frame-pointer','-fno-pie','-no-pie']
        subprocess.run(cmd,check=True)
    @classmethod
    def tearDownClass(cls): cls.temp.cleanup()
    def invoke(self,mode='load',seed=0):
        result=subprocess.run([str(self.exe),mode,str(seed)],capture_output=True,text=True,check=True)
        return json.loads(result.stdout)
    def test_representative_seeds_are_deterministic(self):
        for seed in (0,1,17,65535,4294967295):
            with self.subTest(seed=seed):
                first=self.invoke(seed=seed);second=self.invoke(seed=seed)
                self.assertEqual(first,second)
                self.assertEqual(first['result'],0);self.assertEqual(first['valid'],1)
                self.assertEqual(first['count'],532);self.assertEqual(first['attempt'],0)
                self.assertEqual(first['index'],mix32(seed)&31)
                self.assertEqual(first['lookup'],1);self.assertEqual(first['algorithm'],4)
                self.assertEqual(first['ruleset'],1)
    def test_all_layouts_are_selectable_and_distinct(self):
        seeds={}
        seed=0
        while len(seeds)<32:
            seeds.setdefault(mix32(seed)&31,seed);seed+=1
        rows=[self.invoke(seed=seeds[index]) for index in range(32)]
        self.assertEqual([row['index'] for row in rows],list(range(32)))
        self.assertEqual(len({row['digest'] for row in rows}),32)
    def test_failures_invalidate_before_return(self):
        expected={'bad_crc':12,'bad_algorithm':11,'bad_ruleset':11,
                  'bad_fingerprint':11,'bad_count':1}
        for mode,code in expected.items():
            with self.subTest(mode=mode):
                row=self.invoke(mode,17)
                self.assertEqual(row['result'],code);self.assertEqual(row['valid'],0)
                self.assertEqual(row['count'],0);self.assertEqual(row['lookup'],-2)

if __name__=='__main__': unittest.main(verbosity=2)
