#!/usr/bin/env python3
import copy, hashlib, importlib.util, json, os, pathlib, subprocess, sys, tempfile, unittest
ROOT=pathlib.Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/'tests'))
from validate import validate, Invalid
spec=importlib.util.spec_from_file_location('compiler',ROOT/'tools/warprandogen/compile.py')
compiler=importlib.util.module_from_spec(spec);spec.loader.exec_module(compiler)

def model(n=2,active=True):
    return {'schema':2,'description':'Synthetic diagnostic fixture, not Emerald map data',
      'capabilities':[],'nodes':[{'name':f'N{i:04}', 'id':[1,i//128,i%128],
       'trigger':[2,i//128,i%128],'rep':f'N{i:04}','active':active} for i in range(n)],
      'edges':[],'rules':[],'root':'N0000','goals':[f'N{n-1:04}']}
def edge(d,a,b,cap=None):
    d['edges'].append({'from':f'N{a:04}','to':f'N{b:04}','requires':cap})
def rows(d,partners):
    out={}
    for v in d['nodes']:
        if v['active']:
            target=d['nodes'][partners[int(v['rep'][1:])]]['id']
            out[tuple(v['trigger'])]=list(v['trigger'])+target
    return list(out.values())
class Suite(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.temp=tempfile.TemporaryDirectory();cls.path=pathlib.Path(cls.temp.name);cls.cache={};cls.results=[]
    @classmethod
    def tearDownClass(cls):
        out=ROOT/'build/test-cases.json';out.parent.mkdir(exist_ok=True)
        out.write_text(json.dumps(cls.results,indent=2)+'\n');cls.temp.cleanup()
    def run_core(self,d,seed=0,records=None,retries=8):
        header=compiler.emit(d); digest=hashlib.sha256(header.encode()).hexdigest()
        directory=self.path/digest
        if digest not in self.cache:
            directory.mkdir();(directory/'graph.h').write_text(header)
            cmd=[os.environ.get('CC','cc'),'-std=c99','-Wall','-Wextra','-Werror','-pedantic','-O1','-g',
                '-I'+str(ROOT/'include'),'-I'+str(directory),str(ROOT/'src/warp_rando.c'),str(ROOT/'tests/harness.c'),'-o',str(directory/'run')]
            if os.environ.get('SANITIZE')=='1':cmd[1:1]=['-fsanitize=address,undefined','-fno-omit-frame-pointer','-fno-pie','-no-pie']
            p=subprocess.run(cmd,capture_output=True,text=True)
            self.assertEqual(p.returncode,0,p.stderr); self.cache[digest]=True
        arg='validate' if records is not None else str(retries)
        p=subprocess.run([str(directory/'run'),str(seed),arg],input=''.join(' '.join(map(str,r))+'\n' for r in records or []),capture_output=True,text=True)
        self.assertEqual(p.returncode,0,p.stdout+p.stderr)
        result=json.loads(p.stdout)
        self.results.append({'case':self.id().split('.')[-1],'seed':seed,'result':result['result'],
                             'last_rejection':result['last_rejection'],'attempt':result['attempt'],
                             'records':len(result['records']),'active':result['active']})
        return result
    def accepted(self,d,records=None):
        r=self.run_core(d,records=records);self.assertEqual(r['result'],0,r)
        return validate(d,r['records'])
    def rejected(self,d,records):
        with self.assertRaises(Invalid):validate(d,records)
        r=self.run_core(d,records=records);self.assertNotEqual(r['result'],0);self.assertFalse(r['active'])
    def test_reciprocal_and_restart(self):
        d=model(); first=self.run_core(d,seed=0)
        self.assertEqual(first['records'],[[2,0,0,1,0,1],[2,0,1,1,0,0]])
        for seed in [0,1,2,17,255,256,65535,4294967295]:
            a=self.run_core(d,seed);b=self.run_core(d,seed)
            self.assertEqual(a,b);validate(d,a['records'])
        self.rejected(d,first['records'][:1])
        broken=copy.deepcopy(first['records']);broken[0][3:]=[100,100,100];self.rejected(d,broken)
    def test_grouped_both_sides_and_equivalent_alias(self):
        d=model(4)
        for member,rep in [(1,0),(3,2)]:
            d['nodes'][member]['rep']=d['nodes'][rep]['name'];d['nodes'][member]['trigger']=d['nodes'][rep]['trigger'][:]
            edge(d,rep,member);edge(d,member,rep)
        r=self.run_core(d);self.assertEqual(r['result'],0);self.assertEqual(len(r['records']),2);validate(d,r['records'])
    def test_conflicting_aliases(self):
        d=model(4);d['nodes'][2]['trigger']=d['nodes'][0]['trigger'][:]
        for i in range(1,4):edge(d,0,i);edge(d,i,0)
        r=self.run_core(d);self.assertEqual(r['result'],10);self.assertEqual(r['last_rejection'],6);self.assertFalse(r['records'])
    def test_wide_indices(self):
        d=model(902)
        for member,rep in [(256,255),(842,841)]:d['nodes'][member]['rep']=d['nodes'][rep]['name']
        for i in range(1,902):edge(d,0,i);edge(d,i,0)
        normalized=compiler.normalize(d)
        self.assertEqual(normalized['nodes'][256][2],255);self.assertEqual(normalized['nodes'][842][2],841)
        self.accepted(d)
    def test_odd_pool_and_no_source(self):
        r=self.run_core(model(3));self.assertEqual(r['last_rejection'],2);self.assertFalse(r['active'])
        d=model(4);d['root']='N0000';d['nodes'][0]['active']=False;d['nodes'][1]['active']=False
        r=self.run_core(d);self.assertEqual(r['last_rejection'],3);self.assertFalse(r['active'])
    def test_forbidden_pair(self):
        d=model();d['nodes'][0]['tags']=1;d['nodes'][1]['tags']=2
        self.rejected(d,rows(d,{0:1,1:0}));self.assertEqual(self.run_core(d)['last_rejection'],4)
    def test_ninth_requirement_mutation(self):
        d=model(11,False);d['capabilities']=['WATERFALL'];d['goals']=['N0010']
        for i in range(1,9):edge(d,0,i);edge(d,i,0)
        edge(d,0,10,'WATERFALL');edge(d,10,0)
        d['rules']=[{'grant':'WATERFALL','requires':[{'location':f'N{i:04}'} for i in range(1,10)]}]
        self.assertEqual(len(compiler.normalize(d)['reqs']),9);self.rejected(d,[])
        mutation=copy.deepcopy(d);mutation['rules'][0]['requires'].pop();self.accepted(mutation,[])
        edge(d,0,9);edge(d,9,0);self.accepted(d,[])
    def test_self_lock_and_disconnected_objective(self):
        d=model(2,False);d['capabilities']=['SURF'];edge(d,0,1,'SURF');edge(d,1,0)
        d['rules']=[{'grant':'SURF','requires':[{'location':'N0001'}]}];self.rejected(d,[])
        d['rules']=[];d['edges']=[];self.rejected(d,[])
    def test_multiround_capability_derivations(self):
        d=model(4,False);d['capabilities']=['A','B','C']
        edge(d,0,1);edge(d,1,0);edge(d,0,2,'B');edge(d,2,0);edge(d,0,3,'C');edge(d,3,0)
        d['rules']=[{'grant':'A','requires':[{'location':'N0001'}]},
          {'grant':'B','requires':[{'capability':'A'}]},
          {'grant':'C','requires':[{'location':'N0002'}]},
          {'grant':'C','requires':[{'location':'N0003'}]}]
        stages=self.accepted(d,[]);self.assertGreaterEqual(len(stages),4)
    def test_directed_trap_and_escape(self):
        d=model(2,False);edge(d,0,1);self.rejected(d,[])
        d['capabilities']=['ROPE'];edge(d,1,0,'ROPE');self.rejected(d,[])
        d['edges'][-1]['requires']=None;self.accepted(d,[])
    def test_unsafe_item_collection_and_later_escape(self):
        d=model(3,False);d['goals']=['N0001'];d['capabilities']=['ESCAPE']
        edge(d,0,1);edge(d,1,0);edge(d,0,2);edge(d,2,0,'ESCAPE')
        d['rules']=[{'grant':'ESCAPE','requires':[{'location':'N0002'}]}];self.rejected(d,[])
        d['rules'][0]['requires']=[{'location':'N0001'}];self.rejected(d,[])
    def test_fixed_travel_through_excluded_nodes(self):
        d=model(4);d['nodes'][1]['active']=False;d['nodes'][2]['active']=False
        edge(d,0,1);edge(d,1,2);edge(d,2,3);edge(d,3,2);edge(d,2,1);edge(d,1,0)
        d['goals']=['N0002'];self.accepted(d)
    def test_bad_input_and_determinism(self):
        d=model();self.assertEqual(compiler.emit(d),compiler.emit(json.loads(json.dumps(d))))
        for mutation in ['unknown','ref','group','overflow','mixed','bool','grant']:
            bad=copy.deepcopy(d)
            if mutation=='unknown':edge(bad,0,1,'TYPO')
            if mutation=='ref':edge(bad,0,99)
            if mutation=='group':bad['nodes'][0]['rep']='N0001';bad['nodes'][1]['rep']='N0000'
            if mutation=='overflow':bad['nodes'][0]['id'][0]=256
            if mutation=='mixed':bad['nodes'][1]['active']=False;bad['nodes'][1]['trigger']=bad['nodes'][0]['trigger'][:]
            if mutation=='bool':bad['nodes'][0]['active']=1
            if mutation=='grant':bad['rules']=[{'grant':'UNKNOWN','requires':[]}]
            with self.subTest(mutation=mutation),self.assertRaises(ValueError):compiler.emit(bad)
    def test_frontier_and_directed_sink_construction(self):
        # Two hubs, a one-way drop and two isolated leaves. The dropped-to
        # endpoint must keep a route home; leaves must not exhaust the frontier.
        d=model(10)
        for a,b in [(0,1),(1,0),(2,3),(3,2),(2,4),(4,2),(2,5),(5,2),(6,7)]:edge(d,a,b)
        d['goals']=[v['name'] for v in d['nodes']]
        for seed in [0,1,2,17,255,4294967295]:
            r=self.run_core(d,seed=seed);self.assertEqual(r['result'],0,r)
            validate(d,r['records'])
    def test_reference_aliases_and_unknown_requirements(self):
        sys.path.insert(0,str(ROOT/'tools/warprandogen'))
        from import_reference import convert
        overrides=json.loads((ROOT/'data/overrides.json').read_text())
        data,report=convert(ROOT/'data/reference',overrides)
        self.assertEqual(report['max_requirements'],9)
        self.assertIn('HOENN_FLASH',data['capabilities'])
        self.assertIn('HOENN_FLASH_1',data['capabilities'])
        self.assertFalse(any(r['grant']=='HOENN_FLASH_1' for r in data['rules']))
        self.assertTrue(any(e['requires']=='WEATHER_INSTITUTE' for e in data['edges']))
        self.assertFalse(any(r['grant']=='WEATHER_INSTITUTE' for r in data['rules']))
        alias=copy.deepcopy(overrides);alias['aliases']={'HOENN_FLASH_1':'HOENN_FLASH'}
        aliased,_=convert(ROOT/'data/reference',alias)
        self.assertNotIn('HOENN_FLASH_1',aliased['capabilities'])
        bad=copy.deepcopy(overrides);bad['blocked_capabilities']=[];bad['unknown_requirement_policy']='error'
        bad['aliases']={'HOENN_FLASH_1':'HOENN_FLASH'}
        with self.assertRaisesRegex(ValueError,'unknown requirement WEATHER_INSTITUTE'):
            convert(ROOT/'data/reference',bad)
    def test_zero_retries(self):
        r=self.run_core(model(),retries=0);self.assertEqual(r['result'],10);self.assertFalse(r['records'])
if __name__=='__main__':unittest.main(verbosity=2)
