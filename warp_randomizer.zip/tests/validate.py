"""Independent acceptance over JSON rules and emitted records. No C state imports."""
class Invalid(ValueError): pass

def validate(data,records):
    nodes={v['name']:v for v in data['nodes']}
    byid={tuple(v['id']):v['name'] for v in nodes.values()}
    expected={tuple(v['trigger']) for v in nodes.values() if v['active']}
    mapping={}
    for row in records:
        k=tuple(row[:3]); dest=tuple(row[3:])
        if k in mapping: raise Invalid('duplicate trigger')
        if dest not in byid: raise Invalid('invalid landing')
        mapping[k]=byid[dest]
    if set(mapping)!=expected: raise Invalid('trigger coverage')
    travel={}
    for name,v in nodes.items():
        if not v['active']: continue
        t=mapping[tuple(v['trigger'])]; partner=nodes[t]
        if not partner['active'] or partner['rep']!=t or v['rep']==t: raise Invalid('bad partner')
        if mapping[tuple(nodes[v['rep']]['trigger'])]!=t: raise Invalid('inconsistent aliases')
        if mapping[tuple(partner['trigger'])]!=v['rep']: raise Invalid('missing reverse pair')
        if ((v.get('tags',0)&1 and partner.get('tags',0)&2) or
            (v.get('tags',0)&2 and partner.get('tags',0)&1)): raise Invalid('forbidden pairing')
        travel[name]=t
    def search(edges,start,reverse=False):
        seen={start}; todo=[start]
        while todo:
            current=todo.pop()
            for a,b in edges:
                if reverse: a,b=b,a
                if a==current and b not in seen: seen.add(b);todo.append(b)
        return seen
    caps=set(); stages=[]
    while True:
        edges=list(travel.items())+[(e['from'],e['to']) for e in data['edges'] if e.get('requires') is None or e['requires'] in caps]
        reached=search(edges,data['root']);home=search(edges,data['root'],True)
        # Optional traversal to a currently inescapable place is unsafe even if a
        # capability could later be obtained elsewhere. Reject at every stage.
        if reached-home: raise Invalid('one-way trap: '+','.join(sorted(reached-home)))
        earned={r['grant'] for r in data['rules'] if all(
            (q['location'] in reached & home if 'location' in q else q['capability'] in caps)
            for q in r['requires'])}
        stages.append({'reachable':sorted(reached),'capabilities':sorted(caps)})
        if earned<=caps: break
        caps |= earned
    if not set(data['goals'])<=reached: raise Invalid('unreachable objective')
    return stages
