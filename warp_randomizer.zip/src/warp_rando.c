#include "warp_rando.h"
#include <string.h>

static int keyeq(struct WrKey a, struct WrKey b)
{ return a.group == b.group && a.map == b.map && a.warp == b.warp; }
static int keycmp(struct WrKey a, struct WrKey b)
{ if(a.group != b.group) return a.group < b.group ? -1 : 1;
  if(a.map != b.map) return a.map < b.map ? -1 : 1;
  return (a.warp > b.warp) - (a.warp < b.warp); }
static int identityeq(const struct WrIdentity *a, const struct WrIdentity *b)
{ return a->seed == b->seed && a->algorithm == b->algorithm &&
    a->ruleset == b->ruleset && !memcmp(a->data,b->data,32); }
static int identityok(const struct WrGraph *g, const struct WrIdentity *i)
{ return i->algorithm == WR_ALGORITHM && i->ruleset == 1 &&
    !memcmp(i->data,g->fingerprint,32); }
void wr_invalidate(struct WrActive *a) { a->valid = 0; a->count = 0; }
static int allowed(const struct WrNode *a, const struct WrNode *b)
{ return !((a->tags & WR_NEEDS_RETURN && b->tags & WR_NO_RETURN) ||
           (b->tags & WR_NEEDS_RETURN && a->tags & WR_NO_RETURN)); }
int wr_graph_check(const struct WrGraph *g)
{
    uint16_t i,j;
    if(!g || !g->n || g->n > WR_MAX_NODES || g->caps > WR_MAX_CAPS ||
       g->root >= g->n || !g->nodes || !g->bounds || !g->reverse_bounds ||
       !g->edges || !g->reverse_edges || !g->rules || !g->reqs || !g->goals)
        return WR_BAD_DATA;
    if(g->bounds[0] || g->reverse_bounds[0] || g->bounds[g->n] != g->edge_count ||
       g->reverse_bounds[g->n] != g->edge_count) return WR_BAD_DATA;
    for(i=0;i<g->n;i++) {
        const struct WrNode *v=&g->nodes[i];
        if(v->rep >= g->n || g->nodes[v->rep].rep != v->rep ||
           v->active != g->nodes[v->rep].active || v->active > 1 || v->tags > 3 ||
           v->tags != g->nodes[v->rep].tags ||
           g->bounds[i]>g->bounds[i+1] || g->reverse_bounds[i]>g->reverse_bounds[i+1])
            return WR_BAD_DATA;
        for(j=0;j<i;j++)
            if(keyeq(v->id,g->nodes[j].id) ||
               (v->active != g->nodes[j].active && keyeq(v->trigger,g->nodes[j].trigger)))
                return WR_BAD_DATA;
    }
    for(i=0;i<g->edge_count;i++) {
        const struct WrEdge *e=&g->edges[i], *r=&g->reverse_edges[i];
        if(e->to>=g->n || r->to>=g->n ||
           (e->cap!=WR_NONE && e->cap>=g->caps) ||
           (r->cap!=WR_NONE && r->cap>=g->caps)) return WR_BAD_DATA;
    }
    /* Prove that the reverse adjacency supplied by the compiler is exact. */
    for(i=0;i<g->n;i++) for(j=g->bounds[i];j<g->bounds[i+1];j++) {
        uint16_t k, hits=0, to=g->edges[j].to;
        for(k=g->reverse_bounds[to];k<g->reverse_bounds[to+1];k++)
            if(g->reverse_edges[k].to==i && g->reverse_edges[k].cap==g->edges[j].cap) hits++;
        if(hits!=1) return WR_BAD_DATA;
    }
    for(i=0;i<g->n;i++) for(j=g->reverse_bounds[i];j<g->reverse_bounds[i+1];j++) {
        uint16_t k, hits=0, to=g->reverse_edges[j].to;
        for(k=g->bounds[to];k<g->bounds[to+1];k++)
            if(g->edges[k].to==i && g->edges[k].cap==g->reverse_edges[j].cap) hits++;
        if(hits!=1) return WR_BAD_DATA;
    }
    for(i=0;i<g->rule_count;i++) {
        const struct WrRule *r=&g->rules[i];
        if(r->grant>=g->caps || (uint32_t)r->offset+r->count>g->req_count) return WR_BAD_DATA;
    }
    for(i=0;i<g->req_count;i++)
        if(g->reqs[i].capability>1 || g->reqs[i].index >=
           (g->reqs[i].capability ? g->caps:g->n)) return WR_BAD_DATA;
    for(i=0;i<g->goal_count;i++) if(g->goals[i]>=g->n) return WR_BAD_DATA;
    return WR_OK;
}
int wr_emit(const struct WrGraph *g,const uint16_t *p,struct WrRecord *out,uint16_t *count)
{
    uint16_t i,j,n=0;
    *count=0;
    if(wr_graph_check(g)) return WR_BAD_DATA;
    for(i=0;i<g->n;i++) if(g->nodes[i].active) {
        uint16_t r=g->nodes[i].rep, t=p[r];
        struct WrRecord row;
        if(t>=g->n || t==r || !g->nodes[t].active || g->nodes[t].rep!=t ||
           p[t]!=r || !allowed(&g->nodes[r],&g->nodes[t])) return WR_BAD_PAIR;
        row.trigger=g->nodes[i].trigger; row.landing=g->nodes[t].id;
        for(j=0;j<n;j++) if(keyeq(out[j].trigger,row.trigger)) break;
        if(j<n) { if(!keyeq(out[j].landing,row.landing)) return WR_CONFLICT; }
        else out[n++]=row;
    }
    /* Stable insertion sort; output has at most n physical triggers. */
    for(i=1;i<n;i++) {
        struct WrRecord row=out[i]; j=i;
        while(j && keycmp(row.trigger,out[j-1].trigger)<0) { out[j]=out[j-1]; j--; }
        out[j]=row;
    }
    *count=n; return WR_OK;
}
static void traverse(const struct WrGraph *g, struct WrWork *w, int reverse)
{
    uint16_t head=0,tail=0,i,v,t;
    uint8_t *seen=reverse?w->home:w->reached;
    const uint16_t *bounds=reverse?g->reverse_bounds:g->bounds;
    const struct WrEdge *edges=reverse?g->reverse_edges:g->edges;
    memset(seen,0,g->n); seen[g->root]=1; w->queue[tail++]=g->root;
    while(head<tail) {
        v=w->queue[head++];
        for(i=bounds[v];i<bounds[v+1];i++) {
            t=edges[i].to;
            if((edges[i].cap==WR_NONE || w->caps[edges[i].cap]) && !seen[t]) {
                seen[t]=1; w->queue[tail++]=t;
            }
        }
        if(reverse) {
            for(t=w->reverse_head[v];t!=WR_NONE;t=w->reverse_next[t])
                if(!seen[t]) { seen[t]=1; w->queue[tail++]=t; }
        } else {
            t=w->destination[v];
            if(t!=WR_NONE && !seen[t]) { seen[t]=1; w->queue[tail++]=t; }
        }
    }
}
static void reverse_warps(const struct WrGraph *g,struct WrWork *w)
{
    uint16_t i,t;
    for(i=0;i<g->n;i++) w->reverse_head[i]=WR_NONE;
    for(i=0;i<g->n;i++) {
        t=w->destination[i];
        if(t!=WR_NONE) { w->reverse_next[i]=w->reverse_head[t]; w->reverse_head[t]=i; }
    }
}
/* Fresh-state monotone closure. Only collect at locations already able to return
 * to the anchor with current capabilities. This is deliberately conservative. */
static int closure_until(const struct WrGraph *g,struct WrWork *w,int stop_unsafe)
{
    uint16_t i,j; int changed, unsafe=0;
    uint8_t next_caps[WR_MAX_CAPS];
    memset(w->caps,0,g->caps); reverse_warps(g,w);
    do {
        changed=0; traverse(g,w,0); traverse(g,w,1);
        for(i=0;i<g->n;i++) if(w->reached[i] && !w->home[i]) unsafe=1;
        if(unsafe && stop_unsafe) return 1;
        memcpy(next_caps,w->caps,g->caps);
        for(i=0;i<g->rule_count;i++) {
            const struct WrRule *r=&g->rules[i]; int all=1;
            if(w->caps[r->grant]) continue;
            for(j=0;j<r->count;j++) {
                const struct WrReq *q=&g->reqs[r->offset+j];
                if(q->capability ? !w->caps[q->index] :
                   !(w->reached[q->index] && w->home[q->index])) { all=0; break; }
            }
            if(all) { next_caps[r->grant]=1; changed=1; }
        }
        memcpy(w->caps,next_caps,g->caps);
    } while(changed);
    return unsafe;
}
static int closure(const struct WrGraph *g,struct WrWork *w)
{ return closure_until(g,w,0); }
int wr_validate(const struct WrGraph *g,const struct WrRecord *table,uint16_t count,struct WrWork *w)
{
    uint16_t i,j,t;
    int result=wr_graph_check(g);
    if(result || count>g->n) return WR_BAD_DATA;
    for(i=0;i<count;i++) {
        int used=0;
        for(j=0;j<i;j++) if(keyeq(table[i].trigger,table[j].trigger)) return WR_CONFLICT;
        for(j=0;j<g->n;j++) if(g->nodes[j].active && keyeq(table[i].trigger,g->nodes[j].trigger)) used=1;
        if(!used) return WR_COVERAGE;
    }
    for(i=0;i<g->n;i++) {
        w->destination[i]=WR_NONE; w->partner[i]=WR_NONE;
        if(!g->nodes[i].active) continue;
        for(j=0;j<count;j++) if(keyeq(table[j].trigger,g->nodes[i].trigger)) break;
        if(j==count) return WR_COVERAGE;
        for(t=0;t<g->n;t++) if(keyeq(g->nodes[t].id,table[j].landing)) break;
        if(t==g->n || !g->nodes[t].active || g->nodes[t].rep!=t) return WR_BAD_PAIR;
        w->destination[i]=t;
    }
    for(i=0;i<g->n;i++) if(g->nodes[i].active) {
        uint16_t r=g->nodes[i].rep;
        t=w->destination[i];
        if(t==r || w->destination[r]!=t || w->destination[t]!=r ||
           !allowed(&g->nodes[r],&g->nodes[t])) return WR_BAD_PAIR;
    }
    if(closure(g,w)) return WR_TRAP;
    for(i=0;i<g->n;i++) if(w->reached[i] && !w->home[i]) return WR_TRAP;
    for(i=0;i<g->goal_count;i++) if(!w->reached[g->goals[i]]) return WR_OBJECTIVE;
    return WR_OK;
}
int wr_publish(const struct WrGraph *g,const struct WrIdentity *id,const struct WrRecord *table,
               uint16_t count,struct WrActive *a,struct WrWork *w)
{
    int result; wr_invalidate(a);
    if(!identityok(g,id)) return WR_BAD_IDENTITY;
    result=wr_validate(g,table,count,w); if(result) return result;
    memcpy(a->records,table,count*sizeof(*table)); a->identity=*id;
    a->count=count; a->attempt=0; a->valid=1; return WR_OK;
}
static uint32_t rng(uint32_t *s) { *s=*s*1664525u+1013904223u; return *s; }
static uint16_t choose(uint32_t *s,uint16_t count)
{ /* rejection sampling, including seed zero, without gameplay RNG */
    uint32_t r,threshold=(0u-(uint32_t)count)%count;
    do {r=rng(s);} while(r<threshold); return (uint16_t)(r%count);
}
/* Recompute from the partial pairing and stop at the FIRST unsafe capability
 * stage. A later item must not hide an earlier return obligation. */
static int construction_state(const struct WrGraph *g,struct WrWork *w)
{
    uint16_t i;
    for(i=0;i<g->n;i++) w->destination[i]=g->nodes[i].active?w->partner[g->nodes[i].rep]:WR_NONE;
    return closure_until(g,w,1);
}
static int free_endpoint(const struct WrGraph *g,const struct WrWork *w,uint16_t i)
{ return g->nodes[i].active && g->nodes[i].rep==i && w->partner[i]==WR_NONE; }
/* Every unsafe reached vertex must retain a route to an unpaired endpoint.
 * Reverse multi-source traversal checks this without assuming symmetric walks. */
static int repairable(const struct WrGraph *g,struct WrWork *w)
{
    uint16_t i,v,t,head=0,tail=0;
    memset(w->scratch,0,g->n);
    for(i=0;i<g->n;i++) if(free_endpoint(g,w,i) && w->reached[i]) {
        w->scratch[i]=1;w->queue[tail++]=i;
    }
    while(head<tail) {
        v=w->queue[head++];
        for(i=g->reverse_bounds[v];i<g->reverse_bounds[v+1];i++) {
            const struct WrEdge *e=&g->reverse_edges[i];t=e->to;
            if((e->cap==WR_NONE || w->caps[e->cap]) && !w->scratch[t]) {
                w->scratch[t]=1;w->queue[tail++]=t;
            }
        }
        for(t=w->reverse_head[v];t!=WR_NONE;t=w->reverse_next[t])
            if(!w->scratch[t]) {w->scratch[t]=1;w->queue[tail++]=t;}
    }
    for(i=0;i<g->n;i++)
        if(w->reached[i] && !w->home[i] && !w->scratch[i]) return 0;
    return 1;
}
static int construct(const struct WrGraph *g,uint32_t seed,struct WrWork *w)
{
    uint16_t i,left=0;uint32_t state=seed;
    for(i=0;i<g->n;i++) {
        w->partner[i]=WR_NONE;
        if(g->nodes[i].active && g->nodes[i].rep==i) left++;
    }
    if(left%2) return WR_ODD_POOL;
    while(left) {
        uint16_t n=0,source,target=WR_NONE,ties=0,j;
        int unsafe=construction_state(g,w),best=-1;
        /* Repair unsafe reachable components before extending another one. */
        for(i=0;i<g->n;i++) if(free_endpoint(g,w,i) && w->reached[i] &&
            (unsafe ? !w->home[i] : w->home[i])) w->candidates[n++]=i;
        if(!n) return unsafe?WR_TRAP:WR_NO_SOURCE;
        source=w->candidates[choose(&state,n)];n=0;
        for(i=0;i<g->n;i++) if(free_endpoint(g,w,i) && i!=source &&
            allowed(&g->nodes[source],&g->nodes[i]) && (!unsafe || w->home[i]))
            w->candidates[n++]=i;
        /* Score actual reachable free canonical endpoints after a trial,
         * not adjacency degree or item labels. No trial publishes a table. */
        for(j=0;j<n;j++) {
            uint16_t trial=w->candidates[j],free_count=0,safe_count=0;
            int trial_unsafe,score;
            w->partner[source]=trial;w->partner[trial]=source;
            trial_unsafe=construction_state(g,w);
            for(i=0;i<g->n;i++) if(free_endpoint(g,w,i) && w->reached[i]) {
                free_count++;if(w->home[i]) safe_count++;
            }
            score=(int)free_count;
            if((left>2 && !free_count) ||
               (trial_unsafe && (!safe_count || !repairable(g,w)))) score=-1;
            w->partner[source]=WR_NONE;w->partner[trial]=WR_NONE;
            if(score<0) continue;
            if(score>best) {best=score;target=trial;ties=1;}
            else if(score==best && choose(&state,++ties)==0) target=trial;
        }
        if(target==WR_NONE) return WR_NO_PARTNER;
        w->partner[source]=target;w->partner[target]=source;left-=2;
    }
    return WR_OK;
}
int wr_generate(const struct WrGraph *g,const struct WrIdentity *id,uint16_t retries,
                struct WrActive *a,struct WrWork *w,int *last)
{
    uint16_t attempt,count; int r;
    wr_invalidate(a); *last=WR_OK;
    w->attempts=0;w->candidate_count=0;memset(w->rejection_counts,0,sizeof(w->rejection_counts));
    if(wr_graph_check(g)) return WR_BAD_DATA;
    if(!identityok(g,id)) return WR_BAD_IDENTITY;
    for(attempt=0;attempt<retries;attempt++) {
        w->attempts++;w->candidate_count=0;
        r=construct(g,id->seed+0x9e3779b9u*attempt,w);
        if(!r) {r=wr_emit(g,w->partner,w->candidate,&count);if(!r)w->candidate_count=count;}
        if(!r) r=wr_publish(g,id,w->candidate,count,a,w);
        if(!r) {a->attempt=attempt;return WR_OK;}
        *last=r;w->rejection_counts[r]++;
    }
    wr_invalidate(a); return WR_RETRIES;
}
int wr_lookup(const struct WrActive *a,const struct WrIdentity *id,struct WrKey *requested)
{
    uint16_t i;
    if(!a->valid || !identityeq(&a->identity,id)) return -1;
    for(i=0;i<a->count;i++) if(keyeq(a->records[i].trigger,*requested)) {
        *requested=a->records[i].landing;return 1;
    }
    return 0;
}

static void put32(uint8_t *p,uint32_t v)
{ p[0]=(uint8_t)v;p[1]=(uint8_t)(v>>8);p[2]=(uint8_t)(v>>16);p[3]=(uint8_t)(v>>24); }
static uint32_t get32(const uint8_t *p)
{ return (uint32_t)p[0]|((uint32_t)p[1]<<8)|((uint32_t)p[2]<<16)|((uint32_t)p[3]<<24); }
static uint32_t crc32(const uint8_t *p,size_t n)
{
    uint32_t crc=UINT32_MAX;size_t i;unsigned b;
    for(i=0;i<n;i++) {crc^=p[i];for(b=0;b<8;b++) crc=(crc>>1)^(0xedb88320u & (0u-(crc&1u)));}
    return ~crc;
}
int wr_encode(const struct WrActive *a,uint8_t out[WR_SAVE_BYTES])
{
    if(!a->valid) return WR_BAD_IDENTITY;
    memset(out,0,WR_SAVE_BYTES);memcpy(out,"WR02",4);
    put32(out+4,a->identity.seed);put32(out+8,a->identity.algorithm);put32(out+12,a->identity.ruleset);
    memcpy(out+16,a->identity.data,32);out[48]=(uint8_t)a->attempt;out[49]=(uint8_t)(a->attempt>>8);
    put32(out+52,crc32(out,52));return WR_OK;
}
int wr_decode(const struct WrGraph *g,const uint8_t in[WR_SAVE_BYTES],struct WrIdentity *id,uint16_t *attempt)
{
    struct WrIdentity candidate;
    if(memcmp(in,"WR02",4) || in[50] || in[51] || crc32(in,52)!=get32(in+52)) return WR_BAD_IDENTITY;
    candidate.seed=get32(in+4);candidate.algorithm=get32(in+8);candidate.ruleset=get32(in+12);
    memcpy(candidate.data,in+16,32);
    if(!identityok(g,&candidate)) return WR_BAD_IDENTITY;
    *id=candidate;*attempt=(uint16_t)(in[48]|((uint16_t)in[49]<<8));return WR_OK;
}
