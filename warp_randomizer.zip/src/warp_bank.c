#include "warp_bank.h"
#include <string.h>

static int bank_ok(const struct WrBank *bank)
{
    uint16_t count;
    if(!bank || !bank->triggers || !bank->landings || !bank->row_crc32 ||
       !bank->record_count || bank->record_count > WR_MAX_NODES)
        return 0;
    count=bank->layout_count;
    return count >= 2 && count <= 256 && !(count & (count-1));
}

static uint32_t bank_crc(const struct WrBank *bank, uint16_t layout)
{
    uint32_t crc=UINT32_MAX;
    uint16_t i;
    unsigned j,b;
    const uint8_t *landing=bank->landings+
        (size_t)layout*bank->record_count*3u;
    for(i=0;i<bank->record_count;i++) for(j=0;j<6;j++) {
        uint8_t value=j<3 ? bank->triggers[(size_t)i*3u+j] :
            landing[(size_t)i*3u+j-3u];
        crc^=value;
        for(b=0;b<8;b++)
            crc=(crc>>1)^(0xedb88320u & (0u-(crc&1u)));
    }
    return ~crc;
}

uint16_t wr_bank_index(uint32_t seed,uint16_t layout_count)
{
    uint32_t value=seed;
    if(layout_count < 2 || layout_count > 256 ||
       (layout_count & (layout_count-1))) return WR_NONE;
    value+=0x9e3779b9u;
    value=(value^(value>>16))*0x85ebca6bu;
    value=(value^(value>>13))*0xc2b2ae35u;
    value^=value>>16;
    return (uint16_t)(value&(layout_count-1u));
}

int wr_bank_make_identity(const struct WrBank *bank,uint32_t seed,
                          struct WrIdentity *identity)
{
    if(!identity || !bank_ok(bank)) return WR_BAD_DATA;
    memset(identity,0,sizeof(*identity));
    identity->seed=seed;
    identity->algorithm=WR_BANK_ALGORITHM;
    identity->ruleset=WR_BANK_RULESET;
    memcpy(identity->data,bank->fingerprint,sizeof(identity->data));
    return WR_OK;
}

int wr_bank_load(const struct WrBank *bank,const struct WrIdentity *identity,
                 struct WrActive *active)
{
    uint16_t i,index;
    const uint8_t *landing;
    if(!active) return WR_BAD_DATA;
    wr_invalidate(active);
    if(!identity || !bank_ok(bank)) return WR_BAD_DATA;
    if(identity->algorithm != WR_BANK_ALGORITHM ||
       identity->ruleset != WR_BANK_RULESET ||
       memcmp(identity->data,bank->fingerprint,sizeof(identity->data)))
        return WR_BAD_IDENTITY;
    index=wr_bank_index(identity->seed,bank->layout_count);
    if(index==WR_NONE) return WR_BAD_DATA;
    if(bank_crc(bank,index)!=bank->row_crc32[index]) return WR_BANK_BAD_CRC;

    /* Do not expose a partially copied table. valid is the publication flag. */
    memset(active,0,sizeof(*active));
    landing=bank->landings+(size_t)index*bank->record_count*3u;
    for(i=0;i<bank->record_count;i++) {
        const uint8_t *trigger=bank->triggers+(size_t)i*3u;
        const uint8_t *target=landing+(size_t)i*3u;
        active->records[i].trigger=(struct WrKey){trigger[0],trigger[1],trigger[2]};
        active->records[i].landing=(struct WrKey){target[0],target[1],target[2]};
    }
    active->identity=*identity;
    active->count=bank->record_count;
    active->attempt=0;
    active->valid=1;
    return WR_OK;
}
