# Provenance and attribution

Revision prepared 2026-09-04 from the two supplied attachments. Input archive
SHA-256 is `9a618fc6110ed1a4d44da53ba7912cf9403e7c87eb1f6229bb95dc29afdc9c59`,
matching the review brief. Individual source and plan hashes are preserved in
reports/input-hashes.json. No assertions depend on an earlier chat/workspace.

| Repository | Selected ref | Exact inspected commit |
|---|---|---|
| KittyPBoxx/upr-speedchoice-ex-gen9 | master as retrieved; pin authoritative | 5abfca86134872dbb3c54fa48e5920b6549cfb69 |
| KittyPBoxx/pokeemerald-ex-speedchoice-maprando-gen9 | speedchoice-maprando | f539267677ec3686c7f22bae2a63dc6f1a5267e9 |
| KittyPBoxx/Emerald-Ex-Map-Rando | main as retrieved; historical flag comment | f0966a668d3e7a7e937a519365cb1391d4a174a4 |
| rh-hideout/pokeemerald-expansion | expansion/1.17.0 | e8bd1cd7b03fc032ea37e3ecd38b379b5d01a1e7 |

Retrieved with Git and inspected locally. Reproduction uses full commits in
tools/audit/fetch_sources.py; target tag resolution was also checked with
`git ls-remote`. The source checkouts are not bundled. Unchanged JSON input
hashes accompany reports/reference-import.json, and target/reference map file
hashes accompany reports/map-input-hashes.json.

Tools executed: Python 3.12.13, GCC/cc 13.3.0, GNU make, Git, GCC AddressSanitizer
and UndefinedBehaviorSanitizer. Exact compiler resource output is in
reports/resources.json. C4 additionally used ARM GCC 13.2.1, binutils 2.42,
newlib 4.4.0.20231231 and the pinned target's bundled headless mGBA. Both normal
proof ROM modes built; ten target tests passed per mode. Package hashes,
emulator source/binary identity and target measurements are in
reports/target-toolchain-packages.json and reports/engine-proof/. Interactive
movement, complete restart/Continue and hardware behavior remain unverified. LeakSanitizer process enumeration is unavailable in
this runtime; its exit check is disabled in the host harness, while ASan/UBSan
checks remain active. No desktop timing or sizeof value is a GBA measurement.

Attribution: KittyPBoxx and the Universal Pokemon Randomizer contributors for
the reference design and bundled annotation data; RHH and pret contributors
for the target engine; the supplied GLM handoff and independent revision brief
for the defect register and architecture investigation. Based off RHH's
pokeemerald-expansion 1.17.0: https://github.com/rh-hideout/pokeemerald-expansion.
UPR: https://github.com/KittyPBoxx/upr-speedchoice-ex-gen9.
Speedchoice: https://github.com/KittyPBoxx/pokeemerald-ex-speedchoice-maprando-gen9.

The upstream UPR GPLv3 license is preserved in licenses/UPR-GPL-3.0.txt.
New compiler/core/test code in this revision is supplied under GPLv3. This
statement does not relicense third-party target files represented by patch
context; retain their upstream notices and contributor credits. No proprietary
ROM or private source is bundled. Scope and legal provenance of the original
user attachment are not independently certified.

Historical fallback-policy source: https://github.com/KittyPBoxx/Emerald-Ex-Map-Rando/blob/f0966a668d3e7a7e937a519365cb1391d4a174a4/dist/Randomiser/Flags.json.js
(lines 56–69). Its whole-file SHA-256 is in reports/historical-policy.json.

C6C also inspected two user-supplied optional design inputs without merging or
redistributing them: `MiMo-GLM-Optimized.tar` SHA-256
`9100b37140f7318ff4ede31aa7d9ad6f7f159731cfbfd86b4ed42d0a2e8402c0`
and `MiMo-GLM-Optimization.md` SHA-256
`6eee3f02bb86eae24dfd9310e701f87ab512c5984c54fbbe73efea5c232714e7`.
Their measured review is in docs/mimo-optimization-assessment.md. No license or
authorship conclusion beyond the user's description is inferred.

C7A merged none of the supplied MiMo implementation. Its experimental bounded
candidate includes the delivered GPLv3 Algorithm-3 translation unit solely to
reuse the exact current graph, closure, repair and validation semantics. The
new scheduling code and host audit/test tools are supplied under the same
project GPLv3 terms.

C7B compiled that exact shared scheduler with the unchanged core and generated
graph in the pinned target test build. No MiMo code, ROM or new external input
was added. The ARM harness and checked-report script are supplied under the same
project GPLv3 terms; the target patch context retains upstream notices.

C7C adds an independently generated SCC/bitset index and a current-model
experimental closure implementation. It uses no MiMo source and changes no
production algorithm or identity. Its host tests, compiler, ARM harness and
checked-report scripts are supplied under the same project GPLv3 terms.

C8A extends that independently written current-model work with generated
component/capability adjacency and event-driven delta propagation. It uses no
MiMo source, changes no production code or identity, and retains the same
conservative input policy. Its compiler, host tests, ARM harness and audit
scripts are supplied under the project GPLv3 terms.
