# Fixed-table expansion 1.17.0 integration proof

Status: normal ROM builds and ten ARM engine tests per mode pass against
`e8bd1cd7b03fc032ea37e3ecd38b379b5d01a1e7`, with the proof enabled and disabled.
The host stub tests also pass. Actual flash save/load and collision checks run
in headless mGBA. Interactive movement, complete restart/Continue and hardware
remain unverified. See engine-tests/README.md for executable reproduction.
This patch does not install the full random generator or alter SaveBlock3.

From the handoff directory, after fetching sources as described in README:

```sh
python3 tools/audit/make_proof_patch.py ../sources/target build/proof.patch
cmp patches/expansion-1.17.0-proof.patch build/proof.patch
git -C ../sources/target apply --check "$PWD/patches/expansion-1.17.0-proof.patch"
git -C ../sources/target apply "$PWD/patches/expansion-1.17.0-proof.patch"
```

Follow the pinned target's INSTALL.md, or use the local checksum-pinned
bootstrap in engine-tests/README.md, to prepare the toolchain. Set
WR_PROOF_ENABLED to 1 in the **target** include/warp_rando_proof.h; then build
using the target's documented command. It defaults to zero. The target Makefile
already discovers new src/*.c files. No JSON generation is required for this
fixed mapping. Do not copy the reference graph/core into the target as though
that were a finished integration.

## Expected observable cases

Target map order establishes Oldale=(0,10), House1=(2,0), House2=(2,1).
The experiment pairs outside House1 with inside House2, and outside House2 with
inside House1. Both indoor exit tiles are aliases.

| Source event(s) | Requested destination | Expected landing |
|---|---|---|
| Oldale warp 0 | 2,0,0 | 2,1,0 (House2), then experimental coordinates (3,6) |
| House2 warps 0 and 1 | 0,10,1 | 0,10,0 (outside House1) |
| Oldale warp 1 | 2,1,0 | 2,0,0 (House1), default warp-event coordinates |
| House1 warps 0 and 1 | 0,10,0 | 0,10,1 (outside House2) |
| Oldale center/mart | Original | Original |
| Different source requesting a listed destination | Listed triple | Original; source-context gate rejects it |

Walk both round trips and both aliases. Observe (3,6) for House2 and confirm it
is walkable and does not retrigger a warp. Headless target checks confirm (3,6) is passable and outside warp events;
its behavior through full door animations is still unobserved. Save inside, restart and exit; the fixed
table is constant. Flash save/load is tested, but a full emulator restart and
Continue callback remain open.
Build disabled and confirm ordinary behavior; no byte-identical ROM claim.

## Hook coverage and follow-up state

`SetupWarp` knows the actual event and requested destination. The patch calls
WrProof_Resolve there only for ordinary non-Trainer-Hill, non-dynamic events.
The rewritten triple is used for SetWarpDestinationToMapWarp, UpdateEscapeWarp's
pending destination, and the redirected destination-header inspection.
The original non-proof branch is retained, including its existing use of
warpEventId in a destination array access; that preexisting code deserves a
separate upstream review and is not silently changed for every game here.

Queued correction is applied immediately **after SetPlayerCoordsFromWarp in
WarpIntoMap**, so coordinate initialization cannot overwrite it. It clears on
consumption, mismatch, new game, Continue, ordinary destination setup and the
listed dynamic/escape/whiteout/Teleport/Dive/fall bypass setters. Script setters
are not remapped by this proof. Loading a save does not reapply a pending fix.

| Path | Proof behavior / outstanding audit |
|---|---|
| Ordinary eligible event | Redirected using source context plus requested triple |
| Grouped indoor exit | Both event indices accepted with same requested trigger |
| Ambiguous shared trigger from another source | Left unchanged; no numeric proxy synthesis |
| Script warp/coordinate warp | Fixed/original, no source-event lookup |
| MAP_DYNAMIC and Trainer Hill | Excluded from experiment |
| Dive, fall, Dig/Rope, Teleport, whiteout | Original travel; pending correction reset in common bypass setters |
| Continue/restart | Original saved destination; correction cleared; fixed table needs no seed save |
| Map connections and exceptional direct assignments | No remapping; full engine coverage unverified |

The broader runtime will need audited normalization for scripts and ambiguous
reference proxy tokens, real arrival corrections, game-state repairs and save
integration. A small proof makes those obligations observable; it does not
claim that one central hook safely covers every transition.
