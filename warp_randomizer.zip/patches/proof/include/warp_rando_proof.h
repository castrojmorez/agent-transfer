#ifndef WARP_RANDO_PROOF_H
#define WARP_RANDO_PROOF_H
#include "global.h"
/* Fixed mapping experiment only; never enables the full graph generator. */
#ifndef WR_PROOF_ENABLED
#define WR_PROOF_ENABLED 0
#endif
bool8 WrProof_Resolve(s8 sg, s8 sm, s8 sw, s8 *dg, s8 *dm, s8 *dw);
void WrProof_Reset(void);
void WrProof_QueueArrival(s8 dg, s8 dm, s8 dw);
void WrProof_Apply(s8 dg, s8 dm, s8 dw, s16 *x, s16 *y);
#endif
