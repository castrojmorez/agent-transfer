#include "warp_rando_proof.h"
#if WR_PROOF_ENABLED
EWRAM_DATA static bool8 sPending = FALSE;
/* Source gating deliberately prevents scripts sharing a destination from
 * entering this event-only experiment. All destination triples are target data. */
bool8 WrProof_Resolve(s8 sg,s8 sm,s8 sw,s8 *dg,s8 *dm,s8 *dw)
{
    if(sg==0 && sm==10 && sw==0 && *dg==2 && *dm==0 && *dw==0)
        { *dg=2;*dm=1;*dw=0;return TRUE; }
    if(sg==2 && sm==1 && (sw==0 || sw==1) && *dg==0 && *dm==10 && *dw==1)
        { *dg=0;*dm=10;*dw=0;return TRUE; }
    if(sg==0 && sm==10 && sw==1 && *dg==2 && *dm==1 && *dw==0)
        { *dg=2;*dm=0;*dw=0;return TRUE; }
    if(sg==2 && sm==0 && (sw==0 || sw==1) && *dg==0 && *dm==10 && *dw==0)
        { *dg=0;*dm=10;*dw=1;return TRUE; }
    return FALSE;
}
void WrProof_Reset(void) { sPending=FALSE; }
void WrProof_QueueArrival(s8 dg,s8 dm,s8 dw)
{ sPending=(dg==2 && dm==1 && dw==0); }
void WrProof_Apply(s8 dg,s8 dm,s8 dw,s16 *x,s16 *y)
{
    if(sPending && dg==2 && dm==1 && dw==0) { *x=3;*y=6; }
    sPending=FALSE;
}
#else
bool8 WrProof_Resolve(s8 sg,s8 sm,s8 sw,s8 *dg,s8 *dm,s8 *dw)
{ (void)sg;(void)sm;(void)sw;(void)dg;(void)dm;(void)dw;return FALSE; }
void WrProof_Reset(void) {}
void WrProof_QueueArrival(s8 dg,s8 dm,s8 dw) { (void)dg;(void)dm;(void)dw; }
void WrProof_Apply(s8 dg,s8 dm,s8 dw,s16 *x,s16 *y)
{ (void)dg;(void)dm;(void)dw;(void)x;(void)y; }
#endif
