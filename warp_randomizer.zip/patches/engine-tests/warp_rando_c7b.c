#include "global.h"
#include "test/test.h"
#include "malloc.h"
#include "warp_rando.h"
#include "warp_reference_graph.h"
#include <limits.h>
#include <string.h>

/* C7B compiles the unchanged core and the exact C7A experimental scheduler in
 * one private test translation unit. This is test-only and assigns no ID. */
#include "warp_rando_core.c"
#include "c7a_candidate_core.inc"

EWRAM_DATA static struct WrActive sC7bActive = {0};

struct HeapStats
{
    u32 freeBytes;
    u32 largestFree;
    u16 freeBlocks;
    u16 allocatedBlocks;
};

static struct HeapStats MeasureHeap(void)
{
    struct HeapStats stats = {0};
    const struct MemBlock *head = HeapHead();
    const struct MemBlock *block = head;

    do
    {
        if (block->allocated)
            stats.allocatedBlocks++;
        else
        {
            stats.freeBlocks++;
            stats.freeBytes += block->size;
            if (block->size > stats.largestFree)
                stats.largestFree = block->size;
        }
        block = block->next;
    } while (block != head);
    return stats;
}

static u32 HashByte(u32 hash, u8 byte)
{
    return (hash ^ byte) * 16777619u;
}

static u32 HashActiveRecords(const struct WrActive *active)
{
    u32 hash = 2166136261u;
    u16 i;

    for (i = 0; i < active->count; i++)
    {
        const struct WrRecord *record = &active->records[i];
        hash = HashByte(hash, record->trigger.group);
        hash = HashByte(hash, record->trigger.map);
        hash = HashByte(hash, record->trigger.warp);
        hash = HashByte(hash, record->landing.group);
        hash = HashByte(hash, record->landing.map);
        hash = HashByte(hash, record->landing.warp);
    }
    return hash;
}

static int GenerateAndPublish(u32 seed, struct WrWork *work,
                              struct C7aStats *stats, u16 *attempt,
                              int *lastRejection)
{
    u16 count;
    int result;

    wr_invalidate(&sC7bActive);
    result = c7a_generate_candidate(&wr_graph, seed, 4, 8, work, stats,
                                    &count, attempt, lastRejection);
    if (result != WR_OK)
        return result;
    memcpy(sC7bActive.records, work->candidate, count * sizeof(*work->candidate));
    sC7bActive.identity.seed = seed;
    sC7bActive.identity.algorithm = 0; /* Deliberately unassigned test identity. */
    sC7bActive.identity.ruleset = 1;
    memcpy(sC7bActive.identity.data, wr_graph.fingerprint,
           sizeof(sC7bActive.identity.data));
    sC7bActive.count = count;
    sC7bActive.attempt = *attempt;
    sC7bActive.valid = TRUE; /* Publish validity last. */
    return WR_OK;
}

static u32 GenerateTimed(u32 seed, struct WrWork *work,
                         struct C7aStats *stats, u16 *attempt,
                         int *result, int *lastRejection)
{
    u16 oldTimer0Low = REG_TM0CNT_L;
    u16 oldTimer0High = REG_TM0CNT_H;
    u16 oldTimer1Low = REG_TM1CNT_L;
    u16 oldTimer1High = REG_TM1CNT_H;
    u32 ticks;

    REG_TM0CNT_H = 0;
    REG_TM1CNT_H = 0;
    REG_TM0CNT_L = 0;
    REG_TM1CNT_L = 0;
    REG_TM1CNT_H = TIMER_ENABLE | TIMER_COUNTUP;
    REG_TM0CNT_H = TIMER_ENABLE | TIMER_64CLK;
    *result = GenerateAndPublish(seed, work, stats, attempt, lastRejection);
    REG_TM0CNT_H = 0;
    REG_TM1CNT_H = 0;
    ticks = REG_TM0CNT_L | ((u32)REG_TM1CNT_L << 16);
    REG_TM0CNT_L = oldTimer0Low;
    REG_TM1CNT_L = oldTimer1Low;
    REG_TM1CNT_H = oldTimer1High;
    REG_TM0CNT_H = oldTimer0High;
    return ticks;
}

TEST("WarpC7B: bounded candidate measures first and second attempt seeds")
{
    struct WrWork *work;
    struct C7aStats stats0 = {0}, stats42 = {0};
    struct HeapStats before, during, after;
    u32 oldTimeout = gTestRunnerState.timeoutSeconds;
    u32 ticks0, ticks42, digest0, digest42;
    u16 attempt0 = 0, attempt42 = 0;
    int result0, result42, last0 = WR_OK, last42 = WR_OK;

    before = MeasureHeap();
    work = AllocZeroedUnchecked(sizeof(*work));
    EXPECT(work != NULL);
    if (work == NULL)
        return;
    during = MeasureHeap();
    EXPECT_EQ(((uintptr_t)&sC7bActive) >> 24, 2);
    gTestRunnerState.timeoutSeconds = UINT_MAX;
    ticks0 = GenerateTimed(0, work, &stats0, &attempt0, &result0, &last0);
    digest0 = HashActiveRecords(&sC7bActive);
    ticks42 = GenerateTimed(42, work, &stats42, &attempt42, &result42, &last42);
    digest42 = HashActiveRecords(&sC7bActive);
    gTestRunnerState.timeoutSeconds = oldTimeout;
    Free(work);
    after = MeasureHeap();

    EXPECT_EQ(result0, WR_OK);
    EXPECT_EQ(last0, WR_OK);
    EXPECT_EQ(attempt0, 0);
    EXPECT_EQ(digest0, 0xaa8b08fdu);
    EXPECT_EQ(stats0.attempts, 1);
    EXPECT_EQ(stats0.partner_trials, 1020);
    EXPECT_EQ(stats0.state_closures, 1276);
    EXPECT_EQ(result42, WR_OK);
    EXPECT_EQ(last42, WR_NO_PARTNER);
    EXPECT_EQ(attempt42, 1);
    EXPECT_EQ(digest42, 0x4c5a43e2u);
    EXPECT_EQ(stats42.attempts, 2);
    EXPECT_EQ(stats42.partner_trials, 2039);
    EXPECT_EQ(stats42.state_closures, 2550);
    EXPECT_EQ(sC7bActive.valid, TRUE);
    EXPECT_EQ(sC7bActive.count, 532);
    EXPECT_EQ(sC7bActive.identity.algorithm, 0);
    EXPECT_EQ(before.freeBytes, after.freeBytes);
    EXPECT_EQ(before.largestFree, after.largestFree);
    EXPECT_EQ(before.freeBlocks, after.freeBlocks);
    EXPECT_EQ(before.allocatedBlocks, after.allocatedBlocks);
    EXPECT_GE(before.largestFree, sizeof(*work));

    Test_MgbaPrintf("WRC7B ticks0=%d frames0_floor=%d result0=%d last0=%d attempt0=%d digest0_decimal=%d trials0=%d closures0=%d ticks42=%d frames42_floor=%d result42=%d last42=%d attempt42=%d digest42_decimal=%d trials42=%d closures42=%d",
                    (s32)ticks0, (s32)(ticks0 / 4389u), result0, last0,
                    attempt0, (s32)digest0, (s32)stats0.partner_trials,
                    (s32)stats0.state_closures, (s32)ticks42,
                    (s32)(ticks42 / 4389u), result42, last42, attempt42,
                    (s32)digest42, (s32)stats42.partner_trials,
                    (s32)stats42.state_closures);
    Test_MgbaPrintf("WRC7BMEM work=%d active=%d algorithm=%d heap_before_free=%d heap_before_largest=%d heap_during_free=%d heap_during_largest=%d heap_after_free=%d heap_after_largest=%d",
                    sizeof(*work), sizeof(sC7bActive),
                    sC7bActive.identity.algorithm,
                    (s32)before.freeBytes, (s32)before.largestFree,
                    (s32)during.freeBytes, (s32)during.largestFree,
                    (s32)after.freeBytes, (s32)after.largestFree);
}
