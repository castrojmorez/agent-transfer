#include "global.h"
#include "test/test.h"
#include "malloc.h"
#include "task.h"
#include "warp_rando.h"
#include "warp_reference_graph.h"
#include <limits.h>
#include <string.h>

/* C10C is a test-only budgeted task adapter over C10B. No runtime identity. */
#include "warp_rando_core.c"
#include "c9c_candidate_core.inc"
#include "warp_reference_c9c_event_index.h"
#include "c10b_candidate_core.inc"
#include "c10c_scheduler_core.inc"

EWRAM_DATA static struct WrActive sC10cActive={0};
static volatile u32 sC10cLoadSink;
struct HeapStats {u32 freeBytes,largestFree;u16 freeBlocks,allocatedBlocks;};
struct TimerState {u16 l0,h0,l1,h1;};
struct RunningClock {u32 base;};
struct C10cEngine {
    struct C10cJob job;struct C9cStats stats;struct C9cWork *work;
    u32 maxCallbackTicks,totalCallbackTicks,maxFrameTicks,frames,loadVisits;
    u16 lastProgress,progressRegressions,invalidations,publishes,releases;
    int result;u8 taskId,done;
};
EWRAM_DATA static struct C10cEngine sEngine={0};

static struct HeapStats MeasureHeap(void)
{
    struct HeapStats s={0};const struct MemBlock *head=HeapHead(),*b=head;
    do {if(b->allocated)s.allocatedBlocks++;else{s.freeBlocks++;s.freeBytes+=b->size;
        if(b->size>s.largestFree)s.largestFree=b->size;}b=b->next;}while(b!=head);return s;
}
static void TimerStart(struct TimerState *s)
{
    s->l0=REG_TM0CNT_L;s->h0=REG_TM0CNT_H;s->l1=REG_TM1CNT_L;s->h1=REG_TM1CNT_H;
    REG_TM0CNT_H=0;REG_TM1CNT_H=0;REG_TM0CNT_L=0;REG_TM1CNT_L=0;
    REG_TM1CNT_H=TIMER_ENABLE|TIMER_COUNTUP;REG_TM0CNT_H=TIMER_ENABLE|TIMER_64CLK;
}
static u32 TimerRead(void)
{return REG_TM0CNT_L|((u32)REG_TM1CNT_L<<16);}
static u32 TimerStop(const struct TimerState *s)
{
    u32 ticks=TimerRead();REG_TM0CNT_H=0;REG_TM1CNT_H=0;
    REG_TM0CNT_L=s->l0;REG_TM1CNT_L=s->l1;REG_TM1CNT_H=s->h1;REG_TM0CNT_H=s->h0;return ticks;
}
static u32 Elapsed(void *context)
{struct RunningClock *clock=context;return TimerRead()-clock->base;}
static u32 HashByte(u32 h,u8 b){return(h^b)*16777619u;}
static u32 HashActive(void)
{
    u32 h=2166136261u;u16 i;for(i=0;i<sC10cActive.count;i++){const struct WrRecord *r=&sC10cActive.records[i];
        h=HashByte(h,r->trigger.group);h=HashByte(h,r->trigger.map);h=HashByte(h,r->trigger.warp);
        h=HashByte(h,r->landing.group);h=HashByte(h,r->landing.map);h=HashByte(h,r->landing.warp);}return h;
}
static void Invalidate(void *context)
{struct C10cEngine *e=context;wr_invalidate(&sC10cActive);e->invalidations++;}
static int Publish(void *context,const struct C10bSession *q)
{
    struct C10cEngine *e=context;memcpy(sC10cActive.records,q->work->candidate,q->count*sizeof(*q->work->candidate));
    sC10cActive.identity.seed=q->seed;sC10cActive.identity.algorithm=0;sC10cActive.identity.ruleset=1;
    memcpy(sC10cActive.identity.data,wr_graph.fingerprint,sizeof(sC10cActive.identity.data));
    sC10cActive.count=q->count;sC10cActive.attempt=q->successful_attempt;sC10cActive.valid=TRUE;
    e->publishes++;return WR_OK;
}
static void Release(void *context,struct C9cWork *work)
{struct C10cEngine *e=context;if(work)Free(work);e->work=NULL;e->releases++;}
static void Task_SyntheticLoad(u8 taskId)
{
    u16 i;(void)taskId;sEngine.loadVisits++;
    for(i=0;i<2048;i++)sC10cLoadSink=(sC10cLoadSink<<5)^(sC10cLoadSink>>2)^i^0x9e3779b9u;
}
static void Task_C10cGenerate(u8 taskId)
{
    struct RunningClock clock;struct C10cView view;u32 ticks;
    clock.base=TimerRead();sEngine.result=c10c_pump(&sEngine.job,Elapsed,&clock);
    ticks=TimerRead()-clock.base;sEngine.totalCallbackTicks+=ticks;
    if(ticks>sEngine.maxCallbackTicks)sEngine.maxCallbackTicks=ticks;
    c10c_snapshot(&sEngine.job,&view);
    if(view.progress<sEngine.lastProgress)sEngine.progressRegressions++;
    sEngine.lastProgress=view.progress;
    if(sEngine.result!=C10B_PENDING){sEngine.done=1;DestroyTask(taskId);}
}
static int Start(u32 seed)
{
    struct C10cHooks hooks={Invalidate,Publish,Release,&sEngine};
    memset(&sEngine,0,sizeof(sEngine));sEngine.work=AllocZeroedUnchecked(sizeof(*sEngine.work));
    if(!sEngine.work){Invalidate(&sEngine);sEngine.result=WR_BAD_DATA;sEngine.done=1;return sEngine.result;}
    sEngine.result=c10c_begin_prevalidated(&sEngine.job,&wr_graph,&c9c_index,seed,3,8,
                                           C10C_DEFAULT_BUDGET_TICKS,sEngine.work,&sEngine.stats,&hooks);
    if(sEngine.result!=C10B_PENDING){sEngine.done=1;return sEngine.result;}
    sEngine.taskId=CreateTask(Task_C10cGenerate,1);
    if(sEngine.taskId==TASK_NONE){sEngine.result=c10c_cancel(&sEngine.job);sEngine.done=1;return WR_BAD_DATA;}
    return C10B_PENDING;
}
static int Run(u32 seed,u32 cancelFrame,u32 *digest)
{
    u8 loadTask;u32 guard=0;int result;ResetTasks();loadTask=CreateTask(Task_SyntheticLoad,0);
    result=Start(seed);
    while(result==C10B_PENDING && guard++<10000) {
        struct TimerState timer;u32 ticks;TimerStart(&timer);RunTasks();ticks=TimerStop(&timer);
        sEngine.frames++;if(ticks>sEngine.maxFrameTicks)sEngine.maxFrameTicks=ticks;
        if(!sEngine.done && sC10cActive.valid)sEngine.progressRegressions++;
        if(cancelFrame && sEngine.frames==cancelFrame)c10c_request_cancel(&sEngine.job);
        result=sEngine.result;
    }
    DestroyTask(loadTask);if(digest)*digest=HashActive();return result;
}
static u32 ValidateTimed(int *result)
{struct TimerState timer;TimerStart(&timer);*result=c9c_validate_reference(&wr_graph,&c9c_index);return TimerStop(&timer);}

TEST("WarpC10C: budgeted engine task is responsive, monotonic, and publish-last")
{
    struct HeapStats before,after0,after42,afterCancel;struct C10cEngine result0,result42,cancelled;
    u32 oldTimeout=gTestRunnerState.timeoutSeconds,approvalTicks,digest0,digest42;
    int approvalResult,r0,r42,rc;before=MeasureHeap();gTestRunnerState.timeoutSeconds=UINT_MAX;
    approvalTicks=ValidateTimed(&approvalResult);
    r0=Run(0,0,&digest0);result0=sEngine;after0=MeasureHeap();
    r42=Run(42,0,&digest42);result42=sEngine;after42=MeasureHeap();
    rc=Run(0,32,NULL);cancelled=sEngine;afterCancel=MeasureHeap();
    gTestRunnerState.timeoutSeconds=oldTimeout;ResetTasks();
    EXPECT_EQ(approvalResult,WR_OK);EXPECT_EQ(r0,WR_OK);EXPECT_EQ(r42,WR_OK);EXPECT_EQ(rc,C10B_CANCELLED);
    EXPECT_EQ(digest0,0xd2f14b80u);EXPECT_EQ(digest42,0x3d354fa7u);
    EXPECT_EQ(result0.stats.partner_trials,766);EXPECT_EQ(result42.stats.partner_trials,1525);
    EXPECT_EQ(result0.job.generation.successful_attempt,0);EXPECT_EQ(result42.job.generation.successful_attempt,1);
    EXPECT_EQ(result0.job.progress,C10C_PROGRESS_MAX);EXPECT_EQ(result42.job.progress,C10C_PROGRESS_MAX);
    EXPECT_EQ(result0.progressRegressions,0);EXPECT_EQ(result42.progressRegressions,0);
    EXPECT_EQ(result0.invalidations,1);EXPECT_EQ(result0.publishes,1);EXPECT_EQ(result0.releases,1);
    EXPECT_EQ(result42.invalidations,1);EXPECT_EQ(result42.publishes,1);EXPECT_EQ(result42.releases,1);
    EXPECT_EQ(cancelled.invalidations,1);EXPECT_EQ(cancelled.publishes,0);EXPECT_EQ(cancelled.releases,1);
    EXPECT_EQ(cancelled.job.published,0);EXPECT_EQ(cancelled.job.released,1);
    EXPECT(result0.job.max_steps_per_callback>1);EXPECT(result42.job.max_steps_per_callback>1);
    EXPECT(result0.maxCallbackTicks<=C10C_DEFAULT_BUDGET_TICKS);
    EXPECT(result42.maxCallbackTicks<=C10C_DEFAULT_BUDGET_TICKS);
    EXPECT(result0.maxFrameTicks<4389);EXPECT(result42.maxFrameTicks<4389);EXPECT(cancelled.maxFrameTicks<4389);
    EXPECT_EQ(result0.loadVisits,result0.frames);EXPECT_EQ(result42.loadVisits,result42.frames);
    EXPECT_EQ(before.freeBytes,after0.freeBytes);EXPECT_EQ(before.freeBytes,after42.freeBytes);
    EXPECT_EQ(before.freeBytes,afterCancel.freeBytes);EXPECT_EQ(before.largestFree,afterCancel.largestFree);
    Test_MgbaPrintf("WRC10C0 frames0=%d callback_max0=%d frame_max0=%d callback_total0=%d callbacks0=%d steps0=%d max_steps0=%d digest0_decimal=%d",(s32)result0.frames,(s32)result0.maxCallbackTicks,(s32)result0.maxFrameTicks,(s32)result0.totalCallbackTicks,(s32)result0.job.callbacks,(s32)result0.job.generation.steps,(s32)result0.job.max_steps_per_callback,(s32)digest0);
    Test_MgbaPrintf("WRC10C42 frames42=%d callback_max42=%d frame_max42=%d callback_total42=%d callbacks42=%d steps42=%d max_steps42=%d digest42_decimal=%d attempt42=%d",(s32)result42.frames,(s32)result42.maxCallbackTicks,(s32)result42.maxFrameTicks,(s32)result42.totalCallbackTicks,(s32)result42.job.callbacks,(s32)result42.job.generation.steps,(s32)result42.job.max_steps_per_callback,(s32)digest42,result42.job.generation.successful_attempt);
    Test_MgbaPrintf("WRC10CCANCEL frames_cancel=%d callback_max_cancel=%d frame_max_cancel=%d result_cancel=%d progress_cancel=%d publishes_cancel=%d releases_cancel=%d",(s32)cancelled.frames,(s32)cancelled.maxCallbackTicks,(s32)cancelled.maxFrameTicks,rc,cancelled.job.progress,cancelled.publishes,cancelled.releases);
    Test_MgbaPrintf("WRC10CLIFE invalid0=%d publish0=%d release0=%d regress0=%d invalid42=%d publish42=%d release42=%d regress42=%d approval_ticks=%d",result0.invalidations,result0.publishes,result0.releases,result0.progressRegressions,result42.invalidations,result42.publishes,result42.releases,result42.progressRegressions,(s32)approvalTicks);
    Test_MgbaPrintf("WRC10CMEM work=%d session=%d job=%d active=%d algorithm=%d heap_before_free=%d heap_after0_free=%d heap_after42_free=%d heap_after_cancel_free=%d",sizeof(struct C9cWork),sizeof(struct C10bSession),sizeof(struct C10cJob),sizeof(sC10cActive),sC10cActive.identity.algorithm,(s32)before.freeBytes,(s32)after0.freeBytes,(s32)after42.freeBytes,(s32)afterCancel.freeBytes);
}
