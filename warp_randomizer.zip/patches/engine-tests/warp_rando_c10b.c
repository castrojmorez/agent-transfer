#include "global.h"
#include "test/test.h"
#include "malloc.h"
#include "warp_rando.h"
#include "warp_reference_graph.h"
#include <limits.h>
#include <string.h>

/* C10B is a test-only internally resumable wrapper over C9C. No runtime identity. */
#include "warp_rando_core.c"
#include "c9c_candidate_core.inc"
#include "warp_reference_c9c_event_index.h"
#include "c10b_candidate_core.inc"
EWRAM_DATA static struct WrActive sC10bActive={0};
struct HeapStats {u32 freeBytes,largestFree;u16 freeBlocks,allocatedBlocks;};
struct TimerState {u16 l0,h0,l1,h1;};
static struct HeapStats MeasureHeap(void)
{
    struct HeapStats s={0};const struct MemBlock *head=HeapHead(),*b=head;
    do {if(b->allocated)s.allocatedBlocks++;else{s.freeBlocks++;s.freeBytes+=b->size;
        if(b->size>s.largestFree)s.largestFree=b->size;}b=b->next;}while(b!=head);return s;
}
static void TimerStart(struct TimerState *s)
{
    s->l0=REG_TM0CNT_L;s->h0=REG_TM0CNT_H;s->l1=REG_TM1CNT_L;s->h1=REG_TM1CNT_H;
    REG_TM0CNT_H=0;REG_TM1CNT_H=0;REG_TM0CNT_L=0;REG_TM1CNT_L=0;
    REG_TM1CNT_H=TIMER_ENABLE|TIMER_COUNTUP;REG_TM0CNT_H=TIMER_ENABLE|TIMER_64CLK;
}
static u32 TimerStop(const struct TimerState *s)
{
    u32 ticks;REG_TM0CNT_H=0;REG_TM1CNT_H=0;ticks=REG_TM0CNT_L|((u32)REG_TM1CNT_L<<16);
    REG_TM0CNT_L=s->l0;REG_TM1CNT_L=s->l1;REG_TM1CNT_H=s->h1;REG_TM0CNT_H=s->h0;return ticks;
}
static u32 HashByte(u32 h,u8 b){return(h^b)*16777619u;}
static u32 HashActive(void)
{
    u32 h=2166136261u;u16 i;for(i=0;i<sC10bActive.count;i++){const struct WrRecord *r=&sC10bActive.records[i];
        h=HashByte(h,r->trigger.group);h=HashByte(h,r->trigger.map);h=HashByte(h,r->trigger.warp);
        h=HashByte(h,r->landing.group);h=HashByte(h,r->landing.map);h=HashByte(h,r->landing.warp);}return h;
}
static void Publish(u32 seed,const struct C10bSession *q)
{
    memcpy(sC10bActive.records,q->work->candidate,q->count*sizeof(*q->work->candidate));
    sC10bActive.identity.seed=seed;sC10bActive.identity.algorithm=0;sC10bActive.identity.ruleset=1;
    memcpy(sC10bActive.identity.data,wr_graph.fingerprint,sizeof(sC10bActive.identity.data));
    sC10bActive.count=q->count;sC10bActive.attempt=q->successful_attempt;sC10bActive.valid=TRUE;
}
static u32 RunTotal(u32 seed,struct C9cWork *w,struct C9cStats *stats,
                    struct C10bSession *q,int *result)
{
    struct TimerState timer;wr_invalidate(&sC10bActive);TimerStart(&timer);
    *result=c10b_begin_prevalidated(q,&wr_graph,&c9c_index,seed,3,8,w,stats);
    while(*result==C10B_PENDING)*result=c10b_advance(q,1);
    if(*result==WR_OK)Publish(seed,q);
    return TimerStop(&timer);
}
static int RunProfile(u32 seed,struct C9cWork *w,struct C9cStats *stats,
                      struct C10bSession *q,u32 maximum[6],u32 *maximumAny,u8 *maximumPhase)
{
    int result=c10b_begin_prevalidated(q,&wr_graph,&c9c_index,seed,3,8,w,stats);
    while(result==C10B_PENDING){u8 phase=q->phase,group=c10b_group(phase);u32 ticks;struct TimerState timer;
        TimerStart(&timer);result=c10b_step(q);ticks=TimerStop(&timer);
        if(ticks>maximum[group])maximum[group]=ticks;
        if(ticks>*maximumAny){*maximumAny=ticks;*maximumPhase=phase;}}
    return result;
}
static u32 ValidateTimed(int *result)
{struct TimerState timer;TimerStart(&timer);*result=c9c_validate_reference(&wr_graph,&c9c_index);return TimerStop(&timer);}

TEST("WarpC10B: internally resumable C9C schedule stays below one frame")
{
    struct C9cWork *work;struct C9cStats cancelStats={0},stats0={0},stats42={0},profile0={0},profile42={0};
    struct C10bSession cancelSession,session0,session42,profileSession0,profileSession42;
    struct HeapStats before,during,after;u32 max0[6]={0},max42[6]={0},maxAny0=0,maxAny42=0;
    u8 maxPhase0=0,maxPhase42=0;u32 oldTimeout=gTestRunnerState.timeoutSeconds,approvalTicks,ticks0,ticks42,digest0,digest42;
    int approvalResult,result0,result42,profileResult0,profileResult42,cancelResult;
    before=MeasureHeap();work=AllocZeroedUnchecked(sizeof(*work));EXPECT(work!=NULL);if(work==NULL)return;
    during=MeasureHeap();EXPECT_EQ(((uintptr_t)&sC10bActive)>>24,2);gTestRunnerState.timeoutSeconds=UINT_MAX;
    approvalTicks=ValidateTimed(&approvalResult);
    cancelResult=c10b_begin_prevalidated(&cancelSession,&wr_graph,&c9c_index,0,3,8,work,&cancelStats);
    cancelResult=c10b_advance(&cancelSession,64);EXPECT_EQ(cancelResult,C10B_PENDING);
    cancelResult=c10b_cancel(&cancelSession);EXPECT_EQ(cancelResult,C10B_CANCELLED);EXPECT_EQ(cancelSession.count,0);
    ticks0=RunTotal(0,work,&stats0,&session0,&result0);digest0=HashActive();
    ticks42=RunTotal(42,work,&stats42,&session42,&result42);digest42=HashActive();
    profileResult0=RunProfile(0,work,&profile0,&profileSession0,max0,&maxAny0,&maxPhase0);
    profileResult42=RunProfile(42,work,&profile42,&profileSession42,max42,&maxAny42,&maxPhase42);
    gTestRunnerState.timeoutSeconds=oldTimeout;Free(work);after=MeasureHeap();
    EXPECT_EQ(approvalResult,WR_OK);EXPECT_EQ(result0,WR_OK);EXPECT_EQ(result42,WR_OK);
    EXPECT_EQ(profileResult0,WR_OK);EXPECT_EQ(profileResult42,WR_OK);
    EXPECT_EQ(digest0,0xd2f14b80u);EXPECT_EQ(digest42,0x3d354fa7u);
    EXPECT_EQ(session0.steps,66274);EXPECT_EQ(session42.steps,94230);
    EXPECT_EQ(stats0.partner_trials,766);EXPECT_EQ(stats42.partner_trials,1525);
    EXPECT_EQ(session0.successful_attempt,0);EXPECT_EQ(session42.successful_attempt,1);
    EXPECT(maxAny0<4389);EXPECT(maxAny42<4389);
    EXPECT_EQ(sC10bActive.valid,TRUE);EXPECT_EQ(sC10bActive.count,532);EXPECT_EQ(sC10bActive.identity.algorithm,0);
    EXPECT_EQ(before.freeBytes,after.freeBytes);EXPECT_EQ(before.largestFree,after.largestFree);
    EXPECT_EQ(before.freeBlocks,after.freeBlocks);EXPECT_EQ(before.allocatedBlocks,after.allocatedBlocks);
    Test_MgbaPrintf("WRC10B0 ticks0=%d frames0_floor=%d result0=%d attempt0=%d digest0_decimal=%d steps0=%d trials0=%d",(s32)ticks0,(s32)(ticks0/4389u),result0,session0.successful_attempt,(s32)digest0,(s32)session0.steps,(s32)stats0.partner_trials);
    Test_MgbaPrintf("WRC10B42 ticks42=%d frames42_floor=%d result42=%d attempt42=%d last42=%d digest42_decimal=%d steps42=%d trials42=%d",(s32)ticks42,(s32)(ticks42/4389u),result42,session42.successful_attempt,session42.last_rejection,(s32)digest42,(s32)session42.steps,(s32)stats42.partner_trials);
    Test_MgbaPrintf("WRC10BSTEP0 max_any0=%d max_phase0=%d init0=%d select0=%d trial0=%d commit0=%d emit0=%d validate0=%d",(s32)maxAny0,maxPhase0,(s32)max0[0],(s32)max0[1],(s32)max0[2],(s32)max0[3],(s32)max0[4],(s32)max0[5]);
    Test_MgbaPrintf("WRC10BSTEP42 max_any42=%d max_phase42=%d init42=%d select42=%d trial42=%d commit42=%d emit42=%d validate42=%d",(s32)maxAny42,maxPhase42,(s32)max42[0],(s32)max42[1],(s32)max42[2],(s32)max42[3],(s32)max42[4],(s32)max42[5]);
    Test_MgbaPrintf("WRC10BPHASE approval_ticks=%d cancel_steps=%d cancel_result=%d",(s32)approvalTicks,(s32)cancelSession.steps,cancelResult);
    Test_MgbaPrintf("WRC10BMEM work=%d session=%d active=%d algorithm=%d heap_before_free=%d heap_before_largest=%d heap_during_free=%d heap_during_largest=%d heap_after_free=%d heap_after_largest=%d",sizeof(*work),sizeof(session0),sizeof(sC10bActive),sC10bActive.identity.algorithm,(s32)before.freeBytes,(s32)before.largestFree,(s32)during.freeBytes,(s32)during.largestFree,(s32)after.freeBytes,(s32)after.largestFree);
}
