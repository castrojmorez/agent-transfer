#include "global.h"
#include "test/test.h"
#include "malloc.h"
#include "warp_rando.h"
#include "warp_reference_graph.h"
#include <limits.h>
#include <string.h>

/* This test is staged with exact copies of the portable production core and
 * generated reference graph. The active table models persistent EWRAM state;
 * the much larger constructor workspace exists only for generation. */
EWRAM_DATA static struct WrActive sGeneratorActive = {0};

struct HeapStats
{
    u32 freeBytes;
    u32 largestFree;
    u16 freeBlocks;
    u16 allocatedBlocks;
};

static struct HeapStats MeasureHeap(void)
{
    struct HeapStats stats = {0};
    const struct MemBlock *head = HeapHead();
    const struct MemBlock *block = head;

    do
    {
        if (block->allocated)
            stats.allocatedBlocks++;
        else
        {
            stats.freeBlocks++;
            stats.freeBytes += block->size;
            if (block->size > stats.largestFree)
                stats.largestFree = block->size;
        }
        block = block->next;
    } while (block != head);
    return stats;
}

static u32 HashByte(u32 hash, u8 byte)
{
    return (hash ^ byte) * 16777619u;
}

static u32 HashActiveRecords(const struct WrActive *active)
{
    u32 hash = 2166136261u;
    u16 i;

    for (i = 0; i < active->count; i++)
    {
        const struct WrRecord *record = &active->records[i];
        hash = HashByte(hash, record->trigger.group);
        hash = HashByte(hash, record->trigger.map);
        hash = HashByte(hash, record->trigger.warp);
        hash = HashByte(hash, record->landing.group);
        hash = HashByte(hash, record->landing.map);
        hash = HashByte(hash, record->landing.warp);
    }
    return hash;
}

static u32 GenerateTimed(const struct WrIdentity *identity, struct WrWork *work,
                         int *result, int *lastRejection)
{
    u16 oldTimer0Low = REG_TM0CNT_L;
    u16 oldTimer0High = REG_TM0CNT_H;
    u16 oldTimer1Low = REG_TM1CNT_L;
    u16 oldTimer1High = REG_TM1CNT_H;
    u32 ticks;

    REG_TM0CNT_H = 0;
    REG_TM1CNT_H = 0;
    REG_TM0CNT_L = 0;
    REG_TM1CNT_L = 0;
    REG_TM1CNT_H = TIMER_ENABLE | TIMER_COUNTUP;
    REG_TM0CNT_H = TIMER_ENABLE | TIMER_64CLK;

    *result = wr_generate(&wr_graph, identity, 1, &sGeneratorActive, work,
                          lastRejection);

    REG_TM0CNT_H = 0;
    REG_TM1CNT_H = 0;
    ticks = REG_TM0CNT_L | ((u32)REG_TM1CNT_L << 16);
    REG_TM0CNT_L = oldTimer0Low;
    REG_TM1CNT_L = oldTimer1Low;
    REG_TM1CNT_H = oldTimer1High;
    REG_TM0CNT_H = oldTimer0High;
    return ticks;
}

TEST("WarpGenerator: full reference generation uses temporary heap and survives release")
{
    struct WrIdentity identity;
    struct WrWork *work;
    struct WrKey requested;
    struct HeapStats before, during, after;
    u32 previousTimeout = gTestRunnerState.timeoutSeconds;
    u32 ticks64, digest;
    int result, lastRejection = WR_OK;

    memset(&sGeneratorActive, 0, sizeof(sGeneratorActive));
    identity.seed = 0;
    identity.algorithm = WR_ALGORITHM;
    identity.ruleset = 1;
    memcpy(identity.data, wr_graph.fingerprint, sizeof(identity.data));

    before = MeasureHeap();
    work = AllocZeroedUnchecked(sizeof(*work));
    EXPECT(work != NULL);
    if (work == NULL)
        return;
    during = MeasureHeap();
    EXPECT((u8 *)work >= gHeap);
    EXPECT((u8 *)work + sizeof(*work) <= gHeap + HEAP_SIZE);
    EXPECT_EQ(((uintptr_t)&sGeneratorActive) >> 24, 2);

    /* Synchronous generation cannot yield to the test runner's progress
     * timeout. The external emulator process still has a hard timeout. */
    gTestRunnerState.timeoutSeconds = UINT_MAX;
    ticks64 = GenerateTimed(&identity, work, &result, &lastRejection);
    gTestRunnerState.timeoutSeconds = previousTimeout;
    Free(work);
    after = MeasureHeap();

    EXPECT_EQ(result, WR_OK);
    EXPECT_EQ(lastRejection, WR_OK);
    EXPECT_EQ(sGeneratorActive.valid, TRUE);
    EXPECT_EQ(sGeneratorActive.attempt, 0);
    EXPECT_EQ(sGeneratorActive.count, 532);
    digest = HashActiveRecords(&sGeneratorActive);
    EXPECT_EQ(digest, 0x36115947u);

    /* The persistent table must remain usable after WrWork is released. */
    requested = sGeneratorActive.records[0].trigger;
    EXPECT_EQ(wr_lookup(&sGeneratorActive, &identity, &requested), 1);
    EXPECT_EQ(before.freeBytes, after.freeBytes);
    EXPECT_EQ(before.largestFree, after.largestFree);
    EXPECT_EQ(before.freeBlocks, after.freeBlocks);
    EXPECT_EQ(before.allocatedBlocks, after.allocatedBlocks);
    EXPECT_GE(before.largestFree, sizeof(*work));
    EXPECT_LE(during.freeBytes + sizeof(*work), before.freeBytes);

    /* One timer tick is 64 CPU cycles; a GBA frame is exactly 4,389 ticks. */
    /* The target test logger intentionally supports only signed decimal %d. */
    Test_MgbaPrintf("WRGEN ticks64=%d frames_floor=%d result=%d last=%d records=%d attempt=%d fnv1a32_decimal=%d work=%d active=%d heap_before_free=%d heap_before_largest=%d heap_during_free=%d heap_during_largest=%d heap_after_free=%d heap_after_largest=%d",
                    (s32)ticks64, (s32)(ticks64 / 4389u), result,
                    lastRejection, sGeneratorActive.count,
                    sGeneratorActive.attempt, (s32)digest, sizeof(*work),
                    sizeof(sGeneratorActive), (s32)before.freeBytes,
                    (s32)before.largestFree, (s32)during.freeBytes,
                    (s32)during.largestFree, (s32)after.freeBytes,
                    (s32)after.largestFree);
}
