#include "global.h"
#include "test/test.h"
#include "test_runner.h"
#include "bg.h"
#include "gpu_regs.h"
#include "main.h"
#include "malloc.h"
#include "menu.h"
#include "palette.h"
#include "sound.h"
#include "sprite.h"
#include "task.h"
#include "text.h"
#include "text_window.h"
#include "window.h"
#include "constants/rgb.h"
#include "constants/songs.h"
#include "warp_rando.h"
#include "warp_reference_graph.h"
#include <limits.h>
#include <string.h>

/* C10D is a test-only rendered lifecycle over C10C. No runtime identity. */
#include "warp_rando_core.c"
#include "c9c_candidate_core.inc"
#include "warp_reference_c9c_event_index.h"
#include "c10b_candidate_core.inc"
#include "c10c_scheduler_core.inc"

#define C10D_BUDGET_TICKS 2800
#define C10D_FRAME_TICKS 4389
#define C10D_BAR_WIDTH 200

enum { WIN_STATUS };

static const struct BgTemplate sBgTemplates[] =
{
    {
        .bg = 0,
        .charBaseIndex = 2,
        .mapBaseIndex = 31,
        .screenSize = 0,
        .paletteMode = 0,
        .priority = 0,
        .baseTile = 0,
    },
};

static const struct WindowTemplate sWindowTemplates[] =
{
    [WIN_STATUS] = {
        .bg = 0,
        .tilemapLeft = 1,
        .tilemapTop = 5,
        .width = 28,
        .height = 10,
        .paletteNum = 14,
        .baseBlock = 20,
    },
    DUMMY_WIN_TEMPLATE
};

static const u8 sTextTitle[] = _("BUILDING RANDOMIZED WORLD");
static const u8 sTextAttempt[] = _("ATTEMPT / LIMIT");
static const u8 sTextCancel[] = _("B: CANCEL");
static const u8 sTextComplete[] = _("WORLD READY");
static const u8 sTextCancelled[] = _("GENERATION CANCELLED");
static const u8 sTextFailed[] = _("GENERATION FAILED");

struct HeapStats
{
    u32 freeBytes;
    u32 largestFree;
    u16 freeBlocks;
    u16 allocatedBlocks;
};

struct C10dClock
{
    u16 base;
};

struct C10dScreen
{
    struct C10cJob job;
    struct C10cView pendingView;
    struct C9cStats stats;
    struct C9cWork *work;
    MainCallback savedMain;
    IntrCallback savedVBlank;
    u32 frames;
    u32 callbacks;
    u32 maxCallbackTicks;
    u32 maxMainTicks;
    u32 maxVBlankTicks;
    u32 maxActiveTicks;
    u32 deadlineMisses;
    u32 vblankVisits;
    u32 renderUpdates;
    u32 audioRequests;
    u32 invalidations;
    u32 publishes;
    u32 releases;
    u32 progressRegressions;
    u32 terminalRenders;
    u16 lastProgress;
    u16 renderedProgress;
    u16 vblankEntry;
    u8 lastAttempt;
    u8 windowId;
    u8 taskId;
    u8 done;
    u8 jobDone;
    u8 renderPending;
    u8 initialized;
    int result;
};

struct C10dResult
{
    u32 frames;
    u32 callbacks;
    u32 maxCallbackTicks;
    u32 maxMainTicks;
    u32 maxVBlankTicks;
    u32 maxActiveTicks;
    u32 deadlineMisses;
    u32 vblankVisits;
    u32 renderUpdates;
    u32 audioRequests;
    u32 invalidations;
    u32 publishes;
    u32 releases;
    u32 progressRegressions;
    u32 terminalRenders;
    u32 digest;
    u32 steps;
    u32 partnerTrials;
    u32 heapDuringFree;
    u32 heapAfterJobFree;
    u32 pixelDigest;
    u32 vramDigest;
    u16 finalProgress;
    u8 successfulAttempt;
    int result;
};

EWRAM_DATA static struct WrActive sC10dActive = {0};
EWRAM_DATA static struct C10dScreen sScreen = {0};

static struct HeapStats MeasureHeap(void)
{
    struct HeapStats s = {0};
    const struct MemBlock *head = HeapHead();
    const struct MemBlock *block = head;

    do
    {
        if (block->allocated)
            s.allocatedBlocks++;
        else
        {
            s.freeBlocks++;
            s.freeBytes += block->size;
            if (block->size > s.largestFree)
                s.largestFree = block->size;
        }
        block = block->next;
    } while (block != head);
    return s;
}

static void Timer3Start(void)
{
    REG_TM3CNT_H = 0;
    REG_TM3CNT_L = 0;
    REG_TM3CNT_H = TIMER_ENABLE | TIMER_64CLK;
}

static u16 Timer3Read(void)
{
    return REG_TM3CNT_L;
}

static void Timer3Stop(void)
{
    REG_TM3CNT_H = 0;
    REG_TM3CNT_L = 0;
}

static u32 Elapsed(void *context)
{
    const struct C10dClock *clock = context;
    return (u16)(Timer3Read() - clock->base);
}

static u32 HashByte(u32 hash, u8 byte)
{
    return (hash ^ byte) * 16777619u;
}

static u32 HashActive(void)
{
    u32 hash = 2166136261u;
    u16 i;

    for (i = 0; i < sC10dActive.count; i++)
    {
        const struct WrRecord *record = &sC10dActive.records[i];
        hash = HashByte(hash, record->trigger.group);
        hash = HashByte(hash, record->trigger.map);
        hash = HashByte(hash, record->trigger.warp);
        hash = HashByte(hash, record->landing.group);
        hash = HashByte(hash, record->landing.map);
        hash = HashByte(hash, record->landing.warp);
    }
    return hash;
}

static void Invalidate(void *context)
{
    struct C10dScreen *screen = context;
    wr_invalidate(&sC10dActive);
    screen->invalidations++;
}

static int Publish(void *context, const struct C10bSession *session)
{
    struct C10dScreen *screen = context;
    memcpy(sC10dActive.records, session->work->candidate,
           session->count * sizeof(*session->work->candidate));
    sC10dActive.identity.seed = session->seed;
    sC10dActive.identity.algorithm = 0;
    sC10dActive.identity.ruleset = 1;
    memcpy(sC10dActive.identity.data, wr_graph.fingerprint,
           sizeof(sC10dActive.identity.data));
    sC10dActive.count = session->count;
    sC10dActive.attempt = session->successful_attempt;
    sC10dActive.valid = TRUE;
    screen->publishes++;
    return WR_OK;
}

static void Release(void *context, struct C9cWork *work)
{
    struct C10dScreen *screen = context;
    if (work != NULL)
        Free(work);
    screen->work = NULL;
    screen->releases++;
}

static void VBlankCB_C10d(void)
{
    sScreen.vblankEntry = Timer3Read();
    sScreen.vblankVisits++;
    LoadOam();
    ProcessSpriteCopyRequests();
    TransferPlttBuffer();
}

static void DrawStatus(const struct C10cView *view)
{
    u16 filled = (u32)view->progress * C10D_BAR_WIDTH / C10C_PROGRESS_MAX;
    u16 pulse = (sScreen.frames / 60u) % 25u;

    FillWindowPixelRect(WIN_STATUS, PIXEL_FILL(1), 8, 27, C10D_BAR_WIDTH, 9);
    FillWindowPixelRect(WIN_STATUS, PIXEL_FILL(4), 8, 27, filled, 9);
    if (view->progress < C10C_PROGRESS_MAX && pulse * 8u >= filled)
        FillWindowPixelRect(WIN_STATUS, PIXEL_FILL(3), 8 + pulse * 8u, 27, 6, 9);
    CopyWindowRectToVram(WIN_STATUS, COPYWIN_GFX, 1, 3, 25, 2);
    if (view->attempt != sScreen.lastAttempt)
    {
        u8 i;
        FillWindowPixelRect(WIN_STATUS, PIXEL_FILL(1), 8, 54, C10D_BAR_WIDTH, 10);
        for (i = 0; i < view->retries; i++)
            FillWindowPixelRect(WIN_STATUS,
                                PIXEL_FILL(i + 1 == view->attempt ? 4 : 2),
                                8 + i * 14, 55, 10, 8);
        CopyWindowRectToVram(WIN_STATUS, COPYWIN_GFX, 1, 6, 25, 2);
    }
    sScreen.renderedProgress = view->progress;
    sScreen.lastAttempt = view->attempt;
    sScreen.renderUpdates++;
}

static void DrawTerminal(int result)
{
    const u8 *text = result == WR_OK ? sTextComplete
                   : result == C10B_CANCELLED ? sTextCancelled : sTextFailed;
    FillWindowPixelRect(WIN_STATUS, PIXEL_FILL(1), 8, 66, C10D_BAR_WIDTH, 12);
    AddTextPrinterParameterized(WIN_STATUS, FONT_SMALL, text,
                                8, 66, TEXT_SKIP_DRAW, NULL);
    CopyWindowRectToVram(WIN_STATUS, COPYWIN_GFX, 1, 8, 25, 2);
    sScreen.terminalRenders++;
}

static bool32 InitGraphics(void)
{
    SetVBlankCallback(NULL);
    SetGpuReg(REG_OFFSET_DISPCNT, 0);
    DmaFill16(3, 0, VRAM, VRAM_SIZE);
    DmaFill32(3, 0, OAM, OAM_SIZE);
    DmaFill16(3, 0, PLTT, PLTT_SIZE);
    ResetSpriteData();
    ResetPaletteFade();
    ResetBgsAndClearDma3BusyFlags(0);
    InitBgsFromTemplates(0, sBgTemplates, ARRAY_COUNT(sBgTemplates));
    if (!InitWindows(sWindowTemplates))
        return FALSE;
    DeactivateAllTextPrinters();
    FillBgTilemapBufferRect_Palette0(0, 0, 0, 0,
                                     DISPLAY_TILE_WIDTH, DISPLAY_TILE_HEIGHT);
    LoadUserWindowBorderGfx(0, 1, BG_PLTT_ID(13));
    Menu_LoadStdPalAt(BG_PLTT_ID(14));
    FillWindowPixelBuffer(WIN_STATUS, PIXEL_FILL(1));
    DrawStdFrameWithCustomTileAndPalette(WIN_STATUS, FALSE, 1, 13);
    AddTextPrinterParameterized(WIN_STATUS, FONT_SMALL, sTextTitle,
                                8, 5, TEXT_SKIP_DRAW, NULL);
    AddTextPrinterParameterized(WIN_STATUS, FONT_SMALL, sTextAttempt,
                                8, 42, TEXT_SKIP_DRAW, NULL);
    AddTextPrinterParameterized(WIN_STATUS, FONT_SMALL, sTextCancel,
                                8, 66, TEXT_SKIP_DRAW, NULL);
    PutWindowTilemap(WIN_STATUS);
    CopyWindowToVram(WIN_STATUS, COPYWIN_FULL);
    SetBackdropFromColor(RGB_BLACK);
    SetGpuReg(REG_OFFSET_DISPCNT,
              DISPCNT_MODE_0 | DISPCNT_OBJ_1D_MAP | DISPCNT_BG0_ON);
    SetGpuReg(REG_OFFSET_BLDCNT, 0);
    ShowBg(0);
    SetVBlankCallback(VBlankCB_C10d);
    return TRUE;
}

static void Task_C10dGenerate(u8 taskId)
{
    struct C10dClock clock;
    u32 ticks;

    clock.base = Timer3Read();
    sScreen.result = c10c_pump(&sScreen.job, Elapsed, &clock);
    ticks = (u16)(Timer3Read() - clock.base);
    sScreen.callbacks++;
    if (ticks > sScreen.maxCallbackTicks)
        sScreen.maxCallbackTicks = ticks;
    if (sScreen.result != C10B_PENDING)
    {
        sScreen.jobDone = TRUE;
        DestroyTask(taskId);
    }
}

static void CB2_C10d(void)
{
    struct C10cView view;

    if (!sScreen.jobDone && JOY_NEW(B_BUTTON))
        c10c_request_cancel(&sScreen.job);
    if (sScreen.jobDone)
    {
        DrawTerminal(sScreen.result);
        sScreen.done = TRUE;
    }
    else if (sScreen.renderPending)
    {
        DrawStatus(&sScreen.pendingView);
        sScreen.renderPending = FALSE;
    }
    else
    {
        RunTasks();
        c10c_snapshot(&sScreen.job, &view);
        if (view.progress < sScreen.lastProgress)
            sScreen.progressRegressions++;
        sScreen.lastProgress = view.progress;
        if (view.progress >= sScreen.renderedProgress + 10
         || view.attempt != sScreen.lastAttempt
         || (sScreen.frames % 60) == 0
         || sScreen.frames == 0)
        {
            sScreen.pendingView = view;
            sScreen.renderPending = TRUE;
        }
    }
    if ((sScreen.frames % 180) == 0)
    {
        PlaySE(SE_SELECT);
        sScreen.audioRequests++;
    }
    AnimateSprites();
    BuildOamBuffer();
    RunTextPrinters();
    UpdatePaletteFade();
}

static bool32 StartScreen(u32 seed)
{
    struct C10cHooks hooks;

    memset(&sScreen, 0, sizeof(sScreen));
    sScreen.windowId = WINDOW_NONE;
    sScreen.lastAttempt = 0xFF;
    sScreen.renderPending = TRUE;
    sScreen.savedMain = gMain.callback2;
    sScreen.savedVBlank = gMain.vblankCallback;
    ResetTasks();
    if (!InitGraphics())
        return FALSE;
    sScreen.initialized = TRUE;
    sScreen.work = AllocZeroedUnchecked(sizeof(*sScreen.work));
    if (sScreen.work == NULL)
        return FALSE;
    hooks.invalidate = Invalidate;
    hooks.publish = Publish;
    hooks.release = Release;
    hooks.context = &sScreen;
    sScreen.result = c10c_begin_prevalidated(&sScreen.job, &wr_graph, &c9c_index,
                                              seed, 3, 8, C10D_BUDGET_TICKS,
                                              sScreen.work, &sScreen.stats, &hooks);
    if (sScreen.result != C10B_PENDING)
        return FALSE;
    c10c_snapshot(&sScreen.job, &sScreen.pendingView);
    sScreen.taskId = CreateTask(Task_C10dGenerate, 0);
    if (sScreen.taskId == TASK_NONE)
    {
        c10c_cancel(&sScreen.job);
        return FALSE;
    }
    SetMainCallback2(CB2_C10d);
    return TRUE;
}

static u32 HashWindowPixels(void)
{
    const u8 *pixels = (const u8 *)(uintptr_t)GetWindowAttribute(WIN_STATUS,
                                                                   WINDOW_TILE_DATA);
    u32 hash = 2166136261u;
    u32 i;
    for (i = 0; i < 28 * 10 * 32; i++)
        hash = HashByte(hash, pixels[i]);
    return hash;
}

static u32 HashWindowVram(void)
{
    const volatile u16 *tiles = (const volatile u16 *)(BG_CHAR_ADDR(2) + 20 * 32);
    u32 hash = 2166136261u;
    u32 i;
    for (i = 0; i < 28 * 10 * 16; i++)
    {
        u16 value = tiles[i];
        hash = HashByte(hash, value & 0xFF);
        hash = HashByte(hash, value >> 8);
    }
    return hash;
}

static u32 WaitForVBlankTimed(void)
{
    u32 ticks;
    Timer3Start();
    VBlankIntrWait();
    ticks = (u16)(Timer3Read() - sScreen.vblankEntry);
    Timer3Stop();
    if (ticks > sScreen.maxVBlankTicks)
        sScreen.maxVBlankTicks = ticks;
    return ticks;
}

static void TeardownScreen(void)
{
    Timer3Stop();
    ResetTasks();
    SetVBlankCallback(NULL);
    FreeAllWindowBuffers();
    HideBg(0);
    SetGpuReg(REG_OFFSET_DISPCNT, 0);
    SetMainCallback2(sScreen.savedMain);
    SetVBlankCallback(sScreen.savedVBlank);
    gMain.newKeys = 0;
    gMain.heldKeys = 0;
    sScreen.initialized = FALSE;
}

static bool32 WindowReachedVram(void)
{
    const u16 *pixels = (const u16 *)(uintptr_t)GetWindowAttribute(WIN_STATUS,
                                                                  WINDOW_TILE_DATA);
    const volatile u16 *tiles = (const volatile u16 *)(BG_CHAR_ADDR(2) + 20 * 32);
    u32 i;
    for (i = 0; i < 28 * 10 * 16; i++)
        if (pixels[i] != tiles[i])
            return FALSE;
    return TRUE;
}

static struct C10dResult RunScreen(u32 seed, u32 cancelFrame)
{
    struct C10dResult result = {0};
    struct HeapStats during;
    struct HeapStats afterJob;
    u32 guard = 0;

    if (!StartScreen(seed))
    {
        result.result = WR_BAD_DATA;
        if (sScreen.initialized)
            TeardownScreen();
        return result;
    }
    during = MeasureHeap();
    while (!sScreen.done && guard++ < 12000)
    {
        u32 before;
        u32 mainTicks;
        u32 vblankTicks = WaitForVBlankTimed();

        if (!gTestRunnerHeadless && cancelFrame != 0)
        {
            u16 held = REG_KEYINPUT ^ KEYS_MASK;
            gMain.newKeys = held & ~gMain.heldKeys;
            gMain.heldKeys = held;
        }
        else if (cancelFrame != 0 && sScreen.frames + 1 == cancelFrame)
            gMain.newKeys = B_BUTTON;
        else
            gMain.newKeys = 0;
        before = gMain.vblankCounter1;
        Timer3Start();
        gMain.callback2();
        mainTicks = Timer3Read();
        Timer3Stop();
        if (gMain.vblankCounter1 != before)
            sScreen.deadlineMisses++;
        if (mainTicks > sScreen.maxMainTicks)
            sScreen.maxMainTicks = mainTicks;
        if (mainTicks + vblankTicks > sScreen.maxActiveTicks)
            sScreen.maxActiveTicks = mainTicks + vblankTicks;
        sScreen.frames++;
    }
    gMain.newKeys = 0;
    WaitForVBlankTimed();
    if (!gTestRunnerHeadless)
    {
        u16 holdFrames;
        for (holdFrames = 0; holdFrames < 120; holdFrames++)
            WaitForVBlankTimed();
    }
    afterJob = MeasureHeap();
    result.frames = sScreen.frames;
    result.callbacks = sScreen.callbacks;
    result.maxCallbackTicks = sScreen.maxCallbackTicks;
    result.maxMainTicks = sScreen.maxMainTicks;
    result.maxVBlankTicks = sScreen.maxVBlankTicks;
    result.maxActiveTicks = sScreen.maxActiveTicks;
    result.deadlineMisses = sScreen.deadlineMisses;
    result.vblankVisits = sScreen.vblankVisits;
    result.renderUpdates = sScreen.renderUpdates;
    result.audioRequests = sScreen.audioRequests;
    result.invalidations = sScreen.invalidations;
    result.publishes = sScreen.publishes;
    result.releases = sScreen.releases;
    result.progressRegressions = sScreen.progressRegressions;
    result.terminalRenders = sScreen.terminalRenders;
    result.digest = HashActive();
    result.steps = sScreen.job.generation.steps;
    result.partnerTrials = sScreen.stats.partner_trials;
    result.heapDuringFree = during.freeBytes;
    result.heapAfterJobFree = afterJob.freeBytes;
    result.pixelDigest = HashWindowPixels();
    result.vramDigest = HashWindowVram();
    result.finalProgress = sScreen.job.progress;
    result.successfulAttempt = sScreen.job.generation.successful_attempt;
    result.result = sScreen.result;
    if (!WindowReachedVram())
        result.deadlineMisses++;
    TeardownScreen();
    return result;
}

TEST("WarpC10D: rendered mGBA loading flow preserves budget, input, and publish-last")
{
    struct HeapStats before = MeasureHeap();
    struct HeapStats after;
    struct C10dResult result0;
    struct C10dResult result42;
    struct C10dResult cancelled;
    u32 oldTimeout = gTestRunnerState.timeoutSeconds;
    int approvalResult;

    gTestRunnerState.timeoutSeconds = UINT_MAX;
    approvalResult = c9c_validate_reference(&wr_graph, &c9c_index);
    result0 = RunScreen(0, 0);
    result42 = RunScreen(42, 0);
    cancelled = RunScreen(0, 32);
    after = MeasureHeap();
    gTestRunnerState.timeoutSeconds = oldTimeout;

    EXPECT_EQ(approvalResult, WR_OK);
    EXPECT_EQ(result0.result, WR_OK);
    EXPECT_EQ(result42.result, WR_OK);
    EXPECT_EQ(cancelled.result, C10B_CANCELLED);
    EXPECT_EQ(result0.digest, 0xd2f14b80u);
    EXPECT_EQ(result42.digest, 0x3d354fa7u);
    EXPECT_EQ(result0.steps, 66274);
    EXPECT_EQ(result42.steps, 94230);
    EXPECT_EQ(result0.partnerTrials, 766);
    EXPECT_EQ(result42.partnerTrials, 1525);
    EXPECT_EQ(result0.successfulAttempt, 0);
    EXPECT_EQ(result42.successfulAttempt, 1);
    EXPECT_EQ(result0.finalProgress, C10C_PROGRESS_MAX);
    EXPECT_EQ(result42.finalProgress, C10C_PROGRESS_MAX);
    EXPECT_EQ(result0.progressRegressions, 0);
    EXPECT_EQ(result42.progressRegressions, 0);
    EXPECT_EQ(result0.deadlineMisses, 0);
    EXPECT_EQ(result42.deadlineMisses, 0);
    EXPECT_EQ(cancelled.deadlineMisses, 0);
    EXPECT(result0.maxCallbackTicks <= C10D_BUDGET_TICKS);
    EXPECT(result42.maxCallbackTicks <= C10D_BUDGET_TICKS);
    EXPECT(cancelled.maxCallbackTicks <= C10D_BUDGET_TICKS);
    EXPECT(result0.maxActiveTicks < C10D_FRAME_TICKS);
    EXPECT(result42.maxActiveTicks < C10D_FRAME_TICKS);
    EXPECT(cancelled.maxActiveTicks < C10D_FRAME_TICKS);
    EXPECT(result0.renderUpdates > 2);
    EXPECT(result42.renderUpdates > 2);
    EXPECT(result0.audioRequests > 0);
    EXPECT(result42.audioRequests > 0);
    EXPECT(result0.vblankVisits > result0.frames);
    EXPECT(result42.vblankVisits > result42.frames);
    EXPECT_EQ(result0.terminalRenders, 1);
    EXPECT_EQ(result42.terminalRenders, 1);
    EXPECT_EQ(cancelled.terminalRenders, 1);
    EXPECT_EQ(result0.invalidations, 1);
    EXPECT_EQ(result0.publishes, 1);
    EXPECT_EQ(result0.releases, 1);
    EXPECT_EQ(result42.invalidations, 1);
    EXPECT_EQ(result42.publishes, 1);
    EXPECT_EQ(result42.releases, 1);
    EXPECT_EQ(cancelled.invalidations, 1);
    EXPECT_EQ(cancelled.publishes, 0);
    EXPECT_EQ(cancelled.releases, 1);
    EXPECT_EQ(result0.pixelDigest, result0.vramDigest);
    EXPECT_EQ(result42.pixelDigest, result42.vramDigest);
    EXPECT_EQ(cancelled.pixelDigest, cancelled.vramDigest);
    EXPECT(result0.heapAfterJobFree > result0.heapDuringFree);
    EXPECT(result42.heapAfterJobFree > result42.heapDuringFree);
    EXPECT_EQ(before.freeBytes, after.freeBytes);
    EXPECT_EQ(before.largestFree, after.largestFree);
    EXPECT_EQ(sC10dActive.identity.algorithm, 0);

    Test_MgbaPrintf("WRC10D0 frames0=%d callbacks0=%d callback_max0=%d main_max0=%d vblank_max0=%d active_max0=%d deadline0=%d renders0=%d audio0=%d digest0_decimal=%d steps0=%d", (s32)result0.frames, (s32)result0.callbacks, (s32)result0.maxCallbackTicks, (s32)result0.maxMainTicks, (s32)result0.maxVBlankTicks, (s32)result0.maxActiveTicks, (s32)result0.deadlineMisses, (s32)result0.renderUpdates, (s32)result0.audioRequests, (s32)result0.digest, (s32)result0.steps);
    Test_MgbaPrintf("WRC10D42 frames42=%d callbacks42=%d callback_max42=%d main_max42=%d vblank_max42=%d active_max42=%d deadline42=%d renders42=%d audio42=%d digest42_decimal=%d steps42=%d attempt42=%d", (s32)result42.frames, (s32)result42.callbacks, (s32)result42.maxCallbackTicks, (s32)result42.maxMainTicks, (s32)result42.maxVBlankTicks, (s32)result42.maxActiveTicks, (s32)result42.deadlineMisses, (s32)result42.renderUpdates, (s32)result42.audioRequests, (s32)result42.digest, (s32)result42.steps, result42.successfulAttempt);
    Test_MgbaPrintf("WRC10DCANCEL frames_cancel=%d callbacks_cancel=%d callback_max_cancel=%d active_max_cancel=%d deadline_cancel=%d progress_cancel=%d renders_cancel=%d audio_cancel=%d publishes_cancel=%d releases_cancel=%d result_cancel=%d", (s32)cancelled.frames, (s32)cancelled.callbacks, (s32)cancelled.maxCallbackTicks, (s32)cancelled.maxActiveTicks, (s32)cancelled.deadlineMisses, cancelled.finalProgress, (s32)cancelled.renderUpdates, (s32)cancelled.audioRequests, (s32)cancelled.publishes, (s32)cancelled.releases, cancelled.result);
    Test_MgbaPrintf("WRC10DLIFE invalid0=%d publish0=%d release0=%d regress0=%d terminal0=%d invalid42=%d publish42=%d release42=%d regress42=%d terminal42=%d vblanks0=%d vblanks42=%d", (s32)result0.invalidations, (s32)result0.publishes, (s32)result0.releases, (s32)result0.progressRegressions, (s32)result0.terminalRenders, (s32)result42.invalidations, (s32)result42.publishes, (s32)result42.releases, (s32)result42.progressRegressions, (s32)result42.terminalRenders, (s32)result0.vblankVisits, (s32)result42.vblankVisits);
    Test_MgbaPrintf("WRC10DMEM work=%d session=%d job=%d screen=%d active=%d algorithm=%d heap_before_free=%d heap_during0_free=%d heap_after_job0_free=%d heap_after_free=%d pixel0_decimal=%d pixel42_decimal=%d pixel_cancel_decimal=%d", sizeof(struct C9cWork), sizeof(struct C10bSession), sizeof(struct C10cJob), sizeof(struct C10dScreen), sizeof(sC10dActive), sC10dActive.identity.algorithm, (s32)before.freeBytes, (s32)result0.heapDuringFree, (s32)result0.heapAfterJobFree, (s32)after.freeBytes, (s32)result0.pixelDigest, (s32)result42.pixelDigest, (s32)cancelled.pixelDigest);
}
