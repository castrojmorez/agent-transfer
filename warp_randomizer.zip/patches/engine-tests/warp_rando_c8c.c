#include "global.h"
#include "test/test.h"
#include "malloc.h"
#include "warp_rando.h"
#include "warp_reference_graph.h"
#include <limits.h>
#include <string.h>

/* C8C is a test-only indexed event-driven implementation. It preserves the
 * selected C8B cap-three policy, assigns no identity and leaves production code unchanged. */
#include "warp_rando_core.c"
#include "c8c_candidate_core.inc"
#include "warp_reference_c8c_event_index.h"

EWRAM_DATA static struct WrActive sC8cActive = {0};

struct HeapStats
{
    u32 freeBytes;
    u32 largestFree;
    u16 freeBlocks;
    u16 allocatedBlocks;
};

static struct HeapStats MeasureHeap(void)
{
    struct HeapStats stats = {0};
    const struct MemBlock *head = HeapHead();
    const struct MemBlock *block = head;
    do
    {
        if (block->allocated)
            stats.allocatedBlocks++;
        else
        {
            stats.freeBlocks++;
            stats.freeBytes += block->size;
            if (block->size > stats.largestFree)
                stats.largestFree = block->size;
        }
        block = block->next;
    } while (block != head);
    return stats;
}

static u32 HashByte(u32 hash, u8 byte) { return (hash ^ byte) * 16777619u; }
static u32 HashActiveRecords(const struct WrActive *active)
{
    u32 hash = 2166136261u;
    u16 i;
    for (i = 0; i < active->count; i++)
    {
        const struct WrRecord *r = &active->records[i];
        hash = HashByte(hash, r->trigger.group);hash = HashByte(hash, r->trigger.map);
        hash = HashByte(hash, r->trigger.warp);hash = HashByte(hash, r->landing.group);
        hash = HashByte(hash, r->landing.map);hash = HashByte(hash, r->landing.warp);
    }
    return hash;
}

static int GenerateAndPublish(u32 seed, struct C8cWork *work,
                              struct C8cStats *stats, u16 *attempt,
                              int *lastRejection)
{
    u16 count;int result;
    wr_invalidate(&sC8cActive);
    result = c8c_generate_candidate(&wr_graph, &c8c_index, seed, 3, 8, work,
                                    stats, &count, attempt, lastRejection);
    if (result != WR_OK)
        return result;
    memcpy(sC8cActive.records, work->candidate, count * sizeof(*work->candidate));
    sC8cActive.identity.seed = seed;
    sC8cActive.identity.algorithm = 0; /* Deliberately unassigned. */
    sC8cActive.identity.ruleset = 1;
    memcpy(sC8cActive.identity.data, wr_graph.fingerprint,
           sizeof(sC8cActive.identity.data));
    sC8cActive.count = count;sC8cActive.attempt = *attempt;
    sC8cActive.valid = TRUE;
    return WR_OK;
}

static u32 GenerateTimed(u32 seed, struct C8cWork *work,
                         struct C8cStats *stats, u16 *attempt,
                         int *result, int *lastRejection)
{
    u16 old0l=REG_TM0CNT_L,old0h=REG_TM0CNT_H,old1l=REG_TM1CNT_L,old1h=REG_TM1CNT_H;
    u32 ticks;
    REG_TM0CNT_H=0;REG_TM1CNT_H=0;REG_TM0CNT_L=0;REG_TM1CNT_L=0;
    REG_TM1CNT_H=TIMER_ENABLE|TIMER_COUNTUP;REG_TM0CNT_H=TIMER_ENABLE|TIMER_64CLK;
    *result=GenerateAndPublish(seed,work,stats,attempt,lastRejection);
    REG_TM0CNT_H=0;REG_TM1CNT_H=0;ticks=REG_TM0CNT_L|((u32)REG_TM1CNT_L<<16);
    REG_TM0CNT_L=old0l;REG_TM1CNT_L=old1l;REG_TM1CNT_H=old1h;REG_TM0CNT_H=old0h;
    return ticks;
}

TEST("WarpC8C: indexed reverse state validates and restores heap")
{
    struct C8cWork *work;
    struct C8cStats stats0={0},stats42={0};
    struct HeapStats before,during,after;
    u32 oldTimeout=gTestRunnerState.timeoutSeconds,ticks0,ticks42,digest0,digest42;
    u16 attempt0=0,attempt42=0;int result0,result42,last0=WR_OK,last42=WR_OK;
    before=MeasureHeap();work=AllocZeroedUnchecked(sizeof(*work));EXPECT(work != NULL);
    if (work == NULL) return;
    during=MeasureHeap();EXPECT_EQ(((uintptr_t)&sC8cActive)>>24,2);
    gTestRunnerState.timeoutSeconds=UINT_MAX;
    ticks0=GenerateTimed(0,work,&stats0,&attempt0,&result0,&last0);
    digest0=HashActiveRecords(&sC8cActive);
    ticks42=GenerateTimed(42,work,&stats42,&attempt42,&result42,&last42);
    digest42=HashActiveRecords(&sC8cActive);
    gTestRunnerState.timeoutSeconds=oldTimeout;Free(work);after=MeasureHeap();
    EXPECT_EQ(result0,WR_OK);EXPECT_EQ(last0,WR_OK);EXPECT_EQ(attempt0,0);
    EXPECT_EQ(digest0,0xd2f14b80u);EXPECT_EQ(stats0.attempts,1);
    EXPECT_EQ(stats0.partner_trials,766);
    EXPECT_EQ(result42,WR_OK);EXPECT_EQ(last42,WR_NO_PARTNER);EXPECT_EQ(attempt42,1);
    EXPECT_EQ(digest42,0x3d354fa7u);EXPECT_EQ(stats42.attempts,2);
    EXPECT_EQ(stats42.partner_trials,1525);
    EXPECT_EQ(sC8cActive.valid,TRUE);EXPECT_EQ(sC8cActive.count,532);
    EXPECT_EQ(sC8cActive.identity.algorithm,0);
    EXPECT_EQ(before.freeBytes,after.freeBytes);EXPECT_EQ(before.largestFree,after.largestFree);
    EXPECT_EQ(before.freeBlocks,after.freeBlocks);EXPECT_EQ(before.allocatedBlocks,after.allocatedBlocks);
    EXPECT_GE(before.largestFree,sizeof(*work));
    Test_MgbaPrintf("WRC8C0 ticks0=%d frames0_floor=%d result0=%d last0=%d attempt0=%d digest0_decimal=%d trials0=%d states0=%d rows0=%d",
      (s32)ticks0,(s32)(ticks0/4389u),result0,last0,attempt0,(s32)digest0,
      (s32)stats0.partner_trials,(s32)stats0.state_evaluations,(s32)stats0.row_ors);
    Test_MgbaPrintf("WRC8C42 ticks42=%d frames42_floor=%d result42=%d last42=%d attempt42=%d digest42_decimal=%d trials42=%d states42=%d rows42=%d",
      (s32)ticks42,(s32)(ticks42/4389u),result42,last42,attempt42,(s32)digest42,
      (s32)stats42.partner_trials,(s32)stats42.state_evaluations,(s32)stats42.row_ors);
    Test_MgbaPrintf("WRC8COPS0 forward=%d reverse=%d repair=%d active=%d conditional=%d",
      (s32)stats0.forward_components,(s32)stats0.reverse_components,
      (s32)stats0.repair_components,(s32)stats0.active_visits,
      (s32)stats0.conditional_visits);
    Test_MgbaPrintf("WRC8COPS42 forward=%d reverse=%d repair=%d active=%d conditional=%d",
      (s32)stats42.forward_components,(s32)stats42.reverse_components,
      (s32)stats42.repair_components,(s32)stats42.active_visits,
      (s32)stats42.conditional_visits);
    Test_MgbaPrintf("WRC8CIDX0 reps=%d aliases=%d reverse_calls=%d reverse_updates=%d",
      (s32)stats0.representative_visits,(s32)stats0.pair_alias_visits,
      (s32)stats0.reverse_calls,(s32)stats0.reverse_edge_updates);
    Test_MgbaPrintf("WRC8CIDX42 reps=%d aliases=%d reverse_calls=%d reverse_updates=%d",
      (s32)stats42.representative_visits,(s32)stats42.pair_alias_visits,
      (s32)stats42.reverse_calls,(s32)stats42.reverse_edge_updates);
    Test_MgbaPrintf("WRC8CMEM work=%d active=%d algorithm=%d heap_before_free=%d heap_before_largest=%d heap_during_free=%d heap_during_largest=%d heap_after_free=%d heap_after_largest=%d",
      sizeof(*work),sizeof(sC8cActive),sC8cActive.identity.algorithm,
      (s32)before.freeBytes,(s32)before.largestFree,(s32)during.freeBytes,
      (s32)during.largestFree,(s32)after.freeBytes,(s32)after.largestFree);
}

