#include "global.h"
#include "test/test.h"
#include "malloc.h"
#include "warp_rando.h"
#include "warp_reference_graph.h"
#include <limits.h>
#include <string.h>

/* C9C is test-only. It preserves C9A cap-three policy, assigns no identity
 * and separates cold reference approval from warm generation. */
#include "warp_rando_core.c"
#include "c9c_candidate_core.inc"
#include "warp_reference_c9c_event_index.h"

EWRAM_DATA static struct WrActive sC9cActive = {0};
struct HeapStats {u32 freeBytes,largestFree;u16 freeBlocks,allocatedBlocks;};

static struct HeapStats MeasureHeap(void)
{
    struct HeapStats stats={0};const struct MemBlock *head=HeapHead(),*block=head;
    do {if(block->allocated) stats.allocatedBlocks++;else {stats.freeBlocks++;
        stats.freeBytes+=block->size;if(block->size>stats.largestFree) stats.largestFree=block->size;}
        block=block->next;} while(block!=head);return stats;
}
static u32 HashByte(u32 hash,u8 byte) {return (hash^byte)*16777619u;}
static u32 HashActiveRecords(const struct WrActive *active)
{
    u32 hash=2166136261u;u16 i;for(i=0;i<active->count;i++) {const struct WrRecord *r=&active->records[i];
        hash=HashByte(hash,r->trigger.group);hash=HashByte(hash,r->trigger.map);
        hash=HashByte(hash,r->trigger.warp);hash=HashByte(hash,r->landing.group);
        hash=HashByte(hash,r->landing.map);hash=HashByte(hash,r->landing.warp);}return hash;
}
static int GenerateAndPublish(u32 seed,bool8 warm,struct C9cWork *work,
                              struct C9cStats *stats,u16 *attempt,int *lastRejection)
{
    u16 count;int result;wr_invalidate(&sC9cActive);
    if(warm) result=c9c_generate_prevalidated(&wr_graph,&c9c_index,seed,3,8,work,stats,&count,attempt,lastRejection);
    else result=c9c_generate_candidate(&wr_graph,&c9c_index,seed,3,8,work,stats,&count,attempt,lastRejection);
    if(result!=WR_OK) return result;
    memcpy(sC9cActive.records,work->candidate,count*sizeof(*work->candidate));
    sC9cActive.identity.seed=seed;sC9cActive.identity.algorithm=0;sC9cActive.identity.ruleset=1;
    memcpy(sC9cActive.identity.data,wr_graph.fingerprint,sizeof(sC9cActive.identity.data));
    sC9cActive.count=count;sC9cActive.attempt=*attempt;sC9cActive.valid=TRUE;return WR_OK;
}
static u32 GenerateTimed(u32 seed,bool8 warm,struct C9cWork *work,struct C9cStats *stats,
                         u16 *attempt,int *result,int *lastRejection)
{
    u16 old0l=REG_TM0CNT_L,old0h=REG_TM0CNT_H,old1l=REG_TM1CNT_L,old1h=REG_TM1CNT_H;u32 ticks;
    REG_TM0CNT_H=0;REG_TM1CNT_H=0;REG_TM0CNT_L=0;REG_TM1CNT_L=0;
    REG_TM1CNT_H=TIMER_ENABLE|TIMER_COUNTUP;REG_TM0CNT_H=TIMER_ENABLE|TIMER_64CLK;
    *result=GenerateAndPublish(seed,warm,work,stats,attempt,lastRejection);
    REG_TM0CNT_H=0;REG_TM1CNT_H=0;ticks=REG_TM0CNT_L|((u32)REG_TM1CNT_L<<16);
    REG_TM0CNT_L=old0l;REG_TM1CNT_L=old1l;REG_TM1CNT_H=old1h;REG_TM0CNT_H=old0h;return ticks;
}
static u32 ValidateTimed(int *result)
{
    u16 old0l=REG_TM0CNT_L,old0h=REG_TM0CNT_H,old1l=REG_TM1CNT_L,old1h=REG_TM1CNT_H;u32 ticks;
    REG_TM0CNT_H=0;REG_TM1CNT_H=0;REG_TM0CNT_L=0;REG_TM1CNT_L=0;
    REG_TM1CNT_H=TIMER_ENABLE|TIMER_COUNTUP;REG_TM0CNT_H=TIMER_ENABLE|TIMER_64CLK;
    *result=c9c_validate_reference(&wr_graph,&c9c_index);
    REG_TM0CNT_H=0;REG_TM1CNT_H=0;ticks=REG_TM0CNT_L|((u32)REG_TM1CNT_L<<16);
    REG_TM0CNT_L=old0l;REG_TM1CNT_L=old1l;REG_TM1CNT_H=old1h;REG_TM0CNT_H=old0h;return ticks;
}

TEST("WarpC9C: cold and prevalidated indexed emission restore heap")
{
    struct C9cWork *work;struct C9cStats cold0={0},cold42={0},warm0={0},warm42={0};
    struct HeapStats before,during,after;u32 oldTimeout=gTestRunnerState.timeoutSeconds;
    u32 coldTicks0,coldTicks42,warmTicks0,warmTicks42,coldDigest0,coldDigest42,warmDigest0,warmDigest42,approvalTicks;
    u16 coldAttempt0=0,coldAttempt42=0,warmAttempt0=0,warmAttempt42=0;
    int coldResult0,coldResult42,warmResult0,warmResult42,approvalResult;
    int coldLast0=WR_OK,coldLast42=WR_OK,warmLast0=WR_OK,warmLast42=WR_OK;
    before=MeasureHeap();work=AllocZeroedUnchecked(sizeof(*work));EXPECT(work!=NULL);if(work==NULL)return;
    during=MeasureHeap();EXPECT_EQ(((uintptr_t)&sC9cActive)>>24,2);gTestRunnerState.timeoutSeconds=UINT_MAX;
    coldTicks0=GenerateTimed(0,FALSE,work,&cold0,&coldAttempt0,&coldResult0,&coldLast0);coldDigest0=HashActiveRecords(&sC9cActive);
    coldTicks42=GenerateTimed(42,FALSE,work,&cold42,&coldAttempt42,&coldResult42,&coldLast42);coldDigest42=HashActiveRecords(&sC9cActive);
    approvalTicks=ValidateTimed(&approvalResult);
    warmTicks0=GenerateTimed(0,TRUE,work,&warm0,&warmAttempt0,&warmResult0,&warmLast0);warmDigest0=HashActiveRecords(&sC9cActive);
    warmTicks42=GenerateTimed(42,TRUE,work,&warm42,&warmAttempt42,&warmResult42,&warmLast42);warmDigest42=HashActiveRecords(&sC9cActive);
    gTestRunnerState.timeoutSeconds=oldTimeout;Free(work);after=MeasureHeap();
    EXPECT_EQ(approvalResult,WR_OK);EXPECT_EQ(coldResult0,WR_OK);EXPECT_EQ(coldLast0,WR_OK);EXPECT_EQ(coldAttempt0,0);
    EXPECT_EQ(coldResult42,WR_OK);EXPECT_EQ(coldLast42,WR_NO_PARTNER);EXPECT_EQ(coldAttempt42,1);
    EXPECT_EQ(warmResult0,WR_OK);EXPECT_EQ(warmLast0,WR_OK);EXPECT_EQ(warmAttempt0,0);
    EXPECT_EQ(warmResult42,WR_OK);EXPECT_EQ(warmLast42,WR_NO_PARTNER);EXPECT_EQ(warmAttempt42,1);
    EXPECT_EQ(coldDigest0,0xd2f14b80u);EXPECT_EQ(warmDigest0,coldDigest0);
    EXPECT_EQ(coldDigest42,0x3d354fa7u);EXPECT_EQ(warmDigest42,coldDigest42);
    EXPECT_EQ(warm0.attempts,1);EXPECT_EQ(warm0.partner_trials,766);EXPECT_EQ(warm42.attempts,2);EXPECT_EQ(warm42.partner_trials,1525);
    EXPECT_EQ(sC9cActive.valid,TRUE);EXPECT_EQ(sC9cActive.count,532);EXPECT_EQ(sC9cActive.identity.algorithm,0);
    EXPECT_EQ(before.freeBytes,after.freeBytes);EXPECT_EQ(before.largestFree,after.largestFree);
    EXPECT_EQ(before.freeBlocks,after.freeBlocks);EXPECT_EQ(before.allocatedBlocks,after.allocatedBlocks);EXPECT_GE(before.largestFree,sizeof(*work));
    Test_MgbaPrintf("WRC9C0 cold_ticks0=%d warm_ticks0=%d cold_frames0_floor=%d warm_frames0_floor=%d result0=%d last0=%d attempt0=%d digest0_decimal=%d trials0=%d states0=%d rows0=%d",
      (s32)coldTicks0,(s32)warmTicks0,(s32)(coldTicks0/4389u),(s32)(warmTicks0/4389u),warmResult0,warmLast0,warmAttempt0,(s32)warmDigest0,(s32)warm0.partner_trials,(s32)warm0.state_evaluations,(s32)warm0.row_ors);
    Test_MgbaPrintf("WRC9C42 cold_ticks42=%d warm_ticks42=%d cold_frames42_floor=%d warm_frames42_floor=%d result42=%d last42=%d attempt42=%d digest42_decimal=%d trials42=%d states42=%d rows42=%d",
      (s32)coldTicks42,(s32)warmTicks42,(s32)(coldTicks42/4389u),(s32)(warmTicks42/4389u),warmResult42,warmLast42,warmAttempt42,(s32)warmDigest42,(s32)warm42.partner_trials,(s32)warm42.state_evaluations,(s32)warm42.row_ors);
    Test_MgbaPrintf("WRC9COPS0 forward=%d reverse=%d repair=%d active=%d conditional=%d",(s32)warm0.forward_components,(s32)warm0.reverse_components,(s32)warm0.repair_components,(s32)warm0.active_visits,(s32)warm0.conditional_visits);
    Test_MgbaPrintf("WRC9COPS42 forward=%d reverse=%d repair=%d active=%d conditional=%d",(s32)warm42.forward_components,(s32)warm42.reverse_components,(s32)warm42.repair_components,(s32)warm42.active_visits,(s32)warm42.conditional_visits);
    Test_MgbaPrintf("WRC9CIDX0 rep_bits=%d set_words=%d score_words=%d rep_updates=%d aliases=%d reverse_calls=%d reverse_updates=%d",(s32)warm0.representative_bit_visits,(s32)warm0.set_word_ops,(s32)warm0.score_word_ops,(s32)warm0.component_rep_updates,(s32)warm0.pair_alias_visits,(s32)warm0.reverse_calls,(s32)warm0.reverse_edge_updates);
    Test_MgbaPrintf("WRC9CIDX42 rep_bits=%d set_words=%d score_words=%d rep_updates=%d aliases=%d reverse_calls=%d reverse_updates=%d",(s32)warm42.representative_bit_visits,(s32)warm42.set_word_ops,(s32)warm42.score_word_ops,(s32)warm42.component_rep_updates,(s32)warm42.pair_alias_visits,(s32)warm42.reverse_calls,(s32)warm42.reverse_edge_updates);
    Test_MgbaPrintf("WRC9CPHASE approval_ticks=%d emit_records=%d aliases_elided=%d",(s32)approvalTicks,c9c_index.emit_count,c9c_index.active_count-c9c_index.emit_count);
    Test_MgbaPrintf("WRC9CMEM work=%d active=%d algorithm=%d heap_before_free=%d heap_before_largest=%d heap_during_free=%d heap_during_largest=%d heap_after_free=%d heap_after_largest=%d",sizeof(*work),sizeof(sC9cActive),sC9cActive.identity.algorithm,(s32)before.freeBytes,(s32)before.largestFree,(s32)during.freeBytes,(s32)during.largestFree,(s32)after.freeBytes,(s32)after.largestFree);
}
