#include "global.h"
#include "test/test.h"
#include "malloc.h"
#include "warp_rando.h"
#include "warp_reference_graph.h"
#include <limits.h>
#include <string.h>

/* C9B is a test-only validated-emission implementation. It preserves the
 * selected C9A cap-three policy, assigns no identity and leaves production code unchanged. */
#include "warp_rando_core.c"
#include "c9b_candidate_core.inc"
#include "warp_reference_c9b_event_index.h"

EWRAM_DATA static struct WrActive sC9bActive = {0};

struct HeapStats
{
    u32 freeBytes;
    u32 largestFree;
    u16 freeBlocks;
    u16 allocatedBlocks;
};

static struct HeapStats MeasureHeap(void)
{
    struct HeapStats stats = {0};
    const struct MemBlock *head = HeapHead();
    const struct MemBlock *block = head;
    do
    {
        if (block->allocated)
            stats.allocatedBlocks++;
        else
        {
            stats.freeBlocks++;
            stats.freeBytes += block->size;
            if (block->size > stats.largestFree)
                stats.largestFree = block->size;
        }
        block = block->next;
    } while (block != head);
    return stats;
}

static u32 HashByte(u32 hash, u8 byte) { return (hash ^ byte) * 16777619u; }
static u32 HashActiveRecords(const struct WrActive *active)
{
    u32 hash = 2166136261u;
    u16 i;
    for (i = 0; i < active->count; i++)
    {
        const struct WrRecord *r = &active->records[i];
        hash = HashByte(hash, r->trigger.group);hash = HashByte(hash, r->trigger.map);
        hash = HashByte(hash, r->trigger.warp);hash = HashByte(hash, r->landing.group);
        hash = HashByte(hash, r->landing.map);hash = HashByte(hash, r->landing.warp);
    }
    return hash;
}

static int GenerateAndPublish(u32 seed, struct C9bWork *work,
                              struct C9bStats *stats, u16 *attempt,
                              int *lastRejection)
{
    u16 count;int result;
    wr_invalidate(&sC9bActive);
    result = c9b_generate_candidate(&wr_graph, &c9b_index, seed, 3, 8, work,
                                    stats, &count, attempt, lastRejection);
    if (result != WR_OK)
        return result;
    memcpy(sC9bActive.records, work->candidate, count * sizeof(*work->candidate));
    sC9bActive.identity.seed = seed;
    sC9bActive.identity.algorithm = 0; /* Deliberately unassigned. */
    sC9bActive.identity.ruleset = 1;
    memcpy(sC9bActive.identity.data, wr_graph.fingerprint,
           sizeof(sC9bActive.identity.data));
    sC9bActive.count = count;sC9bActive.attempt = *attempt;
    sC9bActive.valid = TRUE;
    return WR_OK;
}

static u32 GenerateTimed(u32 seed, struct C9bWork *work,
                         struct C9bStats *stats, u16 *attempt,
                         int *result, int *lastRejection)
{
    u16 old0l=REG_TM0CNT_L,old0h=REG_TM0CNT_H,old1l=REG_TM1CNT_L,old1h=REG_TM1CNT_H;
    u32 ticks;
    REG_TM0CNT_H=0;REG_TM1CNT_H=0;REG_TM0CNT_L=0;REG_TM1CNT_L=0;
    REG_TM1CNT_H=TIMER_ENABLE|TIMER_COUNTUP;REG_TM0CNT_H=TIMER_ENABLE|TIMER_64CLK;
    *result=GenerateAndPublish(seed,work,stats,attempt,lastRejection);
    REG_TM0CNT_H=0;REG_TM1CNT_H=0;ticks=REG_TM0CNT_L|((u32)REG_TM1CNT_L<<16);
    REG_TM0CNT_L=old0l;REG_TM1CNT_L=old1l;REG_TM1CNT_H=old1h;REG_TM0CNT_H=old0h;
    return ticks;
}

static u32 GraphCheckTimed(int *result)
{
    u16 old0l=REG_TM0CNT_L,old0h=REG_TM0CNT_H,old1l=REG_TM1CNT_L,old1h=REG_TM1CNT_H;
    u32 ticks;
    REG_TM0CNT_H=0;REG_TM1CNT_H=0;REG_TM0CNT_L=0;REG_TM1CNT_L=0;
    REG_TM1CNT_H=TIMER_ENABLE|TIMER_COUNTUP;REG_TM0CNT_H=TIMER_ENABLE|TIMER_64CLK;
    *result=wr_graph_check(&wr_graph);
    REG_TM0CNT_H=0;REG_TM1CNT_H=0;ticks=REG_TM0CNT_L|((u32)REG_TM1CNT_L<<16);
    REG_TM0CNT_L=old0l;REG_TM1CNT_L=old1l;REG_TM1CNT_H=old1h;REG_TM0CNT_H=old0h;
    return ticks;
}

static u32 EmitTimed(struct C9bWork *work,u16 *count,int *result)
{
    u16 old0l=REG_TM0CNT_L,old0h=REG_TM0CNT_H,old1l=REG_TM1CNT_L,old1h=REG_TM1CNT_H;
    u32 ticks;
    REG_TM0CNT_H=0;REG_TM1CNT_H=0;REG_TM0CNT_L=0;REG_TM1CNT_L=0;
    REG_TM1CNT_H=TIMER_ENABLE|TIMER_COUNTUP;REG_TM0CNT_H=TIMER_ENABLE|TIMER_64CLK;
    *result=c9b_emit_after_check(&wr_graph,work->partner,work->candidate,count);
    REG_TM0CNT_H=0;REG_TM1CNT_H=0;ticks=REG_TM0CNT_L|((u32)REG_TM1CNT_L<<16);
    REG_TM0CNT_L=old0l;REG_TM1CNT_L=old1l;REG_TM1CNT_H=old1h;REG_TM0CNT_H=old0h;
    return ticks;
}

TEST("WarpC9B: indexed reverse state validates and restores heap")
{
    struct C9bWork *work;
    struct C9bStats stats0={0},stats42={0};
    struct HeapStats before,during,after;
    u32 oldTimeout=gTestRunnerState.timeoutSeconds,ticks0,ticks42,digest0,digest42;
    u32 graphCheckTicks,emitTicks;
    u16 attempt0=0,attempt42=0,emitCount=0;
    int result0,result42,last0=WR_OK,last42=WR_OK,graphCheckResult,emitResult;
    before=MeasureHeap();work=AllocZeroedUnchecked(sizeof(*work));EXPECT(work != NULL);
    if (work == NULL) return;
    during=MeasureHeap();EXPECT_EQ(((uintptr_t)&sC9bActive)>>24,2);
    gTestRunnerState.timeoutSeconds=UINT_MAX;
    ticks0=GenerateTimed(0,work,&stats0,&attempt0,&result0,&last0);
    digest0=HashActiveRecords(&sC9bActive);
    ticks42=GenerateTimed(42,work,&stats42,&attempt42,&result42,&last42);
    digest42=HashActiveRecords(&sC9bActive);
    graphCheckTicks=GraphCheckTimed(&graphCheckResult);
    emitTicks=EmitTimed(work,&emitCount,&emitResult);
    gTestRunnerState.timeoutSeconds=oldTimeout;Free(work);after=MeasureHeap();
    EXPECT_EQ(result0,WR_OK);EXPECT_EQ(last0,WR_OK);EXPECT_EQ(attempt0,0);
    EXPECT_EQ(digest0,0xd2f14b80u);EXPECT_EQ(stats0.attempts,1);
    EXPECT_EQ(stats0.partner_trials,766);
    EXPECT_EQ(result42,WR_OK);EXPECT_EQ(last42,WR_NO_PARTNER);EXPECT_EQ(attempt42,1);
    EXPECT_EQ(digest42,0x3d354fa7u);EXPECT_EQ(stats42.attempts,2);
    EXPECT_EQ(stats42.partner_trials,1525);
    EXPECT_EQ(sC9bActive.valid,TRUE);EXPECT_EQ(sC9bActive.count,532);
    EXPECT_EQ(graphCheckResult,WR_OK);EXPECT_EQ(emitResult,WR_OK);EXPECT_EQ(emitCount,532);
    EXPECT_EQ(sC9bActive.identity.algorithm,0);
    EXPECT_EQ(before.freeBytes,after.freeBytes);EXPECT_EQ(before.largestFree,after.largestFree);
    EXPECT_EQ(before.freeBlocks,after.freeBlocks);EXPECT_EQ(before.allocatedBlocks,after.allocatedBlocks);
    EXPECT_GE(before.largestFree,sizeof(*work));
    Test_MgbaPrintf("WRC9B0 ticks0=%d frames0_floor=%d result0=%d last0=%d attempt0=%d digest0_decimal=%d trials0=%d states0=%d rows0=%d",
      (s32)ticks0,(s32)(ticks0/4389u),result0,last0,attempt0,(s32)digest0,
      (s32)stats0.partner_trials,(s32)stats0.state_evaluations,(s32)stats0.row_ors);
    Test_MgbaPrintf("WRC9B42 ticks42=%d frames42_floor=%d result42=%d last42=%d attempt42=%d digest42_decimal=%d trials42=%d states42=%d rows42=%d",
      (s32)ticks42,(s32)(ticks42/4389u),result42,last42,attempt42,(s32)digest42,
      (s32)stats42.partner_trials,(s32)stats42.state_evaluations,(s32)stats42.row_ors);
    Test_MgbaPrintf("WRC9BOPS0 forward=%d reverse=%d repair=%d active=%d conditional=%d",
      (s32)stats0.forward_components,(s32)stats0.reverse_components,
      (s32)stats0.repair_components,(s32)stats0.active_visits,
      (s32)stats0.conditional_visits);
    Test_MgbaPrintf("WRC9BOPS42 forward=%d reverse=%d repair=%d active=%d conditional=%d",
      (s32)stats42.forward_components,(s32)stats42.reverse_components,
      (s32)stats42.repair_components,(s32)stats42.active_visits,
      (s32)stats42.conditional_visits);
    Test_MgbaPrintf("WRC9BIDX0 rep_bits=%d set_words=%d score_words=%d rep_updates=%d aliases=%d reverse_calls=%d reverse_updates=%d",
      (s32)stats0.representative_bit_visits,(s32)stats0.set_word_ops,
      (s32)stats0.score_word_ops,(s32)stats0.component_rep_updates,
      (s32)stats0.pair_alias_visits,(s32)stats0.reverse_calls,(s32)stats0.reverse_edge_updates);
    Test_MgbaPrintf("WRC9BIDX42 rep_bits=%d set_words=%d score_words=%d rep_updates=%d aliases=%d reverse_calls=%d reverse_updates=%d",
      (s32)stats42.representative_bit_visits,(s32)stats42.set_word_ops,
      (s32)stats42.score_word_ops,(s32)stats42.component_rep_updates,
      (s32)stats42.pair_alias_visits,(s32)stats42.reverse_calls,(s32)stats42.reverse_edge_updates);
    Test_MgbaPrintf("WRC9BPHASE graph_check_ticks=%d emit_after_check_ticks=%d",
      (s32)graphCheckTicks,(s32)emitTicks);
    Test_MgbaPrintf("WRC9BMEM work=%d active=%d algorithm=%d heap_before_free=%d heap_before_largest=%d heap_during_free=%d heap_during_largest=%d heap_after_free=%d heap_after_largest=%d",
      sizeof(*work),sizeof(sC9bActive),sC9bActive.identity.algorithm,
      (s32)before.freeBytes,(s32)before.largestFree,(s32)during.freeBytes,
      (s32)during.largestFree,(s32)after.freeBytes,(s32)after.largestFree);
}
