#include "global.h"
#include "test/test.h"
#include "warp_bank.h"
#include "warp_reference_bank.h"
#include <string.h>

/* The active table models the one persistent runtime allocation. The mapping
 * bank itself is const ROM data and Algorithm 4 has no WrWork. */
EWRAM_DATA static struct WrActive sBankActive = {0};

static u32 HashByte(u32 hash, u8 byte)
{
    return (hash ^ byte) * 16777619u;
}

static u32 HashActiveRecords(const struct WrActive *active)
{
    u32 hash = 2166136261u;
    u16 i;

    for (i = 0; i < active->count; i++)
    {
        const struct WrRecord *record = &active->records[i];
        hash = HashByte(hash, record->trigger.group);
        hash = HashByte(hash, record->trigger.map);
        hash = HashByte(hash, record->trigger.warp);
        hash = HashByte(hash, record->landing.group);
        hash = HashByte(hash, record->landing.map);
        hash = HashByte(hash, record->landing.warp);
    }
    return hash;
}

static u32 LoadTimed(const struct WrIdentity *identity, int *result)
{
    u16 oldTimer0Low = REG_TM0CNT_L;
    u16 oldTimer0High = REG_TM0CNT_H;
    u16 oldTimer1Low = REG_TM1CNT_L;
    u16 oldTimer1High = REG_TM1CNT_H;
    u32 ticks;

    REG_TM0CNT_H = 0;
    REG_TM1CNT_H = 0;
    REG_TM0CNT_L = 0;
    REG_TM1CNT_L = 0;
    REG_TM1CNT_H = TIMER_ENABLE | TIMER_COUNTUP;
    REG_TM0CNT_H = TIMER_ENABLE | TIMER_64CLK;
    *result = wr_bank_load(&wr_reference_bank, identity, &sBankActive);
    REG_TM0CNT_H = 0;
    REG_TM1CNT_H = 0;
    ticks = REG_TM0CNT_L | ((u32)REG_TM1CNT_L << 16);
    REG_TM0CNT_L = oldTimer0Low;
    REG_TM1CNT_L = oldTimer1Low;
    REG_TM1CNT_H = oldTimer1High;
    REG_TM0CNT_H = oldTimer0High;
    return ticks;
}

TEST("WarpBank: schema 1 loads and rejects corruption atomically")
{
    struct WrBank bank = wr_reference_bank;
    struct WrIdentity identity;
    struct WrKey requested;
    u32 rowCrc[WR_REFERENCE_BANK_LAYOUTS];
    u32 ticks64, digest, repeatedDigest;
    u16 index;
    int result;

    memset(&sBankActive, 0, sizeof(sBankActive));
    EXPECT_EQ(wr_bank_make_identity(&bank, 0, &identity), WR_OK);
    index = wr_bank_index(identity.seed, bank.layout_count);
    EXPECT_EQ(index, 14);
    ticks64 = LoadTimed(&identity, &result);
    EXPECT_EQ(result, WR_OK);
    EXPECT_EQ(sBankActive.valid, TRUE);
    EXPECT_EQ(sBankActive.count, 532);
    EXPECT_EQ(sBankActive.attempt, 0);
    EXPECT_EQ(sBankActive.identity.algorithm, WR_BANK_ALGORITHM);
    EXPECT_EQ(sBankActive.identity.ruleset, WR_BANK_RULESET);
    EXPECT_EQ(((uintptr_t)&sBankActive) >> 24, 2);
    digest = HashActiveRecords(&sBankActive);
    EXPECT_EQ(digest, 0xafc54651u);

    requested = sBankActive.records[0].trigger;
    EXPECT_EQ(wr_lookup(&sBankActive, &identity, &requested), 1);
    EXPECT(memcmp(&requested, &sBankActive.records[0].landing,
                  sizeof(requested)) == 0);
    EXPECT_EQ(wr_bank_load(&bank, &identity, &sBankActive), WR_OK);
    repeatedDigest = HashActiveRecords(&sBankActive);
    EXPECT_EQ(repeatedDigest, digest);

    memcpy(rowCrc, bank.row_crc32, sizeof(rowCrc));
    rowCrc[index] ^= 1u;
    bank.row_crc32 = rowCrc;
    EXPECT_EQ(wr_bank_load(&bank, &identity, &sBankActive), WR_BANK_BAD_CRC);
    EXPECT_EQ(sBankActive.valid, FALSE);
    EXPECT_EQ(sBankActive.count, 0);

    bank = wr_reference_bank;
    EXPECT_EQ(wr_bank_make_identity(&bank, 0, &identity), WR_OK);
    identity.algorithm++;
    EXPECT_EQ(wr_bank_load(&bank, &identity, &sBankActive), WR_BAD_IDENTITY);
    EXPECT_EQ(sBankActive.valid, FALSE);
    identity.algorithm--;
    identity.ruleset++;
    EXPECT_EQ(wr_bank_load(&bank, &identity, &sBankActive), WR_BAD_IDENTITY);
    EXPECT_EQ(sBankActive.valid, FALSE);
    identity.ruleset--;
    identity.data[0] ^= 1u;
    EXPECT_EQ(wr_bank_load(&bank, &identity, &sBankActive), WR_BAD_IDENTITY);
    EXPECT_EQ(sBankActive.valid, FALSE);
    identity.data[0] ^= 1u;
    bank.layout_count = 3;
    EXPECT_EQ(wr_bank_load(&bank, &identity, &sBankActive), WR_BAD_DATA);
    EXPECT_EQ(sBankActive.valid, FALSE);
    EXPECT_EQ(sBankActive.count, 0);

    /* One timer tick is 64 CPU cycles; a GBA frame is exactly 4,389 ticks. */
    Test_MgbaPrintf("WRBANK ticks64=%d frames_floor=%d result=%d records=%d index=%d fnv1a32_decimal=%d active=%d layouts=%d packed=%d algorithm=%d ruleset=%d crc_error=%d identity_error=%d data_error=%d failure_invalid=%d",
                    (s32)ticks64, (s32)(ticks64 / 4389u), result, 532,
                    index, (s32)digest, sizeof(sBankActive),
                    WR_REFERENCE_BANK_LAYOUTS,
                    3 * WR_REFERENCE_BANK_RECORDS +
                    3 * WR_REFERENCE_BANK_RECORDS * WR_REFERENCE_BANK_LAYOUTS +
                    4 * WR_REFERENCE_BANK_LAYOUTS,
                    WR_BANK_ALGORITHM, WR_BANK_RULESET, WR_BANK_BAD_CRC,
                    WR_BAD_IDENTITY, WR_BAD_DATA,
                    !sBankActive.valid && sBankActive.count == 0);
}
