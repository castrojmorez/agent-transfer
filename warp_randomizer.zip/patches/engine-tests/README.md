# ARM engine proof tests

These tests compile the actual pinned game and run its C test harness in the
bundled headless mGBA. A TESTING-only bridge calls the actual static SetupWarp;
WarpIntoMap, map headers, collision lookup and flash save/load are target code.
There is no copied warp engine or host type stub in this suite.

## Reproduce on Linux amd64

Requirements for the local bootstrap: Python, curl, dpkg-deb, make, native C/C++
compilers, Git, and a glibc >=2.38 host. No root/system installation is used.
Use the target's INSTALL.md/toolchain instructions on other platforms.
Start with a clean isolated checkout at the exact expansion/1.17.0 commit:

```sh
# From the handoff directory. Choose your own external directories.
python3 tools/audit/fetch_sources.py ../sources
git -C ../sources/target worktree add --detach ../../proof-target e8bd1cd7b03fc032ea37e3ecd38b379b5d01a1e7
python3 tools/audit/prepare_target_toolchain.py ../proof-tools

git -C ../proof-target apply "$PWD/patches/expansion-1.17.0-proof.patch"
git -C ../proof-target apply "$PWD/patches/build-without-dev-fd.patch"
git -C ../proof-target apply "$PWD/patches/engine-test-access.patch"
cp patches/engine-tests/warp_rando_proof.c ../proof-target/test/warp_rando_proof.c

python3 tools/audit/build_engine_proof.py ../proof-target ../proof-tools/prefix --mode 0 --log reports/engine-mode0.log
python3 tools/audit/build_engine_proof.py ../proof-target ../proof-tools/prefix --mode 1 --log reports/engine-mode1.log
python3 tools/audit/build_engine_proof.py ../proof-target ../proof-tools/prefix --mode 1 --rom --log reports/rom-mode1.log
# Full reference graph/core, persistent-table plus temporary-workspace probe:
python3 tools/audit/build_engine_proof.py ../proof-target ../proof-tools/prefix --mode 1 --generator-probe --log reports/generator-mode1.log
# Frozen 32-layout bank, persistent table and loader timing/failure probe:
python3 tools/audit/build_engine_proof.py ../proof-target ../proof-tools/prefix --mode 1 --bank-probe --log reports/bank-mode1.log
python3 tools/audit/build_engine_proof.py ../proof-target ../proof-tools/prefix --mode 1 --c7c-probe --log reports/c7c-mode1.log
python3 tools/audit/build_engine_proof.py ../proof-target ../proof-tools/prefix --mode 1 --c8a-probe --log reports/c8a-mode1.log
python3 tools/audit/build_engine_proof.py ../proof-target ../proof-tools/prefix --mode 1 --c8b-probe --log reports/c8b-mode1.log
python3 tools/audit/build_engine_proof.py ../proof-target ../proof-tools/prefix --mode 1 --c8c-probe --log reports/c8c-mode1.log
python3 tools/audit/build_engine_proof.py ../proof-target ../proof-tools/prefix --mode 1 --c9a-probe --log reports/c9a-mode1.log
python3 tools/audit/build_engine_proof.py ../proof-target ../proof-tools/prefix --mode 1 --c9b-probe --log reports/c9b-mode1.log
python3 tools/audit/build_engine_proof.py ../proof-target ../proof-tools/prefix --mode 1 --c9c-probe --log reports/c9c-mode1.log
python3 tools/audit/build_engine_proof.py ../proof-target ../proof-tools/prefix --mode 1 --c10a-probe --log reports/c10a-mode1.log
python3 tools/audit/build_engine_proof.py ../proof-target ../proof-tools/prefix --mode 1 --c10b-probe --log reports/c10b-mode1.log
python3 tools/audit/build_engine_proof.py ../proof-target ../proof-tools/prefix --mode 1 --c10c-probe --log reports/c10c-mode1.log
python3 tools/audit/build_engine_proof.py ../proof-target ../proof-tools/prefix --mode 1 --c10d-probe --log reports/c10d-mode1.log
# Graphical mGBA ROM after a successful headless preflight:
python3 tools/audit/build_c10d_interactive.py ../proof-target ../proof-tools/prefix build/c10d-interactive.gba
```

The first build converts the target's many assets and is much slower than
subsequent proof-mode changes. Do not build both modes concurrently in one
checkout: they share the header, objects and output files. Bootstrap downloads
are checksum-pinned in reports/target-toolchain-packages.json. Binaries and ROMs
are not included in this handoff.

## What is tested

* Both outside doors select the expected interior in each proof mode.
* Both exit aliases of each house return to the intended outside door.
* The queued House2 correction applies after engine coordinate initialization,
  is consumed once, and does not leak into script/dynamic/escape destinations.
* Center and mart remain ordinary event warps; other source context does not
  redirect merely because it requests the same destination triple.
* House2 tile (3,6) has zero collision and is outside its warp-event positions.
* Actual emulated flash save/load preserves the interior and coordinates; after
  restoring the current map header, the event exit uses the expected mapping.

House1's native exit row is **8**, House2's is **7** in the pinned target.
The initial test wrongly expected House1 row 7; its emulator failure exposed the
assumption and it was corrected from target map.json. No engine code was changed
for that assertion. The proof's corrected House2 coordinate is (3,6).

## Evidence limits

This is headless target execution, not a video of player-controlled movement.
The flash case does not power-cycle the emulator, exercise the full Continue
callback, or execute door animations. Collision and event-position checks do
not by themselves prove every animation path, NPC interaction or movement
transition is safe. Full restart, both walking round trips and physical player
arrival still need observation. No randomized graph is installed by the proof.

## Build portability adjustments

The pinned Makefile uses Bash process substitution in two compile pipelines.
In this workspace /dev/fd is unavailable. build-without-dev-fd.patch appends the
same assembler directives using an ordinary pipe group. It changes build I/O,
not the engine algorithm. engine-test-access.patch is TESTING-only and adds no
release entry point. The bundled Hydra launcher hardcodes /tmp; the build script
instead runs the same mGBA binary/settings sequentially on a regular file in the
checkout, and requires every declared WarpProof test to pass.

With `--generator-probe`, the script stages byte-identical copies of the current
portable header/core and generated full reference graph as target-test inputs.
It also stages `warp_rando_generator.c`, runs all `WarpProof:` and
`WarpGenerator:` cases, and emits one machine-readable `WRGEN` measurement
line. The generator case places only `WrActive` in EWRAM, obtains `WrWork` from
the target allocator, and proves that heap block totals and the deterministic
active mapping are unchanged after `WrWork` is freed. Its 64-cycle timer
excludes allocation/zero-fill and release; one frame is exactly 4,389 ticks.

With `--bank-probe`, the script stages byte-identical copies of the current
portable header, lookup support, Algorithm-4 loader and generated schema-1 bank.
`warp_rando_bank.c` keeps `WrActive` in EWRAM and checks deterministic replay,
lookup, selected-row corruption, identity mismatch, invalid descriptor and
failure invalidation. Its `WRBANK` timer covers CRC plus copying/publication;
Algorithm 4 has no `WrWork`. C6C's checked log, baseline comparison and resource
reports are under `reports/engine-proof/bank-*`.

With `--c7a-probe`, the script stages the unchanged core, full graph and exact
shared cap-4 scheduler in one private test translation unit. `warp_rando_c7b.c`
times seed 0 and second-attempt seed 42, copies validated records with validity
published last, checks host digests and restores the temporary workspace heap.
The test identity is deliberately zero: no Algorithm ID 5 is assigned. Its
`WRC7B`/`WRC7BMEM` evidence and checked resource report are under
`reports/engine-proof/c7b-*`; read `docs/c7b-arm-checkpoint.md`.

With `--c7c-probe`, it additionally stages the generated SCC closure index and
graph-sized C7C workspace. The test measures the same seeds and digests, checks
allocation/restoration and keeps the identity unassigned. Its
`WRC7C0`/`WRC7C42`/`WRC7CMEM` evidence is under
`reports/engine-proof/c7c-*`; read `docs/c7c-scc-checkpoint.md`.

With `--c8a-probe`, the generated index additionally groups component and
capability adjacency so only new reachability is queued. The test measures the
same seeds/digests and compact heap lifetime without assigning an identity. Its
`WRC8A*` evidence is under `reports/engine-proof/c8a-*`; read
`docs/c8a-event-checkpoint.md`.

With `--c8b-probe`, the isolated cap-three policy uses the same event-driven
engine and generated data, then measures its changed layouts and retry
behavior. Its `WRC8B*` evidence is under
`reports/engine-proof/c8b-*`; read
`docs/c8b-trial-volume-checkpoint.md`.

With `--c8c-probe`, representative alias slices replace pair-wide scans and
reverse-warp buckets are maintained incrementally. The test preserves the C8B
cap-three host digests and compact heap lifetime. Its `WRC8C*` evidence is
under `reports/engine-proof/c8c-*`; read
`docs/c8c-indexed-state-checkpoint.md`.

With `--c9a-probe`, compact free/reached/home representative bitsets replace
the remaining broad endpoint scans while preserving C8C's seeded order. The
test checks unchanged host digests and the slightly larger temporary heap
lifetime. Its `WRC9A*` evidence is under `reports/engine-proof/c9a-*`; read
`docs/c9a-representative-bitset-checkpoint.md`.

With `--c9b-probe`, the successful emitter reuses the entry graph validation
instead of repeating it. The harness also times one standalone graph check and
post-check emission to ground the phase profile. Its `WRC9B*` evidence is under
`reports/engine-proof/c9b-*`; read
`docs/c9b-validated-emission-checkpoint.md`.

With `--c9c-probe`, generated unique-trigger records replace runtime alias
de-duplication/sorting. The harness measures cold validated and warm
prevalidated paths separately, including an isolated immutable-reference
approval, and checks unchanged digests/counters plus heap restoration. Its
`WRC9C*` evidence is under `reports/engine-proof/c9c-*`; read
`docs/c9c-cold-warm-checkpoint.md`.

With `--c10a-probe`, the cooperative wrapper runs the exact C9C policy one
phase at a time, checks cancellation and measures total one-quantum-loop time
plus the maximum isolated cost of every phase. Its `WRC10A*` evidence is under
`reports/engine-proof/c10a-*`; read `docs/c10a-cooperative-checkpoint.md`.

With `--c10b-probe`, trial propagation, repair and final validation run as
internally resumable microphases. The harness checks exact seed digests,
cancellation, heap restoration, total time, and the maximum isolated ARM cost
of all six logical groups. Its `WRC10B*` evidence is under
`reports/engine-proof/c10b-*`; read `docs/c10b-frame-bounded-checkpoint.md`.

With `--c10c-probe`, an actual engine task pumps C10B under a 3,200-tick
admission budget while a second deterministic task supplies competing per-frame
CPU load. The harness checks exact seed digests, monotonic progress,
cancellation on the next frame, success-only publication, heap restoration,
maximum callback time and maximum whole task-frame time. Its `WRC10C*` evidence
is under `reports/engine-proof/c10c-*`; read
`docs/c10c-budgeted-task-checkpoint.md`.

With `--c10d-probe`, the exact task runs behind a real target window and main
callback with separate render frames, progress/activity and attempt indicators,
terminal text, sound requests, normal VBlank transfers and `JOY_NEW` B
cancellation. Timer 3 leaves the sound timers intact. The dual-mode harness
checks VRAM equality, exact digests, publication/cleanup, allocation staging and
missed deadlines. Its `WRC10D*` evidence is under
`reports/engine-proof/c10d-*`; read
`docs/c10d-rendered-mgba-checkpoint.md`.

`build_c10d_interactive.py` emits an unpatched graphical test ROM after running
the headless preflight. In that ROM, the cancellation run reads `REG_KEYINPUT`
instead of injecting B. Follow `docs/c10d-mgba-manual-test.md`. ROM binaries are
not distributed in this handoff.
