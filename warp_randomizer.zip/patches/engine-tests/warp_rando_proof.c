#include "global.h"
#include "test/test.h"
#include "overworld.h"
#include "fieldmap.h"
#include "metatile_behavior.h"
#include "warp_rando_proof.h"
#include "load_save.h"
#include "save.h"

/* Test-only bridge invokes the exact static engine SetupWarp; no copied hook. */
void WrProof_TestSetupWarp(s8 warpId, struct MapPosition *position);

static void Enter(s8 group, s8 map)
{
    SetWarpDestinationToMapWarp(group, map, 0);
    WarpIntoMap();
}

static void TakeDoor(s8 event)
{
    const struct WarpEvent *warp = &gMapHeader.events->warps[event];
    struct MapPosition position = { .x = warp->x + MAP_OFFSET,
        .y = warp->y + MAP_OFFSET, .elevation = warp->elevation };
    WrProof_TestSetupWarp(event, &position);
    WarpIntoMap();
}

TEST("WarpProof: Oldale House1 door lands in selected interior after coordinate setup")
{
    Enter(0, 10);
    TakeDoor(0);
    EXPECT_EQ(gSaveBlock1Ptr->location.mapGroup, 2);
    EXPECT_EQ(gSaveBlock1Ptr->location.mapNum, WR_PROOF_ENABLED ? 1 : 0);
    EXPECT_EQ(gSaveBlock1Ptr->location.warpId, 0);
    EXPECT_EQ(gSaveBlock1Ptr->pos.x, 3);
    EXPECT_EQ(gSaveBlock1Ptr->pos.y, WR_PROOF_ENABLED ? 6 : 8);
}

TEST("WarpProof: Oldale House2 door lands in selected interior")
{
    Enter(0, 10);
    TakeDoor(1);
    EXPECT_EQ(gSaveBlock1Ptr->location.mapGroup, 2);
    EXPECT_EQ(gSaveBlock1Ptr->location.mapNum, WR_PROOF_ENABLED ? 0 : 1);
    EXPECT_EQ(gSaveBlock1Ptr->pos.x, 3);
    EXPECT_EQ(gSaveBlock1Ptr->pos.y, WR_PROOF_ENABLED ? 8 : 7);
}

TEST("WarpProof: both House2 exit aliases return outside selected house")
{
    for (s8 event = 0; event < 2; event++)
    {
        Enter(2, 1);
        TakeDoor(event);
        EXPECT_EQ(gSaveBlock1Ptr->location.mapGroup, 0);
        EXPECT_EQ(gSaveBlock1Ptr->location.mapNum, 10);
        EXPECT_EQ(gSaveBlock1Ptr->location.warpId, WR_PROOF_ENABLED ? 0 : 1);
        EXPECT_EQ(gSaveBlock1Ptr->pos.x, gMapHeader.events->warps[WR_PROOF_ENABLED ? 0 : 1].x);
        EXPECT_EQ(gSaveBlock1Ptr->pos.y, gMapHeader.events->warps[WR_PROOF_ENABLED ? 0 : 1].y);
    }
}

TEST("WarpProof: both House1 exit aliases return outside selected house")
{
    for (s8 event = 0; event < 2; event++)
    {
        Enter(2, 0);
        TakeDoor(event);
        EXPECT_EQ(gSaveBlock1Ptr->location.mapGroup, 0);
        EXPECT_EQ(gSaveBlock1Ptr->location.mapNum, 10);
        EXPECT_EQ(gSaveBlock1Ptr->location.warpId, WR_PROOF_ENABLED ? 1 : 0);
    }
}

TEST("WarpProof: center and mart remain ordinary engine warps")
{
    for (s8 event = 2; event < 4; event++)
    {
        s8 group, map, warp;
        Enter(0, 10);
        group = gMapHeader.events->warps[event].mapGroup;
        map = gMapHeader.events->warps[event].mapNum;
        warp = gMapHeader.events->warps[event].warpId;
        TakeDoor(event);
        EXPECT_EQ(gSaveBlock1Ptr->location.mapGroup, group);
        EXPECT_EQ(gSaveBlock1Ptr->location.mapNum, map);
        EXPECT_EQ(gSaveBlock1Ptr->location.warpId, warp);
    }
}

TEST("WarpProof: correction consumed once and script warp clears queued correction")
{
    s16 x = 99, y = 99;
    Enter(0, 10);
    TakeDoor(0);
    WrProof_Apply(2, 1, 0, &x, &y);
    EXPECT_EQ(x, 99);
    EXPECT_EQ(y, 99);
    WrProof_QueueArrival(2, 1, 0);
    SetWarpDestinationToMapWarp(2, 1, 0);
    WarpIntoMap();
    EXPECT_EQ(gSaveBlock1Ptr->pos.y, 7);
}

TEST("WarpProof: dynamic and escape setters clear stale correction")
{
    Enter(2, 1);
    gSaveBlock1Ptr->dynamicWarp = gSaveBlock1Ptr->location;
    gSaveBlock1Ptr->escapeWarp = gSaveBlock1Ptr->location;
    WrProof_QueueArrival(2, 1, 0);
    SetWarpDestinationToDynamicWarp(0);
    WarpIntoMap();
    EXPECT_EQ(gSaveBlock1Ptr->pos.y, 7);
    WrProof_QueueArrival(2, 1, 0);
    SetWarpDestinationToEscapeWarp();
    WarpIntoMap();
    EXPECT_EQ(gSaveBlock1Ptr->pos.y, 7);
}

TEST("WarpProof: other source context does not redirect matching destination")
{
    s8 group = 2, map = 0, warp = 0;
    EXPECT_EQ(WrProof_Resolve(0, 0, 0, &group, &map, &warp), FALSE);
    EXPECT_EQ(group, 2);
    EXPECT_EQ(map, 0);
    EXPECT_EQ(warp, 0);
}

TEST("WarpProof: House2 corrected arrival is passable and outside warp events")
{
    Enter(2, 1);
    InitMap();
    EXPECT_EQ(MapGridGetCollisionAt(3 + MAP_OFFSET, 6 + MAP_OFFSET), 0);
    for (u8 event = 0; event < gMapHeader.events->warpCount; event++)
        EXPECT(gMapHeader.events->warps[event].x != 3 || gMapHeader.events->warps[event].y != 6);
}

TEST("WarpProof: flash save load preserves interior coordinates and exit mapping")
{
    s8 expectedMap = WR_PROOF_ENABLED ? 1 : 0;
    s16 expectedY = WR_PROOF_ENABLED ? 6 : 8;
    EXPECT_EQ(gFlashMemoryPresent, TRUE);
    Enter(0, 10);
    TakeDoor(0);
    Save_ResetSaveCounters();
    EXPECT_EQ(TrySavingData(SAVE_NORMAL), SAVE_STATUS_OK);
    // Destroy the live location before reading actual emulated flash sectors.
    Enter(0, 10);
    EXPECT_EQ(LoadGameSave(SAVE_NORMAL), SAVE_STATUS_OK);
    EXPECT_EQ(gSaveBlock1Ptr->location.mapGroup, 2);
    EXPECT_EQ(gSaveBlock1Ptr->location.mapNum, expectedMap);
    EXPECT_EQ(gSaveBlock1Ptr->pos.x, 3);
    EXPECT_EQ(gSaveBlock1Ptr->pos.y, expectedY);
    // Restore the current header for an event exit. This is a flash round trip,
    // not a power cycle or execution of the full Continue callback/animations.
    gMapHeader = *Overworld_GetMapHeaderByGroupAndId(2, expectedMap);
    TakeDoor(0);
    EXPECT_EQ(gSaveBlock1Ptr->location.mapGroup, 0);
    EXPECT_EQ(gSaveBlock1Ptr->location.mapNum, 10);
    EXPECT_EQ(gSaveBlock1Ptr->location.warpId, 0);
}
