# GLM Warp Randomizer — revised engineering handoff

**ARM-tested Algorithm-4 bank loader plus a C9C-exact C10D rendered mGBA
loading-flow prototype; measured frames remain below one frame, but graphical
human review and production new-game/save integration remain open; not a
playable or verified full-game randomizer.** Target remains RHH expansion/1.17.0 at
`e8bd1cd7b03fc032ea37e3ecd38b379b5d01a1e7`. Read HANDOFF.md first; STATUS.md separates evidence from open integration work.

Follow-up failure diagnosis: see `docs/failure-diagnosis.md`. The disputed
Weather/Flash edge choices do not explain the recorded batch failures; missing
constructive return protection and premature frontier consumption do.

This revision replaces unsafe data handling and remap generation, adds an
independent validator and reproducible audit, and removes unsupported completion
claims. The player-facing goal remains seed generation in-game. Python is used
only at development/build time; the delivered C core generates seed mappings.

## Reproduce offline host checks

Requirements: Python 3.10+, GNU make, a C99 compiler (`cc`; tested GCC 13.3.0).
No pip/npm/json11 downloads are needed. From this directory:

```sh
make test
make sanitize
make data
make seeds
make bank
make c7a
make c7c
make c8a
make c8b
make c8c
make c9a
make c9b
make c9c
make c10a
make c10b
make c10c
```

The first command runs the regression suite, fixed proof adapter tests and the
Algorithm-4 bank loader tests;
sanitize adds ASan/UBSan (LeakSanitizer disabled as explained in tests/README.md).
The data command deterministically recompiles the bundled pinned annotations.
The seeds command reports an eight-seed, eight-attempt batch. Algorithm 3
accepted all eight; the wider recorded sample accepted all 68 seeds on their
first attempt, with fresh Python validation and metadata replay. These are
reference-model results, not verified playable layouts. The algorithm-2 failure
reports and an isolated rollback reproduction remain available.

Reproduce the broader sample:

```sh
python3 tools/audit/seed_batch.py --output reports/seed-sweep.json --seeds {0..63} 255 256 65535 4294967295
python3 tools/audit/reproduce_algorithm2.py
```

The seed range above uses Bash brace expansion. No success is counted from a
vanilla fallback. Unknown requirements are unavailable to the solver by default;
WEATHER_INSTITUTE and HOENN_FLASH_1 both remain ungrantable. See
`docs/constructor-checkpoint.md` for the code and policy decisions.

## Reproduce upstream audit and patch check

Network and Git are needed only for the four exact public source checkouts:

```sh
python3 tools/audit/fetch_sources.py ../sources
python3 tools/audit/drift.py data/reference/Warps.json ../sources/target ../sources/speedchoice reports
python3 tools/audit/make_proof_patch.py ../sources/target build/proof.patch
cmp patches/expansion-1.17.0-proof.patch build/proof.patch
git -C ../sources/target apply --check "$PWD/patches/expansion-1.17.0-proof.patch"
```

These compare real map_groups ordering, map identity, warp index, destinations,
source coordinates and elevation. The CSV contains every reference/target key,
including open target-only decisions. They do not validate walkable collision
tiles or story progression. Apply/build instructions and observed-test checklist
are in patches/README.md. C4 built both normal proof ROM modes and passed ten
ARM engine tests per mode in headless mGBA; interactive movement and full
restart/Continue remain open. See patches/engine-tests/README.md for the local
ARM bootstrap and executable tests, and docs/engine-proof-checkpoint.md for
results and the measured RAM integration constraint. C5 additionally ran the
full Algorithm-3 reference constructor on ARM: its temporary-heap lifetime
passed, but seed 0 took about 41 target minutes. See
docs/generator-lifetime-checkpoint.md; the current constructor must not be
called synchronously in the game.

C6B froze a 32-layout schema-1 bank and assigned Algorithm ID 4. Its host
loader checks the selected row CRC, copies 532 packed mappings without
`WrWork`, and publishes the active table last. All 32 rows and all negative
paths pass normally and under ASan/UBSan. `make bank` regenerates and
independently validates the bank (about 70 seconds on the recorded host).

C6C ran that exact bank and loader on ARM in the pinned target test ROM. The
combined suite passed 11/11; CRC plus copying/publishing 532 records took
45.612 ms (2.724 frames). The actual test-link delta was 61,893 ROM-section
bytes including harness overhead and exactly 16,436 EWRAM bytes, with no
`WrWork`. Bank-aware save restoration and player-facing integration remain
open. See docs/bank-arm-checkpoint.md.

C7A isolated a bounded on-demand policy without changing production: sample and
score at most four partners per source, with at most eight whole attempts. It
accepted and independently validated all 68 recorded seeds (66 first attempt,
two second), replayed deterministically, and cut comparable host time from
105.115 to 4.615 seconds. Candidate-specific synthetic tests pass normally and
under ASan/UBSan. It still uses Algorithm 3's 47,388-byte target workspace. C7A
assigned no Algorithm ID 5; the subsequent ARM decision follows. See
docs/c7a-feasibility.md.

C7B ran that exact scheduler on ARM. Seed 0 took 67.136 seconds and retrying
seed 42 took 131.465 seconds; all 11 combined tests passed and both mappings
matched host digests. The seed-0 result is 36.636x faster than Algorithm 3, but
still fails the blocking-runtime gate. The heap lifetime restored exactly;
the test used the same 47,388-byte workspace and 16,436-byte persistent table.
Algorithm ID 5 remains unassigned. See docs/c7b-arm-checkpoint.md.

C7C replaces full-node closure buffers with a generated 400-component SCC
index and compact bitsets. All 68 outputs exactly match C7A and independently
validate; synthetic checks pass normally and under ASan/UBSan. Target workspace
falls from 47,388 to 10,944 bytes and the controlled heap restores exactly.
The ARM suite passes 11/11, but seed 0 still takes 38.032 seconds and seed 42
takes 75.148 seconds. C7 therefore closes with memory feasibility established
and synchronous Algorithm 5 rejected. See docs/c7c-scc-checkpoint.md.

C8A queues only reachability deltas introduced by a temporary pair and groups
conditional edges by component/capability. It remains byte-identical to C7A for
all 68 seeds and sanitizer-clean. ARM time improves to 23.931 seconds for seed 0
and 45.469 seconds for seed 42; workspace is 13,776 bytes and restores exactly.
This still fails the synchronous gate. Algorithm ID 5 remains unassigned, and
C8B was tasked with reducing or reusing the 1,020–2,039 scored trial states. See
docs/c8a-event-checkpoint.md.

C8B varies that candidate's scored-partner cap. Caps one and two fail the
standard corpus; cap three succeeds 68/68 standard and 1,024/1,024 stress
seeds, with deterministic replay and independent validation. On ARM it takes
21.813 seconds for seed 0 and 36.021 seconds for retrying seed 42: only 1.097x
and 1.262x faster than C8A. Trial-cap tuning is therefore exhausted as a route
to synchronous real-time generation. Algorithm ID 5 remained unassigned, and
that result led to C8C's indexed-state experiment. See
docs/c8b-trial-volume-checkpoint.md.

C8C preserves C8B cap three exactly while replacing repeated all-alias scans
with representative slices and maintaining reverse-warp buckets incrementally.
It matches C8B across all 68 standard and 1,024 stress seeds. ARM time falls to
10.900 seconds for seed 0 and 16.085 seconds for retrying seed 42, 2.001x and
2.239x faster than C8B with the same 13,776-byte workspace. This is a material
architecture win, but still too slow synchronously. C8 closes without assigning
Algorithm ID 5; C9A should test indexed frontier/free-set maintenance against
the remaining endpoint scans. See docs/c8c-indexed-state-checkpoint.md.

C9A preserves C8C exactly while replacing broad canonical-endpoint scans with
compact free/reached/home representative bitsets and popcount scoring. It
matches C8C across all 68 standard and 1,024 stress seeds. ARM time falls to
7.609 seconds for seed 0 and 9.357 seconds for retrying seed 42, 1.433x and
1.719x faster than C8C. The target workspace rises by 448 bytes to 14,224 and
the heap restores exactly. This is another material gain but remains 3.8x–4.7x
above the provisional two-second budget. Algorithm ID 5 remains unassigned;
C9B should profile and reduce repeated trial-state propagation rather than tune
scan constants. See docs/c9a-representative-bitset-checkpoint.md.

C9B's profile found that generation validated the immutable graph once at entry
and again inside successful emission. It retains the fail-closed entry check and
uses an otherwise identical post-check emitter. All 68 standard and 1,024
stress outputs and counters exactly match C9A. ARM time falls to 5.982 seconds
for seed 0 and 7.730 seconds for seed 42, 1.272x and 1.210x faster than C9A.
The separately measured remaining graph check costs 1.608 seconds and emission
0.533 seconds; even subtracting both leaves 3.841–5.590 seconds of constructor
and validation work. Algorithm ID 5 remains unassigned. C9C is the final
bounded reference-specialization gate before reassessing this scheduler. See
docs/c9b-validated-emission-checkpoint.md.

C9C compiles 608 active aliases into 532 already sorted unique-trigger records
and separates full cold validation from a warm path that reuses approval of the
immutable embedded reference. It exactly matches C9A/C9B over 68 standard and
1,024 stress seeds. On ARM, cold generation takes 5.439 and 7.159 seconds for
seeds 0 and 42; warm generation takes 3.807 and 5.527 seconds. The one-time
approval costs 1.632 seconds. All 11 combined tests pass, the 14,224-byte heap
workspace restores exactly and Algorithm ID 5 remains unassigned. Because the
warm constructor still exceeds two seconds, further micro-optimization of this
scheduler is closed; the next on-demand prototype should be frame-sliced and
asynchronous (or use a different constructor). See
docs/c9c-cold-warm-checkpoint.md.

C10A moves C9C's loop locals into a 136-byte target session and exposes
resumable attempt-init, selection, single-trial, commit, emission and validation
phases. All 68 standard and 1,024 stress seeds exactly match C9C regardless of
advance batching; cancellation exposes zero records and the same workspace can
restart exactly. The ARM suite passes 11/11. Cooperative total time is 3.992
seconds for seed 0 and 5.871 seconds for seed 42, only 4.9–6.2% over C9C. Most
phases fit one frame, but the worst trial is 1.604 frames and final validation
is 3.382 frames. C10B must split those propagation paths before callback/UI
integration. Algorithm ID 5 remains unassigned. See
docs/c10a-cooperative-checkpoint.md.

C10B internally resumes C10A's partner-trial propagation, repair, and final
validation. All 68 standard and 1,024 stress seeds remain exactly C9C-equivalent
under alternate advancement schedules. The ARM suite passes 11/11. Its worst
isolated step is 2,383 ticks (0.543 frame), down from C10A's 14,842-tick
validation atom; trial and validation microsteps peak at 399 and 533 ticks.
Total work rises to 5.894 seconds for seed 0 and 8.459 seconds for seed 42, so
C10C should use a timer-budgeted callback that groups cheap microsteps while
remaining responsive. The target session is 156 bytes beside the unchanged
14,224-byte workspace. Algorithm ID 5 remains unassigned. See
docs/c10b-frame-bounded-checkpoint.md.

C10C wraps that state machine in a 3,200-tick engine-task budget with monotonic
progress, deferred cancellation, invalidation before start, success-only
publication and exactly-once cleanup. All 68 standard and 1,024 stress seeds
remain exactly C9C-equivalent under alternate callback schedules. The ARM suite
passes 11/11. Under a second 2,048-iteration task, the worst generator callback
is 2,962 ticks and worst whole task frame 3,869/4,389 ticks (0.882 frame).
Seed 0/42 complete in 685/1,102 scheduled frames (about 11.4/18.4 seconds at
60 Hz); cancellation requested after frame 32 finishes on frame 33 without
publication and with exact heap release. C10D should prove the same flow in a
real rendered/input loading screen and establish the production allocation
point. Algorithm ID 5 remains unassigned. See
docs/c10c-budgeted-task-checkpoint.md.

C10D replaces the synthetic load with an actual engine window/main-callback
flow. It renders progress plus an activity pulse, shows an eight-slot attempt
limit, requests sound effects, runs normal sprite/text/palette and VBlank DMA
work, and consumes B through `JOY_NEW`. Generation and UI refreshes use
separate frames after the first naive full-window version exceeded one frame.
With a 2,800-tick generator allowance, both proof modes pass 11/11 under the
bundled mGBA. Seed 0/42 take 883/1,264 screen frames (about 14.7/21.1 seconds);
the worst generator callback is 2,366 ticks and worst measured main-plus-VBlank
frame 4,079/4,389 ticks, leaving 310 ticks. Exact C9C digests, publish-last,
cancellation and heap restoration all hold. A graphical mGBA/physical-input
check and production new-game hook remain open; Algorithm ID 5 is unassigned.
See `docs/c10d-rendered-mgba-checkpoint.md` and
`docs/c10d-mgba-manual-test.md`.

## Files to start with

* HANDOFF.md: recovery instructions, decisions, checkpoint and next action.
* STATUS.md and PROVENANCE.md: evidence and exact inputs.
* docs/runtime-contract.md: destination-key lookup, both-way pairing and aliases.
* docs/ruleset.md: supported abstraction and missing game behavior.
* include/warp_rando.h and src/warp_rando.c: one current portable implementation.
* tools/warprandogen/: strict compiler and reference importer.
* tests/: harness, independent validator and negative fixtures.
* tools/audit/ and reports/: reproducible drift, seed and resource evidence.
* patches/: applicable, disabled-by-default Oldale fixed-table experiment.
* docs/generator-lifetime-checkpoint.md: target heap, ABI and timing result.
* docs/precomputed-bank-feasibility.md: bounded C6A fast-start alternative.
* docs/bank-loader-checkpoint.md: frozen C6B bank format, tests and next gate.
* docs/bank-arm-checkpoint.md: C6C ARM timing, target resources and conclusion.
* docs/mimo-optimization-assessment.md: optional on-demand design input and Algorithm-5 direction.
* docs/c10d-rendered-mgba-checkpoint.md: rendered callback, input, allocation and frame evidence.
* docs/c7a-feasibility.md, docs/c7b-arm-checkpoint.md and
  docs/c7c-scc-checkpoint.md: C7 host, ARM and compact-closure evidence.
* docs/c8a-event-checkpoint.md: event-driven delta design, exact equivalence,
  ARM timing/memory and C8B gate.
* docs/c8b-trial-volume-checkpoint.md: cap sweep, 1,024-seed stress evidence,
  ARM timing and C8C architectural gate.
* docs/c8c-indexed-state-checkpoint.md: indexed alias/reverse-state design,
  exact equivalence, ARM timing and C9A gate.
* docs/c9a-representative-bitset-checkpoint.md: compact endpoint-set design,
  exact equivalence, ARM timing and C9B profiling gate.
* docs/c9b-validated-emission-checkpoint.md: duplicate validation diagnosis,
  exact equivalence, ARM timing and C9C specialization gate.
* docs/c9c-cold-warm-checkpoint.md: immutable approval, indexed emission,
  cold/warm ARM timing and the asynchronous-next decision.
* docs/c10a-cooperative-checkpoint.md: resumable state-machine contract, exact
  schedule/cancellation evidence and ARM maximum-phase timing.
* docs/c10b-frame-bounded-checkpoint.md: internally resumable propagation,
  one-frame ARM ceiling, total-work tradeoff and C10C callback gate.
* docs/c10c-budgeted-task-checkpoint.md: timer-budgeted engine task, progress,
  cancellation, publish/cleanup lifecycle and loaded-frame ARM evidence.
* docs/revision-notes.md and docs/next-steps.md: defect dispositions and next work.

No ROM, dependency cache or obsolete implementation is bundled. The original
archive is identified by hash; its findings and useful architecture have been
reconciled into this package rather than left in contradictory paste guides.
