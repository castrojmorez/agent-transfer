/* Single-generation host timing control for C7A. Production Algorithm 3 is
 * included unchanged; this omits save replay and subprocess-side validation so
 * wall time is comparable with c7a_candidate.c. */
#include "../../src/warp_rando.c"
#include "graph.h"
#include <stdio.h>
#include <stdlib.h>

int main(int argc,char **argv)
{
    static struct WrWork work;
    uint32_t seed=argc>1?(uint32_t)strtoul(argv[1],0,0):0;
    uint16_t retries=argc>2?(uint16_t)strtoul(argv[2],0,0):8;
    uint16_t attempt,count=0,i;int r=WR_BAD_DATA,last=WR_OK;
    if(wr_graph_check(&wr_graph)) r=WR_BAD_DATA;
    else for(attempt=0;attempt<retries;attempt++) {
        r=construct(&wr_graph,seed+0x9e3779b9u*attempt,&work);
        if(!r) r=wr_emit(&wr_graph,work.partner,work.candidate,&count);
        if(!r) r=wr_validate(&wr_graph,work.candidate,count,&work);
        if(!r) break;
        last=r;count=0;
    }
    if(r) r=WR_RETRIES;
    printf("{\"result\":%d,\"last_rejection\":%d,\"attempt\":%u,\"records\":[",
           r,last,r?0:attempt);
    if(!r) for(i=0;i<count;i++) {
        const struct WrRecord *v=&work.candidate[i];
        printf("%s[%u,%u,%u,%u,%u,%u]",i?",":"",v->trigger.group,
               v->trigger.map,v->trigger.warp,v->landing.group,
               v->landing.map,v->landing.warp);
    }
    printf("],\"work_bytes\":%zu}\n",sizeof(work));
    return 0;
}
