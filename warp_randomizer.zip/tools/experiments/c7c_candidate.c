/* Host-only C7C harness. No production API or save identity. */
#include "../../src/warp_rando.c"
#include "graph.h"
#include <stdio.h>
#include <stdlib.h>
int __lsan_is_turned_off(void) { return 1; }
#include "c7c_candidate_core.inc"
#ifndef C7C_CLOSURE_HEADER
#define C7C_CLOSURE_HEADER "reference-closure.h"
#endif
#include C7C_CLOSURE_HEADER

int main(int argc,char **argv)
{
    static struct C7cWork work;struct C7cStats stats={0};
    uint32_t seed=argc>1?(uint32_t)strtoul(argv[1],0,0):0;
    uint16_t retries=argc>2?(uint16_t)strtoul(argv[2],0,0):8;
    uint16_t attempt=0,count=0,i;int last=WR_OK;
    int r=c7c_generate_candidate(&wr_graph,&c7c_index,seed,retries,&work,&stats,&count,&attempt,&last);
    printf("{\"result\":%d,\"last_rejection\":%d,\"attempt\":%u,\"records\":[",r,last,r?0:attempt);
    if(!r) for(i=0;i<count;i++) {const struct WrRecord *v=&work.candidate[i];
        printf("%s[%u,%u,%u,%u,%u,%u]",i?",":"",v->trigger.group,v->trigger.map,
               v->trigger.warp,v->landing.group,v->landing.map,v->landing.warp);}
    printf("],\"attempts\":%u,\"pairs\":%u,\"eligible_partners\":%u,"
           "\"partner_trials\":%u,\"state_evaluations\":%u,"
           "\"forward_rounds\":%u,\"reverse_rounds\":%u,"
           "\"repair_rounds\":%u,\"row_ors\":%u,\"work_bytes\":%zu}\n",stats.attempts,
           (unsigned)stats.pairs,(unsigned)stats.eligible_partners,
           (unsigned)stats.partner_trials,(unsigned)stats.state_evaluations,
           (unsigned)stats.forward_rounds,(unsigned)stats.reverse_rounds,
           (unsigned)stats.repair_rounds,(unsigned)stats.row_ors,sizeof(work));
    return 0;
}
