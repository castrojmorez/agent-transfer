/* Host-only C10B internally resumable scheduler harness. No production/save identity. */
#include "../../src/warp_rando.c"
#include "graph.h"
#include <stdio.h>
#include <stdlib.h>
int __lsan_is_turned_off(void) { return 1; }
#include "c9c_candidate_core.inc"
#ifndef C9C_EVENT_INDEX_HEADER
#define C9C_EVENT_INDEX_HEADER "reference-c9c-event-index.h"
#endif
#include C9C_EVENT_INDEX_HEADER
#include "c10b_candidate_core.inc"

int main(int argc,char **argv)
{
    static struct C9cWork work;struct C9cStats stats={0};struct C10bSession session;
    uint32_t seed=argc>1?(uint32_t)strtoul(argv[1],0,0):0;
    uint16_t trial_cap=argc>2?(uint16_t)strtoul(argv[2],0,0):3;
    uint16_t retries=argc>3?(uint16_t)strtoul(argv[3],0,0):8;
    uint16_t budget=argc>4?(uint16_t)strtoul(argv[4],0,0):1;
    uint32_t cancel_after=argc>5?(uint32_t)strtoul(argv[5],0,0):0,advances=0;uint16_t i;
    int restart_after_cancel=argc>6?atoi(argv[6]):0,cancelled_once=0,r;
    r=c10b_begin(&session,&wr_graph,&c9c_index,seed,trial_cap,retries,&work,&stats);
    while(r==C10B_PENDING) {if(cancel_after && session.steps>=cancel_after) {r=c10b_cancel(&session);break;}
        r=c10b_advance(&session,budget);advances++;}
    if(r==C10B_CANCELLED && restart_after_cancel) {
        cancelled_once=1;advances=0;r=c10b_begin(&session,&wr_graph,&c9c_index,seed,trial_cap,retries,&work,&stats);
        while(r==C10B_PENDING) {r=c10b_advance(&session,budget);advances++;}
    }
    printf("{\"result\":%d,\"last_rejection\":%d,\"attempt\":%u,\"trial_cap\":%u,\"records\":[",
           r,session.last_rejection,r?0:session.successful_attempt,trial_cap);
    if(!r) for(i=0;i<session.count;i++) {const struct WrRecord *v=&work.candidate[i];
        printf("%s[%u,%u,%u,%u,%u,%u]",i?",":"",v->trigger.group,v->trigger.map,
               v->trigger.warp,v->landing.group,v->landing.map,v->landing.warp);}
    printf("],\"attempts\":%u,\"pairs\":%u,\"eligible_partners\":%u,"
           "\"partner_trials\":%u,\"state_evaluations\":%u,"
           "\"forward_components\":%u,\"reverse_components\":%u,"
           "\"repair_components\":%u,\"active_visits\":%u,"
           "\"conditional_visits\":%u,\"row_ors\":%u,"
           "\"representative_bit_visits\":%u,\"pair_alias_visits\":%u,"
           "\"reverse_calls\":%u,\"reverse_edge_updates\":%u,"
           "\"set_word_ops\":%u,\"score_word_ops\":%u,"
           "\"component_rep_updates\":%u,\"work_bytes\":%zu,"
           "\"session_bytes\":%zu,\"steps\":%u,\"advances\":%u,"
           "\"trial_steps\":%u,\"select_steps\":%u,\"commit_steps\":%u,"
           "\"attempt_init_steps\":%u,\"emit_steps\":%u,\"validate_steps\":%u,"
           "\"max_step_active_visits\":%u,\"max_step_conditional_visits\":%u,"
           "\"max_step_row_ors\":%u,\"max_step_rep_bits\":%u,"
           "\"max_step_reverse_calls\":%u,\"max_init_units\":%u,"
           "\"max_select_units\":%u,\"max_trial_units\":%u,\"max_commit_units\":%u,"
           "\"max_emit_units\":%u,\"max_validate_units\":%u,"
           "\"phase\":%u,\"pairs_done\":%u,\"cancelled_once\":%d}\n",stats.attempts,
           (unsigned)stats.pairs,(unsigned)stats.eligible_partners,
           (unsigned)stats.partner_trials,(unsigned)stats.state_evaluations,
           (unsigned)stats.forward_components,(unsigned)stats.reverse_components,
           (unsigned)stats.repair_components,(unsigned)stats.active_visits,
           (unsigned)stats.conditional_visits,(unsigned)stats.row_ors,
           (unsigned)stats.representative_bit_visits,(unsigned)stats.pair_alias_visits,
           (unsigned)stats.reverse_calls,(unsigned)stats.reverse_edge_updates,
           (unsigned)stats.set_word_ops,(unsigned)stats.score_word_ops,
           (unsigned)stats.component_rep_updates,sizeof(work),sizeof(session),
           (unsigned)session.steps,(unsigned)advances,(unsigned)session.trial_steps,
           (unsigned)session.select_steps,(unsigned)session.commit_steps,
           session.attempt_init_steps,session.emit_steps,session.validate_steps,
           (unsigned)session.max_step_active_visits,(unsigned)session.max_step_conditional_visits,
           (unsigned)session.max_step_row_ors,(unsigned)session.max_step_representative_bit_visits,
           (unsigned)session.max_step_reverse_calls,
           (unsigned)session.max_group_units[C10B_GROUP_INIT],
           (unsigned)session.max_group_units[C10B_GROUP_SELECT],
           (unsigned)session.max_group_units[C10B_GROUP_TRIAL],
           (unsigned)session.max_group_units[C10B_GROUP_COMMIT],
           (unsigned)session.max_group_units[C10B_GROUP_EMIT],
           (unsigned)session.max_group_units[C10B_GROUP_VALIDATE],
           session.phase,c10b_pairs_done(&session),cancelled_once);return 0;
}
