/* In-process core timing control for C7C/C8A. It omits JSON/process overhead. */
#include "../../src/warp_rando.c"
#include "graph.h"
#include <stdio.h>
#include <stdlib.h>
#if defined(BENCH_C10C)
#include "c9c_candidate_core.inc"
#include "reference-c9c-event-index.h"
#include "c10b_candidate_core.inc"
#include "c10c_scheduler_core.inc"
typedef struct C9cWork BenchWork;
typedef struct C9cStats BenchStats;
struct C10cBenchClock {uint32_t ticks;};
static uint32_t c10c_bench_ticks(void *context)
{struct C10cBenchClock *clock=context;uint32_t result=clock->ticks;clock->ticks+=37;return result;}
static int c10c_bench_publish(void *context,const struct C10bSession *session)
{(void)context;(void)session;return WR_OK;}
static int c10c_bench_generate(uint32_t seed,BenchWork *work,BenchStats *stats,
                               uint16_t *count,uint16_t *attempt,int *last)
{
    struct C10cJob job;struct C10cBenchClock clock={0};
    struct C10cHooks hooks={0,c10c_bench_publish,0,0};int result;
    result=c10c_begin_prevalidated(&job,&wr_graph,&c9c_index,seed,3,8,
                                   C10C_DEFAULT_BUDGET_TICKS,work,stats,&hooks);
    while(result==C10B_PENDING){clock.ticks=0;result=c10c_pump(&job,c10c_bench_ticks,&clock);}
    *count=job.generation.count;*attempt=job.generation.successful_attempt;
    *last=job.generation.last_rejection;(void)c10c_snapshot;(void)c10c_request_cancel;
    return result;
}
#define APPROVE() ((void)c10b_begin,(void)c10b_advance,c9c_validate_reference(&wr_graph,&c9c_index))
#define GENERATE(seed,work,stats,count,attempt,last) \
    c10c_bench_generate(seed,work,stats,count,attempt,last)
#elif defined(BENCH_C10B)
#include "c9c_candidate_core.inc"
#include "reference-c9c-event-index.h"
#include "c10b_candidate_core.inc"
typedef struct C9cWork BenchWork;
typedef struct C9cStats BenchStats;
#ifndef C10B_BENCH_QUANTA
#define C10B_BENCH_QUANTA 1
#endif
static int c10b_bench_generate(uint32_t seed,BenchWork *work,BenchStats *stats,
                               uint16_t *count,uint16_t *attempt,int *last)
{
    struct C10bSession session;int result=c10b_begin_prevalidated(&session,&wr_graph,
      &c9c_index,seed,3,8,work,stats);
    while(result==C10B_PENDING)result=c10b_advance(&session,C10B_BENCH_QUANTA);
    *count=session.count;*attempt=session.successful_attempt;*last=session.last_rejection;
    return result;
}
#define APPROVE() ((void)c10b_begin,(void)c10b_cancel,(void)c10b_pairs_done, \
                   c9c_validate_reference(&wr_graph,&c9c_index))
#define GENERATE(seed,work,stats,count,attempt,last) \
    c10b_bench_generate(seed,work,stats,count,attempt,last)
#elif defined(BENCH_C10A)
#include "c9c_candidate_core.inc"
#include "reference-c9c-event-index.h"
#include "c10a_candidate_core.inc"
typedef struct C9cWork BenchWork;
typedef struct C9cStats BenchStats;
#ifndef C10A_BENCH_QUANTA
#define C10A_BENCH_QUANTA 1
#endif
static int c10a_bench_generate(uint32_t seed,BenchWork *work,BenchStats *stats,
                               uint16_t *count,uint16_t *attempt,int *last)
{
    struct C10aSession session;int result=c10a_begin_prevalidated(&session,&wr_graph,
      &c9c_index,seed,3,8,work,stats);
    while(result==C10A_PENDING) result=c10a_advance(&session,C10A_BENCH_QUANTA);
    *count=session.count;*attempt=session.successful_attempt;*last=session.last_rejection;
    return result;
}
#define APPROVE() ((void)c10a_begin,(void)c10a_cancel,(void)c10a_pairs_done, \
                   c9c_validate_reference(&wr_graph,&c9c_index))
#define GENERATE(seed,work,stats,count,attempt,last) \
    c10a_bench_generate(seed,work,stats,count,attempt,last)
#elif defined(BENCH_C9C) || defined(BENCH_C9C_WARM)
#include "c9c_candidate_core.inc"
#include "reference-c9c-event-index.h"
typedef struct C9cWork BenchWork;
typedef struct C9cStats BenchStats;
#if defined(BENCH_C9C_WARM)
#define APPROVE() ((void)c9c_generate_candidate,c9c_validate_reference(&wr_graph,&c9c_index))
#define GENERATE(seed,work,stats,count,attempt,last) \
    c9c_generate_prevalidated(&wr_graph,&c9c_index,seed,3,8,work,stats,count,attempt,last)
#else
#define GENERATE(seed,work,stats,count,attempt,last) \
    c9c_generate_candidate(&wr_graph,&c9c_index,seed,3,8,work,stats,count,attempt,last)
#endif
#elif defined(BENCH_C9B)
#include "c9b_candidate_core.inc"
#include "reference-c9b-event-index.h"
typedef struct C9bWork BenchWork;
typedef struct C9bStats BenchStats;
#define GENERATE(seed,work,stats,count,attempt,last) \
    c9b_generate_candidate(&wr_graph,&c9b_index,seed,3,8,work,stats,count,attempt,last)
#elif defined(BENCH_C9A)
#include "c9a_candidate_core.inc"
#include "reference-c9a-event-index.h"
typedef struct C9aWork BenchWork;
typedef struct C9aStats BenchStats;
#define GENERATE(seed,work,stats,count,attempt,last) \
    c9a_generate_candidate(&wr_graph,&c9a_index,seed,3,8,work,stats,count,attempt,last)
#elif defined(BENCH_C8C)
#include "c8c_candidate_core.inc"
#include "reference-c8c-event-index.h"
typedef struct C8cWork BenchWork;
typedef struct C8cStats BenchStats;
#define GENERATE(seed,work,stats,count,attempt,last) \
    c8c_generate_candidate(&wr_graph,&c8c_index,seed,3,8,work,stats,count,attempt,last)
#elif defined(BENCH_C8B)
#include "c8b_candidate_core.inc"
#include "reference-c8b-event-index.h"
typedef struct C8bWork BenchWork;
typedef struct C8bStats BenchStats;
#define GENERATE(seed,work,stats,count,attempt,last) \
    c8b_generate_candidate(&wr_graph,&c8b_index,seed,3,8,work,stats,count,attempt,last)
#elif defined(BENCH_C8A)
#include "c8a_candidate_core.inc"
#include "reference-event-index.h"
typedef struct C8aWork BenchWork;
typedef struct C8aStats BenchStats;
#define GENERATE(seed,work,stats,count,attempt,last) \
    c8a_generate_candidate(&wr_graph,&c8a_index,seed,8,work,stats,count,attempt,last)
#else
#include "c7c_candidate_core.inc"
#include "reference-closure.h"
typedef struct C7cWork BenchWork;
typedef struct C7cStats BenchStats;
#define GENERATE(seed,work,stats,count,attempt,last) \
    c7c_generate_candidate(&wr_graph,&c7c_index,seed,8,work,stats,count,attempt,last)
#endif

#ifndef APPROVE
#define APPROVE() WR_OK
#endif

static const uint32_t seeds[] = {
    0,1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,
    16,17,18,19,20,21,22,23,24,25,26,27,28,29,30,31,
    32,33,34,35,36,37,38,39,40,41,42,43,44,45,46,47,
    48,49,50,51,52,53,54,55,56,57,58,59,60,61,62,63,
    255,256,65535,4294967295u
};

int main(int argc,char **argv)
{
    static BenchWork work;uint32_t hash=2166136261u;
    unsigned repetitions=argc>1?(unsigned)strtoul(argv[1],0,0):10,repeat,position;
    if(APPROVE()!=WR_OK) return 3;
    for(repeat=0;repeat<repetitions;repeat++) for(position=0;position<68;position++) {
        BenchStats stats={0};uint16_t count=0,attempt=0,i;int last=0;
        if(GENERATE(seeds[position],&work,&stats,&count,&attempt,&last)!=WR_OK) return 2;
        hash=(hash^attempt)*16777619u;
        for(i=0;i<count;i++) {const struct WrRecord *r=&work.candidate[i];
            hash=(hash^r->trigger.group)*16777619u;hash=(hash^r->trigger.map)*16777619u;
            hash=(hash^r->trigger.warp)*16777619u;hash=(hash^r->landing.group)*16777619u;
            hash=(hash^r->landing.map)*16777619u;hash=(hash^r->landing.warp)*16777619u;}
    }
    printf("repetitions=%u generations=%u digest=%08x\n",repetitions,repetitions*68u,hash);
    return 0;
}
