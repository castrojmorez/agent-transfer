/* Host-only C8C indexed-state harness. No production API or save identity. */
#include "../../src/warp_rando.c"
#include "graph.h"
#include <stdio.h>
#include <stdlib.h>
int __lsan_is_turned_off(void) { return 1; }
#include "c8c_candidate_core.inc"
#ifndef C8C_EVENT_INDEX_HEADER
#define C8C_EVENT_INDEX_HEADER "reference-c8c-event-index.h"
#endif
#include C8C_EVENT_INDEX_HEADER

int main(int argc,char **argv)
{
    static struct C8cWork work;struct C8cStats stats={0};
    uint32_t seed=argc>1?(uint32_t)strtoul(argv[1],0,0):0;
    uint16_t trial_cap=argc>2?(uint16_t)strtoul(argv[2],0,0):4;
    uint16_t retries=argc>3?(uint16_t)strtoul(argv[3],0,0):8;
    uint16_t attempt=0,count=0,i;int last=WR_OK;
    int r=c8c_generate_candidate(&wr_graph,&c8c_index,seed,trial_cap,retries,&work,&stats,&count,&attempt,&last);
    printf("{\"result\":%d,\"last_rejection\":%d,\"attempt\":%u,\"trial_cap\":%u,\"records\":[",r,last,r?0:attempt,trial_cap);
    if(!r) for(i=0;i<count;i++) {const struct WrRecord *v=&work.candidate[i];
        printf("%s[%u,%u,%u,%u,%u,%u]",i?",":"",v->trigger.group,v->trigger.map,
               v->trigger.warp,v->landing.group,v->landing.map,v->landing.warp);}
    printf("],\"attempts\":%u,\"pairs\":%u,\"eligible_partners\":%u,"
           "\"partner_trials\":%u,\"state_evaluations\":%u,"
           "\"forward_components\":%u,\"reverse_components\":%u,"
           "\"repair_components\":%u,\"active_visits\":%u,"
           "\"conditional_visits\":%u,\"row_ors\":%u,"
           "\"representative_visits\":%u,\"pair_alias_visits\":%u,"
           "\"reverse_calls\":%u,\"reverse_edge_updates\":%u,"
           "\"work_bytes\":%zu}\n",stats.attempts,
           (unsigned)stats.pairs,(unsigned)stats.eligible_partners,
           (unsigned)stats.partner_trials,(unsigned)stats.state_evaluations,
           (unsigned)stats.forward_components,(unsigned)stats.reverse_components,
           (unsigned)stats.repair_components,(unsigned)stats.active_visits,
           (unsigned)stats.conditional_visits,(unsigned)stats.row_ors,
           (unsigned)stats.representative_visits,(unsigned)stats.pair_alias_visits,
           (unsigned)stats.reverse_calls,(unsigned)stats.reverse_edge_updates,sizeof(work));
    return 0;
}


