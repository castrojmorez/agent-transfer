/* C7A host-only feasibility prototype. This deliberately includes the frozen
 * Algorithm-3 translation unit so the experiment exercises the exact graph,
 * closure, repair and final-validator semantics without changing production.
 * It is not a public runtime algorithm and has no save identity. */
#include "../../src/warp_rando.c"
#include "graph.h"
#include <stdio.h>
#include <stdlib.h>

/* LeakSanitizer cannot enumerate processes in the restricted host. The
 * prototype owns only static workspace; ASan bounds and UBSan remain active. */
int __lsan_is_turned_off(void) { return 1; }

#include "c7a_candidate_core.inc"

int main(int argc,char **argv)
{
    static struct WrWork work;
    struct C7aStats stats={0};
    uint32_t seed=argc>1?(uint32_t)strtoul(argv[1],0,0):0;
    uint16_t cap=argc>2?(uint16_t)strtoul(argv[2],0,0):16;
    uint16_t retries=argc>3?(uint16_t)strtoul(argv[3],0,0):8;
    uint16_t attempt=0,count=0,i;int last=WR_OK;
    int r=c7a_generate_candidate(&wr_graph,seed,cap,retries,&work,&stats,
                                 &count,&attempt,&last);
    printf("{\"result\":%d,\"last_rejection\":%d,\"attempt\":%u,"
           "\"trial_cap\":%u,\"records\":[",r,last,
           r?0:attempt,cap);
    if(!r) for(i=0;i<count;i++) {
        const struct WrRecord *v=&work.candidate[i];
        printf("%s[%u,%u,%u,%u,%u,%u]",i?",":"",v->trigger.group,
               v->trigger.map,v->trigger.warp,v->landing.group,
               v->landing.map,v->landing.warp);
    }
    printf("],\"attempts\":%u,\"pairs\":%u,\"eligible_partners\":%u,"
           "\"partner_trials\":%u,\"state_closures\":%u,"
           "\"repair_checks\":%u,\"work_bytes\":%zu}\n",
           stats.attempts,(unsigned)stats.pairs,
           (unsigned)stats.eligible_partners,(unsigned)stats.partner_trials,
           (unsigned)stats.state_closures,(unsigned)stats.repair_checks,
           sizeof(work));
    return 0;
}
