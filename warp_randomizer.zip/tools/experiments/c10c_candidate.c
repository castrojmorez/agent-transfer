/* Host-only C10C budgeted lifecycle harness. No production/save identity. */
#include "../../src/warp_rando.c"
#include "graph.h"
#include <stdio.h>
#include <stdlib.h>
int __lsan_is_turned_off(void) { return 1; }
#include "c9c_candidate_core.inc"
#ifndef C9C_EVENT_INDEX_HEADER
#define C9C_EVENT_INDEX_HEADER "reference-c9c-event-index.h"
#endif
#include C9C_EVENT_INDEX_HEADER
#include "c10b_candidate_core.inc"
#include "c10c_scheduler_core.inc"

struct HostLife {
    struct WrRecord active[C9C_MAX_EMIT];
    uint32_t fake_ticks,tick_increment;
    uint16_t active_count,invalidations,publishes,releases;
    int active_valid,publish_result;
};
static void host_invalidate(void *context)
{struct HostLife *h=context;h->active_valid=0;h->active_count=0;h->invalidations++;}
static int host_publish(void *context,const struct C10bSession *q)
{
    struct HostLife *h=context;h->publishes++;if(h->publish_result)return h->publish_result;
    memcpy(h->active,q->work->candidate,q->count*sizeof(*h->active));
    h->active_count=q->count;h->active_valid=1;return WR_OK;
}
static void host_release(void *context,struct C9cWork *work)
{struct HostLife *h=context;(void)work;h->releases++;}
static uint32_t host_ticks(void *context)
{struct HostLife *h=context;uint32_t result=h->fake_ticks;h->fake_ticks+=h->tick_increment;return result;}

int main(int argc,char **argv)
{
    static struct C9cWork work;struct C9cStats stats={0};struct C10cJob job;
    struct HostLife life={0};struct C10cHooks hooks={host_invalidate,host_publish,host_release,&life};
    struct C10cView view;uint32_t seed=argc>1?(uint32_t)strtoul(argv[1],0,0):0;
    uint16_t trial_cap=argc>2?(uint16_t)strtoul(argv[2],0,0):3;
    uint16_t retries=argc>3?(uint16_t)strtoul(argv[3],0,0):8;
    uint16_t budget=argc>4?(uint16_t)strtoul(argv[4],0,0):C10C_DEFAULT_BUDGET_TICKS;
    uint32_t cancel_after=argc>5?(uint32_t)strtoul(argv[5],0,0):0;uint16_t i;
    int restart=argc>6?atoi(argv[6]):0,cancelled_once=0,r;
    life.tick_increment=argc>7?(uint32_t)strtoul(argv[7],0,0):37;
    life.publish_result=argc>8?atoi(argv[8]):WR_OK;
    r=c10c_begin_prevalidated(&job,&wr_graph,&c9c_index,seed,trial_cap,retries,budget,&work,&stats,&hooks);
    while(r==C10B_PENDING) {
        life.fake_ticks=0;
        if(cancel_after && job.callbacks>=cancel_after)c10c_request_cancel(&job);
        r=c10c_pump(&job,host_ticks,&life);
    }
    if(r==C10B_CANCELLED && restart) {
        cancelled_once=1;cancel_after=0;life.fake_ticks=0;
        r=c10c_begin_prevalidated(&job,&wr_graph,&c9c_index,seed,trial_cap,retries,budget,&work,&stats,&hooks);
        while(r==C10B_PENDING){life.fake_ticks=0;r=c10c_pump(&job,host_ticks,&life);}
    }
    c10c_snapshot(&job,&view);
    printf("{\"result\":%d,\"last_rejection\":%d,\"attempt\":%u,\"trial_cap\":%u,\"records\":[",
           r,job.generation.last_rejection,r?0:job.generation.successful_attempt,trial_cap);
    if(!r)for(i=0;i<life.active_count;i++){const struct WrRecord *v=&life.active[i];
        printf("%s[%u,%u,%u,%u,%u,%u]",i?",":"",v->trigger.group,v->trigger.map,
               v->trigger.warp,v->landing.group,v->landing.map,v->landing.warp);}
    printf("],\"attempts\":%u,\"pairs\":%u,\"eligible_partners\":%u,"
           "\"partner_trials\":%u,\"state_evaluations\":%u,"
           "\"forward_components\":%u,\"reverse_components\":%u,"
           "\"repair_components\":%u,\"active_visits\":%u,"
           "\"conditional_visits\":%u,\"row_ors\":%u,"
           "\"representative_bit_visits\":%u,\"pair_alias_visits\":%u,"
           "\"reverse_calls\":%u,\"reverse_edge_updates\":%u,"
           "\"set_word_ops\":%u,\"score_word_ops\":%u,"
           "\"component_rep_updates\":%u,\"work_bytes\":%zu,"
           "\"job_bytes\":%zu,\"steps\":%u,\"callbacks\":%u,"
           "\"max_steps_per_callback\":%u,\"progress\":%u,\"status\":%u,"
           "\"published\":%u,\"released\":%u,\"invalidations\":%u,"
           "\"publishes\":%u,\"releases\":%u,\"active_valid\":%d,"
           "\"active_count\":%u,\"view_attempt\":%u,\"view_pairs_done\":%u,"
           "\"phase\":%u,\"cancelled_once\":%d}\n",stats.attempts,
           (unsigned)stats.pairs,(unsigned)stats.eligible_partners,
           (unsigned)stats.partner_trials,(unsigned)stats.state_evaluations,
           (unsigned)stats.forward_components,(unsigned)stats.reverse_components,
           (unsigned)stats.repair_components,(unsigned)stats.active_visits,
           (unsigned)stats.conditional_visits,(unsigned)stats.row_ors,
           (unsigned)stats.representative_bit_visits,(unsigned)stats.pair_alias_visits,
           (unsigned)stats.reverse_calls,(unsigned)stats.reverse_edge_updates,
           (unsigned)stats.set_word_ops,(unsigned)stats.score_word_ops,
           (unsigned)stats.component_rep_updates,sizeof(work),sizeof(job),
           (unsigned)job.generation.steps,(unsigned)job.callbacks,
           (unsigned)job.max_steps_per_callback,view.progress,view.status,
           job.published,job.released,life.invalidations,life.publishes,life.releases,
           life.active_valid,life.active_count,view.attempt,view.pairs_done,
           view.phase,cancelled_once);return 0;
}
