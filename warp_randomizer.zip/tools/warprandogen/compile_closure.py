#!/usr/bin/env python3
"""Compile unconditional SCC reachability used by the C7C experiment."""
import argparse,hashlib,importlib.util,json,pathlib,sys
ROOT=pathlib.Path(__file__).resolve().parents[2]
spec=importlib.util.spec_from_file_location('graph_compiler',ROOT/'tools/warprandogen/compile.py')
compiler=importlib.util.module_from_spec(spec);spec.loader.exec_module(compiler)

def emit(data):
    x=compiler.normalize(data);n=len(x['nodes']);sys.setrecursionlimit(max(3000,n*3))
    adj=[[] for _ in range(n)]
    for a,b,cap in x['edges']:
        if cap==compiler.NONE:adj[a].append(b)
    index=[-1]*n;low=[0]*n;stack=[];on=[False]*n;components=[]
    def visit(v):
        index[v]=low[v]=visit.clock;visit.clock+=1;stack.append(v);on[v]=True
        for t in adj[v]:
            if index[t]<0:visit(t);low[v]=min(low[v],low[t])
            elif on[t]:low[v]=min(low[v],index[t])
        if low[v]==index[v]:
            row=[]
            while True:
                t=stack.pop();on[t]=False;row.append(t)
                if t==v:break
            components.append(sorted(row))
    visit.clock=0
    for v in range(n):
        if index[v]<0:visit(v)
    components.sort(key=lambda row:row[0]);node_component=[0]*n
    for c,row in enumerate(components):
        for v in row:node_component[v]=c
    count=len(components);words=(count+31)//32
    dag=[set() for _ in range(count)]
    for a in range(n):
        for b in adj[a]:
            ca,cb=node_component[a],node_component[b]
            if ca!=cb:dag[ca].add(cb)
    def closures(graph):
        memo={}
        def walk(c):
            if c in memo:return memo[c]
            bits=1<<c
            for t in sorted(graph[c]):bits|=walk(t)
            memo[c]=bits;return bits
        return [walk(c) for c in range(count)]
    forward=closures(dag);rev=[set() for _ in range(count)]
    for a,row in enumerate(dag):
        for b in row:rev[b].add(a)
    reverse=closures(rev)
    conditional=sorted(set((node_component[a],node_component[b],cap)
                           for a,b,cap in x['edges'] if cap!=compiler.NONE
                           and node_component[a]!=node_component[b]))
    active=[i for i,row in enumerate(x['nodes']) if row[3]]
    def arr(ctype,name,rows):
        rows=list(rows);return f'static const {ctype} {name}[{max(1,len(rows))}] = {{\n'+''.join('    '+r+',\n' for r in (rows or ['0']))+'};\n'
    def flat_words(rows):
        for bits in rows:
            for i in range(words):
                yield f'0x{(bits>>(32*i))&0xffffffff:08x}u'
    source_hash=hashlib.sha256(json.dumps(data,sort_keys=True,separators=(',',':')).encode()).hexdigest()
    out='#ifndef C7C_CLOSURE_GENERATED_H\n#define C7C_CLOSURE_GENERATED_H\n'
    out+=f'/* C7C SCC index; source SHA-256 {source_hash}; deterministic, no paths/timestamp. */\n'
    out+=arr('uint16_t','c7c_node_component',map(str,node_component))
    out+=arr('uint16_t','c7c_active_nodes',map(str,active))
    out+=arr('uint32_t','c7c_forward_closure',flat_words(forward))
    out+=arr('uint32_t','c7c_reverse_closure',flat_words(reverse))
    out+=arr('struct C7cCondEdge','c7c_conditional_edges',
             ('{'+f'{a},{b},{cap}'+'}' for a,b,cap in conditional))
    out+='static const struct C7cIndex c7c_index = {\n'
    out+=f'    {n},{count},{words},{len(active)},{len(conditional)},\n'
    out+='    c7c_node_component,c7c_active_nodes,c7c_forward_closure,c7c_reverse_closure,c7c_conditional_edges\n};\n#endif\n'
    return out,{'nodes':n,'components':count,'words':words,'active_nodes':len(active),
                'conditional_edges':len(conditional),'source_sha256':source_hash}

if __name__=='__main__':
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('input');p.add_argument('output');p.add_argument('--report');a=p.parse_args()
    text,report=emit(json.loads(pathlib.Path(a.input).read_text()));dest=pathlib.Path(a.output);dest.parent.mkdir(parents=True,exist_ok=True)
    tmp=dest.with_suffix(dest.suffix+'.tmp');tmp.write_text(text);tmp.replace(dest)
    if a.report:pathlib.Path(a.report).write_text(json.dumps(report,indent=2)+'\n')
    print(json.dumps(report))
