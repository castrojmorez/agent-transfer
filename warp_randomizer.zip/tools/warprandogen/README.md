# Build-time compiler

The original standalone warprandogen.cpp required missing json11 files and
emitted unsafe layouts. It is replaced by import_reference.py plus compile.py,
using only Python 3's standard library. There is no second obsolete compiler.

Run `make data` at the package root. The first program validates/normalizes
pinned reference JSON with explicit overrides and writes an audit report. The
second compiles normalized schema 2 to standalone C99 arrays for warp_rando.h.
The complete runtime generator remains src/warp_rando.c; these tools do not
choose player seeds or substitute host layout generation for the in-game goal.

`compile_closure.py` and `compile_event_index.py` generate the experimental
C7C/C8A SCC indexes. `compile_c8b_index.py` emits the same event-index data
under isolated C8B symbols for the trial-cap experiment. These generated
indexes are test-only and do not assign a runtime/save identity.
`compile_c8c_index.py` adds deterministic representative-to-active-alias
slices used to avoid repeated broad scans; it is also test-only.
`compile_c9a_index.py` additionally emits representative ordinals and sparse
component membership used by C9A's free/reached/home bitsets; it is test-only.
`compile_c9b_index.py` emits the same deterministic structure under isolated
C9B symbols for the validated-emission experiment; it is test-only.

Normalization must finish successfully before writing a new header. Output
uses a temporary sibling plus replacement, so invalid input does not publish a
partial header. No condition is made unrestricted because its name was unknown.
The normalized-schema compiler can also compile synthetic/new audited inputs;
see data/README.md and tests/run.py for independently reviewable examples.
