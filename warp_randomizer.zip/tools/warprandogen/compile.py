#!/usr/bin/env python3
"""Strict normalized graph -> deterministic C99 data; Python standard library only."""
import argparse, hashlib, json, pathlib
NONE=65535

def fail(message): raise ValueError(message)
def integer(v, lo, hi, label):
    if type(v) is not int or not lo <= v <= hi: fail(f'{label}: expected integer {lo}..{hi}, got {v!r}')
    return v

def key(v):
    if not isinstance(v,list) or len(v)!=3: fail(f'bad triple: {v!r}')
    return [integer(x,0,127,'triple') for x in v]

def normalize(d):
    if d.get('schema')!=2: fail('schema must be 2')
    nodes=d['nodes']; n=len(nodes)
    integer(n,1,2048,'node count')
    ids=[x['name'] for x in nodes]
    if len(set(ids))!=n or any(not isinstance(x,str) or not x for x in ids): fail('duplicate/invalid node name')
    if ids!=sorted(ids): fail('nodes must be sorted by name')
    ni={s:i for i,s in enumerate(ids)}
    caps=d['capabilities']; integer(len(caps),0,256,'capabilities')
    if caps!=sorted(set(caps)) or any(not isinstance(x,str) for x in caps): fail('capabilities must be unique sorted strings')
    ci={s:i for i,s in enumerate(caps)}
    def ref(name):
        if name not in ni: fail(f'unknown node: {name}')
        return ni[name]
    def cap(name):
        if name is None: return NONE
        if name not in ci: fail(f'unknown requirement: {name}')
        return ci[name]
    outnodes=[]; seen=set(); triggers={}
    for v in nodes:
        k=tuple(key(v['id'])); tr=tuple(key(v['trigger']))
        if k in seen: fail('duplicate physical endpoint')
        seen.add(k)
        if type(v['active']) is not bool: fail('active must be Boolean')
        tags=integer(v.get('tags',0),0,3,'tags')
        r=ref(v['rep'])
        if nodes[r]['rep']!=v['rep']: fail('representative is not canonical')
        if nodes[r]['active']!=v['active'] or nodes[r].get('tags',0)!=tags: fail('inconsistent group participation/tags')
        if tr in triggers and triggers[tr]!=v['active']: fail('trigger shared by participating and excluded events')
        triggers[tr]=v['active']
        outnodes.append([list(k),list(tr),r,int(v['active']),tags])
    edges=sorted(set((ref(e['from']),ref(e['to']),cap(e.get('requires'))) for e in d['edges']))
    integer(len(edges),0,65534,'edges')
    req=[]; rules=[]
    for r in sorted(d['rules'],key=lambda r:json.dumps(r,sort_keys=True)):
        grant=cap(r['grant'])
        if grant==NONE: fail('rule needs grant')
        start=len(req)
        for q in r['requires']:
            if set(q)=={'location'}: req.append([ref(q['location']),0])
            elif set(q)=={'capability'}:
                if q['capability'] is None: fail('capability requirement cannot be null')
                req.append([cap(q['capability']),1])
            else: fail(f'bad rule requirement {q}')
        rules.append([grant,start,len(req)-start])
    for name,value in [('requirements',len(req)),('rules',len(rules)),('goals',len(d['goals']))]: integer(value,0,65534,name)
    goals=sorted(set(ref(s) for s in d['goals']))
    if not goals: fail('at least one explicit objective is required')
    digest=hashlib.sha256(json.dumps(d,sort_keys=True,separators=(',',':')).encode()).hexdigest()
    return dict(nodes=outnodes,edges=edges,rules=rules,reqs=req,goals=goals,root=ref(d['root']),caps=len(caps),sha256=digest)

def emit(d):
    x=normalize(d); n=len(x['nodes'])
    def arr(ctype,name,rows):
        rows=list(rows)
        return f'static const {ctype} {name}[{max(1,len(rows))}] = {{\n'+''.join('    '+s+',\n' for s in (rows or (['{0}'] if ctype.startswith('struct') else ['0'])))+'};\n'
    def triple(k): return '{'+','.join(map(str,k))+'}'
    out='#ifndef WR_GENERATED_H\n#define WR_GENERATED_H\n#include "warp_rando.h"\n'
    out+=f'/* schema 2; SHA-256 {x["sha256"]}; no timestamp or paths */\n'
    out+=arr('struct WrNode','wr_nodes',('{'+triple(a)+','+triple(b)+f',{r},{active},{tags}'+'}' for a,b,r,active,tags in x['nodes']))
    for suffix,edges in [('',x['edges']),('_reverse',sorted((b,a,c) for a,b,c in x['edges']))]:
        bounds=[sum(a<i for a,b,c in edges) for i in range(n+1)]
        out+=arr('struct WrEdge','wr_edges'+suffix,('{'+f'{b},{c}'+'}' for a,b,c in edges))
        out+=arr('uint16_t','wr_bounds'+suffix,map(str,bounds))
    for typ,name in [('WrRule','rules'),('WrReq','reqs')]:
        out+=arr('struct '+typ,'wr_'+name,('{'+','.join(map(str,row))+'}' for row in x[name]))
    out+=arr('uint16_t','wr_goals',map(str,x['goals']))
    digest=','.join(str(b) for b in bytes.fromhex(x['sha256']))
    out+='static const struct WrGraph wr_graph = {\n'
    out+=f'    {n},{x["caps"]},{len(x["edges"])},{len(x["rules"])},{len(x["reqs"])},{len(x["goals"])},{x["root"]},\n'
    out+='    wr_nodes,wr_edges,wr_edges_reverse,wr_bounds,wr_bounds_reverse,wr_rules,wr_reqs,wr_goals,\n'
    out+='    {'+digest+'}\n};\n#endif\n'
    return out

if __name__=='__main__':
    p=argparse.ArgumentParser(description=__doc__); p.add_argument('input');p.add_argument('output'); a=p.parse_args()
    try:
        text=emit(json.loads(pathlib.Path(a.input).read_text()))
        dest=pathlib.Path(a.output);dest.parent.mkdir(parents=True,exist_ok=True)
        tmp=dest.with_suffix(dest.suffix+'.tmp');tmp.write_text(text);tmp.replace(dest)
    except (ValueError,KeyError,TypeError) as e: p.exit(1,f'error: {e}\n')
