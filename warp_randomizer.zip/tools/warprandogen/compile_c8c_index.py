#!/usr/bin/env python3
"""Compile the C8C event index with representative/alias lookup slices."""
import argparse,importlib.util,json,pathlib
ROOT=pathlib.Path(__file__).resolve().parents[2]
spec=importlib.util.spec_from_file_location('event_compiler',ROOT/'tools/warprandogen/compile_event_index.py')
module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module)

def emit(data):
    text,report=module.emit(data);built=module.build(data);normalized=built['normalized']
    text=text.replace('C8A','C8C').replace('C8a','C8c').replace('c8a','c8c')
    active_position={node:i for i,node in enumerate(built['active_nodes'])}
    representatives=[i for i,row in enumerate(normalized['nodes']) if row[3] and row[2]==i]
    grouped=sorted((row[2],active_position[node]) for node,row in enumerate(normalized['nodes']) if row[3])
    offsets=[];position=0
    for representative in range(len(normalized['nodes'])):
        offsets.append(position)
        while position<len(grouped) and grouped[position][0]==representative:position+=1
    offsets.append(position)
    indices=[active_index for _,active_index in grouped]
    def arr(name,rows):
        rows=list(rows)
        return f'static const uint16_t {name}[{max(1,len(rows))}] = {{\n'+''.join('    '+str(row)+',\n' for row in (rows or [0]))+'};\n'
    additions=(arr('c8c_representatives',representatives)+
               arr('c8c_representative_active_offsets',offsets)+
               arr('c8c_representative_active_indices',indices))
    marker='static const struct C8cIndex c8c_index = {\n'
    text=text.replace(marker,additions+marker)
    old=f"    {len(built['node_component'])},{built['components']},{built['words']},{len(built['active_nodes'])},{len(built['forward_conditional'])},\n"
    new=f"    {len(built['node_component'])},{built['components']},{built['words']},{len(built['active_nodes'])},{len(built['forward_conditional'])},{len(representatives)},\n"
    text=text.replace(old,new)
    text=text.replace('    c8c_node_component,c8c_component_active_offsets,c8c_component_active_nodes,\n',
      '    c8c_node_component,c8c_component_active_offsets,c8c_component_active_nodes,\n'
      '    c8c_representatives,c8c_representative_active_offsets,c8c_representative_active_indices,\n')
    return text,report|{'symbol_namespace':'c8c','active_representatives':len(representatives),
      'representative_alias_indices':len(indices),
      'max_active_aliases_per_representative':max((offsets[i+1]-offsets[i] for i in representatives),default=0)}

if __name__=='__main__':
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('input');p.add_argument('output');p.add_argument('--report');a=p.parse_args()
    text,report=emit(json.loads(pathlib.Path(a.input).read_text()))
    destination=pathlib.Path(a.output);destination.parent.mkdir(parents=True,exist_ok=True)
    temporary=destination.with_suffix(destination.suffix+'.tmp');temporary.write_text(text);temporary.replace(destination)
    if a.report:pathlib.Path(a.report).write_text(json.dumps(report,indent=2)+'\n')
    print(json.dumps(report))

