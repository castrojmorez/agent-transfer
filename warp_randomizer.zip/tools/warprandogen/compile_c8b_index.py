#!/usr/bin/env python3
"""Compile the C8A event index under isolated C8B symbols."""
import argparse,importlib.util,json,pathlib
ROOT=pathlib.Path(__file__).resolve().parents[2]
spec=importlib.util.spec_from_file_location('event_compiler',ROOT/'tools/warprandogen/compile_event_index.py')
module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module)

def emit(data):
    text,report=module.emit(data)
    return (text.replace('C8A','C8B').replace('C8a','C8b').replace('c8a','c8b'),
            report|{'symbol_namespace':'c8b'})

if __name__=='__main__':
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('input');p.add_argument('output');p.add_argument('--report');a=p.parse_args()
    text,report=emit(json.loads(pathlib.Path(a.input).read_text()))
    destination=pathlib.Path(a.output);destination.parent.mkdir(parents=True,exist_ok=True)
    temporary=destination.with_suffix(destination.suffix+'.tmp');temporary.write_text(text);temporary.replace(destination)
    if a.report:pathlib.Path(a.report).write_text(json.dumps(report,indent=2)+'\n')
    print(json.dumps(report))


