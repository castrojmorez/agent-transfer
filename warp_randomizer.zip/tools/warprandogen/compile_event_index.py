#!/usr/bin/env python3
"""Compile the SCC closure plus grouped adjacency used by C8A."""
import argparse,hashlib,importlib.util,json,pathlib,sys
ROOT=pathlib.Path(__file__).resolve().parents[2]
spec=importlib.util.spec_from_file_location('graph_compiler',ROOT/'tools/warprandogen/compile.py')
compiler=importlib.util.module_from_spec(spec);spec.loader.exec_module(compiler)

def build(data):
    x=compiler.normalize(data);n=len(x['nodes']);sys.setrecursionlimit(max(3000,n*3))
    adjacency=[[] for _ in range(n)]
    for source,target,capability in x['edges']:
        if capability==compiler.NONE:adjacency[source].append(target)
    index=[-1]*n;low=[0]*n;stack=[];on_stack=[False]*n;components=[]
    def visit(node):
        index[node]=low[node]=visit.clock;visit.clock+=1;stack.append(node);on_stack[node]=True
        for target in adjacency[node]:
            if index[target]<0:visit(target);low[node]=min(low[node],low[target])
            elif on_stack[target]:low[node]=min(low[node],index[target])
        if low[node]==index[node]:
            row=[]
            while True:
                target=stack.pop();on_stack[target]=False;row.append(target)
                if target==node:break
            components.append(sorted(row))
    visit.clock=0
    for node in range(n):
        if index[node]<0:visit(node)
    components.sort(key=lambda row:row[0]);node_component=[0]*n
    for component,row in enumerate(components):
        for node in row:node_component[node]=component
    count=len(components);words=(count+31)//32;dag=[set() for _ in range(count)]
    for source in range(n):
        for target in adjacency[source]:
            a,b=node_component[source],node_component[target]
            if a!=b:dag[a].add(b)
    def closures(graph):
        memo={}
        def walk(component):
            if component in memo:return memo[component]
            bits=1<<component
            for target in sorted(graph[component]):bits|=walk(target)
            memo[component]=bits;return bits
        return [walk(component) for component in range(count)]
    forward=closures(dag);reverse_dag=[set() for _ in range(count)]
    for source,row in enumerate(dag):
        for target in row:reverse_dag[target].add(source)
    reverse=closures(reverse_dag)
    conditional=sorted(set((node_component[a],node_component[b],cap)
                           for a,b,cap in x['edges'] if cap!=compiler.NONE
                           and node_component[a]!=node_component[b]))
    active=sorted((node_component[node],node) for node,row in enumerate(x['nodes']) if row[3])
    def offsets(rows,key,count):
        result=[];position=0
        for component in range(count):
            result.append(position)
            while position<len(rows) and key(rows[position])==component:position+=1
        result.append(position);return result
    reverse_conditional=sorted(conditional,key=lambda row:(row[1],row[0],row[2]))
    capability_conditional=sorted(conditional,key=lambda row:(row[2],row[0],row[1]))
    return {'normalized':x,'node_component':node_component,'components':count,'words':words,
            'forward':forward,'reverse':reverse,'active_nodes':[node for _,node in active],
            'active_offsets':offsets(active,lambda row:row[0],count),
            'forward_conditional':conditional,
            'forward_offsets':offsets(conditional,lambda row:row[0],count),
            'reverse_conditional':reverse_conditional,
            'reverse_offsets':offsets(reverse_conditional,lambda row:row[1],count),
            'capability_conditional':capability_conditional,
            'capability_offsets':offsets(capability_conditional,lambda row:row[2],x['caps'])}

def emit(data):
    x=build(data);words=x['words']
    def arr(ctype,name,rows):
        rows=list(rows);return f'static const {ctype} {name}[{max(1,len(rows))}] = {{\n'+''.join('    '+row+',\n' for row in (rows or ['0']))+'};\n'
    def flat_words(rows):
        for bits in rows:
            for word in range(words):yield f'0x{(bits>>(32*word))&0xffffffff:08x}u'
    source_hash=hashlib.sha256(json.dumps(data,sort_keys=True,separators=(',',':')).encode()).hexdigest()
    out='#ifndef C8A_EVENT_INDEX_GENERATED_H\n#define C8A_EVENT_INDEX_GENERATED_H\n'
    out+=f'/* C8A event index; source SHA-256 {source_hash}; deterministic, no paths/timestamp. */\n'
    out+=arr('uint16_t','c8a_node_component',map(str,x['node_component']))
    out+=arr('uint16_t','c8a_component_active_offsets',map(str,x['active_offsets']))
    out+=arr('uint16_t','c8a_component_active_nodes',map(str,x['active_nodes']))
    out+=arr('uint32_t','c8a_forward_closure',flat_words(x['forward']))
    out+=arr('uint32_t','c8a_reverse_closure',flat_words(x['reverse']))
    out+=arr('uint16_t','c8a_forward_conditional_offsets',map(str,x['forward_offsets']))
    out+=arr('struct C8aCondEdge','c8a_forward_conditional',
             ('{'+f'{a},{b},{cap}'+'}' for a,b,cap in x['forward_conditional']))
    out+=arr('uint16_t','c8a_reverse_conditional_offsets',map(str,x['reverse_offsets']))
    out+=arr('struct C8aCondEdge','c8a_reverse_conditional',
             ('{'+f'{a},{b},{cap}'+'}' for a,b,cap in x['reverse_conditional']))
    out+=arr('uint16_t','c8a_capability_conditional_offsets',map(str,x['capability_offsets']))
    out+=arr('struct C8aCondEdge','c8a_capability_conditional',
             ('{'+f'{a},{b},{cap}'+'}' for a,b,cap in x['capability_conditional']))
    out+='static const struct C8aIndex c8a_index = {\n'
    out+=f"    {len(x['node_component'])},{x['components']},{words},{len(x['active_nodes'])},{len(x['forward_conditional'])},\n"
    out+='    c8a_node_component,c8a_component_active_offsets,c8a_component_active_nodes,\n'
    out+='    c8a_forward_closure,c8a_reverse_closure,\n'
    out+='    c8a_forward_conditional_offsets,c8a_forward_conditional,\n'
    out+='    c8a_reverse_conditional_offsets,c8a_reverse_conditional,\n'
    out+='    c8a_capability_conditional_offsets,c8a_capability_conditional\n};\n#endif\n'
    report={'nodes':len(x['node_component']),'components':x['components'],'words':words,
            'active_nodes':len(x['active_nodes']),'conditional_edges':len(x['forward_conditional']),
            'source_sha256':source_hash}
    return out,report

if __name__=='__main__':
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('input');p.add_argument('output');p.add_argument('--report');a=p.parse_args()
    text,report=emit(json.loads(pathlib.Path(a.input).read_text()));destination=pathlib.Path(a.output);destination.parent.mkdir(parents=True,exist_ok=True)
    temporary=destination.with_suffix(destination.suffix+'.tmp');temporary.write_text(text);temporary.replace(destination)
    if a.report:pathlib.Path(a.report).write_text(json.dumps(report,indent=2)+'\n')
    print(json.dumps(report))
