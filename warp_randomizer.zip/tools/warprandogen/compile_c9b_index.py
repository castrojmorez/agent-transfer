#!/usr/bin/env python3
"""Compile the C9B event index with representative bitset membership."""
import argparse,importlib.util,json,pathlib
ROOT=pathlib.Path(__file__).resolve().parents[2]
spec=importlib.util.spec_from_file_location('event_compiler',ROOT/'tools/warprandogen/compile_event_index.py')
module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module)

def emit(data):
    text,report=module.emit(data);built=module.build(data);normalized=built['normalized']
    text=text.replace('C8A','C9B').replace('C8a','C9b').replace('c8a','c9b')
    active_position={node:i for i,node in enumerate(built['active_nodes'])}
    representatives=[i for i,row in enumerate(normalized['nodes']) if row[3] and row[2]==i]
    grouped=sorted((row[2],active_position[node]) for node,row in enumerate(normalized['nodes']) if row[3])
    offsets=[];position=0
    for representative in range(len(normalized['nodes'])):
        offsets.append(position)
        while position<len(grouped) and grouped[position][0]==representative:position+=1
    offsets.append(position)
    indices=[active_index for _,active_index in grouped]
    representative_words=(len(representatives)+31)//32
    representative_index_by_node=[65535]*len(normalized['nodes'])
    component_groups=[[] for _ in range(built['components'])]
    for ordinal,node in enumerate(representatives):
        representative_index_by_node[node]=ordinal
        component_groups[built['node_component'][node]].append(ordinal)
    component_representative_offsets=[0]
    component_representative_indices=[]
    for group in component_groups:
        component_representative_indices.extend(group)
        component_representative_offsets.append(len(component_representative_indices))
    def arr(name,rows):
        rows=list(rows)
        return f'static const uint16_t {name}[{max(1,len(rows))}] = {{\n'+''.join('    '+str(row)+',\n' for row in (rows or [0]))+'};\n'
    additions=(arr('c9b_representatives',representatives)+
               arr('c9b_representative_active_offsets',offsets)+
               arr('c9b_representative_active_indices',indices)+
               arr('c9b_representative_index_by_node',representative_index_by_node)+
               arr('c9b_component_representative_offsets',component_representative_offsets)+
               arr('c9b_component_representative_indices',component_representative_indices))
    marker='static const struct C9bIndex c9b_index = {\n'
    text=text.replace(marker,additions+marker)
    old=f"    {len(built['node_component'])},{built['components']},{built['words']},{len(built['active_nodes'])},{len(built['forward_conditional'])},\n"
    new=f"    {len(built['node_component'])},{built['components']},{built['words']},{len(built['active_nodes'])},{len(built['forward_conditional'])},{len(representatives)},{representative_words},\n"
    text=text.replace(old,new)
    text=text.replace('    c9b_node_component,c9b_component_active_offsets,c9b_component_active_nodes,\n',
      '    c9b_node_component,c9b_component_active_offsets,c9b_component_active_nodes,\n'
      '    c9b_representatives,c9b_representative_active_offsets,c9b_representative_active_indices,\n'
      '    c9b_representative_index_by_node,c9b_component_representative_offsets,\n'
      '    c9b_component_representative_indices,\n')
    return text,report|{'symbol_namespace':'c9b','active_representatives':len(representatives),
      'representative_alias_indices':len(indices),
      'max_active_aliases_per_representative':max((offsets[i+1]-offsets[i] for i in representatives),default=0),
      'representative_words':representative_words,
      'component_representative_indices':len(component_representative_indices),
      'max_representatives_per_component':max(map(len,component_groups),default=0)}

if __name__=='__main__':
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('input');p.add_argument('output');p.add_argument('--report');a=p.parse_args()
    text,report=emit(json.loads(pathlib.Path(a.input).read_text()))
    destination=pathlib.Path(a.output);destination.parent.mkdir(parents=True,exist_ok=True)
    temporary=destination.with_suffix(destination.suffix+'.tmp');temporary.write_text(text);temporary.replace(destination)
    if a.report:pathlib.Path(a.report).write_text(json.dumps(report,indent=2)+'\n')
    print(json.dumps(report))
