#!/usr/bin/env python3
"""Compile C9C representative membership and sorted unique-trigger emission."""
import argparse,importlib.util,json,pathlib
ROOT=pathlib.Path(__file__).resolve().parents[2]
spec=importlib.util.spec_from_file_location('event_compiler',ROOT/'tools/warprandogen/compile_event_index.py')
module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module)

def emit(data):
    text,report=module.emit(data);built=module.build(data);normalized=built['normalized']
    text=text.replace('C8A','C9C').replace('C8a','C9c').replace('c8a','c9c')
    active_position={node:i for i,node in enumerate(built['active_nodes'])}
    representatives=[i for i,row in enumerate(normalized['nodes']) if row[3] and row[2]==i]
    grouped=sorted((row[2],active_position[node]) for node,row in enumerate(normalized['nodes']) if row[3])
    offsets=[];position=0
    for representative in range(len(normalized['nodes'])):
        offsets.append(position)
        while position<len(grouped) and grouped[position][0]==representative:position+=1
    offsets.append(position)
    indices=[active_index for _,active_index in grouped]
    representative_words=(len(representatives)+31)//32
    representative_index_by_node=[65535]*len(normalized['nodes'])
    component_groups=[[] for _ in range(built['components'])]
    for ordinal,node in enumerate(representatives):
        representative_index_by_node[node]=ordinal
        component_groups[built['node_component'][node]].append(ordinal)
    component_representative_offsets=[0]
    component_representative_indices=[]
    for group in component_groups:
        component_representative_indices.extend(group)
        component_representative_offsets.append(len(component_representative_indices))
    trigger_groups={}
    for node,row in enumerate(normalized['nodes']):
        if row[3]:trigger_groups.setdefault(tuple(row[1]),[]).append(node)
    emit_nodes=[];emit_index_by_node=[65535]*len(normalized['nodes'])
    for ordinal,trigger in enumerate(sorted(trigger_groups)):
        nodes=trigger_groups[trigger];representative=normalized['nodes'][nodes[0]][2]
        if any(normalized['nodes'][node][2]!=representative for node in nodes):
            raise ValueError(f'active trigger {trigger} maps through multiple representatives')
        emit_nodes.append(min(nodes))
        for node in nodes:emit_index_by_node[node]=ordinal
    def arr(name,rows):
        rows=list(rows)
        return f'static const uint16_t {name}[{max(1,len(rows))}] = {{\n'+''.join('    '+str(row)+',\n' for row in (rows or [0]))+'};\n'
    additions=(arr('c9c_representatives',representatives)+
               arr('c9c_representative_active_offsets',offsets)+
               arr('c9c_representative_active_indices',indices)+
               arr('c9c_representative_index_by_node',representative_index_by_node)+
               arr('c9c_component_representative_offsets',component_representative_offsets)+
               arr('c9c_component_representative_indices',component_representative_indices)+
               arr('c9c_emit_nodes',emit_nodes)+
               arr('c9c_emit_index_by_node',emit_index_by_node))
    marker='static const struct C9cIndex c9c_index = {\n'
    text=text.replace(marker,additions+marker)
    old=f"    {len(built['node_component'])},{built['components']},{built['words']},{len(built['active_nodes'])},{len(built['forward_conditional'])},\n"
    new=f"    {len(built['node_component'])},{built['components']},{built['words']},{len(built['active_nodes'])},{len(built['forward_conditional'])},{len(representatives)},{representative_words},{len(emit_nodes)},\n"
    text=text.replace(old,new)
    text=text.replace('    c9c_node_component,c9c_component_active_offsets,c9c_component_active_nodes,\n',
      '    c9c_node_component,c9c_component_active_offsets,c9c_component_active_nodes,\n'
      '    c9c_representatives,c9c_representative_active_offsets,c9c_representative_active_indices,\n'
      '    c9c_representative_index_by_node,c9c_component_representative_offsets,\n'
      '    c9c_component_representative_indices,c9c_emit_nodes,c9c_emit_index_by_node,\n')
    return text,report|{'symbol_namespace':'c9c','active_representatives':len(representatives),
      'representative_alias_indices':len(indices),
      'max_active_aliases_per_representative':max((offsets[i+1]-offsets[i] for i in representatives),default=0),
      'representative_words':representative_words,
      'component_representative_indices':len(component_representative_indices),
      'max_representatives_per_component':max(map(len,component_groups),default=0),
      'emit_records':len(emit_nodes),'active_aliases_elided':len(built['active_nodes'])-len(emit_nodes),
      'emit_index_nodes':len(emit_index_by_node)}

if __name__=='__main__':
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('input');p.add_argument('output');p.add_argument('--report');a=p.parse_args()
    text,report=emit(json.loads(pathlib.Path(a.input).read_text()))
    destination=pathlib.Path(a.output);destination.parent.mkdir(parents=True,exist_ok=True)
    temporary=destination.with_suffix(destination.suffix+'.tmp');temporary.write_text(text);temporary.replace(destination)
    if a.report:pathlib.Path(a.report).write_text(json.dumps(report,indent=2)+'\n')
    print(json.dumps(report))
