#!/usr/bin/env python3
"""Import pinned annotations into an explicitly reference-only normalized graph."""
import argparse, collections, hashlib, json, pathlib, sys
sys.path.insert(0,str(pathlib.Path(__file__).parent))
from compile import normalize

def convert(folder,overrides):
    raw={s:json.loads((folder/(s+'.json')).read_text()) for s in ['Warps','Flags','KeyLocations','EscapePaths']}
    warps=raw['Warps'];ids=sorted(warps);parent={s:s for s in ids}; issues=[]
    def find(s):
        if s not in parent: raise ValueError('invalid warp reference '+s)
        while s!=parent[s]:s=parent[s]
        return s
    def triple(s):
        parts=s.split(',')
        if len(parts)!=4 or parts[0]!='E':raise ValueError('invalid warp ID '+s)
        values=list(map(int,parts[1:]))
        if any(x<0 or x>127 for x in values):raise ValueError('out of range triple '+s)
        return values
    for s,w in warps.items():
        triple(s);triple(w['to'])
        for other in w.get('grouped',[]):
            a,b=find(s),find(other);parent[b]=a
            if s==other or s not in warps[other].get('grouped',[]):issues.append({'kind':'group_declaration','source':s,'member':other})
    groups=collections.defaultdict(list)
    for s in ids:groups[find(s)].append(s)
    rep={};active={};tags={}
    for members in groups.values():
        mains=[s for s in members if warps[s].get('groupMain')]
        if len(members)>1 and len(mains)!=1:raise ValueError('group needs exactly one representative: '+str(members))
        r=mains[0] if mains else members[0]
        eligible=all(not warps[s].get('ignore') and
            not set(warps[s].get('tags',[])) & {'removeable','extraDeadend'} and
            int(warps[s].get('level','0'))<=10 for s in members)
        mask=0
        for s in members:
            if 'needs_return' in warps[s].get('tags',[]):mask|=1
            if 'no_return' in warps[s].get('tags',[]):mask|=2
        for s in members:rep[s]=r;active[s]=eligible;tags[s]=mask
    # A destination-only contract cannot keep just one side of a mixed collision.
    changed=True
    while changed:
        changed=False; bytrigger=collections.defaultdict(list)
        for s in ids:bytrigger[warps[s]['to']].append(s)
        for trigger,members in bytrigger.items():
            if {active[s] for s in members}=={True,False}:
                rs={rep[s] for s in members if active[s]}
                for s in ids:
                    if rep[s] in rs:active[s]=False;changed=True
                issues.append({'kind':'excluded_trigger_collision','trigger':trigger,'representatives':sorted(rs)})
    locs={}
    for name in ['locationsTrigger','keyLocations']:
        for node,loc in raw['KeyLocations'][name].items():
            find(node)
            if loc in locs and locs[loc]!=node:raise ValueError('duplicate location '+loc)
            locs[loc]=node
    flags=raw['Flags']['compositeFlags'];caps=sorted({r['flag'] for r in flags.values()}|set(overrides['blocked_capabilities']))
    aliases=overrides['aliases']
    for alias,target in aliases.items():
        if alias not in flags or flags[alias]['flag']!=target:raise ValueError('unproven alias '+alias)
    policy=overrides.get('unknown_requirement_policy','unavailable')
    if policy not in ('unavailable','error'):raise ValueError('invalid unknown requirement policy')
    def cap(c):
        c=aliases.get(c,c)
        if c not in caps:
            if policy=='error':raise ValueError('unknown requirement '+c)
            caps.append(c)
            issues.append({'kind':'unresolved_requirement_unavailable','requirement':c})
        return c
    rules=[]
    for k,r in sorted(flags.items()):
        req=[]
        for q in r['condition']:
            req.append({'location':locs[q]} if q in locs else {'capability':cap(q)})
        rules.append({'grant':r['flag'],'requires':req})
    edges=[]
    def add(a,b,c=None):find(a);find(b);edges.append({'from':a,'to':b,'requires':c})
    for s,w in warps.items():
        for t,c in w.get('connections',{}).items():
            if c is True:add(s,t)
            elif c is False:issues.append({'kind':'explicit_closed_edge','from':s,'to':t})
            elif isinstance(c,str):add(s,t,cap(c))
            else:raise ValueError('invalid connection '+s)
        if not active[s]:
            if w['to'] in warps:add(s,w['to'])
            else:issues.append({'kind':'unmodeled_excluded_vanilla_destination','source':s,'to':w['to']})
        if rep[s]!=s:add(s,rep[s]);add(rep[s],s)
    for name in ['rootCandidates','oddOnOutWarps','oddOnOutWithDeadendsRemovedWarps']:
        for s in raw['KeyLocations'][name]:find(s)
    for group in raw['EscapePaths']['paths']:
        for s in group:find(s)
    d={'schema':2,'description':'REFERENCE ANNOTATIONS ONLY: not approved target gameplay data',
       'capabilities':sorted(caps),'nodes':[{'name':s,'id':triple(s),'trigger':triple(warps[s]['to']),
       'rep':rep[s],'active':active[s],'tags':tags[s]} for s in ids],
       'edges':sorted(edges,key=lambda e:json.dumps(e,sort_keys=True)),'rules':rules,
       'root':raw['KeyLocations']['rootCandidates'][0],
       'goals':sorted(raw['KeyLocations']['keyLocations'])}
    norm=normalize(d)
    report={'scope':'reference-only, not target-certified','physical_nodes':len(ids),
      'canonical_nodes':len(groups),'active_canonical':sum(active[s] and rep[s]==s for s in ids),
      'group_reference_max':max(ids.index(rep[s]) for s in ids),
      'group_members_above_255':sum(ids.index(s)>255 and rep[s]!=s for s in ids),
      'edges':len(norm['edges']),'capabilities':len(caps),'rules':len(rules),
      'max_requirements':max(len(r['requires']) for r in rules),'escape_groups':len(raw['EscapePaths']['paths']),
      'fingerprint':norm['sha256'],'unknown_requirement_policy':policy,
      'ungrantable_capabilities':sorted(set(caps)-{r['grant'] for r in rules}),'issues':issues,
      'inputs':{s:hashlib.sha256((folder/(s+'.json')).read_bytes()).hexdigest() for s in raw}}
    return d,report
if __name__=='__main__':
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('data');p.add_argument('overrides');p.add_argument('output');p.add_argument('report');a=p.parse_args()
    try:
        d,r=convert(pathlib.Path(a.data),json.loads(pathlib.Path(a.overrides).read_text()))
        for path,value in [(a.output,d),(a.report,r)]:pathlib.Path(path).write_text(json.dumps(value,indent=2)+'\n')
    except (ValueError,KeyError,TypeError) as e:p.exit(1,f'error: {e}\n')
