#!/usr/bin/env python3
"""Compile independently validated Algorithm-3 layouts into the schema-1 bank."""
import argparse,hashlib,json,os,pathlib,struct,subprocess,sys,tempfile,time,zlib

ROOT=pathlib.Path(__file__).resolve().parents[2]
sys.path.insert(0,str(ROOT/'tests'))
from validate import validate

MIXER=(b'add9e3779b9/xor16-mul85ebca6b/'
       b'xor13-mulc2b2ae35/xor16/mask-count-minus-1')

def canonical(triggers,landings,crcs):
    head=b'WRBK'+struct.pack('<IIII',1,4,len(landings),len(triggers)//3)
    head+=struct.pack('<I',len(MIXER))+MIXER
    return head+triggers+b''.join(landings)+b''.join(struct.pack('<I',v) for v in crcs)

def row_bytes(trigger_bytes,landing_bytes):
    return b''.join(trigger_bytes[i:i+3]+landing_bytes[i:i+3]
                    for i in range(0,len(trigger_bytes),3))

def triple_rows(name,values,dimensions,nested=False):
    lines=[f'static const uint8_t {name}{dimensions} = {{']
    if not nested:
        lines.extend(f'    {{{a},{b},{c}}},' for a,b,c in zip(values[::3],values[1::3],values[2::3]))
    else:
        records=len(values[0])//3
        for layout in values:
            lines.append('    {')
            lines.extend(f'        {{{a},{b},{c}}},'
                         for a,b,c in zip(layout[::3],layout[1::3],layout[2::3]))
            if len(layout)//3 != records: raise ValueError('inconsistent layout')
            lines.append('    },')
    lines.append('};')
    return lines

def render_header(triggers,landings,crcs,fingerprint):
    count=len(landings);records=len(triggers)//3
    lines=['#ifndef WR_REFERENCE_BANK_H','#define WR_REFERENCE_BANK_H',
           '#include "warp_bank.h"',
           '/* Generated schema 1 bank; no timestamp or paths. */',
           f'#define WR_REFERENCE_BANK_LAYOUTS {count}u',
           f'#define WR_REFERENCE_BANK_RECORDS {records}u']
    lines+=triple_rows('wr_bank_triggers',triggers,f'[{records}][3]')
    lines+=triple_rows('wr_bank_landings',landings,f'[{count}][{records}][3]',True)
    lines.append(f'static const uint32_t wr_bank_row_crc32[{count}] = {{')
    lines.append('    '+','.join(f'0x{value:08x}u' for value in crcs))
    lines.append('};')
    fp=','.join(f'0x{value:02x}' for value in fingerprint)
    lines+=['static const struct WrBank wr_reference_bank = {',
            '    WR_REFERENCE_BANK_LAYOUTS,WR_REFERENCE_BANK_RECORDS,',
            '    &wr_bank_triggers[0][0],&wr_bank_landings[0][0][0],',
            '    wr_bank_row_crc32,{'+fp+'}',
            '};','#endif','']
    return '\n'.join(lines)

def generate(count):
    model=json.loads((ROOT/'data/reference-normalized.json').read_text())
    layouts=[];layout_meta=[];triggers=None
    with tempfile.TemporaryDirectory() as temporary:
        temp=pathlib.Path(temporary)
        (temp/'graph.h').write_bytes((ROOT/'data/reference-graph.h').read_bytes())
        executable=temp/'run'
        subprocess.run([os.environ.get('CC','cc'),'-std=c99','-O2',
                        '-I'+str(ROOT/'include'),'-I'+str(temp),
                        str(ROOT/'src/warp_rando.c'),str(ROOT/'tests/harness.c'),
                        '-o',str(executable)],check=True)
        for seed in range(count):
            run=subprocess.run([str(executable),str(seed),'1'],capture_output=True,
                               text=True,check=True)
            result=json.loads(run.stdout)
            if result['result'] or not result['active'] or result['attempt']:
                raise SystemExit(f'seed {seed} did not accept its first attempt')
            rows=result['records'];validate(model,rows)
            current_triggers=bytes(value for row in rows for value in row[:3])
            landing=bytes(value for row in rows for value in row[3:])
            if triggers is None: triggers=current_triggers
            elif current_triggers!=triggers: raise SystemExit('layout triggers differ')
            layouts.append(landing)
            layout_meta.append({'index':seed,'source_seed':seed,
                                'landing_sha256':hashlib.sha256(landing).hexdigest()})
    return triggers,layouts,layout_meta

def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--count',type=int,default=32)
    parser.add_argument('--header',default=str(ROOT/'data/reference-bank.h'))
    parser.add_argument('--report',default=str(ROOT/'reports/reference-bank.json'))
    args=parser.parse_args()
    if args.count<2 or args.count>256 or args.count&(args.count-1):
        parser.error('--count must be a power of two from 2 through 256')
    start=time.perf_counter()
    triggers,landings,layout_meta=generate(args.count)
    crcs=[zlib.crc32(row_bytes(triggers,row)) for row in landings]
    fingerprint=hashlib.sha256(canonical(triggers,landings,crcs)).digest()
    header=render_header(triggers,landings,crcs,fingerprint)
    if header!=render_header(triggers,landings,crcs,fingerprint):
        raise SystemExit('nondeterministic header emitter')
    header_path=pathlib.Path(args.header).resolve();header_path.parent.mkdir(parents=True,exist_ok=True)
    header_path.write_text(header)
    report={
      'checkpoint':'C6B','format':{'schema':1,'algorithm':4,'ruleset':1,
        'layouts':args.count,'records_per_layout':len(triggers)//3,
        'encoding':'shared packed trigger triples; packed landing triples per layout; interleaved-row CRC32',
        'selector':MIXER.decode()},
      'source':{'algorithm':3,'seeds':list(range(args.count)),
        'all_first_attempt':True,'independent_validation':'all layouts accepted the reference abstraction'},
      'identity':{'bank_sha256':fingerprint.hex()},
      'payload':{'trigger_bytes':len(triggers),'landing_bytes':sum(map(len,landings)),
        'crc32_bytes':4*len(crcs),'total_packed_bytes':len(triggers)+sum(map(len,landings))+4*len(crcs)},
      'layouts':[{**row,'crc32':f'{crc:08x}'} for row,crc in zip(layout_meta,crcs)],
      'sha256':{'header':hashlib.sha256(header.encode()).hexdigest(),
        'core':hashlib.sha256((ROOT/'src/warp_rando.c').read_bytes()).hexdigest(),
        'graph':hashlib.sha256((ROOT/'data/reference-graph.h').read_bytes()).hexdigest(),
        'normalized_input':hashlib.sha256((ROOT/'data/reference-normalized.json').read_bytes()).hexdigest()},
      'determinism':'header emitter reproduced byte-for-byte from the generated in-memory layouts',
    }
    report_path=pathlib.Path(args.report).resolve();report_path.parent.mkdir(parents=True,exist_ok=True)
    report_path.write_text(json.dumps(report,indent=2)+'\n')
    print(json.dumps({'layouts':args.count,'records':len(triggers)//3,
      'packed_bytes':report['payload']['total_packed_bytes'],
      'bank_sha256':fingerprint.hex(),'header_sha256':report['sha256']['header'],
      'host_seconds':round(time.perf_counter()-start,3)},indent=2))

if __name__=='__main__': main()
