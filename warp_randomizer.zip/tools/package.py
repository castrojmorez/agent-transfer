#!/usr/bin/env python3
"""Package only handoff sources/data/docs/reports, never runtime scratch files."""
import hashlib,json,pathlib,sys,zipfile
root=pathlib.Path(__file__).resolve().parents[1]
allowed={'data','docs','include','licenses','patches','reports','src','tests','tools'}
files=[]
for p in sorted(root.rglob('*')):
    if not p.is_file():continue
    rel=p.relative_to(root)
    if rel.parts[0] not in allowed and str(rel) not in {'README.md','STATUS.md','PROVENANCE.md','HANDOFF.md','Makefile'}:continue
    if '__pycache__' in rel.parts or p.suffix=='.pyc' or str(rel)=='reports/manifest.json':continue
    files.append(p)
manifest={str(p.relative_to(root)):hashlib.sha256(p.read_bytes()).hexdigest() for p in files}
(root/'reports/manifest.json').write_text(json.dumps(manifest,indent=2)+'\n');files.append(root/'reports/manifest.json')
if len(sys.argv)!=2:raise SystemExit('usage: package.py OUTPUT.zip')
archive=pathlib.Path(sys.argv[1]);archive.parent.mkdir(parents=True,exist_ok=True)
with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED,compresslevel=9) as z:
    for p in sorted(files):
        name='GLM_Random_Warp_Port/'+str(p.relative_to(root))
        info=zipfile.ZipInfo(name,date_time=(2026,9,4,0,0,0));info.compress_type=zipfile.ZIP_DEFLATED;info.external_attr=0o100644<<16
        z.writestr(info,p.read_bytes())
with zipfile.ZipFile(archive) as z:
    assert z.testzip() is None
    for rel,digest in manifest.items():assert hashlib.sha256(z.read('GLM_Random_Warp_Port/'+rel)).hexdigest()==digest
print(json.dumps({'files':len(files),'bytes':archive.stat().st_size,'sha256':hashlib.sha256(archive.read_bytes()).hexdigest()},indent=2))
