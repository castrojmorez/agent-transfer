#!/usr/bin/env python3
"""Prove C9C cold/warm indexed-emission equivalence and host timing."""
import argparse,hashlib,json,pathlib,re,subprocess,sys,time
ROOT=pathlib.Path(__file__).resolve().parents[2]
sys.path.insert(0,str(ROOT/'tests'))
from validate import validate,Invalid
p=argparse.ArgumentParser(description=__doc__)
p.add_argument('--stress-seeds',type=int,default=1024)
p.add_argument('--benchmark-repetitions',type=int,default=10)
a=p.parse_args()
SEEDS=list(range(64))+[255,256,65535,4294967295]
build=ROOT/'build/c9c';build.mkdir(parents=True,exist_ok=True)
data_path=ROOT/'data/reference-normalized.json';graph=build/'graph.h'
subprocess.run([sys.executable,str(ROOT/'tools/warprandogen/compile.py'),str(data_path),str(graph)],check=True)
subprocess.run([sys.executable,str(ROOT/'tools/warprandogen/compile_c9a_index.py'),str(data_path),
                str(build/'reference-c9a-event-index.h')],check=True)
subprocess.run([sys.executable,str(ROOT/'tools/warprandogen/compile_c9b_index.py'),str(data_path),
                str(build/'reference-c9b-event-index.h')],check=True)
subprocess.run([sys.executable,str(ROOT/'tools/warprandogen/compile_c9c_index.py'),str(data_path),
                str(build/'reference-c9c-event-index.h'),'--report',str(ROOT/'reports/reference-c9c-event-index.json')],check=True)
common=['cc','-std=c99','-Wall','-Wextra','-Werror','-pedantic','-O2','-fstack-usage',
        '-I'+str(ROOT/'include'),'-I'+str(build)]
prior=build/'c9a';c9b=build/'c9b';candidate=build/'c9c'
subprocess.run([*common,str(ROOT/'tools/experiments/c9a_candidate.c'),'-o',str(prior)],check=True)
subprocess.run([*common,str(ROOT/'tools/experiments/c9b_candidate.c'),'-o',str(c9b)],check=True)
subprocess.run([*common,str(ROOT/'tools/experiments/c9c_candidate.c'),'-o',str(candidate)],check=True)
data=json.loads(data_path.read_text());rows=[]
keys=('result','last_rejection','attempt','records','attempts','pairs','eligible_partners',
      'partner_trials','state_evaluations','forward_components','reverse_components',
      'repair_components','active_visits','conditional_visits','row_ors',
      'representative_bit_visits','pair_alias_visits','reverse_calls',
      'reverse_edge_updates','set_word_ops','score_word_ops','component_rep_updates','work_bytes')
for position,seed in enumerate(SEEDS):
    start=time.perf_counter();before=json.loads(subprocess.check_output([str(prior),str(seed),'3','8'],text=True))
    before_time=time.perf_counter()-start
    start=time.perf_counter();middle=json.loads(subprocess.check_output([str(c9b),str(seed),'3','8'],text=True))
    middle_time=time.perf_counter()-start
    start=time.perf_counter();result=json.loads(subprocess.check_output([str(candidate),str(seed),'3','8'],text=True))
    elapsed=time.perf_counter()-start
    replay=json.loads(subprocess.check_output([str(candidate),str(seed),'3','8'],text=True))
    if any(before[k]!=middle[k] or before[k]!=result[k] for k in keys):raise SystemExit(f'C9A/C9B/C9C mismatch seed {seed}')
    if result!=replay:raise SystemExit(f'C9C replay mismatch seed {seed}')
    if result['result']!=0:raise SystemExit(f'C9C failure seed {seed}: {result}')
    try:validate(data,result['records'])
    except Invalid as e:raise SystemExit(f'C9C/Python disagreement seed {seed}: {e}')
    records=result.pop('records')
    rows.append(result|{'seed':seed,'record_sha256':hashlib.sha256(
      json.dumps(records,separators=(',',':')).encode()).hexdigest(),
      'host_seconds':elapsed,'c9b_host_seconds':middle_time,'c9a_host_seconds':before_time})
    if position%16==15:print('completed',position+1,'of',len(SEEDS),flush=True)
stress=[]
for seed in range(a.stress_seeds):
    before=json.loads(subprocess.check_output([str(prior),str(seed),'3','8'],text=True))
    result=json.loads(subprocess.check_output([str(candidate),str(seed),'3','8'],text=True))
    replay=json.loads(subprocess.check_output([str(candidate),str(seed),'3','8'],text=True))
    if any(before[k]!=result[k] for k in keys):raise SystemExit(f'C9A/C9C stress mismatch seed {seed}')
    if result!=replay:raise SystemExit(f'C9C stress replay mismatch seed {seed}')
    records=result.pop('records')
    if result['result']==0:
        try:validate(data,records)
        except Invalid as e:raise SystemExit(f'C9C stress/Python disagreement seed {seed}: {e}')
    elif records:raise SystemExit(f'C9C stress published rejected records seed {seed}')
    stress.append({'seed':seed,'result':result['result'],'attempt':result['attempt'],
                   'attempts':result['attempts'],'partner_trials':result['partner_trials']})
    if seed%256==255:print('stress completed',seed+1,'of',a.stress_seeds,flush=True)
benchmarks={}
for name,define in [('c9a','BENCH_C9A'),('c9b','BENCH_C9B'),
                    ('c9c_cold','BENCH_C9C'),('c9c_warm','BENCH_C9C_WARM')]:
    exe=build/('bench-'+name)
    subprocess.run([*common,'-D'+define,str(ROOT/'tools/experiments/candidate_benchmark.c'),'-o',str(exe)],check=True)
    start=time.perf_counter();output=subprocess.check_output([str(exe),str(a.benchmark_repetitions)],text=True).strip()
    benchmarks[name]={'seconds':time.perf_counter()-start,'output':output}
if len({row['output'] for row in benchmarks.values()})!=1:
    raise SystemExit('C9A/C9B/C9C in-process benchmark digest mismatch')
def frames(exe_name):
    result=[]
    for path in build.glob(exe_name+'-*.su'):
        for line in path.read_text().splitlines():
            match=re.search(r':([^:\t]+)\t(\d+)\t(.+)$',line)
            if match:result.append({'function':match.group(1),'bytes':int(match.group(2)),'kind':match.group(3)})
    return result
meta=json.loads((ROOT/'reports/reference-c9c-event-index.json').read_text())
report={'checkpoint':'C9C host','status':'experimental; no public/save identity',
 'scope':'68-seed exact C9A cap-three equivalence plus 1024-seed stress and in-process timing',
 'seeds':SEEDS,'successes':len(rows),'exact_c9a_matches':len(rows),
 'deterministic_replays':len(rows),'independent_validations':len(rows),
 'first_attempt_successes':sum(row['attempt']==0 for row in rows),
 'max_attempts':max(row['attempts'] for row in rows),
 'host_seconds_total':sum(row['host_seconds'] for row in rows),
 'c9b_host_seconds_total':sum(row['c9b_host_seconds'] for row in rows),
 'c9a_host_seconds_total':sum(row['c9a_host_seconds'] for row in rows),
 'same_run_process_speedup':sum(row['c9a_host_seconds'] for row in rows)/sum(row['host_seconds'] for row in rows),
 'in_process_benchmark':benchmarks,
 'same_run_process_speedup_vs_c9b':sum(row['c9b_host_seconds'] for row in rows)/sum(row['host_seconds'] for row in rows),
 'in_process_cold_speedup_vs_c9b':benchmarks['c9b']['seconds']/benchmarks['c9c_cold']['seconds'],
 'in_process_warm_speedup_vs_c9b':benchmarks['c9b']['seconds']/benchmarks['c9c_warm']['seconds'],
 'in_process_warm_speedup_vs_c9a':benchmarks['c9a']['seconds']/benchmarks['c9c_warm']['seconds'],
 'cap3_stress':{'seeds':len(stress),'successes':sum(row['result']==0 for row in stress),
   'failures':sum(row['result']!=0 for row in stress),
   'exact_c9a_matches':len(stress),'deterministic_replays':len(stress),
   'independent_validations':sum(row['result']==0 for row in stress),
   'first_attempt_successes':sum(row['result']==0 and row['attempt']==0 for row in stress),
   'max_attempts':max((row['attempts'] for row in stress),default=0)},
 'profiled_change':{'cold_reference_validations_per_generation':1,
   'warm_reference_validations_per_benchmark':1,
   'runtime_trigger_deduplication_removed':True,'runtime_record_sort_removed':True,
   'constructor_and_scoring_counters_unchanged':True,
   'representative_bit_visits':sum(row['representative_bit_visits'] for row in rows),
   'set_word_ops':sum(row['set_word_ops'] for row in rows),
   'score_word_ops':sum(row['score_word_ops'] for row in rows)},
 'host_work_bytes':rows[0]['work_bytes'],'index':meta,'host_stack_frames':frames('c9c'),
 'input_sha256':hashlib.sha256(data_path.read_bytes()).hexdigest(),
 'c9a_core_sha256':hashlib.sha256((ROOT/'tools/experiments/c9a_candidate_core.inc').read_bytes()).hexdigest(),
 'c9c_core_sha256':hashlib.sha256((ROOT/'tools/experiments/c9c_candidate_core.inc').read_bytes()).hexdigest(),
 'c9c_wrapper_sha256':hashlib.sha256((ROOT/'tools/experiments/c9c_candidate.c').read_bytes()).hexdigest(),
 'c9c_index_header_sha256':hashlib.sha256((build/'reference-c9c-event-index.h').read_bytes()).hexdigest(),
 'limitations':['Host process wall time includes launch and JSON overhead.',
  'Reference-model acceptance is not target-world completion.',
  'No public/save Algorithm 5 identity is assigned.'],'results':rows}
(ROOT/'reports/c9c-feasibility.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps({k:v for k,v in report.items() if k not in ('results','host_stack_frames')},indent=2))
