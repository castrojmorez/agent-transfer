#!/usr/bin/env python3
"""Consolidate checked C7A host evidence after the measured runs."""
import hashlib,json,pathlib,re
ROOT=pathlib.Path(__file__).resolve().parents[2]
candidate=json.loads((ROOT/'reports/c7a-feasibility.json').read_text())
baseline=json.loads((ROOT/'reports/c7a-algorithm3-baseline.json').read_text())
tests=json.loads((ROOT/'reports/c7a-test-cases.json').read_text())
cap=candidate['caps'][0]
if cap['trial_cap']!=4 or cap['successes']!=68 or baseline['successes']!=68:
    raise SystemExit('expected complete cap-4 candidate and Algorithm-3 control evidence')
if any(r['result'] for r in cap['results']) or any(r['records']==0 for r in tests if r['result']==0):
    raise SystemExit('unexpected candidate success evidence')
failed=[r for r in tests if r['result']]
if not failed or any(r['records'] for r in failed):
    raise SystemExit('failure-publication evidence missing')
su=(ROOT/'build/c7a/candidate-c7a_candidate.su').read_text().splitlines()
frames=[]
for line in su:
    m=re.search(r':([^:\t]+)\t(\d+)\t(.+)$',line)
    if m:frames.append({'function':m.group(1),'bytes':int(m.group(2)),'kind':m.group(3)})
eligible=sum(r['eligible_partners'] for r in cap['results'])
report={'checkpoint':'C7A','decision':'continue to C7B ARM measurement; do not assign Algorithm ID 5',
 'candidate_policy':'sample without replacement and score at most 4 partners per selected source; at most 8 whole-construction attempts',
 'reference_seeds':68,'candidate_successes':cap['successes'],
 'candidate_first_attempt_successes':cap['first_attempt_successes'],'candidate_max_attempts':cap['max_attempts'],
 'algorithm3_successes':baseline['successes'],'algorithm3_first_attempt_successes':baseline['first_attempt_successes'],
 'candidate_host_seconds_total':cap['host_seconds_total'],'algorithm3_host_seconds_total':baseline['host_seconds_total'],
 'host_total_speedup':baseline['host_seconds_total']/cap['host_seconds_total'],
 'candidate_partner_trials_total':cap['partner_trials_total'],'candidate_state_closures_total':cap['state_closures_total'],
 'candidate_path_eligible_partners_total':eligible,
 'candidate_path_trial_reduction':eligible/cap['partner_trials_total'],
 'candidate_max_partner_trials_one_seed':max(r['partner_trials'] for r in cap['results']),
 'candidate_max_state_closures_one_seed':max(r['state_closures'] for r in cap['results']),
 'deterministic_replay':'68/68 byte-identical process replays',
 'independent_validation':'68/68 accepted by tests/validate.py',
 'synthetic_executions':len(tests),'synthetic_failures_without_records':len(failed),
 'host_work_bytes':cap['results'][0]['work_bytes'],'known_target_work_bytes_from_c5':47388,
 'host_stack_frames':frames,'max_reported_host_stack_frame_bytes':max(f['bytes'] for f in frames),
 'limitations':['host-only experimental translation unit','same full WrWork memory as Algorithm 3',
  'no public/save algorithm identity','no ARM duration, ROM/RAM link, interactive play or target-world guarantee'],
 'input_sha256':candidate['input_sha256'],'algorithm3_core_sha256':candidate['algorithm3_core_sha256'],
 'candidate_sha256':candidate['candidate_sha256'],
 'candidate_core_sha256':candidate['candidate_core_sha256'],
 'candidate_report_sha256':hashlib.sha256((ROOT/'reports/c7a-feasibility.json').read_bytes()).hexdigest(),
 'baseline_report_sha256':hashlib.sha256((ROOT/'reports/c7a-algorithm3-baseline.json').read_bytes()).hexdigest(),
 'test_report_sha256':hashlib.sha256((ROOT/'reports/c7a-test-cases.json').read_bytes()).hexdigest()}
(ROOT/'reports/c7a-verification.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps(report,indent=2))
