#!/usr/bin/env python3
"""Build/run target engine tests or a normal proof ROM after applying documented patches."""
import argparse,hashlib,json,os,pathlib,re,shutil,subprocess,time
ROOT=pathlib.Path(__file__).resolve().parents[2]
p=argparse.ArgumentParser(description=__doc__)
p.add_argument('target');p.add_argument('prefix',help='local bootstrap prefix containing usr/bin')
p.add_argument('--mode',type=int,choices=[0,1],required=True);p.add_argument('--rom',action='store_true')
p.add_argument('--generator-probe',action='store_true',help='stage and run the full-reference generator lifetime probe')
p.add_argument('--bank-probe',action='store_true',help='stage and run the Algorithm-4 precomputed-bank probe')
p.add_argument('--c7a-probe',action='store_true',help='stage and run the C7A bounded-candidate ARM probe')
p.add_argument('--c7c-probe',action='store_true',help='stage and run the C7C SCC/bitset ARM probe')
p.add_argument('--c8a-probe',action='store_true',help='stage and run the C8A event-driven ARM probe')
p.add_argument('--c8b-probe',action='store_true',help='stage and run the C8B cap-3 trial-volume ARM probe')
p.add_argument('--c8c-probe',action='store_true',help='stage and run the C8C indexed-state ARM probe')
p.add_argument('--c9a-probe',action='store_true',help='stage and run the C9A representative-bitset ARM probe')
p.add_argument('--c9b-probe',action='store_true',help='stage and run the C9B validated-emission ARM probe')
p.add_argument('--c9c-probe',action='store_true',help='stage and run the C9C cold/warm indexed-emission ARM probe')
p.add_argument('--c10a-probe',action='store_true',help='stage and run the C10A cooperative-step ARM probe')
p.add_argument('--c10b-probe',action='store_true',help='stage and run the C10B microstep ARM probe')
p.add_argument('--c10c-probe',action='store_true',help='stage and run the C10C budgeted task ARM probe')
p.add_argument('--c10d-probe',action='store_true',help='stage and run the C10D rendered loading-flow ARM probe')
p.add_argument('--jobs',type=int,default=4);p.add_argument('--log',required=True)
a=p.parse_args();target=pathlib.Path(a.target).resolve();prefix=pathlib.Path(a.prefix).resolve();tc=prefix/'usr'
if a.jobs<1:p.error('jobs must be positive')
sha=subprocess.check_output(['git','-C',str(target),'rev-parse','HEAD'],text=True).strip()
if sha!='e8bd1cd7b03fc032ea37e3ecd38b379b5d01a1e7':p.error('target is not pinned expansion/1.17.0')
header=target/'include/warp_rando_proof.h'
if not header.is_file():p.error('apply the fixed proof patch first; see patches/engine-tests/README.md')
if sum((a.generator_probe,a.bank_probe,a.c7a_probe,a.c7c_probe,a.c8a_probe,a.c8b_probe,a.c8c_probe,a.c9a_probe,a.c9b_probe,a.c9c_probe,a.c10a_probe,a.c10b_probe,a.c10c_probe,a.c10d_probe))>1:p.error('choose only one runtime probe')
if a.rom and (a.generator_probe or a.bank_probe or a.c7a_probe or a.c7c_probe or a.c8a_probe or a.c8b_probe or a.c8c_probe or a.c9a_probe or a.c9b_probe or a.c9c_probe or a.c10a_probe or a.c10b_probe or a.c10c_probe or a.c10d_probe):p.error('runtime probes are test-only')
s=header.read_text();s,n=re.subn(r'#define WR_PROOF_ENABLED [01]\b','#define WR_PROOF_ENABLED '+str(a.mode),s)
if n!=1:p.error('unexpected proof enable definition')
header.write_text(s)
env=dict(os.environ);env['PATH']=str(tc/'bin')+os.pathsep+env['PATH']
env['LD_LIBRARY_PATH']=str(tc/'lib/x86_64-linux-gnu')+(':'+env['LD_LIBRARY_PATH'] if env.get('LD_LIBRARY_PATH') else '')
env['PKG_CONFIG_LIBDIR']=str(tc/'lib/x86_64-linux-gnu/pkgconfig');env['PKG_CONFIG_SYSROOT_DIR']=str(prefix)
# Quotes are consumed by make's recipe shell; reject paths outside this simple contract.
if any(c in str(tc) for c in "'\n\r"):p.error('tool prefix must not contain apostrophes or line breaks')
cc="cc -I'"+str(tc/'include')+"' -L'"+str(tc/'lib/x86_64-linux-gnu')+"'"
args=['make','-j'+str(a.jobs),'CC='+cc]
if a.rom:args+=['rom']
else:
    test_sources=['test/test_runner.c','test/test_runner_battle.c','test/test_runner_args.c',
                  'test/test_test_runner.c','test/warp_rando_proof.c']
    test_files=[target/'test/warp_rando_proof.c']
    test_filter='WarpProof:'
    if a.generator_probe:
        staged=[(ROOT/'include/warp_rando.h',target/'include/warp_rando.h'),
                (ROOT/'src/warp_rando.c',target/'test/warp_rando_core.c'),
                (ROOT/'data/reference-graph.h',target/'test/warp_reference_graph.h'),
                (ROOT/'patches/engine-tests/warp_rando_generator.c',target/'test/warp_rando_generator.c')]
        for source,destination in staged:
            if not source.is_file():p.error('missing generator-probe input: '+str(source))
            shutil.copyfile(source,destination)
        test_sources+=['test/warp_rando_core.c','test/warp_rando_generator.c']
        test_files.append(target/'test/warp_rando_generator.c');test_filter='Warp'
    if a.bank_probe:
        staged=[(ROOT/'include/warp_rando.h',target/'include/warp_rando.h'),
                (ROOT/'include/warp_bank.h',target/'include/warp_bank.h'),
                (ROOT/'src/warp_rando.c',target/'test/warp_rando_core.c'),
                (ROOT/'src/warp_bank.c',target/'test/warp_bank_core.c'),
                (ROOT/'data/reference-bank.h',target/'include/warp_reference_bank.h'),
                (ROOT/'patches/engine-tests/warp_rando_bank.c',target/'test/warp_rando_bank.c')]
        for source,destination in staged:
            if not source.is_file():p.error('missing bank-probe input: '+str(source))
            shutil.copyfile(source,destination)
        test_sources+=['test/warp_rando_core.c','test/warp_bank_core.c','test/warp_rando_bank.c']
        test_files.append(target/'test/warp_rando_bank.c');test_filter='Warp'
    if a.c7a_probe:
        staged=[(ROOT/'include/warp_rando.h',target/'include/warp_rando.h'),
                (ROOT/'src/warp_rando.c',target/'test/warp_rando_core.c'),
                (ROOT/'data/reference-graph.h',target/'test/warp_reference_graph.h'),
                (ROOT/'tools/experiments/c7a_candidate_core.inc',target/'test/c7a_candidate_core.inc'),
                (ROOT/'patches/engine-tests/warp_rando_c7b.c',target/'test/warp_rando_c7b.c')]
        for source,destination in staged:
            if not source.is_file():p.error('missing C7A-probe input: '+str(source))
            shutil.copyfile(source,destination)
        test_sources+=['test/warp_rando_c7b.c']
        test_files.append(target/'test/warp_rando_c7b.c');test_filter='Warp'
    if a.c7c_probe:
        staged=[(ROOT/'include/warp_rando.h',target/'include/warp_rando.h'),
                (ROOT/'src/warp_rando.c',target/'test/warp_rando_core.c'),
                (ROOT/'data/reference-graph.h',target/'test/warp_reference_graph.h'),
                (ROOT/'data/reference-closure.h',target/'test/warp_reference_closure.h'),
                (ROOT/'tools/experiments/c7c_candidate_core.inc',target/'test/c7c_candidate_core.inc'),
                (ROOT/'patches/engine-tests/warp_rando_c7c.c',target/'test/warp_rando_c7c.c')]
        for source,destination in staged:
            if not source.is_file():p.error('missing C7C-probe input: '+str(source))
            shutil.copyfile(source,destination)
        test_sources+=['test/warp_rando_c7c.c']
        test_files.append(target/'test/warp_rando_c7c.c');test_filter='Warp'
    if a.c8a_probe:
        staged=[(ROOT/'include/warp_rando.h',target/'include/warp_rando.h'),
                (ROOT/'src/warp_rando.c',target/'test/warp_rando_core.c'),
                (ROOT/'data/reference-graph.h',target/'test/warp_reference_graph.h'),
                (ROOT/'data/reference-event-index.h',target/'test/warp_reference_event_index.h'),
                (ROOT/'tools/experiments/c8a_candidate_core.inc',target/'test/c8a_candidate_core.inc'),
                (ROOT/'patches/engine-tests/warp_rando_c8a.c',target/'test/warp_rando_c8a.c')]
        for source,destination in staged:
            if not source.is_file():p.error('missing C8A-probe input: '+str(source))
            shutil.copyfile(source,destination)
        test_sources+=['test/warp_rando_c8a.c']
        test_files.append(target/'test/warp_rando_c8a.c');test_filter='Warp'
    if a.c8b_probe:
        staged=[(ROOT/'include/warp_rando.h',target/'include/warp_rando.h'),
                (ROOT/'src/warp_rando.c',target/'test/warp_rando_core.c'),
                (ROOT/'data/reference-graph.h',target/'test/warp_reference_graph.h'),
                (ROOT/'data/reference-c8b-event-index.h',target/'test/warp_reference_c8b_event_index.h'),
                (ROOT/'tools/experiments/c8b_candidate_core.inc',target/'test/c8b_candidate_core.inc'),
                (ROOT/'patches/engine-tests/warp_rando_c8b.c',target/'test/warp_rando_c8b.c')]
        for source,destination in staged:
            if not source.is_file():p.error('missing C8B-probe input: '+str(source))
            shutil.copyfile(source,destination)
        test_sources+=['test/warp_rando_c8b.c']
        test_files.append(target/'test/warp_rando_c8b.c');test_filter='Warp'
    if a.c8c_probe:
        staged=[(ROOT/'include/warp_rando.h',target/'include/warp_rando.h'),
                (ROOT/'src/warp_rando.c',target/'test/warp_rando_core.c'),
                (ROOT/'data/reference-graph.h',target/'test/warp_reference_graph.h'),
                (ROOT/'data/reference-c8c-event-index.h',target/'test/warp_reference_c8c_event_index.h'),
                (ROOT/'tools/experiments/c8c_candidate_core.inc',target/'test/c8c_candidate_core.inc'),
                (ROOT/'patches/engine-tests/warp_rando_c8c.c',target/'test/warp_rando_c8c.c')]
        for source,destination in staged:
            if not source.is_file():p.error('missing C8C-probe input: '+str(source))
            shutil.copyfile(source,destination)
        test_sources+=['test/warp_rando_c8c.c']
        test_files.append(target/'test/warp_rando_c8c.c');test_filter='Warp'
    if a.c9a_probe:
        staged=[(ROOT/'include/warp_rando.h',target/'include/warp_rando.h'),
                (ROOT/'src/warp_rando.c',target/'test/warp_rando_core.c'),
                (ROOT/'data/reference-graph.h',target/'test/warp_reference_graph.h'),
                (ROOT/'data/reference-c9a-event-index.h',target/'test/warp_reference_c9a_event_index.h'),
                (ROOT/'tools/experiments/c9a_candidate_core.inc',target/'test/c9a_candidate_core.inc'),
                (ROOT/'patches/engine-tests/warp_rando_c9a.c',target/'test/warp_rando_c9a.c')]
        for source,destination in staged:
            if not source.is_file():p.error('missing C9A-probe input: '+str(source))
            shutil.copyfile(source,destination)
        test_sources+=['test/warp_rando_c9a.c']
        test_files.append(target/'test/warp_rando_c9a.c');test_filter='Warp'
    if a.c9b_probe:
        staged=[(ROOT/'include/warp_rando.h',target/'include/warp_rando.h'),
                (ROOT/'src/warp_rando.c',target/'test/warp_rando_core.c'),
                (ROOT/'data/reference-graph.h',target/'test/warp_reference_graph.h'),
                (ROOT/'data/reference-c9b-event-index.h',target/'test/warp_reference_c9b_event_index.h'),
                (ROOT/'tools/experiments/c9b_candidate_core.inc',target/'test/c9b_candidate_core.inc'),
                (ROOT/'patches/engine-tests/warp_rando_c9b.c',target/'test/warp_rando_c9b.c')]
        for source,destination in staged:
            if not source.is_file():p.error('missing C9B-probe input: '+str(source))
            shutil.copyfile(source,destination)
        test_sources+=['test/warp_rando_c9b.c']
        test_files.append(target/'test/warp_rando_c9b.c');test_filter='Warp'
    if a.c9c_probe:
        staged=[(ROOT/'include/warp_rando.h',target/'include/warp_rando.h'),
                (ROOT/'src/warp_rando.c',target/'test/warp_rando_core.c'),
                (ROOT/'data/reference-graph.h',target/'test/warp_reference_graph.h'),
                (ROOT/'data/reference-c9c-event-index.h',target/'test/warp_reference_c9c_event_index.h'),
                (ROOT/'tools/experiments/c9c_candidate_core.inc',target/'test/c9c_candidate_core.inc'),
                (ROOT/'patches/engine-tests/warp_rando_c9c.c',target/'test/warp_rando_c9c.c')]
        for source,destination in staged:
            if not source.is_file():p.error('missing C9C-probe input: '+str(source))
            shutil.copyfile(source,destination)
        test_sources+=['test/warp_rando_c9c.c']
        test_files.append(target/'test/warp_rando_c9c.c');test_filter='Warp'
    if a.c10a_probe:
        staged=[(ROOT/'include/warp_rando.h',target/'include/warp_rando.h'),
                (ROOT/'src/warp_rando.c',target/'test/warp_rando_core.c'),
                (ROOT/'data/reference-graph.h',target/'test/warp_reference_graph.h'),
                (ROOT/'data/reference-c9c-event-index.h',target/'test/warp_reference_c9c_event_index.h'),
                (ROOT/'tools/experiments/c9c_candidate_core.inc',target/'test/c9c_candidate_core.inc'),
                (ROOT/'tools/experiments/c10a_candidate_core.inc',target/'test/c10a_candidate_core.inc'),
                (ROOT/'patches/engine-tests/warp_rando_c10a.c',target/'test/warp_rando_c10a.c')]
        for source,destination in staged:
            if not source.is_file():p.error('missing C10A-probe input: '+str(source))
            shutil.copyfile(source,destination)
        test_sources+=['test/warp_rando_c10a.c']
        test_files.append(target/'test/warp_rando_c10a.c');test_filter='Warp'
    if a.c10b_probe:
        staged=[(ROOT/'include/warp_rando.h',target/'include/warp_rando.h'),
                (ROOT/'src/warp_rando.c',target/'test/warp_rando_core.c'),
                (ROOT/'data/reference-graph.h',target/'test/warp_reference_graph.h'),
                (ROOT/'data/reference-c9c-event-index.h',target/'test/warp_reference_c9c_event_index.h'),
                (ROOT/'tools/experiments/c9c_candidate_core.inc',target/'test/c9c_candidate_core.inc'),
                (ROOT/'tools/experiments/c10b_candidate_core.inc',target/'test/c10b_candidate_core.inc'),
                (ROOT/'patches/engine-tests/warp_rando_c10b.c',target/'test/warp_rando_c10b.c')]
        for source,destination in staged:
            if not source.is_file():p.error('missing C10B-probe input: '+str(source))
            shutil.copyfile(source,destination)
        test_sources+=['test/warp_rando_c10b.c']
        test_files.append(target/'test/warp_rando_c10b.c');test_filter='Warp'
    if a.c10c_probe:
        staged=[(ROOT/'include/warp_rando.h',target/'include/warp_rando.h'),
                (ROOT/'src/warp_rando.c',target/'test/warp_rando_core.c'),
                (ROOT/'data/reference-graph.h',target/'test/warp_reference_graph.h'),
                (ROOT/'data/reference-c9c-event-index.h',target/'test/warp_reference_c9c_event_index.h'),
                (ROOT/'tools/experiments/c9c_candidate_core.inc',target/'test/c9c_candidate_core.inc'),
                (ROOT/'tools/experiments/c10b_candidate_core.inc',target/'test/c10b_candidate_core.inc'),
                (ROOT/'tools/experiments/c10c_scheduler_core.inc',target/'test/c10c_scheduler_core.inc'),
                (ROOT/'patches/engine-tests/warp_rando_c10c.c',target/'test/warp_rando_c10c.c')]
        for source,destination in staged:
            if not source.is_file():p.error('missing C10C-probe input: '+str(source))
            shutil.copyfile(source,destination)
        test_sources+=['test/warp_rando_c10c.c']
        test_files.append(target/'test/warp_rando_c10c.c');test_filter='Warp'
    if a.c10d_probe:
        staged=[(ROOT/'include/warp_rando.h',target/'include/warp_rando.h'),
                (ROOT/'src/warp_rando.c',target/'test/warp_rando_core.c'),
                (ROOT/'data/reference-graph.h',target/'test/warp_reference_graph.h'),
                (ROOT/'data/reference-c9c-event-index.h',target/'test/warp_reference_c9c_event_index.h'),
                (ROOT/'tools/experiments/c9c_candidate_core.inc',target/'test/c9c_candidate_core.inc'),
                (ROOT/'tools/experiments/c10b_candidate_core.inc',target/'test/c10b_candidate_core.inc'),
                (ROOT/'tools/experiments/c10c_scheduler_core.inc',target/'test/c10c_scheduler_core.inc'),
                (ROOT/'patches/engine-tests/warp_rando_c10d.c',target/'test/warp_rando_c10d.c')]
        for source,destination in staged:
            if not source.is_file():p.error('missing C10D-probe input: '+str(source))
            shutil.copyfile(source,destination)
        test_sources+=['test/warp_rando_c10d.c']
        test_files.append(target/'test/warp_rando_c10d.c');test_filter='Warp'
    args+=['TEST=1','TEST_SRCS_IN='+' '.join(test_sources),'TESTS='+test_filter,'pokeemerald-test.elf']
log=pathlib.Path(a.log).resolve();log.parent.mkdir(parents=True,exist_ok=True)
start=time.perf_counter()
with log.open('w') as output:
    result=subprocess.run(args,cwd=target,env=env,stdout=output,stderr=subprocess.STDOUT)
    if not result.returncode and not a.rom:
        import shutil
        # Hydra hardcodes /tmp. Use its same runner/settings with ordinary files
        # in the checkout and one process; no engine source or test semantics change.
        elf=target/'build/warp-proof-headless.elf';rom=target/'build/warp-proof-headless.gba'
        shutil.copyfile(target/'pokeemerald-test.elf',elf)
        commands=[['tools/patchelf/patchelf',str(elf),'gTestRunnerHeadless',r'\x01','gTestRunnerSkipIsFail',r'\x01','gTestRunnerN',r'\x01','gTestRunnerI',r'\x00'],
                  ['arm-none-eabi-objcopy','-O','binary',str(elf),str(rom)],
                  ['tools/mgba/mgba-rom-test','-l15','-ClogLevel.gba.dma=16','-Rr0',str(rom)]]
        for command in commands:
            result=subprocess.run(command,cwd=target,env=env,stdout=output,stderr=subprocess.STDOUT,
                                  timeout=600 if (a.c7a_probe or a.c7c_probe or a.c8a_probe or a.c8b_probe or a.c8c_probe or a.c9a_probe or a.c9b_probe or a.c9c_probe or a.c10a_probe or a.c10b_probe or a.c10c_probe or a.c10d_probe) else 180)
            if result.returncode:break
if not a.rom and not result.returncode:
    expected=sum(len(re.findall(r'TEST\("'+test_filter,test_file.read_text())) for test_file in test_files)
    passed=log.read_text().count('GBA Debug: :P')
    if passed!=expected:raise SystemExit('Unexpected emulator test count: '+str(passed)+'/'+str(expected))
summary={'proof_mode':a.mode,'kind':'normal ROM' if a.rom else 'engine tests',
         'generator_probe':a.generator_probe,'bank_probe':a.bank_probe,
         'c7a_probe':a.c7a_probe,
         'c7c_probe':a.c7c_probe,
         'c8a_probe':a.c8a_probe,
         'c8b_probe':a.c8b_probe,
         'c8c_probe':a.c8c_probe,
         'c9a_probe':a.c9a_probe,
         'c9b_probe':a.c9b_probe,
         'c9c_probe':a.c9c_probe,
         'c10a_probe':a.c10a_probe,
         'c10b_probe':a.c10b_probe,
         'c10c_probe':a.c10c_probe,
         'c10d_probe':a.c10d_probe,
         'exit_code':result.returncode,
         'host_seconds':round(time.perf_counter()-start,3),'log':str(log)}
if not a.rom and a.generator_probe and not result.returncode:
    log_text=log.read_text();marker='GBA Debug: WRGEN '
    if marker not in log_text:raise SystemExit('generator probe passed without a WRGEN measurement line')
    segment=log_text.split(marker,1)[1].split('GBA Debug: :N',1)[0]
    summary['generator_metrics']={key:int(value)
                                  for key,value in re.findall(r'(\w+)=(-?\d+)',segment)}
    summary['staged_sha256']={str(source.relative_to(ROOT)):hashlib.sha256(source.read_bytes()).hexdigest()
                              for source,_ in staged}
if not a.rom and a.bank_probe and not result.returncode:
    log_text=log.read_text();marker='GBA Debug: WRBANK '
    if marker not in log_text:raise SystemExit('bank probe passed without a WRBANK measurement line')
    segment=log_text.split(marker,1)[1].split('GBA Debug: :N',1)[0]
    summary['bank_metrics']={key:int(value)
                             for key,value in re.findall(r'(\w+)=(-?\d+)',segment)}
    summary['staged_sha256']={str(source.relative_to(ROOT)):hashlib.sha256(source.read_bytes()).hexdigest()
                              for source,_ in staged}
if not a.rom and a.c7a_probe and not result.returncode:
    log_text=log.read_text();marker='GBA Debug: WRC7B '
    if marker not in log_text:raise SystemExit('C7A probe passed without a WRC7B measurement line')
    segment=log_text.split(marker,1)[1].split('GBA Debug: :N',1)[0]
    summary['c7a_metrics']={key:int(value)
                            for key,value in re.findall(r'(\w+)=(-?\d+)',segment)}
    memory_marker='GBA Debug: WRC7BMEM '
    if memory_marker not in log_text:raise SystemExit('C7A probe passed without a WRC7BMEM line')
    memory_segment=log_text.split(memory_marker,1)[1].split('GBA Debug: :N',1)[0]
    summary['c7a_metrics'].update({key:int(value)
                                   for key,value in re.findall(r'(\w+)=(-?\d+)',memory_segment)})
    summary['staged_sha256']={str(source.relative_to(ROOT)):hashlib.sha256(source.read_bytes()).hexdigest()
                              for source,_ in staged}
if not a.rom and a.c7c_probe and not result.returncode:
    log_text=log.read_text();summary['c7c_metrics']={}
    for marker in ('GBA Debug: WRC7C0 ','GBA Debug: WRC7C42 ','GBA Debug: WRC7CMEM '):
        if marker not in log_text:raise SystemExit('C7C probe passed without '+marker.strip())
        segment=log_text.split(marker,1)[1].splitlines()[0]
        summary['c7c_metrics'].update({key:int(value) for key,value in re.findall(r'(\w+)=(-?\d+)',segment)})
    summary['staged_sha256']={str(source.relative_to(ROOT)):hashlib.sha256(source.read_bytes()).hexdigest()
                              for source,_ in staged}
if not a.rom and a.c8a_probe and not result.returncode:
    log_text=log.read_text();summary['c8a_metrics']={}
    for marker in ('GBA Debug: WRC8A0 ','GBA Debug: WRC8A42 ',
                   'GBA Debug: WRC8AOPS0 ','GBA Debug: WRC8AOPS42 ','GBA Debug: WRC8AMEM '):
        if marker not in log_text:raise SystemExit('C8A probe passed without '+marker.strip())
        segment=log_text.split(marker,1)[1].splitlines()[0]
        suffix='0' if marker.endswith('OPS0 ') else ('42' if marker.endswith('OPS42 ') else '')
        summary['c8a_metrics'].update({key+suffix:int(value) for key,value in re.findall(r'(\w+)=(-?\d+)',segment)})
    summary['staged_sha256']={str(source.relative_to(ROOT)):hashlib.sha256(source.read_bytes()).hexdigest()
                              for source,_ in staged}
if not a.rom and a.c8b_probe and not result.returncode:
    log_text=log.read_text();summary['c8b_metrics']={}
    for marker in ('GBA Debug: WRC8B0 ','GBA Debug: WRC8B42 ',
                   'GBA Debug: WRC8BOPS0 ','GBA Debug: WRC8BOPS42 ','GBA Debug: WRC8BMEM '):
        if marker not in log_text:raise SystemExit('C8B probe passed without '+marker.strip())
        segment=log_text.split(marker,1)[1].splitlines()[0]
        suffix='0' if marker.endswith('OPS0 ') else ('42' if marker.endswith('OPS42 ') else '')
        summary['c8b_metrics'].update({key+suffix:int(value) for key,value in re.findall(r'(\w+)=(-?\d+)',segment)})
    summary['staged_sha256']={str(source.relative_to(ROOT)):hashlib.sha256(source.read_bytes()).hexdigest()
                              for source,_ in staged}
if not a.rom and a.c8c_probe and not result.returncode:
    log_text=log.read_text();summary['c8c_metrics']={}
    for marker in ('GBA Debug: WRC8C0 ','GBA Debug: WRC8C42 ',
                   'GBA Debug: WRC8COPS0 ','GBA Debug: WRC8COPS42 ',
                   'GBA Debug: WRC8CIDX0 ','GBA Debug: WRC8CIDX42 ',
                   'GBA Debug: WRC8CMEM '):
        if marker not in log_text:raise SystemExit('C8C probe passed without '+marker.strip())
        segment=log_text.split(marker,1)[1].splitlines()[0]
        suffix='0' if marker.endswith(('OPS0 ','IDX0 ')) else ('42' if marker.endswith(('OPS42 ','IDX42 ')) else '')
        summary['c8c_metrics'].update({key+suffix:int(value) for key,value in re.findall(r'(\w+)=(-?\d+)',segment)})
    summary['staged_sha256']={str(source.relative_to(ROOT)):hashlib.sha256(source.read_bytes()).hexdigest()
                              for source,_ in staged}
if not a.rom and a.c9a_probe and not result.returncode:
    log_text=log.read_text();summary['c9a_metrics']={}
    for marker in ('GBA Debug: WRC9A0 ','GBA Debug: WRC9A42 ',
                   'GBA Debug: WRC9AOPS0 ','GBA Debug: WRC9AOPS42 ',
                   'GBA Debug: WRC9AIDX0 ','GBA Debug: WRC9AIDX42 ',
                   'GBA Debug: WRC9AMEM '):
        if marker not in log_text:raise SystemExit('C9A probe passed without '+marker.strip())
        segment=log_text.split(marker,1)[1].splitlines()[0]
        suffix='0' if marker.endswith(('OPS0 ','IDX0 ')) else ('42' if marker.endswith(('OPS42 ','IDX42 ')) else '')
        summary['c9a_metrics'].update({key+suffix:int(value) for key,value in re.findall(r'(\w+)=(-?\d+)',segment)})
    summary['staged_sha256']={str(source.relative_to(ROOT)):hashlib.sha256(source.read_bytes()).hexdigest()
                              for source,_ in staged}
if not a.rom and a.c9b_probe and not result.returncode:
    log_text=log.read_text();summary['c9b_metrics']={}
    for marker in ('GBA Debug: WRC9B0 ','GBA Debug: WRC9B42 ',
                   'GBA Debug: WRC9BOPS0 ','GBA Debug: WRC9BOPS42 ',
                   'GBA Debug: WRC9BIDX0 ','GBA Debug: WRC9BIDX42 ',
                   'GBA Debug: WRC9BPHASE ','GBA Debug: WRC9BMEM '):
        if marker not in log_text:raise SystemExit('C9B probe passed without '+marker.strip())
        segment=log_text.split(marker,1)[1].splitlines()[0]
        suffix='0' if marker.endswith(('OPS0 ','IDX0 ')) else ('42' if marker.endswith(('OPS42 ','IDX42 ')) else '')
        summary['c9b_metrics'].update({key+suffix:int(value) for key,value in re.findall(r'(\w+)=(-?\d+)',segment)})
    summary['staged_sha256']={str(source.relative_to(ROOT)):hashlib.sha256(source.read_bytes()).hexdigest()
                              for source,_ in staged}
if not a.rom and a.c9c_probe and not result.returncode:
    log_text=log.read_text();summary['c9c_metrics']={}
    for marker in ('GBA Debug: WRC9C0 ','GBA Debug: WRC9C42 ',
                   'GBA Debug: WRC9COPS0 ','GBA Debug: WRC9COPS42 ',
                   'GBA Debug: WRC9CIDX0 ','GBA Debug: WRC9CIDX42 ',
                   'GBA Debug: WRC9CPHASE ','GBA Debug: WRC9CMEM '):
        if marker not in log_text:raise SystemExit('C9C probe passed without '+marker.strip())
        segment=log_text.split(marker,1)[1].splitlines()[0]
        suffix='0' if marker.endswith(('OPS0 ','IDX0 ')) else ('42' if marker.endswith(('OPS42 ','IDX42 ')) else '')
        summary['c9c_metrics'].update({key+suffix:int(value) for key,value in re.findall(r'(\w+)=(-?\d+)',segment)})
    summary['staged_sha256']={str(source.relative_to(ROOT)):hashlib.sha256(source.read_bytes()).hexdigest()
                              for source,_ in staged}
if not a.rom and a.c10a_probe and not result.returncode:
    log_text=log.read_text();summary['c10a_metrics']={}
    for marker in ('GBA Debug: WRC10A0 ','GBA Debug: WRC10A42 ',
                   'GBA Debug: WRC10ASTEP0 ','GBA Debug: WRC10ASTEP42 ',
                   'GBA Debug: WRC10APHASE ','GBA Debug: WRC10AMEM '):
        if marker not in log_text:raise SystemExit('C10A probe passed without '+marker.strip())
        segment=log_text.split(marker,1)[1].splitlines()[0]
        summary['c10a_metrics'].update({key:int(value) for key,value in re.findall(r'(\w+)=(-?\d+)',segment)})
    summary['staged_sha256']={str(source.relative_to(ROOT)):hashlib.sha256(source.read_bytes()).hexdigest()
                              for source,_ in staged}
if not a.rom and a.c10b_probe and not result.returncode:
    log_text=log.read_text();summary['c10b_metrics']={}
    for marker in ('GBA Debug: WRC10B0 ','GBA Debug: WRC10B42 ',
                   'GBA Debug: WRC10BSTEP0 ','GBA Debug: WRC10BSTEP42 ',
                   'GBA Debug: WRC10BPHASE ','GBA Debug: WRC10BMEM '):
        if marker not in log_text:raise SystemExit('C10B probe passed without '+marker.strip())
        segment=log_text.split(marker,1)[1].splitlines()[0]
        summary['c10b_metrics'].update({key:int(value) for key,value in re.findall(r'(\w+)=(-?\d+)',segment)})
    summary['staged_sha256']={str(source.relative_to(ROOT)):hashlib.sha256(source.read_bytes()).hexdigest()
                              for source,_ in staged}
if not a.rom and a.c10c_probe and not result.returncode:
    log_text=log.read_text();summary['c10c_metrics']={}
    for marker in ('GBA Debug: WRC10C0 ','GBA Debug: WRC10C42 ',
                   'GBA Debug: WRC10CCANCEL ','GBA Debug: WRC10CLIFE ',
                   'GBA Debug: WRC10CMEM '):
        if marker not in log_text:raise SystemExit('C10C probe passed without '+marker.strip())
        segment=log_text.split(marker,1)[1].splitlines()[0]
        summary['c10c_metrics'].update({key:int(value) for key,value in re.findall(r'(\w+)=(-?\d+)',segment)})
    summary['staged_sha256']={str(source.relative_to(ROOT)):hashlib.sha256(source.read_bytes()).hexdigest()
                              for source,_ in staged}
if not a.rom and a.c10d_probe and not result.returncode:
    log_text=log.read_text();summary['c10d_metrics']={}
    for marker in ('GBA Debug: WRC10D0 ','GBA Debug: WRC10D42 ',
                   'GBA Debug: WRC10DCANCEL ','GBA Debug: WRC10DLIFE ',
                   'GBA Debug: WRC10DMEM '):
        if marker not in log_text:raise SystemExit('C10D probe passed without '+marker.strip())
        segment=log_text.split(marker,1)[1].splitlines()[0]
        summary['c10d_metrics'].update({key:int(value) for key,value in re.findall(r'(\w+)=(-?\d+)',segment)})
    summary['staged_sha256']={str(source.relative_to(ROOT)):hashlib.sha256(source.read_bytes()).hexdigest()
                              for source,_ in staged}
print(json.dumps(summary))
raise SystemExit(result.returncode)
