#!/usr/bin/env python3
"""Check C10D rendered mGBA timing, input, lifecycle, and linked resources."""
import argparse
import hashlib
import json
import pathlib
import re
import subprocess

ROOT = pathlib.Path(__file__).resolve().parents[2]
PIN = "e8bd1cd7b03fc032ea37e3ecd38b379b5d01a1e7"
MARKERS = (
    "GBA Debug: WRC10D0 ",
    "GBA Debug: WRC10D42 ",
    "GBA Debug: WRC10DCANCEL ",
    "GBA Debug: WRC10DLIFE ",
    "GBA Debug: WRC10DMEM ",
)


def parse_log(path):
    text = path.read_text()
    metrics = {}
    for marker in MARKERS:
        if marker not in text:
            raise ValueError("missing marker " + marker.strip())
        line = text.split(marker, 1)[1].splitlines()[0]
        metrics.update({key: int(value) for key, value in re.findall(r"(\w+)=(-?\d+)", line)})
    if text.count("GBA Debug: :P") != 11:
        raise ValueError("unexpected target pass count")
    return text, metrics


p = argparse.ArgumentParser(description=__doc__)
p.add_argument("target")
p.add_argument("prefix")
p.add_argument("mode0_log")
p.add_argument("mode1_log")
p.add_argument("elf")
p.add_argument("baseline_resources")
p.add_argument("c10c_resources")
p.add_argument("c10d_resources")
p.add_argument("output")
a = p.parse_args()
target = pathlib.Path(a.target).resolve()
prefix = pathlib.Path(a.prefix).resolve()
if subprocess.check_output(["git", "-C", str(target), "rev-parse", "HEAD"], text=True).strip() != PIN:
    p.error("target checkout is not pinned expansion/1.17.0")

try:
    text0, metrics0 = parse_log(pathlib.Path(a.mode0_log).resolve())
    text1, metrics = parse_log(pathlib.Path(a.mode1_log).resolve())
except ValueError as error:
    p.error(str(error))

expected = {
    "digest0_decimal": -755938432,
    "steps0": 66274,
    "digest42_decimal": 1026903975,
    "steps42": 94230,
    "attempt42": 1,
    "result_cancel": 101,
    "publishes_cancel": 0,
    "releases_cancel": 1,
    "invalid0": 1,
    "publish0": 1,
    "release0": 1,
    "regress0": 0,
    "terminal0": 1,
    "invalid42": 1,
    "publish42": 1,
    "release42": 1,
    "regress42": 0,
    "terminal42": 1,
    "work": 14224,
    "session": 156,
    "job": 200,
    "screen": 388,
    "active": 16436,
    "algorithm": 0,
}
for label, candidate in (("mode 0", metrics0), ("mode 1", metrics)):
    for key, value in expected.items():
        if candidate.get(key) != value:
            p.error(f"{label}: unexpected {key}: {candidate.get(key)} != {value}")
    for key in ("callback_max0", "callback_max42", "callback_max_cancel"):
        if candidate[key] > 2800:
            p.error(f"{label}: {key} exceeded C10D budget")
    for key in ("active_max0", "active_max42", "active_max_cancel"):
        if candidate[key] >= 4389:
            p.error(f"{label}: {key} reached one frame")
    for key in ("deadline0", "deadline42", "deadline_cancel"):
        if candidate[key] != 0:
            p.error(f"{label}: {key} recorded a missed VBlank deadline")
    if candidate["heap_before_free"] != candidate["heap_after_free"]:
        p.error(f"{label}: heap did not restore")
    if candidate["heap_after_job0_free"] <= candidate["heap_during0_free"]:
        p.error(f"{label}: generator allocation did not release before screen teardown")

inputs = {
    "include/warp_rando.h": target / "include/warp_rando.h",
    "src/warp_rando.c": target / "test/warp_rando_core.c",
    "data/reference-graph.h": target / "test/warp_reference_graph.h",
    "data/reference-c9c-event-index.h": target / "test/warp_reference_c9c_event_index.h",
    "tools/experiments/c9c_candidate_core.inc": target / "test/c9c_candidate_core.inc",
    "tools/experiments/c10b_candidate_core.inc": target / "test/c10b_candidate_core.inc",
    "tools/experiments/c10c_scheduler_core.inc": target / "test/c10c_scheduler_core.inc",
    "patches/engine-tests/warp_rando_c10d.c": target / "test/warp_rando_c10d.c",
}
staged = {}
for relative, destination in inputs.items():
    digest = hashlib.sha256((ROOT / relative).read_bytes()).hexdigest()
    if digest != hashlib.sha256(destination.read_bytes()).hexdigest():
        p.error("staged file differs: " + relative)
    staged[relative] = digest

baseline = json.loads(pathlib.Path(a.baseline_resources).read_text())
c10c = json.loads(pathlib.Path(a.c10c_resources).read_text())
c10d = json.loads(pathlib.Path(a.c10d_resources).read_text())
elf = pathlib.Path(a.elf).resolve()
elf_hash = hashlib.sha256(elf.read_bytes()).hexdigest()
if c10d["elf_sha256"] != elf_hash:
    p.error("resource report describes another ELF")

object_path = target / "build/emerald-test/test/warp_rando_c10d.o"
sections = {}
size = prefix / "usr/bin/arm-none-eabi-size"
for line in subprocess.check_output([str(size), "-A", str(object_path)], text=True).splitlines():
    match = re.fullmatch(r"(\S+)\s+(\d+)\s+(\d+)", line.strip())
    if match:
        sections[match.group(1)] = int(match.group(2))

worst_callback = max(metrics[key] for key in ("callback_max0", "callback_max42", "callback_max_cancel"))
worst_active = max(metrics[key] for key in ("active_max0", "active_max42", "active_max_cancel"))
report = {
    "checkpoint": "C10D",
    "decision": "rendered mGBA lifecycle passes automated target gate; retain test-only status pending human visual and physical-input confirmation",
    "scope": "C10C-exact generation in a rendered engine main callback with real window/DMA/VBlank/audio work and JOY_NEW cancellation under bundled mGBA",
    "target_commit": PIN,
    "modes": {"proof_disabled_passes": 11, "proof_enabled_passes": 11},
    "metrics": metrics,
    "correctness": {
        "seed0_exact_c9c": True,
        "seed42_exact_c9c": True,
        "seed0_digest": "d2f14b80",
        "seed42_digest": "3d354fa7",
        "cancellation_published": False,
        "pixel_buffer_reached_vram": True,
    },
    "screen": {
        "main_callback": True,
        "normal_vblank_callback": ["LoadOam", "ProcessSpriteCopyRequests", "TransferPlttBuffer"],
        "common_vblank_work": ["ProcessDma3Requests", "m4aSoundMain"],
        "audio_requests_seed0": metrics["audio0"],
        "audio_requests_seed42": metrics["audio42"],
        "progress_updates_seed0": metrics["renders0"],
        "progress_updates_seed42": metrics["renders42"],
        "attempt_limit_indicator": "eight slots; active attempt highlighted",
        "activity_indicator": "60-frame pulse when semantic progress is unchanged",
        "terminal_state_rendered_once": True,
    },
    "timing": {
        "timer": "TM3 at 64 cycles/tick; TM0/TM1 left to audio",
        "budget_ticks": 2800,
        "worst_generator_callback_ticks": worst_callback,
        "worst_generator_callback_frames": round(worst_callback / 4389, 6),
        "worst_main_plus_vblank_ticks": worst_active,
        "worst_main_plus_vblank_frames": round(worst_active / 4389, 6),
        "headroom_ticks": 4389 - worst_active,
        "missed_vblank_deadlines": 0,
        "seed0_seconds_at_60hz": round(metrics["frames0"] / 60, 3),
        "seed42_seconds_at_60hz": round(metrics["frames42"] / 60, 3),
    },
    "allocation": {
        "point": "after screen/window initialization and before generator task creation",
        "workspace_bytes": metrics["work"],
        "screen_window_heap_bytes_observed": metrics["heap_before_free"] - metrics["heap_after_job0_free"],
        "workspace_allocator_cost_observed": metrics["heap_after_job0_free"] - metrics["heap_during0_free"],
        "workspace_released_before_screen_teardown": True,
        "heap_restored_after_screen_teardown": True,
    },
    "memory": {
        "screen_state_ewram_bytes": metrics["screen"],
        "active_table_bytes": metrics["active"],
        "c10c_to_c10d_ewram_delta_bytes": c10d["regions"]["EWRAM"]["static_span_bytes"] - c10c["regions"]["EWRAM"]["static_span_bytes"],
        "test_build_ewram_unallocated_bytes": c10d["regions"]["EWRAM"]["unallocated_bytes"],
        "test_build_iwram_unallocated_bytes": c10d["regions"]["IWRAM"]["unallocated_bytes"],
        "runtime_stack_high_water_measured": False,
    },
    "identity": {
        "published_test_value": metrics["algorithm"],
        "meaning": "zero remains deliberately unassigned; Algorithm 5 is not yet a save/runtime identity",
    },
    "target_object_sections": sections,
    "staged_input_sha256": staged,
    "target_test_elf_sha256": elf_hash,
    "mode0_log_sha256": hashlib.sha256(text0.encode()).hexdigest(),
    "mode1_log_sha256": hashlib.sha256(text1.encode()).hexdigest(),
    "resource_report": str(pathlib.Path(a.c10d_resources).resolve().relative_to(ROOT)),
    "evidence_limits": [
        "The available mGBA runner is headless; rendered bytes and callbacks are checked, but no human inspected the pixels.",
        "Cancellation is injected into gMain.newKeys and consumed through JOY_NEW; a physical controller was not used.",
        "This is a test-runner screen, not yet hooked into the production new-game menu.",
        "Runtime stack high-water, save/reload identity, and target-world completion remain open.",
        "The immutable approval is run before screen creation; its production boot placement is not yet wired.",
    ],
    "baseline_ewram_static_span_bytes": baseline["regions"]["EWRAM"]["static_span_bytes"],
}
output = pathlib.Path(a.output).resolve()
output.parent.mkdir(parents=True, exist_ok=True)
output.write_text(json.dumps(report, indent=2) + "\n")
print(json.dumps(report, indent=2))
