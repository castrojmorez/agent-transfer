#!/usr/bin/env python3
"""Build and exercise the host-only bounded-candidate C7A prototype."""
import argparse,hashlib,json,pathlib,statistics,subprocess,sys,time
ROOT=pathlib.Path(__file__).resolve().parents[2]
sys.path.insert(0,str(ROOT/'tests'))
from validate import validate,Invalid

DEFAULT_SEEDS=list(range(64))+[255,256,65535,4294967295]
p=argparse.ArgumentParser(description=__doc__)
p.add_argument('--caps',nargs='+',type=int,default=[4,8,16])
p.add_argument('--retries',type=int,default=8)
p.add_argument('--output',default='reports/c7a-feasibility.json')
a=p.parse_args()
if any(not 1<=v<=2048 for v in a.caps) or not 1<=a.retries<=65535:
    p.error('caps/retries out of range')
build=ROOT/'build/c7a';build.mkdir(parents=True,exist_ok=True)
subprocess.run([sys.executable,str(ROOT/'tools/warprandogen/compile.py'),
                str(ROOT/'data/reference-normalized.json'),str(build/'graph.h')],check=True)
exe=build/'candidate'
subprocess.run(['cc','-std=c99','-Wall','-Wextra','-Werror','-pedantic','-O2',
                '-fstack-usage','-I'+str(ROOT/'include'),'-I'+str(build),
                str(ROOT/'tools/experiments/c7a_candidate.c'),'-o',str(exe)],check=True)
data=json.loads((ROOT/'data/reference-normalized.json').read_text())
cap_results=[]
for cap in a.caps:
    rows=[]
    for seed in DEFAULT_SEEDS:
        start=time.perf_counter()
        raw=subprocess.check_output([str(exe),str(seed),str(cap),str(a.retries)],text=True)
        elapsed=time.perf_counter()-start;r=json.loads(raw);r['seed']=seed;r['host_seconds']=elapsed
        replay=json.loads(subprocess.check_output([str(exe),str(seed),str(cap),str(a.retries)],text=True))
        if {k:v for k,v in r.items() if k not in ('seed','host_seconds')} != replay:
            raise SystemExit(f'nondeterministic replay for cap {cap}, seed {seed}')
        if r['result']==0:
            try:validate(data,r['records'])
            except Invalid as e:raise SystemExit(f'C/Python disagreement for cap {cap}, seed {seed}: {e}')
        r['record_sha256']=hashlib.sha256(json.dumps(r.pop('records'),separators=(',',':')).encode()).hexdigest()
        rows.append(r)
    times=[r['host_seconds'] for r in rows]
    cap_results.append({'trial_cap':cap,'successes':sum(r['result']==0 for r in rows),
        'first_attempt_successes':sum(r['result']==0 and r['attempt']==0 for r in rows),
        'host_seconds_total':sum(times),'host_seconds_median':statistics.median(times),
        'host_seconds_max':max(times),'partner_trials_total':sum(r['partner_trials'] for r in rows),
        'state_closures_total':sum(r['state_closures'] for r in rows),
        'max_attempts':max(r['attempts'] for r in rows),'results':rows})
    print('cap',cap,'successes',cap_results[-1]['successes'],'time',round(sum(times),3),
          'trials',cap_results[-1]['partner_trials_total'],flush=True)
report={'checkpoint':'C7A','status':'host-only feasibility; no algorithm ID assigned',
    'scope':'68-seed complete normalized reference abstraction; not target playability or ARM timing',
    'seeds':DEFAULT_SEEDS,'retries':a.retries,
    'input_sha256':hashlib.sha256((ROOT/'data/reference-normalized.json').read_bytes()).hexdigest(),
    'algorithm3_core_sha256':hashlib.sha256((ROOT/'src/warp_rando.c').read_bytes()).hexdigest(),
    'candidate_sha256':hashlib.sha256((ROOT/'tools/experiments/c7a_candidate.c').read_bytes()).hexdigest(),
    'candidate_core_sha256':hashlib.sha256((ROOT/'tools/experiments/c7a_candidate_core.inc').read_bytes()).hexdigest(),
    'timing_scope':'host process wall time; each seed is executed twice but totals include first execution only',
    'caps':cap_results}
(ROOT/a.output).write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps({k:v for k,v in report.items() if k!='caps'}|{'caps':[
    {k:v for k,v in c.items() if k!='results'} for c in cap_results]},indent=2))
