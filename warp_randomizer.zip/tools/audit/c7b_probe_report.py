#!/usr/bin/env python3
"""Check the C7B ARM log, target resources and exact staged candidate."""
import argparse,hashlib,json,pathlib,re,subprocess
ROOT=pathlib.Path(__file__).resolve().parents[2]
p=argparse.ArgumentParser(description=__doc__)
p.add_argument('target');p.add_argument('prefix');p.add_argument('log');p.add_argument('elf')
p.add_argument('baseline_resources');p.add_argument('resources');p.add_argument('output')
a=p.parse_args();target=pathlib.Path(a.target).resolve();prefix=pathlib.Path(a.prefix).resolve()
log=pathlib.Path(a.log).resolve();elf=pathlib.Path(a.elf).resolve()
base_path=pathlib.Path(a.baseline_resources).resolve();resource_path=pathlib.Path(a.resources).resolve()
pin='e8bd1cd7b03fc032ea37e3ecd38b379b5d01a1e7'
if subprocess.check_output(['git','-C',str(target),'rev-parse','HEAD'],text=True).strip()!=pin:
    p.error('target checkout is not pinned expansion/1.17.0')
text=log.read_text();metrics={}
for marker in ('GBA Debug: WRC7B ','GBA Debug: WRC7BMEM '):
    if marker not in text:p.error('missing marker '+marker.strip())
    segment=text.split(marker,1)[1].split('GBA Debug: :N',1)[0]
    metrics.update({k:int(v) for k,v in re.findall(r'(\w+)=(-?\d+)',segment)})
expected={'result0':0,'last0':0,'attempt0':0,'digest0_decimal':-1433728771,
 'trials0':1020,'closures0':1276,'result42':0,'last42':4,'attempt42':1,
 'digest42_decimal':1280984034,'trials42':2039,'closures42':2550,
 'work':47388,'active':16436,'algorithm':0}
for key,value in expected.items():
    if metrics.get(key)!=value:p.error(f'unexpected {key}: {metrics.get(key)} != {value}')
for suffix in ('free','largest'):
    if metrics.get('heap_before_'+suffix)!=metrics.get('heap_after_'+suffix):
        p.error('heap did not return to its pre-workspace state')
passed=text.count('GBA Debug: :P')
if passed!=11:p.error(f'unexpected pass count: {passed}/11')
inputs={'include/warp_rando.h':target/'include/warp_rando.h',
 'src/warp_rando.c':target/'test/warp_rando_core.c',
 'data/reference-graph.h':target/'test/warp_reference_graph.h',
 'tools/experiments/c7a_candidate_core.inc':target/'test/c7a_candidate_core.inc',
 'patches/engine-tests/warp_rando_c7b.c':target/'test/warp_rando_c7b.c'}
staged={}
for relative,destination in inputs.items():
    digest=hashlib.sha256((ROOT/relative).read_bytes()).hexdigest()
    if digest!=hashlib.sha256(destination.read_bytes()).hexdigest():p.error('staged file differs: '+relative)
    staged[relative]=digest
resources=json.loads(resource_path.read_text());baseline=json.loads(base_path.read_text())
elf_hash=hashlib.sha256(elf.read_bytes()).hexdigest()
if resources['elf_sha256']!=elf_hash:p.error('resource report describes another ELF')

# Compile the exact core+scheduler pair separately for attributable object and
# compiler-frame evidence. This wrapper exposes the otherwise static entry.
build=ROOT/'build/c7b-resources';build.mkdir(parents=True,exist_ok=True)
wrapper=build/'candidate.c';wrapper.write_text(
 '#include "src/warp_rando.c"\n#include "tools/experiments/c7a_candidate_core.inc"\n'
 'int c7b_candidate_entry(const struct WrGraph *g,uint32_t seed,uint16_t cap,uint16_t retries,'
 'struct WrWork *w,struct C7aStats *s,uint16_t *count,uint16_t *attempt,int *last)'
 '{return c7a_generate_candidate(g,seed,cap,retries,w,s,count,attempt,last);}\n')
flags=['-std=gnu17','-mthumb','-mthumb-interwork','-O2','-mabi=apcs-gnu','-mtune=arm7tdmi','-march=armv4t']
bin=prefix/'usr/bin';obj=build/'candidate.o'
subprocess.run([str(bin/'arm-none-eabi-gcc'),*flags,'-fstack-usage','-I'+str(ROOT),
                '-I'+str(ROOT/'include'),'-c',str(wrapper),'-o',str(obj)],check=True)
sections={}
for line in subprocess.check_output([str(bin/'arm-none-eabi-size'),'-A',str(obj)],text=True).splitlines():
    m=re.fullmatch(r'(\S+)\s+(\d+)\s+(\d+)',line.strip())
    if m:sections[m.group(1)]=int(m.group(2))
frames={}
for line in obj.with_suffix('.su').read_text().splitlines():
    cols=line.split('\t')
    if len(cols)>=2:frames[cols[0].rsplit(':',1)[-1]]=int(cols[1])
def allocated(report,start,capacity):
    return sum(row['bytes'] for row in report['sections'] if start<=row['address']<start+capacity)
rom0=allocated(baseline,0x08000000,32*1024*1024);rom1=allocated(resources,0x08000000,32*1024*1024)
ticks0=metrics['ticks0'];ticks42=metrics['ticks42'];c5ticks=644772173
report={'checkpoint':'C7B','decision':'reject synchronous promotion; keep Algorithm 5 unassigned',
 'scope':'Exact C7A cap-4 candidate on actual ARM target code in headless mGBA; test-only integration',
 'target_commit':pin,'test_passes':passed,'test_expected':11,'metrics':metrics,
 'timing':{'timer_cpu_cycles_per_tick':64,'gba_cpu_hz':16777216,'ticks_per_frame':4389,
  'seed0_seconds':round(ticks0/262144,6),'seed0_frames':round(ticks0/4389,6),
  'seed42_seconds':round(ticks42/262144,6),'seed42_frames':round(ticks42/4389,6),
  'seed0_speedup_vs_c5_algorithm3':round(c5ticks/ticks0,6),
  'assessment':'Both blocking durations are unacceptable for synchronous new-game or menu generation.'},
 'heap':{'workspace_bytes':metrics['work'],
  'allocator_overhead_bytes':metrics['heap_before_free']-metrics['heap_during_free']-metrics['work'],
  'largest_contiguous_before':metrics['heap_before_largest'],'largest_contiguous_during':metrics['heap_during_largest'],
  'free_bytes_restored_exactly':metrics['heap_before_free']==metrics['heap_after_free'],
  'largest_block_restored_exactly':metrics['heap_before_largest']==metrics['heap_after_largest']},
 'linked_test_image_delta':{'baseline_rom_allocated_section_bytes':rom0,
  'c7b_rom_allocated_section_bytes':rom1,'rom_allocated_section_delta_bytes':rom1-rom0,
  'baseline_ewram_static_span_bytes':baseline['regions']['EWRAM']['static_span_bytes'],
  'c7b_ewram_static_span_bytes':resources['regions']['EWRAM']['static_span_bytes'],
  'ewram_static_span_delta_bytes':resources['regions']['EWRAM']['static_span_bytes']-baseline['regions']['EWRAM']['static_span_bytes'],
  'interpretation':'Conservative test-link delta including harness and retained support, not a production link.'},
 'candidate_object':{'sections':sections,'own_frame_bytes':frames,
  'largest_own_frame_bytes':max(frames.values()),'largest_own_frame_function':max(frames,key=frames.get),
  'warning':'Compiler own frames are not a call-chain or interrupt-stack high-water measurement.'},
 'identity':{'published_test_value':metrics['algorithm'],'meaning':'zero is deliberately unassigned; no save/runtime Algorithm 5 identity exists'},
 'staged_input_sha256':staged,'target_test_elf_sha256':elf_hash,
 'log_sha256':hashlib.sha256(log.read_bytes()).hexdigest(),
 'resource_report':str(resource_path.relative_to(ROOT)),
 'evidence_limits':['Headless target test only; no production hooks or UI.',
  'Timer excludes workspace allocation/zero-fill and release.',
  'Runtime stack high-water was not canary-measured.',
  'Reference-model acceptance is not target-world or completion validation.']}
out=pathlib.Path(a.output).resolve();out.parent.mkdir(parents=True,exist_ok=True)
out.write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report,indent=2))
