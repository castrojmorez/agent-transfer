#!/usr/bin/env python3
"""Join reference IDs with map_groups order and actual map events; no layout inference."""
import argparse, collections, csv, hashlib, json, pathlib, subprocess

def load_maps(root):
    base=root/'data/maps';groups=json.loads((base/'map_groups.json').read_text());maps={};names={};hashes={}
    for g,group in enumerate(groups['group_order']):
        for m,name in enumerate(groups[group]):
            path=base/name/'map.json';raw=path.read_bytes();data=json.loads(raw)
            maps[g,m]=data;names[data['id']]=(g,m);hashes[str(path.relative_to(root))]=hashlib.sha256(raw).hexdigest()
    events={}
    for (g,m),data in maps.items():
        for i,e in enumerate(data.get('warp_events',[])):
            dst=names.get(e['dest_map']);warp=e['dest_warp_id']
            if isinstance(warp,str) and warp.isdecimal():warp=int(warp)
            dest=f'E,{dst[0]},{dst[1]},{warp}' if dst and type(warp) is int else f'{e["dest_map"]}:{warp}'
            events[f'E,{g},{m},{i}']={'map':data['id'],'to':dest,'x':e['x'],'y':e['y'],'elevation':e['elevation']}
    hashes['data/maps/map_groups.json']=hashlib.sha256((base/'map_groups.json').read_bytes()).hexdigest()
    return events,hashes

def audit(ref,target,speed,out):
    warps=json.loads(ref.read_text());t,th=load_maps(target);s,sh=load_maps(speed)
    out.mkdir(parents=True,exist_ok=True);rows=[];counts=collections.Counter();collisions=collections.defaultdict(list)
    for k in sorted(set(warps)|set(t)):
        w=warps.get(k);a=t.get(k);b=s.get(k)
        status='matched' if w and a else ('missing_in_target' if w else 'target_only')
        if w and a and w['to']!=a['to']:status='destination_mismatch'
        counts[status]+=1
        if a:collisions[a['to']].append(k)
        rows.append({'key':k,'status':status,'reference_name':w.get('name','') if w else '',
          'reference_to':w.get('to','') if w else '',
          **{f'target_{f}':a.get(f,'') if a else '' for f in ['map','to','x','y','elevation']},
          **{f'speedchoice_{f}':b.get(f,'') if b else '' for f in ['map','to','x','y','elevation']},
          'arrival_geometry_changed':bool(a and b and any(a[f]!=b[f] for f in ['x','y','elevation'])),
          'decision':'OPEN: audit gameplay/arrival' if status!='matched' else 'identity/destination only; gameplay unverified'})
    with (out/'drift.csv').open('w',newline='') as f:
        writer=csv.DictWriter(f,fieldnames=list(rows[0]));writer.writeheader();writer.writerows(rows)
    report={'reference_count':len(warps),'target_warp_count':len(t),'counts':dict(counts),
       'geometry_changed_on_common_keys':sum(r['arrival_geometry_changed'] for r in rows if r['reference_name']),
       'target_collisions':{k:v for k,v in sorted(collisions.items()) if len(v)>1},
       'revisions':{name:subprocess.check_output(['git','-C',str(root),'rev-parse','HEAD'],text=True).strip() for name,root in [('target',target),('speedchoice',speed)]},
       'scope':'Identity, destination, source-event coordinates/elevation. No tile collision or script equivalence guarantee.'}
    (out/'drift-summary.json').write_text(json.dumps(report,indent=2)+'\n')
    (out/'map-input-hashes.json').write_text(json.dumps({'target':th,'speedchoice':sh},indent=2)+'\n')
    print(json.dumps({k:v for k,v in report.items() if k not in ['target_collisions']},indent=2))
if __name__=='__main__':
    p=argparse.ArgumentParser(description=__doc__)
    for name in ['reference','target','speedchoice','output']:p.add_argument(name,type=pathlib.Path)
    a=p.parse_args();audit(a.reference,a.target,a.speedchoice,a.output)
