#!/usr/bin/env python3
"""Replay the delivered C constructor; inspect directed failure witnesses independently."""
import collections,copy,hashlib,importlib.util,json,pathlib,subprocess,sys
ROOT=pathlib.Path(__file__).resolve().parents[2]
sys.path.insert(0,str(ROOT/'tools/warprandogen'))
from compile import emit
BASE=json.loads((ROOT/'data/reference-normalized.json').read_text())
RAW=json.loads((ROOT/'data/reference/Warps.json').read_text())
SEEDS=[0,1,2,17,255,256,65535,4294967295]
BUILD=ROOT/'build/diagnostics'

def walk(adj,root):
    seen={root};prev={};q=collections.deque([root])
    while q:
        a=q.popleft()
        for b in sorted(adj[a]):
            if b not in seen:seen.add(b);prev[b]=a;q.append(b)
    return seen,prev

def closure(d,partner):
    nodes=d['nodes']; names=[v['name'] for v in nodes];ni={n:i for i,n in enumerate(names)}
    caps=set();stages=[];root=ni[d['root']]
    while True:
        adj=[set() for n in names];rev=[set() for n in names];kinds={}
        for e in d['edges']:
            if e.get('requires') is None or e['requires'] in caps:
                a,b=ni[e['from']],ni[e['to']];adj[a].add(b);kinds[a,b]='fixed' if e.get('requires') is None else e['requires']
        for i,v in enumerate(nodes):
            if v['active']:
                p=partner[ni[v['rep']]]
                if p!=65535:adj[i].add(p);kinds[i,p]='randomized'
        for a,bs in enumerate(adj):
            for b in bs:rev[b].add(a)
        reached,prev=walk(adj,root);home,_=walk(rev,root);traps=reached-home
        earned={r['grant'] for r in d['rules'] if all(
            (ni[q['location']] in reached & home if 'location' in q else q['capability'] in caps) for q in r['requires'])}
        stages.append(dict(caps=sorted(caps),reached=reached,home=home,traps=traps,adj=adj,prev=prev,kinds=kinds))
        if earned<=caps:return stages
        caps|=earned

def name(d,i):return d['nodes'][i]['name']
def summarize(d,result):
    stages=closure(d,result['partner']);first=next((s for s in stages if s['traps']),None);final=stages[-1]
    status=result['construction'] or result['emission'] or result['validation']
    # Negative sentinel emission/validation only occurs on failed construction.
    summary={'status':status,'pairs':sum(p!=65535 and i<p for i,p in enumerate(result['partner'])),
      'caps_at_end':final['caps'],'reachable_at_end':len(final['reached']),
      'traps_at_end':len(final['traps'])}
    if status==3:
        unused=[i for i,v in enumerate(d['nodes']) if v['active'] and v['rep']==v['name'] and result['partner'][i]==65535]
        summary['unused']=[name(d,i) for i in unused]
        summary['reachable_unused']=[name(d,i) for i in unused if i in final['reached']]
        summary['unused_components_outgoing']={name(d,i):[name(d,j) for j in final['adj'][i]] for i in unused}
    if first:
        summary['first_trap_capabilities']=first['caps'];summary['first_traps']=[name(d,i) for i in sorted(first['traps'])]
        # A small sink component is a more diagnostic witness than a long trap list.
        tset=first['traps'];seen=set();order=[]
        def visit(start):
            todo=[(start,False)]
            while todo:
                v,exit=todo.pop()
                if exit:order.append(v);continue
                if v in seen:continue
                seen.add(v);todo.append((v,True))
                todo.extend((u,False) for u in sorted(first['adj'][v],reverse=True) if u in tset and u not in seen)
        for v in sorted(tset):visit(v)
        rev=[set() for _ in d['nodes']]
        for a in tset:
            for b in first['adj'][a]&tset:rev[b].add(a)
        assigned=set();components=[]
        for v in reversed(order):
            if v in assigned:continue
            component=set();todo=[v];assigned.add(v)
            while todo:
                a=todo.pop();component.add(a)
                for b in rev[a]-assigned:assigned.add(b);todo.append(b)
            components.append(component)
        sinks=[c for c in components if not any(first['adj'][a]-c for a in c)]
        summary['sink_components']=[[name(d,i) for i in sorted(c)] for c in sorted(sinks,key=lambda c:(len(c),min(c)))]
        witness=min(sinks,key=lambda c:(len(c),min(c))) if sinks else tset
        target=min(witness);path=[target]
        while path[-1] in first['prev']:path.append(first['prev'][path[-1]])
        path.reverse();summary['witness_path']=[{'from':name(d,a),'to':name(d,b),'kind':first['kinds'][a,b]} for a,b in zip(path,path[1:])]
    return summary

def run_variant(label,d):
    build=BUILD/label;build.mkdir(parents=True,exist_ok=True);(build/'graph.h').write_text(emit(d))
    subprocess.run(['cc','-std=c99','-O2','-Wall','-Wextra','-Werror','-I'+str(ROOT/'include'),'-I'+str(ROOT/'src'),'-I'+str(build),str(ROOT/'tests/diagnostic_driver.c'),'-o',str(build/'run')],check=True)
    candidates=[];counts=collections.Counter();hashes=[]
    for seed in SEEDS:
        for attempt in range(8):
            effective=(seed+0x9e3779b9*attempt)&0xffffffff
            r=json.loads(subprocess.check_output([str(build/'run'),str(effective)],text=True))
            (build/f'{seed}-{attempt}.json').write_text(json.dumps(r,separators=(',',':'))+'\n')
            s=summarize(d,r);s.update(seed=seed,attempt=attempt,effective_seed=effective)
            candidates.append(s);counts[s['status']]+=1
            hashes.append(hashlib.sha256(json.dumps(r['partner']).encode()).hexdigest())
    print(label,dict(counts),flush=True)
    return {'label':label,'counts':dict(counts),'partner_hashes':hashes,'candidates':candidates}

def main():
    if "#define WR_ALGORITHM 2u" not in (ROOT/"include/warp_rando.h").read_text():
        raise SystemExit("Historical algorithm-2 investigation: run tools/audit/reproduce_algorithm2.py")
    variants=[('baseline',copy.deepcopy(BASE))]
    weather=copy.deepcopy(BASE)
    for e in weather['edges']:
        if e['requires']=='WEATHER_INSTITUTE':e['requires']=None
    variants.append(('weather_open',weather))
    flash=copy.deepcopy(BASE);flash['capabilities']=sorted(flash['capabilities']+['HOENN_FLASH_1'])
    for e in flash['edges']:
        if e['from']=='E,24,68,0' and e['to']=='E,24,68,1':e['requires']='HOENN_FLASH_1'
    variants.append(('flash_upstream_closed',flash))
    both=copy.deepcopy(weather)
    for e in both['edges']:
        if e['from']=='E,24,68,0' and e['to']=='E,24,68,1':e['requires']=None
    variants.append(('both_open',both))
    allopen=copy.deepcopy(BASE)
    for e in allopen['edges']:e['requires']=None
    variants.append(('all_conditions_open',allopen))
    nofixed=copy.deepcopy(BASE)
    nofixed['edges']=[e for e in nofixed['edges'] if not (not next(v['active'] for v in BASE['nodes'] if v['name']==e['from']) and RAW[e['from']]['to']==e['to'] and e['requires'] is None)]
    variants.append(('omit_excluded_vanilla_diagnostic_only',nofixed))
    result=[run_variant(label,d) for label,d in variants]
    for r in result:
        r['partners_identical_to_baseline']=sum(a==b for a,b in zip(r['partner_hashes'],result[0]['partner_hashes']))
    assert result[0]['counts']=={8:52,3:12},result[0]['counts']
    (ROOT/'reports/failure-diagnosis.json').write_text(json.dumps({'scope':'Diagnostic counterfactuals; do not deploy modified rules','runs':result},indent=2)+'\n')
if __name__=='__main__':main()
