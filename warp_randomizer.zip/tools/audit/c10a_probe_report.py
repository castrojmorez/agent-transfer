#!/usr/bin/env python3
"""Check C10A ARM timing, target resources and staged experimental inputs."""
import argparse,hashlib,json,pathlib,re,subprocess
ROOT=pathlib.Path(__file__).resolve().parents[2]
p=argparse.ArgumentParser(description=__doc__)
p.add_argument('target');p.add_argument('prefix');p.add_argument('log');p.add_argument('elf')
p.add_argument('baseline_resources');p.add_argument('resources');p.add_argument('output')
a=p.parse_args();target=pathlib.Path(a.target).resolve();prefix=pathlib.Path(a.prefix).resolve()
log=pathlib.Path(a.log).resolve();elf=pathlib.Path(a.elf).resolve()
base_path=pathlib.Path(a.baseline_resources).resolve();resource_path=pathlib.Path(a.resources).resolve()
pin='e8bd1cd7b03fc032ea37e3ecd38b379b5d01a1e7'
if subprocess.check_output(['git','-C',str(target),'rev-parse','HEAD'],text=True).strip()!=pin:
    p.error('target checkout is not pinned expansion/1.17.0')
text=log.read_text();metrics={}
for marker,suffix in (('GBA Debug: WRC10A0 ',''),('GBA Debug: WRC10A42 ',''),
                      ('GBA Debug: WRC10ASTEP0 ',''),('GBA Debug: WRC10ASTEP42 ',''),
                      ('GBA Debug: WRC10APHASE ',''),('GBA Debug: WRC10AMEM ','')):
    if marker not in text:p.error('missing marker '+marker.strip())
    segment=text.split(marker,1)[1].splitlines()[0]
    metrics.update({k+suffix:int(v) for k,v in re.findall(r'(\w+)=(-?\d+)',segment)})
expected={'result0':0,'attempt0':0,'digest0_decimal':-755938432,'steps0':1281,'trials0':766,
 'result42':0,'last42':4,'attempt42':1,'digest42_decimal':1026903975,'steps42':2547,
 'trials42':1525,'cancel_steps':64,'cancel_result':101,
 'work':14224,'session':136,'active':16436,'algorithm':0}
for key,value in expected.items():
    if metrics.get(key)!=value:p.error(f'unexpected {key}: {metrics.get(key)} != {value}')
for suffix in ('free','largest'):
    if metrics.get('heap_before_'+suffix)!=metrics.get('heap_after_'+suffix):p.error('heap was not restored')
if text.count('GBA Debug: :P')!=11:p.error('unexpected target pass count')
inputs={'include/warp_rando.h':target/'include/warp_rando.h',
 'src/warp_rando.c':target/'test/warp_rando_core.c',
 'data/reference-graph.h':target/'test/warp_reference_graph.h',
 'data/reference-c9c-event-index.h':target/'test/warp_reference_c9c_event_index.h',
 'tools/experiments/c9c_candidate_core.inc':target/'test/c9c_candidate_core.inc',
 'tools/experiments/c10a_candidate_core.inc':target/'test/c10a_candidate_core.inc',
 'patches/engine-tests/warp_rando_c10a.c':target/'test/warp_rando_c10a.c'}
staged={}
for relative,destination in inputs.items():
    digest=hashlib.sha256((ROOT/relative).read_bytes()).hexdigest()
    if digest!=hashlib.sha256(destination.read_bytes()).hexdigest():p.error('staged file differs: '+relative)
    staged[relative]=digest
resources=json.loads(resource_path.read_text());baseline=json.loads(base_path.read_text())
elf_hash=hashlib.sha256(elf.read_bytes()).hexdigest()
if resources['elf_sha256']!=elf_hash:p.error('resource report describes another ELF')
build=ROOT/'build/c10a-resources';build.mkdir(parents=True,exist_ok=True)
wrapper=build/'candidate-audit.c';wrapper.write_text(
 '#include "src/warp_rando.c"\n#include "tools/experiments/c9c_candidate_core.inc"\n'
 '#include "data/reference-c9c-event-index.h"\n#include "tools/experiments/c10a_candidate_core.inc"\n'
 'int c10a_candidate_entry(const struct WrGraph *g,uint32_t seed,uint16_t retries,'
 'struct C9cWork *w,struct C9cStats *s,uint16_t *count,uint16_t *attempt,int *last)'
 '{struct C10aSession q;int r=c10a_begin(&q,g,&c9c_index,seed,3,retries,w,s);'
 'while(r==C10A_PENDING)r=c10a_advance(&q,1);*count=q.count;*attempt=q.successful_attempt;'
 '*last=q.last_rejection;(void)c10a_cancel;(void)c10a_pairs_done;return r;}\n')
flags=['-std=gnu17','-mthumb','-mthumb-interwork','-O2','-mabi=apcs-gnu','-mtune=arm7tdmi','-march=armv4t']
bin=prefix/'usr/bin';obj=build/'candidate-audit.o'
subprocess.run([str(bin/'arm-none-eabi-gcc'),*flags,'-fstack-usage',
 '-I'+str(prefix/'usr/include/newlib'),'-I'+str(ROOT),'-I'+str(ROOT/'include'),
 '-c',str(wrapper),'-o',str(obj)],check=True)
sections={}
for line in subprocess.check_output([str(bin/'arm-none-eabi-size'),'-A',str(obj)],text=True).splitlines():
    m=re.fullmatch(r'(\S+)\s+(\d+)\s+(\d+)',line.strip())
    if m:sections[m.group(1)]=int(m.group(2))
frames={}
for line in obj.with_suffix('.su').read_text().splitlines():
    cols=line.split('\t')
    if len(cols)>=2:frames[cols[0].rsplit(':',1)[-1]]=int(cols[1])
def allocated(report,start,capacity):
    return sum(row['bytes'] for row in report['sections'] if start<=row['address']<start+capacity)
rom0=allocated(baseline,0x08000000,32*1024*1024);rom1=allocated(resources,0x08000000,32*1024*1024)
t0=metrics['ticks0'];t42=metrics['ticks42'];c9c0=997859;c9c42=1448983
host=json.loads((ROOT/'reports/c10a-feasibility.json').read_text())
phase0={name:metrics[name+'0'] for name in ('init','select','trial','commit','emit','validate')}
phase42={name:metrics[name+'42'] for name in ('init','select','trial','commit','emit','validate')}
report={'checkpoint':'C10A','decision':'cooperative architecture is viable; C10B must split trial propagation and final validation to enforce a one-frame quantum before runtime integration',
 'scope':'C9C-exact cooperative phases and maximum atomic-step timing on actual ARM target code under headless mGBA; test-only integration',
 'target_commit':pin,'test_passes':11,'test_expected':11,'metrics':metrics,
 'correctness':{'reference_seeds':len(host['seeds']),'reference_successes':host['successes'],
  'exact_c9c_layout_matches':host['exact_c9c_matches'],
  'schedule_independent_replays':host['schedule_independent_replays'],'independent_validations':host['independent_validations'],
  'cap3_stress':host['cap3_stress'],
  'synthetic_test_executions':len(json.loads((ROOT/'reports/c10a-test-cases.json').read_text()))},
 'timing':{'timer_cpu_cycles_per_tick':64,'gba_cpu_hz':16777216,'ticks_per_frame':4389,
  'seed0_total_seconds':round(t0/262144,6),'seed0_total_frames':round(t0/4389,6),
  'seed42_total_seconds':round(t42/262144,6),'seed42_total_frames':round(t42/4389,6),
  'approval_seconds':round(metrics['approval_ticks']/262144,6),
  'total_overhead_vs_c9c_seed0':round(t0/c9c0,6),'total_overhead_vs_c9c_seed42':round(t42/c9c42,6),
  'max_phase_ticks_seed0':phase0,'max_phase_ticks_seed42':phase42,
  'max_phase_frames_seed0':{k:round(v/4389,6) for k,v in phase0.items()},
  'max_phase_frames_seed42':{k:round(v/4389,6) for k,v in phase42.items()},
  'worst_atomic_phase':'validate','worst_atomic_ticks':max((*phase0.values(),*phase42.values())),
  'worst_atomic_seconds':round(max((*phase0.values(),*phase42.values()))/262144,6),
  'worst_atomic_frames':round(max((*phase0.values(),*phase42.values()))/4389,6),
  'assessment':'Cooperative control adds only 4.9–6.2% on ARM. Most phases fit one frame, but the worst trial is 1.60 frames and final validation is 3.38 frames; C10B must make propagation and validation internally resumable.'},
 'heap':{'workspace_bytes':metrics['work'],'session_bytes':metrics['session'],
  'combined_state_bytes':metrics['work']+metrics['session'],'workspace_change_vs_c9c_bytes':0,
  'workspace_reduction_vs_c7b_bytes':47388-metrics['work'],
  'workspace_reduction_vs_c7b_percent':round(100*(47388-metrics['work'])/47388,3),
  'allocator_overhead_bytes':metrics['heap_before_free']-metrics['heap_during_free']-metrics['work'],
  'largest_contiguous_before':metrics['heap_before_largest'],'largest_contiguous_during':metrics['heap_during_largest'],
  'heap_restored_exactly':metrics['heap_before_free']==metrics['heap_after_free'] and metrics['heap_before_largest']==metrics['heap_after_largest']},
 'event_index':json.loads((ROOT/'reports/reference-c9c-event-index.json').read_text()),
 'cooperative_host':{'steps':host['steps'],'simulated_advances':host['simulated_advances'],
  'max_atomic_operation_proxy':host['max_atomic_operation_proxy'],
  'in_process_benchmark':host['in_process_benchmark'],'overhead_vs_c9c_warm':host['overhead_vs_c9c_warm']},
 'linked_test_image_delta':{'baseline_rom_allocated_section_bytes':rom0,'c10a_rom_allocated_section_bytes':rom1,
  'rom_allocated_section_delta_bytes':rom1-rom0,
  'baseline_ewram_static_span_bytes':baseline['regions']['EWRAM']['static_span_bytes'],
  'c10a_ewram_static_span_bytes':resources['regions']['EWRAM']['static_span_bytes'],
  'ewram_static_span_delta_bytes':resources['regions']['EWRAM']['static_span_bytes']-baseline['regions']['EWRAM']['static_span_bytes'],
  'interpretation':'Conservative test-link delta including harness and retained support, not a production link.'},
 'candidate_object':{'sections':sections,'own_frame_bytes':frames,'largest_own_frame_bytes':max(frames.values()),
  'largest_own_frame_function':max(frames,key=frames.get),
  'warning':'Compiler own frames are not a call-chain or interrupt-stack high-water measurement.'},
 'identity':{'published_test_value':metrics['algorithm'],'meaning':'zero is deliberately unassigned; no save/runtime Algorithm 5 identity exists'},
 'staged_input_sha256':staged,'target_test_elf_sha256':elf_hash,
 'log_sha256':hashlib.sha256(log.read_bytes()).hexdigest(),
 'host_report_sha256':hashlib.sha256((ROOT/'reports/c10a-feasibility.json').read_bytes()).hexdigest(),
 'resource_report':str(resource_path.relative_to(ROOT)),
 'evidence_limits':['Headless target test only; no production hooks, save restoration or UI.',
  'Total timer excludes one-time approval and workspace allocation/zero-fill/release.',
  'Per-step timers measure isolated calls without real callback/render/audio contention.',
  'Runtime stack high-water was not canary-measured.',
  'Reference-model acceptance is not target-world or completion validation.']}
out=pathlib.Path(a.output).resolve();out.parent.mkdir(parents=True,exist_ok=True)
out.write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report,indent=2))
