#!/usr/bin/env python3
"""Prove C10B equivalence and quantify internally resumable host work."""
import argparse,hashlib,json,math,pathlib,statistics,subprocess,sys,time
ROOT=pathlib.Path(__file__).resolve().parents[2];sys.path.insert(0,str(ROOT/'tests'))
from validate import validate,Invalid
p=argparse.ArgumentParser(description=__doc__);p.add_argument('--stress-seeds',type=int,default=1024)
p.add_argument('--benchmark-repetitions',type=int,default=5);a=p.parse_args()
SEEDS=list(range(64))+[255,256,65535,4294967295]
BASE_KEYS=('result','last_rejection','attempt','trial_cap','records','attempts','pairs',
 'eligible_partners','partner_trials','state_evaluations','forward_components','reverse_components',
 'repair_components','active_visits','conditional_visits','row_ors','representative_bit_visits',
 'pair_alias_visits','reverse_calls','reverse_edge_updates','set_word_ops','score_word_ops',
 'component_rep_updates','work_bytes')
build=ROOT/'build/c10b';build.mkdir(parents=True,exist_ok=True);data_path=ROOT/'data/reference-normalized.json'
subprocess.run([sys.executable,str(ROOT/'tools/warprandogen/compile.py'),str(data_path),str(build/'graph.h')],check=True)
subprocess.run([sys.executable,str(ROOT/'tools/warprandogen/compile_c9c_index.py'),str(data_path),
                str(build/'reference-c9c-event-index.h')],check=True)
common=['cc','-std=c99','-Wall','-Wextra','-Werror','-pedantic','-O2','-fstack-usage',
        '-I'+str(ROOT/'include'),'-I'+str(build)]
prior=build/'c9c';candidate=build/'c10b'
subprocess.run([*common,str(ROOT/'tools/experiments/c9c_candidate.c'),'-o',str(prior)],check=True)
subprocess.run([*common,str(ROOT/'tools/experiments/c10b_candidate.c'),'-o',str(candidate)],check=True)
def invoke(exe,seed,budget=None):
    args=[str(exe),str(seed),'3','8']
    if budget is not None:args.append(str(budget))
    return json.loads(subprocess.check_output(args,text=True))
def exact(before,result,seed,label):
    if any(before[k]!=result[k] for k in BASE_KEYS):raise SystemExit(f'C9C/C10B mismatch seed {seed} ({label})')
data=json.loads(data_path.read_text());rows=[];budgets=(1,7,31,257,65535)
for position,seed in enumerate(SEEDS):
    before=invoke(prior,seed);budget=budgets[position%len(budgets)]
    start=time.perf_counter();result=invoke(candidate,seed,budget);elapsed=time.perf_counter()-start
    replay=invoke(candidate,seed,budgets[(position+2)%len(budgets)])
    exact(before,result,seed,'selected budget');exact(before,replay,seed,'alternate budget')
    if result['result']!=0:raise SystemExit(f'C10B failure seed {seed}')
    try:validate(data,result['records'])
    except Invalid as e:raise SystemExit(f'C10B/Python disagreement seed {seed}: {e}')
    records=result.pop('records');result.pop('advances')
    rows.append(result|{'seed':seed,'budget':budget,'host_seconds':elapsed,'record_sha256':hashlib.sha256(
      json.dumps(records,separators=(',',':')).encode()).hexdigest()})
    if position%16==15:print('completed',position+1,'of',len(SEEDS),flush=True)
stress=[]
for seed in range(a.stress_seeds):
    before=invoke(prior,seed);result=invoke(candidate,seed,(seed%257)+1);exact(before,result,seed,'stress')
    records=result.pop('records')
    if result['result']==0:
        try:validate(data,records)
        except Invalid as e:raise SystemExit(f'C10B stress/Python disagreement seed {seed}: {e}')
    elif records:raise SystemExit(f'C10B stress exposed rejected records seed {seed}')
    stress.append({'seed':seed,'result':result['result'],'attempt':result['attempt'],
      'attempts':result['attempts'],'steps':result['steps'],'trial_steps':result['trial_steps']})
    if seed%256==255:print('stress completed',seed+1,'of',a.stress_seeds,flush=True)
benchmarks={}
for name,defines in [('c9c_warm',['BENCH_C9C_WARM']),('c10b_q1',['BENCH_C10B','C10B_BENCH_QUANTA=1']),
                     ('c10b_q16',['BENCH_C10B','C10B_BENCH_QUANTA=16']),
                     ('c10b_q64',['BENCH_C10B','C10B_BENCH_QUANTA=64']),
                     ('c10b_q256',['BENCH_C10B','C10B_BENCH_QUANTA=256'])]:
    exe=build/('bench-'+name);subprocess.run([*common,*('-D'+v for v in defines),
      str(ROOT/'tools/experiments/candidate_benchmark.c'),'-o',str(exe)],check=True)
    start=time.perf_counter();output=subprocess.check_output([str(exe),str(a.benchmark_repetitions)],text=True).strip()
    benchmarks[name]={'seconds':time.perf_counter()-start,'output':output}
if len({v['output'] for v in benchmarks.values()})!=1:raise SystemExit('benchmark digest mismatch')
group_keys=('max_init_units','max_select_units','max_trial_units','max_commit_units','max_emit_units','max_validate_units')
report={'checkpoint':'C10B host','status':'experimental internally resumable state machine; no public/save identity',
 'scope':'C9C-exact microphases over 68 standard and 1024 stress seeds; host operation-bound evidence',
 'seeds':SEEDS,'successes':len(rows),'exact_c9c_matches':len(rows),'schedule_independent_replays':len(rows),
 'independent_validations':len(rows),'first_attempt_successes':sum(r['attempt']==0 for r in rows),
 'max_attempts':max(r['attempts'] for r in rows),'host_seconds_total':sum(r['host_seconds'] for r in rows),
 'steps':{'min':min(r['steps'] for r in rows),'median':statistics.median(r['steps'] for r in rows),
   'max':max(r['steps'] for r in rows),'seed0':next(r['steps'] for r in rows if r['seed']==0),
   'seed42':next(r['steps'] for r in rows if r['seed']==42)},
 'simulated_advances':{str(b):{'max_per_generation':max(math.ceil(r['steps']/b) for r in rows),
   'seed0':math.ceil(next(r['steps'] for r in rows if r['seed']==0)/b),
   'seed42':math.ceil(next(r['steps'] for r in rows if r['seed']==42)/b)} for b in (1,16,64,256)},
 'max_atomic_operation_proxy':{k:max(r[k] for r in rows) for k in group_keys},
 'max_atomic_counters':{k:max(r[k] for r in rows) for k in ('max_step_active_visits',
   'max_step_conditional_visits','max_step_row_ors','max_step_rep_bits','max_step_reverse_calls')},
 'cap3_stress':{'seeds':len(stress),'successes':sum(r['result']==0 for r in stress),
   'failures':sum(r['result']!=0 for r in stress),'exact_c9c_matches':len(stress),
   'independent_validations':sum(r['result']==0 for r in stress),
   'first_attempt_successes':sum(r['result']==0 and r['attempt']==0 for r in stress),
   'max_attempts':max((r['attempts'] for r in stress),default=0),
   'max_steps':max((r['steps'] for r in stress),default=0)},
 'in_process_benchmark':benchmarks,
 'overhead_vs_c9c_warm':{name:row['seconds']/benchmarks['c9c_warm']['seconds'] for name,row in benchmarks.items() if name!='c9c_warm'},
 'host_work_bytes':rows[0]['work_bytes'],'host_session_bytes':rows[0]['session_bytes'],
 'input_sha256':hashlib.sha256(data_path.read_bytes()).hexdigest(),
 'c9c_core_sha256':hashlib.sha256((ROOT/'tools/experiments/c9c_candidate_core.inc').read_bytes()).hexdigest(),
 'c10b_core_sha256':hashlib.sha256((ROOT/'tools/experiments/c10b_candidate_core.inc').read_bytes()).hexdigest(),
 'c10b_wrapper_sha256':hashlib.sha256((ROOT/'tools/experiments/c10b_candidate.c').read_bytes()).hexdigest(),
 'limitations':['Host operation counts are not ARM cycle or worst-frame measurements.',
  'Attempt initialization and committed-pair closure remain atomic because C10A already measured them below one frame.',
  'No target callback, UI, cancellation hook, save identity or production integration exists.',
  'Reference-model acceptance is not target-world completion.'],'results':rows}
(ROOT/'reports/c10b-feasibility.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps({k:v for k,v in report.items() if k!='results'},indent=2))
