#!/usr/bin/env python3
"""Prove C9A representative-bitset equivalence to the C8C cap-three policy."""
import argparse,hashlib,json,pathlib,re,statistics,subprocess,sys,time
ROOT=pathlib.Path(__file__).resolve().parents[2]
sys.path.insert(0,str(ROOT/'tests'))
from validate import validate,Invalid
p=argparse.ArgumentParser(description=__doc__)
p.add_argument('--stress-seeds',type=int,default=1024)
p.add_argument('--benchmark-repetitions',type=int,default=10)
a=p.parse_args()
SEEDS=list(range(64))+[255,256,65535,4294967295]
build=ROOT/'build/c9a';build.mkdir(parents=True,exist_ok=True)
data_path=ROOT/'data/reference-normalized.json';graph=build/'graph.h'
subprocess.run([sys.executable,str(ROOT/'tools/warprandogen/compile.py'),str(data_path),str(graph)],check=True)
subprocess.run([sys.executable,str(ROOT/'tools/warprandogen/compile_c8c_index.py'),str(data_path),
                str(build/'reference-c8c-event-index.h')],check=True)
subprocess.run([sys.executable,str(ROOT/'tools/warprandogen/compile_c9a_index.py'),str(data_path),
                str(build/'reference-c9a-event-index.h'),'--report',str(ROOT/'reports/reference-c9a-event-index.json')],check=True)
common=['cc','-std=c99','-Wall','-Wextra','-Werror','-pedantic','-O2','-fstack-usage',
        '-I'+str(ROOT/'include'),'-I'+str(build)]
prior=build/'c8c';candidate=build/'c9a'
subprocess.run([*common,str(ROOT/'tools/experiments/c8c_candidate.c'),'-o',str(prior)],check=True)
subprocess.run([*common,str(ROOT/'tools/experiments/c9a_candidate.c'),'-o',str(candidate)],check=True)
data=json.loads(data_path.read_text());rows=[]
keys=('result','last_rejection','attempt','records','attempts','pairs','eligible_partners',
      'partner_trials','state_evaluations')
for position,seed in enumerate(SEEDS):
    start=time.perf_counter();before=json.loads(subprocess.check_output([str(prior),str(seed),'3','8'],text=True))
    before_time=time.perf_counter()-start
    start=time.perf_counter();result=json.loads(subprocess.check_output([str(candidate),str(seed),'3','8'],text=True))
    elapsed=time.perf_counter()-start
    replay=json.loads(subprocess.check_output([str(candidate),str(seed),'3','8'],text=True))
    if any(before[k]!=result[k] for k in keys):raise SystemExit(f'C8C/C9A mismatch seed {seed}')
    if result!=replay:raise SystemExit(f'C9A replay mismatch seed {seed}')
    if result['result']!=0:raise SystemExit(f'C9A failure seed {seed}: {result}')
    try:validate(data,result['records'])
    except Invalid as e:raise SystemExit(f'C9A/Python disagreement seed {seed}: {e}')
    records=result.pop('records')
    rows.append(result|{'seed':seed,'record_sha256':hashlib.sha256(
      json.dumps(records,separators=(',',':')).encode()).hexdigest(),
      'host_seconds':elapsed,'c8c_host_seconds':before_time,
      'c8c_representative_visits':before['representative_visits']})
    if position%16==15:print('completed',position+1,'of',len(SEEDS),flush=True)
stress=[]
for seed in range(a.stress_seeds):
    before=json.loads(subprocess.check_output([str(prior),str(seed),'3','8'],text=True))
    result=json.loads(subprocess.check_output([str(candidate),str(seed),'3','8'],text=True))
    replay=json.loads(subprocess.check_output([str(candidate),str(seed),'3','8'],text=True))
    if any(before[k]!=result[k] for k in keys):raise SystemExit(f'C8C/C9A stress mismatch seed {seed}')
    if result!=replay:raise SystemExit(f'C9A stress replay mismatch seed {seed}')
    records=result.pop('records')
    if result['result']==0:
        try:validate(data,records)
        except Invalid as e:raise SystemExit(f'C9A stress/Python disagreement seed {seed}: {e}')
    elif records:raise SystemExit(f'C9A stress published rejected records seed {seed}')
    stress.append({'seed':seed,'result':result['result'],'attempt':result['attempt'],
                   'attempts':result['attempts'],'partner_trials':result['partner_trials']})
    if seed%256==255:print('stress completed',seed+1,'of',a.stress_seeds,flush=True)
benchmarks={}
for name,define,index_name in [('c8c','BENCH_C8C','reference-c8c-event-index.h'),
                               ('c9a','BENCH_C9A','reference-c9a-event-index.h')]:
    exe=build/('bench-'+name)
    subprocess.run([*common,'-D'+define,str(ROOT/'tools/experiments/candidate_benchmark.c'),'-o',str(exe)],check=True)
    start=time.perf_counter();output=subprocess.check_output([str(exe),str(a.benchmark_repetitions)],text=True).strip()
    benchmarks[name]={'seconds':time.perf_counter()-start,'output':output}
if benchmarks['c8c']['output']!=benchmarks['c9a']['output']:
    raise SystemExit('C8C/C9A in-process benchmark digest mismatch')
def frames(exe_name):
    result=[]
    for path in build.glob(exe_name+'-*.su'):
        for line in path.read_text().splitlines():
            match=re.search(r':([^:\t]+)\t(\d+)\t(.+)$',line)
            if match:result.append({'function':match.group(1),'bytes':int(match.group(2)),'kind':match.group(3)})
    return result
meta=json.loads((ROOT/'reports/reference-c9a-event-index.json').read_text())
report={'checkpoint':'C9A host','status':'experimental; no public/save identity',
 'scope':'68-seed exact C8C cap-three equivalence plus 1024-seed stress and in-process timing',
 'seeds':SEEDS,'successes':len(rows),'exact_c8c_matches':len(rows),
 'deterministic_replays':len(rows),'independent_validations':len(rows),
 'first_attempt_successes':sum(row['attempt']==0 for row in rows),
 'max_attempts':max(row['attempts'] for row in rows),
 'host_seconds_total':sum(row['host_seconds'] for row in rows),
 'c8c_host_seconds_total':sum(row['c8c_host_seconds'] for row in rows),
 'same_run_process_speedup':sum(row['c8c_host_seconds'] for row in rows)/sum(row['host_seconds'] for row in rows),
 'in_process_benchmark':benchmarks,
 'in_process_speedup':benchmarks['c8c']['seconds']/benchmarks['c9a']['seconds'],
 'cap3_stress':{'seeds':len(stress),'successes':sum(row['result']==0 for row in stress),
   'failures':sum(row['result']!=0 for row in stress),
   'exact_c8c_matches':len(stress),'deterministic_replays':len(stress),
   'independent_validations':sum(row['result']==0 for row in stress),
   'first_attempt_successes':sum(row['result']==0 and row['attempt']==0 for row in stress),
   'max_attempts':max((row['attempts'] for row in stress),default=0)},
 'indexed_work':{'c8c_representative_scan_visits':sum(row['c8c_representative_visits'] for row in rows),
   'c9a_representative_bit_visits':sum(row['representative_bit_visits'] for row in rows),
   'c9a_set_word_ops':sum(row['set_word_ops'] for row in rows),
   'c9a_score_word_ops':sum(row['score_word_ops'] for row in rows),
   'c9a_component_rep_updates':sum(row['component_rep_updates'] for row in rows),
   'pair_alias_visits':sum(row['pair_alias_visits'] for row in rows),
   'reverse_edge_updates':sum(row['reverse_edge_updates'] for row in rows)},
 'host_work_bytes':rows[0]['work_bytes'],'index':meta,'host_stack_frames':frames('c9a'),
 'input_sha256':hashlib.sha256(data_path.read_bytes()).hexdigest(),
 'c8c_core_sha256':hashlib.sha256((ROOT/'tools/experiments/c8c_candidate_core.inc').read_bytes()).hexdigest(),
 'c9a_core_sha256':hashlib.sha256((ROOT/'tools/experiments/c9a_candidate_core.inc').read_bytes()).hexdigest(),
 'c9a_wrapper_sha256':hashlib.sha256((ROOT/'tools/experiments/c9a_candidate.c').read_bytes()).hexdigest(),
 'c9a_index_header_sha256':hashlib.sha256((build/'reference-c9a-event-index.h').read_bytes()).hexdigest(),
 'limitations':['Host process wall time includes launch and JSON overhead.',
  'Reference-model acceptance is not target-world completion.',
  'No public/save Algorithm 5 identity is assigned.'],'results':rows}
(ROOT/'reports/c9a-feasibility.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps({k:v for k,v in report.items() if k not in ('results','host_stack_frames')},indent=2))
