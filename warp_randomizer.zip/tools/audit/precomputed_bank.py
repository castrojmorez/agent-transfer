#!/usr/bin/env python3
"""Measure a compact bank of independently validated Algorithm-3 mappings."""
import argparse,hashlib,json,os,pathlib,subprocess,sys,tempfile,time

ROOT=pathlib.Path(__file__).resolve().parents[2]
sys.path.insert(0,str(ROOT/'tests'))
from validate import validate

p=argparse.ArgumentParser(description=__doc__)
p.add_argument('--count',type=int,default=32)
p.add_argument('--output',default=str(ROOT/'reports/precomputed-bank-feasibility.json'))
a=p.parse_args()
if a.count<2 or a.count>256 or a.count&(a.count-1):
    p.error('--count must be a power of two from 2 through 256')

model=json.loads((ROOT/'data/reference-normalized.json').read_text())
core=ROOT/'src/warp_rando.c';header=ROOT/'include/warp_rando.h'
graph=ROOT/'data/reference-graph.h';harness=ROOT/'tests/harness.c'
start=time.perf_counter();layouts=[];common_triggers=None
with tempfile.TemporaryDirectory() as temporary:
    temp=pathlib.Path(temporary)
    (temp/'graph.h').write_bytes(graph.read_bytes())
    executable=temp/'run'
    subprocess.run([os.environ.get('CC','cc'),'-std=c99','-O2',
                    '-I'+str(ROOT/'include'),'-I'+str(temp),str(core),
                    str(harness),'-o',str(executable)],check=True)
    for seed in range(a.count):
        run=subprocess.run([str(executable),str(seed),'1'],capture_output=True,
                           text=True,check=True)
        result=json.loads(run.stdout)
        if result['result']!=0 or not result['active'] or result['attempt']!=0:
            raise SystemExit(f'seed {seed} did not accept its first attempt')
        records=result['records'];validate(model,records)
        triggers=bytes(value for row in records for value in row[:3])
        landings=bytes(value for row in records for value in row[3:])
        if common_triggers is None:common_triggers=triggers
        elif triggers!=common_triggers:raise SystemExit('record triggers differ between layouts')
        layouts.append({'source_seed':seed,'records':len(records),
                        'landing_sha256':hashlib.sha256(landings).hexdigest()})

def mix32(value):
    value=(value+0x9e3779b9)&0xffffffff
    value=((value^(value>>16))*0x85ebca6b)&0xffffffff
    value=((value^(value>>13))*0xc2b2ae35)&0xffffffff
    return (value^(value>>16))&0xffffffff

histogram=[0]*a.count
for seed in range(65536):histogram[mix32(seed)&(a.count-1)]+=1
records=layouts[0]['records'];trigger_bytes=records*3;crc_bytes=a.count*4
projections=[]
for count in (16,32,64,128,256):
    landing_bytes=count*records*3;total=trigger_bytes+landing_bytes+count*4
    projections.append({'layouts':count,'trigger_bytes':trigger_bytes,
                        'landing_bytes':landing_bytes,'crc32_bytes':count*4,
                        'total_packed_bytes':total})
report={
    'checkpoint':'C6A',
    'scope':'Host-only feasibility measurement; no runtime bank or algorithm-ID change',
    'source_algorithm':3,
    'layouts_generated':a.count,
    'source_seeds':list(range(a.count)),
    'records_per_layout':records,
    'all_first_attempt':True,
    'independent_validation':'all layouts accepted the reference abstraction',
    'unique_landing_layouts':len({row['landing_sha256'] for row in layouts}),
    'common_trigger_sha256':hashlib.sha256(common_triggers).hexdigest(),
    'layout_digests':layouts,
    'measured_bank':{
        'trigger_bytes':trigger_bytes,
        'landing_bytes':a.count*records*3,
        'crc32_bytes':crc_bytes,
        'total_packed_bytes':trigger_bytes+a.count*records*3+crc_bytes,
        'encoding':'one shared 3-byte trigger per record; one 3-byte landing per layout/record; one CRC32 per layout',
    },
    'rom_projections':projections,
    'selection_probe':{
        'seed_domain':'0..65535',
        'mixer':'x += 0x9e3779b9; xor16/mul 0x85ebca6b; xor13/mul 0xc2b2ae35; xor16; mask count-1',
        'minimum_seeds_per_layout':min(histogram),
        'maximum_seeds_per_layout':max(histogram),
        'histogram':histogram,
    },
    'proposal':{
        'status':'candidate only; algorithm ID 4 is not assigned by this checkpoint',
        'runtime_work':'verify selected ROM row CRC, copy 532 trigger/landing triples, publish valid last',
        'persistent_ram':'WrActive only; target-ABI size remains 16,436 bytes',
        'temporary_workspace':'none for bank selection/copy',
        'identity':'preserve the user seed; algorithm identity must also bind bank version/count and selection mixer',
    },
    'tradeoffs':[
        'Startup work becomes bounded copying/checking instead of graph construction.',
        'Different seeds can select the same topology; variety is capped at bank size.',
        'Every bank regeneration becomes versioned build data and changes save identity.',
        'Reference-model validation still does not establish target-world playability.',
    ],
    'host_seconds':round(time.perf_counter()-start,6),
    'sha256':{
        'core':hashlib.sha256(core.read_bytes()).hexdigest(),
        'header':hashlib.sha256(header.read_bytes()).hexdigest(),
        'graph':hashlib.sha256(graph.read_bytes()).hexdigest(),
        'normalized_input':hashlib.sha256((ROOT/'data/reference-normalized.json').read_bytes()).hexdigest(),
    },
}
out=pathlib.Path(a.output).resolve();out.parent.mkdir(parents=True,exist_ok=True)
out.write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps({key:report[key] for key in ('layouts_generated','records_per_layout','unique_landing_layouts','measured_bank','host_seconds')},indent=2))
