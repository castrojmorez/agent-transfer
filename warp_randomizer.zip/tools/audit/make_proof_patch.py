#!/usr/bin/env python3
"""Reproduce fixed-table engine proof patch against the exact target checkout."""
import difflib,pathlib,subprocess,sys
ROOT=pathlib.Path(__file__).resolve().parents[2]
PIN='e8bd1cd7b03fc032ea37e3ecd38b379b5d01a1e7'

def replace_once(s,old,new):
    if s.count(old)!=1:raise ValueError('patch anchor is not unique: '+old[:70])
    return s.replace(old,new,1)
def make(target):
    if subprocess.check_output(['git','-C',str(target),'rev-parse','HEAD'],text=True).strip()!=PIN:raise ValueError('wrong target revision')
    changes={}
    for f in ['src/field_control_avatar.c','src/overworld.c','src/new_game.c']:
        old=(target/f).read_text()
        if old!=subprocess.check_output(['git','-C',str(target),'show','HEAD:'+f],text=True):raise ValueError('modified target input: '+f)
        new=replace_once(old,'#include "global.h"','#include "global.h"\n#include "warp_rando_proof.h"')
        if f.endswith('field_control_avatar.c'):
            new=replace_once(new,'    u8 trainerHillMapId = GetCurrentTrainerHillMapId();\n\n    if (trainerHillMapId)',
                '    u8 trainerHillMapId = GetCurrentTrainerHillMapId();\n\n    WrProof_Reset();\n    if (trainerHillMapId)')
            start='''        const struct MapHeader *mapHeader;

        SetWarpDestinationToMapWarp(warpEvent->mapGroup, warpEvent->mapNum, warpEvent->warpId);
        UpdateEscapeWarp(position->x, position->y);
        mapHeader = Overworld_GetMapHeaderByGroupAndId(warpEvent->mapGroup, warpEvent->mapNum);
        if (mapHeader->events->warps[warpEvent->warpId].mapNum == MAP_NUM(MAP_DYNAMIC))
            SetDynamicWarp(mapHeader->events->warps[warpEventId].warpId, gSaveBlock1Ptr->location.mapGroup, gSaveBlock1Ptr->location.mapNum, warpEventId);'''
            end='''        const struct MapHeader *mapHeader;
        s8 destGroup = warpEvent->mapGroup;
        s8 destMap = warpEvent->mapNum;
        s8 destWarp = warpEvent->warpId;
        bool8 redirected = FALSE;

        if (!trainerHillMapId)
            redirected = WrProof_Resolve(gSaveBlock1Ptr->location.mapGroup,
                gSaveBlock1Ptr->location.mapNum, warpEventId, &destGroup, &destMap, &destWarp);
        SetWarpDestinationToMapWarp(destGroup, destMap, destWarp);
        UpdateEscapeWarp(position->x, position->y);
        mapHeader = Overworld_GetMapHeaderByGroupAndId(destGroup, destMap);
        if (redirected)
        {
            // The proof's four destinations are ordinary static warps.
            // Inspect the actual redirected landing, not the original event.
            if (destWarp >= 0 && destWarp < mapHeader->events->warpCount
             && mapHeader->events->warps[destWarp].mapNum == MAP_NUM(MAP_DYNAMIC))
                SetDynamicWarp(mapHeader->events->warps[destWarp].warpId,
                    gSaveBlock1Ptr->location.mapGroup, gSaveBlock1Ptr->location.mapNum, warpEventId);
            WrProof_QueueArrival(destGroup, destMap, destWarp);
        }
        else
        {
            // Retain the target's preexisting non-proof behavior verbatim.
            if (mapHeader->events->warps[warpEvent->warpId].mapNum == MAP_NUM(MAP_DYNAMIC))
                SetDynamicWarp(mapHeader->events->warps[warpEventId].warpId, gSaveBlock1Ptr->location.mapGroup, gSaveBlock1Ptr->location.mapNum, warpEventId);
        }'''
            new=replace_once(new,start,end)
        elif f.endswith('overworld.c'):
            new=replace_once(new,'void SetWarpDestination(s8 mapGroup, s8 mapNum, s8 warpId, s8 x, s8 y)\n{',
                'void SetWarpDestination(s8 mapGroup, s8 mapNum, s8 warpId, s8 x, s8 y)\n{\n    WrProof_Reset();')
            new=replace_once(new,'    SetPlayerCoordsFromWarp();','    SetPlayerCoordsFromWarp();\n    WrProof_Apply(gSaveBlock1Ptr->location.mapGroup, gSaveBlock1Ptr->location.mapNum,\n        gSaveBlock1Ptr->location.warpId, &gSaveBlock1Ptr->pos.x, &gSaveBlock1Ptr->pos.y);')
            new=replace_once(new,'void CB2_ContinueSavedGame(void)\n{\n    u8 trainerHillMapId;',
                'void CB2_ContinueSavedGame(void)\n{\n    u8 trainerHillMapId;\n\n    WrProof_Reset();')
            # Reset in bypass setters at function entry, before any branches.
            for signature in ['void SetWarpDestinationToDynamicWarp(u8 unusedWarpId)',
              'void SetWarpDestinationToLastHealLocation(void)','void SetWarpDestinationForTeleport(void)',
              'void SetWarpDestinationToEscapeWarp(void)','static void SetWarpDestinationToDiveWarp(void)',
              'void SetWarpDestinationToFixedHoleWarp(s16 x, s16 y)']:
                new=replace_once(new,signature+'\n{',signature+'\n{\n    WrProof_Reset();')
        else:
            new=replace_once(new,'    ClearFollowerNPCData();','    ClearFollowerNPCData();\n    WrProof_Reset();')
        changes[f]=(old,new)
    for directory in ['include','src']:
        for path in sorted((ROOT/'patches/proof'/directory).glob('*')):changes[directory+'/'+path.name]=('',path.read_text())
    out=''
    for name,(old,new) in sorted(changes.items()):
        out+=''.join(difflib.unified_diff(old.splitlines(True),new.splitlines(True),fromfile='a/'+name if old else '/dev/null',tofile='b/'+name))
    return out
if __name__=='__main__':
    if len(sys.argv)!=3:raise SystemExit('usage: make_proof_patch.py TARGET OUTPUT')
    pathlib.Path(sys.argv[2]).write_text(make(pathlib.Path(sys.argv[1])))
