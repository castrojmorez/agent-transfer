#!/usr/bin/env python3
"""Measure unchanged Algorithm 3 with the C7A single-generation control."""
import hashlib,json,pathlib,statistics,subprocess,sys,time
ROOT=pathlib.Path(__file__).resolve().parents[2];sys.path.insert(0,str(ROOT/'tests'))
from validate import validate,Invalid
seeds=list(range(64))+[255,256,65535,4294967295];build=ROOT/'build/c7a';build.mkdir(parents=True,exist_ok=True)
subprocess.run([sys.executable,str(ROOT/'tools/warprandogen/compile.py'),str(ROOT/'data/reference-normalized.json'),str(build/'graph.h')],check=True)
exe=build/'baseline'
subprocess.run(['cc','-std=c99','-Wall','-Wextra','-Werror','-pedantic','-O2','-fstack-usage',
                '-I'+str(ROOT/'include'),'-I'+str(build),str(ROOT/'tools/experiments/c7a_baseline.c'),'-o',str(exe)],check=True)
data=json.loads((ROOT/'data/reference-normalized.json').read_text());rows=[]
for seed in seeds:
    start=time.perf_counter();r=json.loads(subprocess.check_output([str(exe),str(seed),'8'],text=True));elapsed=time.perf_counter()-start
    if r['result']:
        raise SystemExit(f'Algorithm 3 control failed seed {seed}: {r}')
    try:validate(data,r['records'])
    except Invalid as e:raise SystemExit(f'Algorithm 3/Python disagreement seed {seed}: {e}')
    rows.append({'seed':seed,'host_seconds':elapsed,'attempt':r['attempt'],
        'record_sha256':hashlib.sha256(json.dumps(r['records'],separators=(',',':')).encode()).hexdigest()})
    if seed%16==15:print('completed through seed',seed,flush=True)
times=[r['host_seconds'] for r in rows]
report={'checkpoint':'C7A unchanged Algorithm-3 timing control','scope':'same 68-seed normalized reference abstraction; one C construction/emission/validation per process',
 'input_sha256':hashlib.sha256((ROOT/'data/reference-normalized.json').read_bytes()).hexdigest(),
 'core_sha256':hashlib.sha256((ROOT/'src/warp_rando.c').read_bytes()).hexdigest(),
 'successes':len(rows),'first_attempt_successes':sum(r['attempt']==0 for r in rows),
 'host_seconds_total':sum(times),'host_seconds_median':statistics.median(times),'host_seconds_max':max(times),'results':rows}
(ROOT/'reports/c7a-algorithm3-baseline.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps({k:v for k,v in report.items() if k!='results'},indent=2))
