#!/usr/bin/env python3
"""Reconstruct the historical diagnosis without changing current production files."""
import hashlib,json,pathlib,shutil,subprocess,sys,tempfile
ROOT=pathlib.Path(__file__).resolve().parents[2]
with tempfile.TemporaryDirectory(prefix='wr-algorithm2-') as tmp:
    work=pathlib.Path(tmp)
    for folder in ['data','include','src','tests','tools']:
        shutil.copytree(ROOT/folder,work/folder,ignore=shutil.ignore_patterns('__pycache__','*.pyc'))
    (work/'reports').mkdir()
    subprocess.run(['patch','--batch','--fuzz=0','-p1','-i',str(ROOT/'patches/algorithm2-reproduction.patch')],cwd=work,check=True)
    hashes=json.loads((ROOT/'reports/algorithm2/baseline-source-hashes.json').read_text())
    for rel,digest in hashes.items():
        if hashlib.sha256((work/rel).read_bytes()).hexdigest()!=digest:raise SystemExit('baseline hash mismatch: '+rel)
    commands=[['tools/warprandogen/import_reference.py','data/reference','data/overrides.json','data/reference-normalized.json','reports/reference-import.json'],
              ['tools/audit/diagnose_failures.py'],['tools/audit/analyze_counterfactuals.py']]
    for args in commands:subprocess.run([sys.executable,*args],cwd=work,check=True)
    for name in ['failure-diagnosis.json','fixed-mapping-counterfactuals.json']:
        if (work/'reports'/name).read_bytes()!=(ROOT/'reports/algorithm2'/name).read_bytes():
            raise SystemExit('historical report mismatch: '+name)
        print('Exact historical reproduction:',name,flush=True)
