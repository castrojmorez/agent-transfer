#!/usr/bin/env python3
"""Check C8B ARM timing, target resources and staged experimental inputs."""
import argparse,hashlib,json,pathlib,re,subprocess
ROOT=pathlib.Path(__file__).resolve().parents[2]
p=argparse.ArgumentParser(description=__doc__)
p.add_argument('target');p.add_argument('prefix');p.add_argument('log');p.add_argument('elf')
p.add_argument('baseline_resources');p.add_argument('resources');p.add_argument('output')
a=p.parse_args();target=pathlib.Path(a.target).resolve();prefix=pathlib.Path(a.prefix).resolve()
log=pathlib.Path(a.log).resolve();elf=pathlib.Path(a.elf).resolve()
base_path=pathlib.Path(a.baseline_resources).resolve();resource_path=pathlib.Path(a.resources).resolve()
pin='e8bd1cd7b03fc032ea37e3ecd38b379b5d01a1e7'
if subprocess.check_output(['git','-C',str(target),'rev-parse','HEAD'],text=True).strip()!=pin:
    p.error('target checkout is not pinned expansion/1.17.0')
text=log.read_text();metrics={}
for marker,suffix in (('GBA Debug: WRC8B0 ',''),('GBA Debug: WRC8B42 ',''),
                      ('GBA Debug: WRC8BOPS0 ','0'),('GBA Debug: WRC8BOPS42 ','42'),
                      ('GBA Debug: WRC8BMEM ','')):
    if marker not in text:p.error('missing marker '+marker.strip())
    segment=text.split(marker,1)[1].splitlines()[0]
    metrics.update({k+suffix:int(v) for k,v in re.findall(r'(\w+)=(-?\d+)',segment)})
expected={'result0':0,'last0':0,'attempt0':0,'digest0_decimal':-755938432,
 'trials0':766,'states0':766,'result42':0,'last42':4,'attempt42':1,
 'digest42_decimal':1026903975,'trials42':1525,'states42':1525,
 'forward0':5747,'reverse0':3686,'repair0':7404,'active0':24604,'conditional0':35390,
 'forward42':3648,'reverse42':2539,'repair42':10093,'active42':28525,'conditional42':13525,
 'work':13776,'active':16436,'algorithm':0}
for key,value in expected.items():
    if metrics.get(key)!=value:p.error(f'unexpected {key}: {metrics.get(key)} != {value}')
for suffix in ('free','largest'):
    if metrics.get('heap_before_'+suffix)!=metrics.get('heap_after_'+suffix):p.error('heap was not restored')
if text.count('GBA Debug: :P')!=11:p.error('unexpected target pass count')
inputs={'include/warp_rando.h':target/'include/warp_rando.h',
 'src/warp_rando.c':target/'test/warp_rando_core.c',
 'data/reference-graph.h':target/'test/warp_reference_graph.h',
 'data/reference-c8b-event-index.h':target/'test/warp_reference_c8b_event_index.h',
 'tools/experiments/c8b_candidate_core.inc':target/'test/c8b_candidate_core.inc',
 'patches/engine-tests/warp_rando_c8b.c':target/'test/warp_rando_c8b.c'}
staged={}
for relative,destination in inputs.items():
    digest=hashlib.sha256((ROOT/relative).read_bytes()).hexdigest()
    if digest!=hashlib.sha256(destination.read_bytes()).hexdigest():p.error('staged file differs: '+relative)
    staged[relative]=digest
resources=json.loads(resource_path.read_text());baseline=json.loads(base_path.read_text())
elf_hash=hashlib.sha256(elf.read_bytes()).hexdigest()
if resources['elf_sha256']!=elf_hash:p.error('resource report describes another ELF')
build=ROOT/'build/c8b-resources';build.mkdir(parents=True,exist_ok=True)
wrapper=build/'candidate-audit.c';wrapper.write_text(
 '#include "src/warp_rando.c"\n#include "tools/experiments/c8b_candidate_core.inc"\n'
 '#include "data/reference-c8b-event-index.h"\n'
 'int c8b_candidate_entry(const struct WrGraph *g,uint32_t seed,uint16_t retries,'
 'struct C8bWork *w,struct C8bStats *s,uint16_t *count,uint16_t *attempt,int *last)'
 '{return c8b_generate_candidate(g,&c8b_index,seed,3,retries,w,s,count,attempt,last);}\n')
flags=['-std=gnu17','-mthumb','-mthumb-interwork','-O2','-mabi=apcs-gnu','-mtune=arm7tdmi','-march=armv4t']
bin=prefix/'usr/bin';obj=build/'candidate-audit.o'
subprocess.run([str(bin/'arm-none-eabi-gcc'),*flags,'-fstack-usage',
 '-I'+str(prefix/'usr/include/newlib'),'-I'+str(ROOT),'-I'+str(ROOT/'include'),
 '-c',str(wrapper),'-o',str(obj)],check=True)
sections={}
for line in subprocess.check_output([str(bin/'arm-none-eabi-size'),'-A',str(obj)],text=True).splitlines():
    m=re.fullmatch(r'(\S+)\s+(\d+)\s+(\d+)',line.strip())
    if m:sections[m.group(1)]=int(m.group(2))
frames={}
for line in obj.with_suffix('.su').read_text().splitlines():
    cols=line.split('\t')
    if len(cols)>=2:frames[cols[0].rsplit(':',1)[-1]]=int(cols[1])
def allocated(report,start,capacity):
    return sum(row['bytes'] for row in report['sections'] if start<=row['address']<start+capacity)
rom0=allocated(baseline,0x08000000,32*1024*1024);rom1=allocated(resources,0x08000000,32*1024*1024)
t0=metrics['ticks0'];t42=metrics['ticks42'];c8a0=6273289;c8a42=11919509
host=json.loads((ROOT/'reports/c8b-feasibility.json').read_text())
report={'checkpoint':'C8B','decision':'cap 3 is reliable but too small a gain; continue to C8C state reuse/prefilter and leave Algorithm 5 unassigned',
 'scope':'cap-3 C8B trial-volume policy on the event-driven candidate in actual ARM target code under headless mGBA; test-only integration',
 'target_commit':pin,'test_passes':11,'test_expected':11,'metrics':metrics,
 'correctness':{'reference_seeds':host['caps']['3']['seeds'],'reference_successes':host['caps']['3']['successes'],
  'cap4_exact_c8a_layout_matches':host['cap4_exact_c8a_matches'],
  'deterministic_replays':host['deterministic_replays'],'independent_validations':host['independent_validations'],
  'cap3_stress':host['cap3_stress'],
  'synthetic_test_executions':len(json.loads((ROOT/'reports/c8b-test-cases.json').read_text()))},
 'timing':{'timer_cpu_cycles_per_tick':64,'gba_cpu_hz':16777216,'ticks_per_frame':4389,
  'seed0_seconds':round(t0/262144,6),'seed0_frames':round(t0/4389,6),
  'seed42_seconds':round(t42/262144,6),'seed42_frames':round(t42/4389,6),
  'speedup_vs_c8a_seed0':round(c8a0/t0,6),'speedup_vs_c8a_seed42':round(c8a42/t42,6),
  'assessment':'Reliable and faster, but 21.8–36.0 seconds remains unacceptable for synchronous generation; trial-cap tuning is not the route to real time.'},
 'heap':{'workspace_bytes':metrics['work'],'workspace_change_vs_c8a_bytes':metrics['work']-13776,
  'workspace_reduction_vs_c7b_bytes':47388-metrics['work'],
  'workspace_reduction_vs_c7b_percent':round(100*(47388-metrics['work'])/47388,3),
  'allocator_overhead_bytes':metrics['heap_before_free']-metrics['heap_during_free']-metrics['work'],
  'largest_contiguous_before':metrics['heap_before_largest'],'largest_contiguous_during':metrics['heap_during_largest'],
  'heap_restored_exactly':metrics['heap_before_free']==metrics['heap_after_free'] and metrics['heap_before_largest']==metrics['heap_after_largest']},
 'event_index':json.loads((ROOT/'reports/reference-c8b-event-index.json').read_text()),
 'linked_test_image_delta':{'baseline_rom_allocated_section_bytes':rom0,'c8b_rom_allocated_section_bytes':rom1,
  'rom_allocated_section_delta_bytes':rom1-rom0,
  'baseline_ewram_static_span_bytes':baseline['regions']['EWRAM']['static_span_bytes'],
  'c8b_ewram_static_span_bytes':resources['regions']['EWRAM']['static_span_bytes'],
  'ewram_static_span_delta_bytes':resources['regions']['EWRAM']['static_span_bytes']-baseline['regions']['EWRAM']['static_span_bytes'],
  'interpretation':'Conservative test-link delta including harness and retained support, not a production link.'},
 'candidate_object':{'sections':sections,'own_frame_bytes':frames,'largest_own_frame_bytes':max(frames.values()),
  'largest_own_frame_function':max(frames,key=frames.get),
  'warning':'Compiler own frames are not a call-chain or interrupt-stack high-water measurement.'},
 'identity':{'published_test_value':metrics['algorithm'],'meaning':'zero is deliberately unassigned; no save/runtime Algorithm 5 identity exists'},
 'staged_input_sha256':staged,'target_test_elf_sha256':elf_hash,
 'log_sha256':hashlib.sha256(log.read_bytes()).hexdigest(),
 'host_report_sha256':hashlib.sha256((ROOT/'reports/c8b-feasibility.json').read_bytes()).hexdigest(),
 'resource_report':str(resource_path.relative_to(ROOT)),
 'evidence_limits':['Headless target test only; no production hooks, save restoration or UI.',
  'Timer excludes workspace allocation/zero-fill and release.','Runtime stack high-water was not canary-measured.',
  'Reference-model acceptance is not target-world or completion validation.']}
out=pathlib.Path(a.output).resolve();out.parent.mkdir(parents=True,exist_ok=True)
out.write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report,indent=2))
