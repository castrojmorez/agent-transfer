#!/usr/bin/env python3
"""Host sizeof and compiler frame estimates, explicitly not GBA measurements."""
import json,pathlib,subprocess
ROOT=pathlib.Path(__file__).resolve().parents[2];build=ROOT/'build/reference'
if not (build/'graph.h').exists():raise SystemExit('run make seeds first')
source='''#include "graph.h"
#include <stdio.h>
int main(void) {
 printf("{\\\"workspace_bytes\\\":%zu,\\\"active_table_capacity_bytes\\\":%zu,\\\"metadata_bytes\\\":%u,\\\"graph_arrays_bytes\\\":%zu,\\\"graph_descriptor_bytes\\\":%zu}\\n",
 sizeof(struct WrWork),sizeof(struct WrActive),WR_SAVE_BYTES,
 sizeof(wr_nodes)+sizeof(wr_edges)+sizeof(wr_edges_reverse)+sizeof(wr_bounds)+sizeof(wr_bounds_reverse)+sizeof(wr_rules)+sizeof(wr_reqs)+sizeof(wr_goals),sizeof(wr_graph));return 0;
}
'''
(build/'sizes.c').write_text(source)
subprocess.run(['cc','-std=c99','-I'+str(ROOT/'include'),'-I'+str(build),str(build/'sizes.c'),'-o',str(build/'sizes')],check=True)
report=json.loads(subprocess.check_output([str(build/'sizes')],text=True))
report['scope']='Host GCC sizeof only; target ABI/link placement, ROM size, save capacity and duration unverified'
report['compiler']=subprocess.check_output(['cc','--version'],text=True).splitlines()[0]
frames=[]
for path in sorted(build.glob('*warp_rando.su')):
 for line in path.read_text().splitlines():
  parts=line.split('\t');frames.append({'function':parts[0].rsplit(':',1)[-1],'bytes':int(parts[1]),'kind':parts[2]})
report['host_static_stack_frames']=frames
(ROOT/'reports/resources.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report,indent=2))
