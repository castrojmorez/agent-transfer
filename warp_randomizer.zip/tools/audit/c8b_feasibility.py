#!/usr/bin/env python3
"""Measure C8B partner-trial caps against the frozen C8A cap-4 control."""
import argparse,hashlib,json,pathlib,re,statistics,subprocess,sys,time
ROOT=pathlib.Path(__file__).resolve().parents[2]
sys.path.insert(0,str(ROOT/'tests'))
from validate import validate,Invalid
p=argparse.ArgumentParser(description=__doc__)
p.add_argument('--seeds',type=int,default=64,help='consecutive seeds before four boundary seeds')
p.add_argument('--stress-seeds',type=int,default=1024,help='consecutive cap-3 robustness seeds')
a=p.parse_args()
SEEDS=list(range(a.seeds))+[255,256,65535,4294967295]
SEEDS=list(dict.fromkeys(SEEDS))
build=ROOT/'build/c8b';build.mkdir(parents=True,exist_ok=True)
data_path=ROOT/'data/reference-normalized.json';graph=build/'graph.h'
index=build/'reference-c8b-event-index.h'
subprocess.run([sys.executable,str(ROOT/'tools/warprandogen/compile.py'),str(data_path),str(graph)],check=True)
subprocess.run([sys.executable,str(ROOT/'tools/warprandogen/compile_event_index.py'),str(data_path),
                str(build/'reference-event-index.h')],check=True)
subprocess.run([sys.executable,str(ROOT/'tools/warprandogen/compile_c8b_index.py'),str(data_path),str(index),
                '--report',str(ROOT/'reports/reference-c8b-event-index.json')],check=True)
common=['cc','-std=c99','-Wall','-Wextra','-Werror','-pedantic','-O2','-fstack-usage',
        '-I'+str(ROOT/'include'),'-I'+str(build)]
control=build/'c8a-control';candidate=build/'c8b'
subprocess.run([*common,str(ROOT/'tools/experiments/c8a_candidate.c'),'-o',str(control)],check=True)
subprocess.run([*common,str(ROOT/'tools/experiments/c8b_candidate.c'),'-o',str(candidate)],check=True)
data=json.loads(data_path.read_text());rows=[];control_matches=0;deterministic=0;validations=0
keys=('result','last_rejection','attempt','records')
for position,seed in enumerate(SEEDS):
    baseline=json.loads(subprocess.check_output([str(control),str(seed),'8'],text=True))
    for cap in range(1,5):
        start=time.perf_counter()
        result=json.loads(subprocess.check_output([str(candidate),str(seed),str(cap),'8'],text=True))
        elapsed=time.perf_counter()-start
        replay=json.loads(subprocess.check_output([str(candidate),str(seed),str(cap),'8'],text=True))
        if result!=replay:raise SystemExit(f'C8B nondeterministic seed {seed} cap {cap}')
        deterministic+=1
        records=result.pop('records')
        if result['result']==0:
            try:validate(data,records)
            except Invalid as e:raise SystemExit(f'C8B/Python disagreement seed {seed} cap {cap}: {e}')
            validations+=1
        elif records:raise SystemExit(f'C8B published rejected records seed {seed} cap {cap}')
        if cap==4:
            control_records=baseline['records']
            if {k:(records if k=='records' else result[k]) for k in keys}!={k:baseline[k] for k in keys}:
                raise SystemExit(f'C8B cap-4/control mismatch seed {seed}')
            control_matches+=1
        digest=hashlib.sha256(json.dumps(records,separators=(',',':')).encode()).hexdigest()
        rows.append(result|{'seed':seed,'record_count':len(records),'record_sha256':digest,
                            'host_seconds':elapsed})
    if position%16==15:print('completed',position+1,'of',len(SEEDS),flush=True)
def frames(exe_name):
    candidates=list(build.glob(exe_name+'-*.su'))
    result=[]
    for path in candidates:
        for line in path.read_text().splitlines():
            match=re.search(r':([^:\t]+)\t(\d+)\t(.+)$',line)
            if match:result.append({'function':match.group(1),'bytes':int(match.group(2)),'kind':match.group(3)})
    return result
summaries={}
for cap in range(1,5):
    subset=[row for row in rows if row['trial_cap']==cap];success=[row for row in subset if row['result']==0]
    summaries[str(cap)]={'seeds':len(subset),'successes':len(success),
      'failures':len(subset)-len(success),'failure_seeds':[row['seed'] for row in subset if row['result']!=0],
      'first_attempt_successes':sum(row['attempt']==0 for row in success),
      'max_attempts':max((row['attempts'] for row in subset),default=0),
      'partner_trials_total':sum(row['partner_trials'] for row in subset),
      'partner_trials_success_total':sum(row['partner_trials'] for row in success),
      'partner_trials_median':statistics.median(row['partner_trials'] for row in subset),
      'state_evaluations_total':sum(row['state_evaluations'] for row in subset),
      'host_seconds_total':sum(row['host_seconds'] for row in subset),
      'host_seconds_median':statistics.median(row['host_seconds'] for row in subset),
      'host_seconds_max':max(row['host_seconds'] for row in subset)}
stress_rows=[]
for seed in range(a.stress_seeds):
    result=json.loads(subprocess.check_output([str(candidate),str(seed),'3','8'],text=True))
    replay=json.loads(subprocess.check_output([str(candidate),str(seed),'3','8'],text=True))
    if result!=replay:raise SystemExit(f'C8B cap-3 stress replay mismatch seed {seed}')
    records=result.pop('records')
    if result['result']==0:
        try:validate(data,records)
        except Invalid as e:raise SystemExit(f'C8B cap-3 stress/Python disagreement seed {seed}: {e}')
    elif records:raise SystemExit(f'C8B cap-3 stress published rejected records seed {seed}')
    stress_rows.append({'seed':seed,'result':result['result'],'attempt':result['attempt'],
                        'attempts':result['attempts'],'partner_trials':result['partner_trials']})
    if seed%256==255:print('stress completed',seed+1,'of',a.stress_seeds,flush=True)
stress={'trial_cap':3,'seeds':len(stress_rows),
 'successes':sum(row['result']==0 for row in stress_rows),
 'failures':sum(row['result']!=0 for row in stress_rows),
 'deterministic_replays':len(stress_rows),
 'independent_validations':sum(row['result']==0 for row in stress_rows),
 'failure_seeds':[row['seed'] for row in stress_rows if row['result']!=0],
 'first_attempt_successes':sum(row['result']==0 and row['attempt']==0 for row in stress_rows),
 'max_attempts':max((row['attempts'] for row in stress_rows),default=0),
 'partner_trials_total':sum(row['partner_trials'] for row in stress_rows)}
report={'checkpoint':'C8B host','status':'experimental; no public/save identity',
 'scope':f'{len(SEEDS)}-seed normalized reference abstraction; trial caps 1-4, deterministic replay, independent validation, cap-4 C8A control',
 'seeds':SEEDS,'caps':summaries,'cap4_exact_c8a_matches':control_matches,
 'deterministic_replays':deterministic,'independent_validations':validations,
 'cap3_stress':stress,
 'selection':None,'selection_reason':None,
 'host_work_bytes':rows[0]['work_bytes'],'host_stack_frames':frames('c8b'),
 'input_sha256':hashlib.sha256(data_path.read_bytes()).hexdigest(),
 'c8a_core_sha256':hashlib.sha256((ROOT/'tools/experiments/c8a_candidate_core.inc').read_bytes()).hexdigest(),
 'c8b_core_sha256':hashlib.sha256((ROOT/'tools/experiments/c8b_candidate_core.inc').read_bytes()).hexdigest(),
 'c8b_wrapper_sha256':hashlib.sha256((ROOT/'tools/experiments/c8b_candidate.c').read_bytes()).hexdigest(),
 'c8b_index_header_sha256':hashlib.sha256(index.read_bytes()).hexdigest(),
 'limitations':['Host process wall time includes launch overhead.','Reference-model acceptance is not target-world completion.',
                'No public/save Algorithm 5 identity is assigned.'],'results':rows}
if summaries['3']['failures']==0:
    report['selection']=3
    report['selection_reason']='Lowest cap with full corpus success; caps 1 and 2 are rejected if either has failures.'
elif summaries['4']['failures']==0:
    report['selection']=4
    report['selection_reason']='No lower cap preserved full corpus success.'
else:report['selection_reason']='No tested cap preserved full corpus success.'
(ROOT/'reports/c8b-feasibility.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps({k:v for k,v in report.items() if k not in ('results','host_stack_frames')},indent=2))
