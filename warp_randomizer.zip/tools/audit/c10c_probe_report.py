#!/usr/bin/env python3
"""Check C10C ARM task timing, lifecycle, resources, and staged inputs."""
import argparse,hashlib,json,pathlib,re,subprocess
ROOT=pathlib.Path(__file__).resolve().parents[2]
p=argparse.ArgumentParser(description=__doc__)
p.add_argument('target');p.add_argument('prefix');p.add_argument('log');p.add_argument('elf')
p.add_argument('baseline_resources');p.add_argument('resources');p.add_argument('output')
a=p.parse_args();target=pathlib.Path(a.target).resolve();prefix=pathlib.Path(a.prefix).resolve()
log=pathlib.Path(a.log).resolve();elf=pathlib.Path(a.elf).resolve()
base_path=pathlib.Path(a.baseline_resources).resolve();resource_path=pathlib.Path(a.resources).resolve()
pin='e8bd1cd7b03fc032ea37e3ecd38b379b5d01a1e7'
if subprocess.check_output(['git','-C',str(target),'rev-parse','HEAD'],text=True).strip()!=pin:p.error('target checkout is not pinned expansion/1.17.0')
text=log.read_text();metrics={}
for marker in ('GBA Debug: WRC10C0 ','GBA Debug: WRC10C42 ','GBA Debug: WRC10CCANCEL ',
               'GBA Debug: WRC10CLIFE ','GBA Debug: WRC10CMEM '):
    if marker not in text:p.error('missing marker '+marker.strip())
    segment=text.split(marker,1)[1].splitlines()[0]
    metrics.update({k:int(v) for k,v in re.findall(r'(\w+)=(-?\d+)',segment)})
expected={'steps0':66274,'digest0_decimal':-755938432,'steps42':94230,
 'digest42_decimal':1026903975,'attempt42':1,'result_cancel':101,'publishes_cancel':0,
 'releases_cancel':1,'invalid0':1,'publish0':1,'release0':1,'regress0':0,
 'invalid42':1,'publish42':1,'release42':1,'regress42':0,'work':14224,
 'session':156,'job':200,'active':16436,'algorithm':0}
for key,value in expected.items():
    if metrics.get(key)!=value:p.error(f'unexpected {key}: {metrics.get(key)} != {value}')
for key in ('heap_after0_free','heap_after42_free','heap_after_cancel_free'):
    if metrics[key]!=metrics['heap_before_free']:p.error('heap was not restored')
if text.count('GBA Debug: :P')!=11:p.error('unexpected target pass count')
for key in ('callback_max0','callback_max42','callback_max_cancel'):
    if metrics[key]>3200:p.error(key+' exceeded the C10C callback budget')
for key in ('frame_max0','frame_max42','frame_max_cancel'):
    if metrics[key]>=4389:p.error(key+' reached or exceeded one frame')
inputs={'include/warp_rando.h':target/'include/warp_rando.h','src/warp_rando.c':target/'test/warp_rando_core.c',
 'data/reference-graph.h':target/'test/warp_reference_graph.h',
 'data/reference-c9c-event-index.h':target/'test/warp_reference_c9c_event_index.h',
 'tools/experiments/c9c_candidate_core.inc':target/'test/c9c_candidate_core.inc',
 'tools/experiments/c10b_candidate_core.inc':target/'test/c10b_candidate_core.inc',
 'tools/experiments/c10c_scheduler_core.inc':target/'test/c10c_scheduler_core.inc',
 'patches/engine-tests/warp_rando_c10c.c':target/'test/warp_rando_c10c.c'}
staged={}
for relative,destination in inputs.items():
    digest=hashlib.sha256((ROOT/relative).read_bytes()).hexdigest()
    if digest!=hashlib.sha256(destination.read_bytes()).hexdigest():p.error('staged file differs: '+relative)
    staged[relative]=digest
resources=json.loads(resource_path.read_text());baseline=json.loads(base_path.read_text());elf_hash=hashlib.sha256(elf.read_bytes()).hexdigest()
if resources['elf_sha256']!=elf_hash:p.error('resource report describes another ELF')
build=ROOT/'build/c10c-resources';build.mkdir(parents=True,exist_ok=True);wrapper=build/'candidate-audit.c'
wrapper.write_text(
 '#include "src/warp_rando.c"\n#include "tools/experiments/c9c_candidate_core.inc"\n'
 '#include "data/reference-c9c-event-index.h"\n#include "tools/experiments/c10b_candidate_core.inc"\n'
 '#include "tools/experiments/c10c_scheduler_core.inc"\n'
 'static uint32_t now(void *p){uint32_t *v=p;return (*v)++;}\n'
 'static int publish(void *p,const struct C10bSession *q){(void)p;(void)q;return WR_OK;}\n'
 'int c10c_candidate_entry(const struct WrGraph *g,uint32_t seed,struct C9cWork *w,struct C9cStats *s)'
 '{struct C10cJob j;struct C10cView v;struct C10cHooks h={0,publish,0,0};uint32_t ticks=0;'
 'int r=c10c_begin_prevalidated(&j,g,&c9c_index,seed,3,8,3200,w,s,&h);'
 'while(r==C10B_PENDING){ticks=0;r=c10c_pump(&j,now,&ticks);}c10c_snapshot(&j,&v);'
 '(void)c10c_request_cancel;return r+v.progress-v.progress;}\n')
flags=['-std=gnu17','-mthumb','-mthumb-interwork','-O2','-mabi=apcs-gnu','-mtune=arm7tdmi','-march=armv4t']
bin=prefix/'usr/bin';obj=build/'candidate-audit.o'
subprocess.run([str(bin/'arm-none-eabi-gcc'),*flags,'-fstack-usage','-I'+str(prefix/'usr/include/newlib'),
 '-I'+str(ROOT),'-I'+str(ROOT/'include'),'-c',str(wrapper),'-o',str(obj)],check=True)
sections={}
for line in subprocess.check_output([str(bin/'arm-none-eabi-size'),'-A',str(obj)],text=True).splitlines():
    m=re.fullmatch(r'(\S+)\s+(\d+)\s+(\d+)',line.strip())
    if m:sections[m.group(1)]=int(m.group(2))
frames={}
for line in obj.with_suffix('.su').read_text().splitlines():
    cols=line.split('\t')
    if len(cols)>=2:frames[cols[0].rsplit(':',1)[-1]]=int(cols[1])
def allocated(report,start,capacity):return sum(row['bytes'] for row in report['sections'] if start<=row['address']<start+capacity)
rom0=allocated(baseline,0x08000000,32*1024*1024);rom1=allocated(resources,0x08000000,32*1024*1024)
host=json.loads((ROOT/'reports/c10c-feasibility.json').read_text())
worst_callback=max(metrics[k] for k in ('callback_max0','callback_max42','callback_max_cancel'))
worst_frame=max(metrics[k] for k in ('frame_max0','frame_max42','frame_max_cancel'))
report={'checkpoint':'C10C','decision':'budgeted engine-task lifecycle passes under synthetic competing load; next prove a real screen/input flow and production allocation point before assigning Algorithm 5',
 'scope':'C9C-exact timer-governed C10B engine task, monotonic progress, cancellation, publish-last and cleanup on pinned ARM target; test-only integration',
 'target_commit':pin,'test_passes':11,'test_expected':11,'metrics':metrics,
 'correctness':{'reference_seeds':len(host['seeds']),'reference_successes':host['successes'],
  'exact_c9c_layout_matches':host['exact_c9c_matches'],'schedule_independent_replays':host['schedule_independent_replays'],
  'independent_validations':host['independent_validations'],'cap3_stress':host['cap3_stress'],
  'synthetic_test_executions':len(json.loads((ROOT/'reports/c10c-test-cases.json').read_text()))},
 'callback':{'budget_ticks':3200,'phase_admission_bounds_ticks':{'init':700,'select':2600,'trial':700,'commit':500,'emit':1900,'validate':800},
  'seed0_callbacks':metrics['callbacks0'],'seed42_callbacks':metrics['callbacks42'],
  'seed0_frames_at_60hz':round(metrics['frames0']/60,3),'seed42_frames_at_60hz':round(metrics['frames42']/60,3),
  'seed0_max_steps_per_callback':metrics['max_steps0'],'seed42_max_steps_per_callback':metrics['max_steps42'],
  'seed0_callback_cpu_seconds':round(metrics['callback_total0']/262144,6),
  'seed42_callback_cpu_seconds':round(metrics['callback_total42']/262144,6),
  'worst_callback_ticks':worst_callback,'worst_callback_frames':round(worst_callback/4389,6),
  'callback_budget_respected':worst_callback<=3200},
 'loaded_frame':{'synthetic_task_iterations':2048,'worst_ticks':worst_frame,'worst_frames':round(worst_frame/4389,6),
  'headroom_ticks':4389-worst_frame,'all_measured_frames_below_one':worst_frame<4389,
  'warning':'The competing task is deterministic synthetic CPU load, not a rendered new-game screen with audio/VBlank contention.'},
 'lifecycle':{'progress_scale':1000,'progress_basis':'monotonic attempt and committed-pair completion',
  'seed0_progress_regressions':metrics['regress0'],'seed42_progress_regressions':metrics['regress42'],
  'cancel_requested_after_frame':32,'cancel_completed_frame':metrics['frames_cancel'],
  'cancel_progress':metrics['progress_cancel'],'cancel_published':bool(metrics['publishes_cancel']),
  'cancel_releases':metrics['releases_cancel'],'success_publish_release_once':True,'heap_restored_all_paths':True},
 'memory':{'workspace_bytes':metrics['work'],'session_bytes':metrics['session'],'job_bytes':metrics['job'],
  'combined_transient_bytes':metrics['work']+metrics['job'],'active_bytes':metrics['active'],
  'test_engine_state_ewram_bytes':resources['regions']['EWRAM']['static_span_bytes']-baseline['regions']['EWRAM']['static_span_bytes']-metrics['active'],
  'test_build_ewram_unallocated_bytes':resources['regions']['EWRAM']['unallocated_bytes'],'test_build_iwram_unallocated_bytes':resources['regions']['IWRAM']['unallocated_bytes']},
 'linked_test_image_delta':{'baseline_rom_allocated_section_bytes':rom0,'c10c_rom_allocated_section_bytes':rom1,
  'rom_allocated_section_delta_bytes':rom1-rom0,'baseline_ewram_static_span_bytes':baseline['regions']['EWRAM']['static_span_bytes'],
  'c10c_ewram_static_span_bytes':resources['regions']['EWRAM']['static_span_bytes'],
  'ewram_static_span_delta_bytes':resources['regions']['EWRAM']['static_span_bytes']-baseline['regions']['EWRAM']['static_span_bytes'],
  'interpretation':'Conservative test-link delta including active table, scheduler state, harness and retained support; not a production link.'},
 'candidate_object':{'sections':sections,'own_frame_bytes':frames,'largest_own_frame_bytes':max(frames.values()),
  'largest_own_frame_function':max(frames,key=frames.get),'warning':'Compiler own frames are not a call-chain or interrupt-stack high-water measurement.'},
 'identity':{'published_test_value':metrics['algorithm'],'meaning':'zero is deliberately unassigned; no save/runtime Algorithm 5 identity exists'},
 'staged_input_sha256':staged,'target_test_elf_sha256':elf_hash,'log_sha256':hashlib.sha256(log.read_bytes()).hexdigest(),
 'host_report_sha256':hashlib.sha256((ROOT/'reports/c10c-feasibility.json').read_bytes()).hexdigest(),
 'resource_report':str(resource_path.relative_to(ROOT)),
 'evidence_limits':['Headless task test only; no graphical progress screen, input handler, production new-game hook, or save restoration.',
  'The immutable graph approval remains a separate 1.642-second operation and needs a boot/loading placement decision.',
  'Only seeds 0 and 42 plus cancellation were timed on ARM; host equivalence covers the broader corpus.',
  'Runtime stack high-water was not canary-measured.','Reference-model acceptance is not target-world or completion validation.']}
out=pathlib.Path(a.output).resolve();out.parent.mkdir(parents=True,exist_ok=True);out.write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report,indent=2))
