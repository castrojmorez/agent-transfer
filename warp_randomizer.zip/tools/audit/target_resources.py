#!/usr/bin/env python3
"""Measure ARM object sizes and linked target allocation (not dynamic high-water marks)."""
import argparse,hashlib,json,pathlib,re,subprocess
ROOT=pathlib.Path(__file__).resolve().parents[2]
p=argparse.ArgumentParser(description=__doc__);p.add_argument('elf');p.add_argument('prefix');p.add_argument('output');a=p.parse_args()
elf=pathlib.Path(a.elf).resolve();prefix=pathlib.Path(a.prefix).resolve();bin=prefix/'usr/bin'
build=ROOT/'build/arm-resources';build.mkdir(parents=True,exist_ok=True)
source='#include "warp_rando.h"\n'+''.join(f'unsigned char wr_size_{key}[sizeof(struct {name})];\n' for key,name in [('work','WrWork'),('active','WrActive'),('graph','WrGraph'),('record','WrRecord'),('identity','WrIdentity')])
(build/'sizes.c').write_text(source)
abi_flags=['-std=gnu17','-mthumb','-mthumb-interwork','-O2','-mabi=apcs-gnu',
           '-mtune=arm7tdmi','-march=armv4t']
subprocess.run([str(bin/'arm-none-eabi-gcc'),*abi_flags,'-I'+str(ROOT/'include'),'-c',str(build/'sizes.c'),'-o',str(build/'sizes.o')],check=True)
text=subprocess.check_output([str(bin/'arm-none-eabi-nm'),'-S',str(build/'sizes.o')],text=True)
sizes={m.group(2):int(m.group(1),16) for m in re.finditer(r'\S+\s+([0-9a-f]+)\s+B\s+wr_size_(\w+)',text)}
core_object=build/'warp_rando.o'
subprocess.run([str(bin/'arm-none-eabi-gcc'),*abi_flags,'-fstack-usage',
                '-I'+str(ROOT/'include'),'-c',str(ROOT/'src/warp_rando.c'),
                '-o',str(core_object)],check=True)
stack_frames={}
for line in core_object.with_suffix('.su').read_text().splitlines():
    columns=line.split('\t')
    if len(columns)>=2:
        stack_frames[columns[0].rsplit(':',1)[-1]]=int(columns[1])
object_sections={}
for line in subprocess.check_output([str(bin/'arm-none-eabi-size'),'-A',str(core_object)],text=True).splitlines():
    m=re.fullmatch(r'(\S+)\s+(\d+)\s+(\d+)',line.strip())
    if m:object_sections[m.group(1)]=int(m.group(2))
sections=[]
for line in subprocess.check_output([str(bin/'arm-none-eabi-size'),'-A',str(elf)],text=True).splitlines():
    m=re.fullmatch(r'(\S+)\s+(\d+)\s+(\d+)',line.strip())
    if m:sections.append({'name':m[1],'bytes':int(m[2]),'address':int(m[3])})
regions={}
for name,start,capacity in [('EWRAM',0x02000000,256*1024),('IWRAM',0x03000000,32*1024),('ROM',0x08000000,32*1024*1024)]:
    end=max([start]+[s['address']+s['bytes'] for s in sections if start<=s['address']<start+capacity])
    regions[name]={'static_span_bytes':end-start,'capacity_bytes':capacity,'unallocated_bytes':capacity-(end-start)}
symbols=subprocess.check_output([str(bin/'arm-none-eabi-nm'),'-S',str(elf)],text=True)
m=re.search(r'\S+\s+([0-9a-f]+)\s+\w\s+gHeap\b',symbols)
report={'scope':'Target-ABI sizeof and linked image allocation; static function frames are compiler estimates, not runtime stack high-water','elf_sha256':hashlib.sha256(elf.read_bytes()).hexdigest(),'compiler':subprocess.check_output([str(bin/'arm-none-eabi-gcc'),'--version'],text=True).splitlines()[0],'abi_flags':abi_flags,'core_sizes':sizes,'core_object_sections':object_sections,'core_static_stack':{'own_frame_bytes':stack_frames,'largest_own_frame_bytes':max(stack_frames.values()),'largest_own_frame_function':max(stack_frames,key=stack_frames.get),'warning':'Own frames are not a call-chain or interrupt-stack high-water measurement.'},'regions':regions,'existing_reserved_heap_bytes':int(m[1],16) if m else None,'release_contains_test_bridge':'WrProof_TestSetupWarp' in symbols,'core_two_buffer_bytes':sizes['work']+sizes['active'],'additional_static_buffer_shortfall_bytes':max(0,sizes['work']+sizes['active']-regions['EWRAM']['unallocated_bytes']),'sections':sections}
pathlib.Path(a.output).write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report,indent=2))
