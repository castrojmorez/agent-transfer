#!/usr/bin/env python3
"""Prove C7C output equivalence and collect graph-sized host evidence."""
import hashlib,json,pathlib,re,statistics,subprocess,sys,time
ROOT=pathlib.Path(__file__).resolve().parents[2]
sys.path.insert(0,str(ROOT/'tests'))
from validate import validate,Invalid
SEEDS=list(range(64))+[255,256,65535,4294967295]
build=ROOT/'build/c7c';build.mkdir(parents=True,exist_ok=True)
data_path=ROOT/'data/reference-normalized.json';graph=build/'graph.h';closure=build/'reference-closure.h'
subprocess.run([sys.executable,str(ROOT/'tools/warprandogen/compile.py'),str(data_path),str(graph)],check=True)
subprocess.run([sys.executable,str(ROOT/'tools/warprandogen/compile_closure.py'),str(data_path),str(closure),
                '--report',str(ROOT/'reports/reference-closure.json')],check=True)
common=['cc','-std=c99','-Wall','-Wextra','-Werror','-pedantic','-O2','-fstack-usage',
        '-I'+str(ROOT/'include'),'-I'+str(build)]
c7a=build/'c7a';c7c=build/'c7c'
subprocess.run([*common,str(ROOT/'tools/experiments/c7a_candidate.c'),'-o',str(c7a)],check=True)
subprocess.run([*common,str(ROOT/'tools/experiments/c7c_candidate.c'),'-o',str(c7c)],check=True)
data=json.loads(data_path.read_text());rows=[];a_total=0.0;c_total=0.0
keys=('result','last_rejection','attempt','records')
for position,seed in enumerate(SEEDS):
    start=time.perf_counter();a=json.loads(subprocess.check_output([str(c7a),str(seed),'4','8'],text=True));a_time=time.perf_counter()-start
    start=time.perf_counter();c=json.loads(subprocess.check_output([str(c7c),str(seed),'8'],text=True));c_time=time.perf_counter()-start
    replay=json.loads(subprocess.check_output([str(c7c),str(seed),'8'],text=True))
    if {k:a[k] for k in keys}!={k:c[k] for k in keys}:raise SystemExit(f'C7A/C7C mismatch seed {seed}')
    if c!=replay:raise SystemExit(f'C7C nondeterministic replay seed {seed}')
    if c['result']!=0:raise SystemExit(f'C7C failed seed {seed}: {c}')
    try:validate(data,c['records'])
    except Invalid as e:raise SystemExit(f'C7C/Python disagreement seed {seed}: {e}')
    digest=hashlib.sha256(json.dumps(c.pop('records'),separators=(',',':')).encode()).hexdigest()
    rows.append(c|{'seed':seed,'record_sha256':digest,'host_seconds':c_time,'c7a_host_seconds':a_time})
    a_total+=a_time;c_total+=c_time
    if position%16==15:print('completed',position+1,'of',len(SEEDS),flush=True)
def frames(exe_name):
    candidates=list(build.glob(exe_name+'-*.su'))
    if len(candidates)!=1:raise SystemExit(f'unexpected stack report for {exe_name}: {candidates}')
    result=[]
    for line in candidates[0].read_text().splitlines():
        match=re.search(r':([^:\t]+)\t(\d+)\t(.+)$',line)
        if match:result.append({'function':match.group(1),'bytes':int(match.group(2)),'kind':match.group(3)})
    return result
c7c_frames=frames('c7c');times=[r['host_seconds'] for r in rows]
meta=json.loads((ROOT/'reports/reference-closure.json').read_text())
report={'checkpoint':'C7C host','status':'experimental; no public/save identity',
 'scope':'68-seed normalized reference abstraction; exact C7A cap-4 output equivalence plus independent validation',
 'seeds':SEEDS,'successes':len(rows),'first_attempt_successes':sum(r['attempt']==0 for r in rows),
 'max_attempts':max(r['attempts'] for r in rows),'exact_c7a_layout_matches':len(rows),
 'deterministic_replays':len(rows),'independent_validations':len(rows),
 'host_seconds_total':c_total,'host_seconds_median':statistics.median(times),'host_seconds_max':max(times),
 'same-run_c7a_host_seconds_total':a_total,'same-run_speedup':a_total/c_total,
 'partner_trials_total':sum(r['partner_trials'] for r in rows),
 'state_evaluations_total':sum(r['state_evaluations'] for r in rows),
 'forward_rounds_total':sum(r['forward_rounds'] for r in rows),
 'reverse_rounds_total':sum(r['reverse_rounds'] for r in rows),
 'repair_rounds_total':sum(r['repair_rounds'] for r in rows),'row_ors_total':sum(r['row_ors'] for r in rows),
 'host_work_bytes':rows[0]['work_bytes'],'closure_index':meta,
 'host_stack_frames':c7c_frames,'max_reported_host_stack_frame_bytes':max(r['bytes'] for r in c7c_frames),
 'input_sha256':hashlib.sha256(data_path.read_bytes()).hexdigest(),
 'algorithm3_core_sha256':hashlib.sha256((ROOT/'src/warp_rando.c').read_bytes()).hexdigest(),
 'c7a_core_sha256':hashlib.sha256((ROOT/'tools/experiments/c7a_candidate_core.inc').read_bytes()).hexdigest(),
 'c7c_wrapper_sha256':hashlib.sha256((ROOT/'tools/experiments/c7c_candidate.c').read_bytes()).hexdigest(),
 'c7c_core_sha256':hashlib.sha256((ROOT/'tools/experiments/c7c_candidate_core.inc').read_bytes()).hexdigest(),
 'closure_header_sha256':hashlib.sha256(closure.read_bytes()).hexdigest(),
 'limitations':['Host process wall time includes launch overhead.','Reference-model acceptance is not target-world completion.',
                'No public/save Algorithm 5 identity is assigned.'],'results':rows}
(ROOT/'reports/c7c-feasibility.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps({k:v for k,v in report.items() if k not in ('results','host_stack_frames')}|{
 'largest_host_frame':max(c7c_frames,key=lambda r:r['bytes'])},indent=2))
