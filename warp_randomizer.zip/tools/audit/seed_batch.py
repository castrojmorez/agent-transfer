#!/usr/bin/env python3
"""Compile and call delivered C core on complete normalized reference input."""
import argparse,hashlib,json,pathlib,re,subprocess,sys,time
ROOT=pathlib.Path(__file__).resolve().parents[2]
sys.path.insert(0,str(ROOT/'tests'))
from validate import validate,Invalid
p=argparse.ArgumentParser(description=__doc__)
p.add_argument('--output',default='reports/seed-batch.json')
p.add_argument('--seeds',nargs='+',type=lambda v:int(v,0),default=[0,1,2,17,255,256,65535,4294967295])
p.add_argument('--attempts',type=int,default=8)
a=p.parse_args()
if not 1<=a.attempts<=65535 or any(not 0<=s<=4294967295 for s in a.seeds):p.error('seed/attempt out of range')
build=ROOT/'build/reference';build.mkdir(parents=True,exist_ok=True)
subprocess.run([sys.executable,str(ROOT/'tools/warprandogen/compile.py'),str(ROOT/'data/reference-normalized.json'),str(build/'graph.h')],check=True)
subprocess.run(['cc','-std=c99','-Wall','-Wextra','-Werror','-pedantic','-O2','-fstack-usage','-I'+str(ROOT/'include'),'-I'+str(build),str(ROOT/'src/warp_rando.c'),str(ROOT/'tests/harness.c'),'-o',str(build/'run')],check=True)
data=json.loads((ROOT/'data/reference-normalized.json').read_text());results=[]
for seed in a.seeds:
    start=time.perf_counter();r=json.loads(subprocess.check_output([str(build/'run'),str(seed),str(a.attempts)],text=True))
    r['host_seconds']=round(time.perf_counter()-start,6);r['seed']=seed
    if r['result']==0:
        try:validate(data,r['records']);r['independent_validation']='accepted reference abstraction'
        except Invalid as e:raise SystemExit('C/Python disagreement: '+str(e))
    elif r['rejected_candidate']:
        try:validate(data,r['rejected_candidate'])
        except Invalid as e:r['independent_validation']='rejected: '+str(e)
        else:raise SystemExit('C rejects a candidate accepted by Python')
    else:r['independent_validation']='construction failed before complete emitted candidate'
    r['records_sha256']=hashlib.sha256(json.dumps(r['records'],separators=(',',':')).encode()).hexdigest()
    print('seed',seed,'result',r['result'],'attempts',r['attempts'],flush=True)
    r['rejected_candidate_records']=len(r.pop('rejected_candidate'))
    r['record_count']=len(r.pop('records'));r['final_stage_trap_endpoints']=[data['nodes'][i]['name'] for i in r.pop('trap_nodes')];results.append(r)
report={'scope':'Complete reference-only normalized model; no target-world guarantee','attempt_budget':a.attempts,
    'algorithm':int(re.search(r'#define WR_ALGORITHM (\d+)',(ROOT/'include/warp_rando.h').read_text()).group(1)),
    'input_sha256':hashlib.sha256((ROOT/'data/reference-normalized.json').read_bytes()).hexdigest(),
    'core_sha256':hashlib.sha256((ROOT/'src/warp_rando.c').read_bytes()).hexdigest(),
    'timing_scope':'host process time includes generation, validation, metadata replay and regeneration; not GBA timing',
    'results':results,'successes':sum(r['result']==0 for r in results),'failures':sum(r['result']!=0 for r in results),
    'vanilla_fallbacks_counted_as_success':0}
(ROOT/a.output).write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report,indent=2))
