#!/usr/bin/env python3
"""Turn a successful target generator log into a checked evidence report."""
import argparse,hashlib,json,pathlib,re,subprocess

ROOT=pathlib.Path(__file__).resolve().parents[2]
p=argparse.ArgumentParser(description=__doc__)
p.add_argument('target');p.add_argument('log');p.add_argument('elf')
p.add_argument('resources');p.add_argument('output')
a=p.parse_args()
target=pathlib.Path(a.target).resolve();log=pathlib.Path(a.log).resolve()
elf=pathlib.Path(a.elf).resolve();resources_path=pathlib.Path(a.resources).resolve()
target_pin='e8bd1cd7b03fc032ea37e3ecd38b379b5d01a1e7'
if subprocess.check_output(['git','-C',str(target),'rev-parse','HEAD'],text=True).strip()!=target_pin:
    p.error('target checkout is not the pinned expansion/1.17.0 commit')
text=log.read_text();marker='GBA Debug: WRGEN '
if marker not in text:p.error('log has no WRGEN measurement')
segment=text.split(marker,1)[1].split('GBA Debug: :N',1)[0]
metrics={key:int(value) for key,value in re.findall(r'(\w+)=(-?\d+)',segment)}
expected={'result':0,'last':0,'records':532,'attempt':0,
          'fnv1a32_decimal':0x36115947,'work':47388,'active':16436}
for key,value in expected.items():
    if metrics.get(key)!=value:p.error(f'unexpected {key}: {metrics.get(key)} != {value}')
for suffix in ('free','largest'):
    if metrics.get('heap_before_'+suffix)!=metrics.get('heap_after_'+suffix):
        p.error('heap did not return to its pre-workspace state')
passed=text.count('GBA Debug: :P')
if passed!=11:p.error(f'unexpected pass count: {passed}/11')
resources=json.loads(resources_path.read_text())
elf_hash=hashlib.sha256(elf.read_bytes()).hexdigest()
if resources['elf_sha256']!=elf_hash:p.error('resource report describes a different ELF')
inputs={
    'include/warp_rando.h':target/'include/warp_rando.h',
    'src/warp_rando.c':target/'test/warp_rando_core.c',
    'data/reference-graph.h':target/'test/warp_reference_graph.h',
    'patches/engine-tests/warp_rando_generator.c':target/'test/warp_rando_generator.c',
}
staged={}
for relative,destination in inputs.items():
    source=ROOT/relative
    source_hash=hashlib.sha256(source.read_bytes()).hexdigest()
    destination_hash=hashlib.sha256(destination.read_bytes()).hexdigest()
    if source_hash!=destination_hash:p.error('staged file differs: '+relative)
    staged[relative]=source_hash
ticks=metrics['ticks64']
report={
    'checkpoint':'C5',
    'scope':'Full reference Algorithm 3 on actual ARM target code in headless mGBA; test-only integration, not a playable ROM',
    'target_commit':target_pin,
    'test_passes':passed,
    'test_expected':11,
    'deterministic_seed':0,
    'retries':1,
    'metrics':metrics,
    'derived_timing':{
        'timer_cpu_cycles_per_tick':64,
        'gba_cpu_hz':16777216,
        'ticks_per_frame':4389,
        'seconds':round(ticks/262144,6),
        'frames':round(ticks/4389,6),
        'blocking_assessment':'unacceptable; must not run synchronously in gameplay or startup UI',
    },
    'heap':{
        'workspace_bytes':metrics['work'],
        'allocator_overhead_bytes':metrics['heap_before_free']-metrics['heap_during_free']-metrics['work'],
        'largest_contiguous_before':metrics['heap_before_largest'],
        'largest_contiguous_during':metrics['heap_during_largest'],
        'free_bytes_restored_exactly':metrics['heap_before_free']==metrics['heap_after_free'],
        'largest_block_restored_exactly':metrics['heap_before_largest']==metrics['heap_after_largest'],
        'measurement_context':'controlled test start after the function-runner allocation; not arbitrary gameplay heap pressure',
    },
    'active_table':{
        'target_abi_bytes':metrics['active'],
        'records':metrics['records'],
        'fnv1a32_decimal':metrics['fnv1a32_decimal'],
        'lookup_after_workspace_release':'passed',
    },
    'staged_input_sha256':staged,
    'target_test_elf_sha256':elf_hash,
    'log_sha256':hashlib.sha256(log.read_bytes()).hexdigest(),
    'resource_report':str(resources_path.relative_to(ROOT)),
    'resource_summary':{
        'core_sizes':resources['core_sizes'],
        'regions':resources['regions'],
        'core_two_buffer_bytes':resources['core_two_buffer_bytes'],
    },
    'evidence_limits':[
        'The allocator was nearly empty; availability at arbitrary gameplay states is unproved.',
        'The timer excludes workspace allocation/zero-fill and release.',
        'Static stack-usage analysis is separate; no runtime stack high-water canary was measured.',
        'This test stages the portable core and graph only in the target test build.',
    ],
}
out=pathlib.Path(a.output).resolve();out.parent.mkdir(parents=True,exist_ok=True)
out.write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps(report,indent=2))
