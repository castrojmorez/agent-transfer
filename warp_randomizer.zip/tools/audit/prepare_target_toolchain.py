#!/usr/bin/env python3
"""Fetch checksum-pinned Ubuntu amd64 build dependencies into a local prefix."""
import argparse,concurrent.futures,hashlib,json,pathlib,platform,subprocess
ROOT=pathlib.Path(__file__).resolve().parents[2]
p=argparse.ArgumentParser(description=__doc__);p.add_argument('destination');a=p.parse_args()
if platform.system()!='Linux' or platform.machine() not in ('x86_64','AMD64'):
    p.error('this bootstrap targets Linux amd64; use the target INSTALL.md on other hosts')
base=pathlib.Path(a.destination).resolve();downloads=base/'downloads';prefix=base/'prefix'
downloads.mkdir(parents=True,exist_ok=True);prefix.mkdir(parents=True,exist_ok=True)
manifest=json.loads((ROOT/'reports/target-toolchain-packages.json').read_text())
def download(row):
    path=downloads/pathlib.PurePosixPath(row['Filename']).name
    if not path.exists() or hashlib.sha256(path.read_bytes()).hexdigest()!=row['SHA256']:
        partial=path.with_suffix('.partial')
        subprocess.run(['curl','-sSfL','--max-time','240',manifest['base_url']+row['Filename'],'-o',str(partial)],check=True)
        if hashlib.sha256(partial.read_bytes()).hexdigest()!=row['SHA256']:
            raise ValueError('checksum mismatch: '+row['Package'])
        partial.replace(path)
    return path
with concurrent.futures.ThreadPoolExecutor(max_workers=4) as pool:
    paths=list(pool.map(download,manifest['packages']))
for path in paths:subprocess.run(['dpkg-deb','-x',str(path),str(prefix)],check=True)
# Recreate Debian newlib alternatives locally; no maintainer scripts or system writes.
links={'usr/lib/arm-none-eabi/lib':'newlib','usr/lib/arm-none-eabi/include':'../../include/newlib','usr/bin/pkg-config':'pkgconf'}
for rel,target in links.items():
    link=prefix/rel
    if link.is_symlink():
        if str(link.readlink())!=target:raise ValueError('unexpected existing symlink: '+str(link))
    elif link.exists():raise ValueError('refusing to replace existing path: '+str(link))
    else:link.symlink_to(target)
subprocess.run([str(prefix/'usr/bin/arm-none-eabi-gcc'),'--version'],check=True)
print('Build-tool prefix:',prefix)
print('Requires a compatible glibc host (these packages require glibc >= 2.38).')
