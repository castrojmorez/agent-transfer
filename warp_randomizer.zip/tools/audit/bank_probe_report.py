#!/usr/bin/env python3
"""Turn a successful ARM bank log and baseline comparison into C6C evidence."""
import argparse,hashlib,json,pathlib,re,subprocess

ROOT=pathlib.Path(__file__).resolve().parents[2]
p=argparse.ArgumentParser(description=__doc__)
p.add_argument('target');p.add_argument('log');p.add_argument('elf')
p.add_argument('baseline_resources');p.add_argument('bank_resources');p.add_argument('output')
a=p.parse_args()
target=pathlib.Path(a.target).resolve();log=pathlib.Path(a.log).resolve()
elf=pathlib.Path(a.elf).resolve();base_path=pathlib.Path(a.baseline_resources).resolve()
bank_path=pathlib.Path(a.bank_resources).resolve()
target_pin='e8bd1cd7b03fc032ea37e3ecd38b379b5d01a1e7'
if subprocess.check_output(['git','-C',str(target),'rev-parse','HEAD'],text=True).strip()!=target_pin:
    p.error('target checkout is not the pinned expansion/1.17.0 commit')
text=log.read_text();marker='GBA Debug: WRBANK '
if marker not in text:p.error('log has no WRBANK measurement')
segment=text.split(marker,1)[1].split('GBA Debug: :N',1)[0]
metrics={key:int(value) for key,value in re.findall(r'(\w+)=(-?\d+)',segment)}
expected={'result':0,'records':532,'index':14,'fnv1a32_decimal':-1346025903,
          'active':16436,'layouts':32,'packed':52796,'algorithm':4,'ruleset':1,
          'crc_error':12,'identity_error':11,'data_error':1,'failure_invalid':1}
for key,value in expected.items():
    if metrics.get(key)!=value:p.error(f'unexpected {key}: {metrics.get(key)} != {value}')
passed=text.count('GBA Debug: :P')
if passed!=11:p.error(f'unexpected pass count: {passed}/11')
baseline=json.loads(base_path.read_text());bank=json.loads(bank_path.read_text())
elf_hash=hashlib.sha256(elf.read_bytes()).hexdigest()
if bank['elf_sha256']!=elf_hash:p.error('bank resource report describes a different ELF')
inputs={
    'include/warp_rando.h':target/'include/warp_rando.h',
    'include/warp_bank.h':target/'include/warp_bank.h',
    'src/warp_rando.c':target/'test/warp_rando_core.c',
    'src/warp_bank.c':target/'test/warp_bank_core.c',
    'data/reference-bank.h':target/'include/warp_reference_bank.h',
    'patches/engine-tests/warp_rando_bank.c':target/'test/warp_rando_bank.c',
}
staged={}
for relative,destination in inputs.items():
    source=ROOT/relative;source_hash=hashlib.sha256(source.read_bytes()).hexdigest()
    if source_hash!=hashlib.sha256(destination.read_bytes()).hexdigest():
        p.error('staged file differs: '+relative)
    staged[relative]=source_hash

def section_sum(report,start,capacity):
    return sum(row['bytes'] for row in report['sections']
               if start<=row['address']<start+capacity)

ticks=metrics['ticks64'];baseline_rom=section_sum(baseline,0x08000000,32*1024*1024)
bank_rom=section_sum(bank,0x08000000,32*1024*1024)
report={
  'checkpoint':'C6C',
  'scope':'Schema-1 Algorithm-4 bank on actual ARM target code in headless mGBA; test-only integration, not a playable ROM',
  'target_commit':target_pin,'test_passes':passed,'test_expected':11,
  'deterministic_seed':0,'metrics':metrics,
  'derived_timing':{'timer_cpu_cycles_per_tick':64,'gba_cpu_hz':16777216,
    'ticks_per_frame':4389,'seconds':round(ticks/262144,6),
    'milliseconds':round(ticks/262.144,3),'frames':round(ticks/4389,6)},
  'linked_test_image_delta':{
    'baseline_rom_allocated_section_bytes':baseline_rom,
    'bank_rom_allocated_section_bytes':bank_rom,
    'rom_allocated_section_delta_bytes':bank_rom-baseline_rom,
    'baseline_ewram_static_span_bytes':baseline['regions']['EWRAM']['static_span_bytes'],
    'bank_ewram_static_span_bytes':bank['regions']['EWRAM']['static_span_bytes'],
    'ewram_static_span_delta_bytes':bank['regions']['EWRAM']['static_span_bytes']-baseline['regions']['EWRAM']['static_span_bytes'],
    'interpretation':'Actual pinned-target test-link delta; includes the bank test harness and retained loader support, so ROM delta is a conservative integration upper bound rather than a production-hook measurement.'},
  'bank':{'packed_payload_bytes':52796,
    'sha256':'4bd3884b6bea588af31006e9952320a0716860aed59d575b16b8156c110e8fc4',
    'active_target_abi_bytes':metrics['active'],'workspace_bytes':0},
  'staged_input_sha256':staged,'target_test_elf_sha256':elf_hash,
  'baseline_resource_report':str(base_path.relative_to(ROOT)),
  'bank_resource_report':str(bank_path.relative_to(ROOT)),
  'log_sha256':hashlib.sha256(log.read_bytes()).hexdigest(),
  'evidence_limits':[
    'The test executes the portable loader and exact generated bank on ARM but does not install engine interception or a new-game UI.',
    'The timer covers selected-row CRC and record copy/publication, not save I/O or engine hooks.',
    'The linked ROM delta includes test code and is not a final production-link footprint.',
    'Headless execution does not replace interactive walking, reboot/Continue, or hardware tests.'
  ]}
out=pathlib.Path(a.output).resolve();out.parent.mkdir(parents=True,exist_ok=True)
out.write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps(report,indent=2))
