#!/usr/bin/env python3
"""Fetch exact public revisions into a chosen external working directory."""
import pathlib,subprocess,sys
PINS={
 'legacy':('KittyPBoxx/Emerald-Ex-Map-Rando','f0966a668d3e7a7e937a519365cb1391d4a174a4'),
 'upr':('KittyPBoxx/upr-speedchoice-ex-gen9','5abfca86134872dbb3c54fa48e5920b6549cfb69'),
 'speedchoice':('KittyPBoxx/pokeemerald-ex-speedchoice-maprando-gen9','f539267677ec3686c7f22bae2a63dc6f1a5267e9'),
 'target':('rh-hideout/pokeemerald-expansion','e8bd1cd7b03fc032ea37e3ecd38b379b5d01a1e7')}
if __name__=='__main__':
    if len(sys.argv)!=2:raise SystemExit('usage: fetch_sources.py DESTINATION')
    for name,(repo,sha) in PINS.items():
        path=pathlib.Path(sys.argv[1])/name
        if path.exists():
            if subprocess.check_output(['git','-C',str(path),'rev-parse','HEAD'],text=True).strip()!=sha:raise SystemExit('existing checkout has wrong revision: '+name)
            continue
        subprocess.run(['git','init',str(path)],check=True)
        subprocess.run(['git','-C',str(path),'remote','add','origin','https://github.com/'+repo+'.git'],check=True)
        subprocess.run(['git','-C',str(path),'fetch','--depth','1','origin',sha],check=True)
        subprocess.run(['git','-C',str(path),'checkout','--detach','FETCH_HEAD'],check=True)
