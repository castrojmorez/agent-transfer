#!/usr/bin/env python3
"""Prove C10C budget/lifecycle equivalence across reference and stress seeds."""
import argparse,hashlib,json,pathlib,statistics,subprocess,sys,time
ROOT=pathlib.Path(__file__).resolve().parents[2];sys.path.insert(0,str(ROOT/'tests'))
from validate import validate,Invalid
p=argparse.ArgumentParser(description=__doc__);p.add_argument('--stress-seeds',type=int,default=1024)
p.add_argument('--benchmark-repetitions',type=int,default=5);a=p.parse_args()
SEEDS=list(range(64))+[255,256,65535,4294967295]
BASE_KEYS=('result','last_rejection','attempt','trial_cap','records','attempts','pairs',
 'eligible_partners','partner_trials','state_evaluations','forward_components','reverse_components',
 'repair_components','active_visits','conditional_visits','row_ors','representative_bit_visits',
 'pair_alias_visits','reverse_calls','reverse_edge_updates','set_word_ops','score_word_ops',
 'component_rep_updates','work_bytes')
SCHEDULES=((2600,17),(2800,61),(3200,37),(3600,113),(4000,29))
build=ROOT/'build/c10c';build.mkdir(parents=True,exist_ok=True);data_path=ROOT/'data/reference-normalized.json'
subprocess.run([sys.executable,str(ROOT/'tools/warprandogen/compile.py'),str(data_path),str(build/'graph.h')],check=True)
subprocess.run([sys.executable,str(ROOT/'tools/warprandogen/compile_c9c_index.py'),str(data_path),str(build/'reference-c9c-event-index.h')],check=True)
common=['cc','-std=c99','-Wall','-Wextra','-Werror','-pedantic','-O2','-fstack-usage','-I'+str(ROOT/'include'),'-I'+str(build)]
prior=build/'c9c';candidate=build/'c10c'
subprocess.run([*common,str(ROOT/'tools/experiments/c9c_candidate.c'),'-o',str(prior)],check=True)
subprocess.run([*common,str(ROOT/'tools/experiments/c10c_candidate.c'),'-o',str(candidate)],check=True)
def invoke(exe,seed,schedule=None):
    args=[str(exe),str(seed),'3','8']
    if schedule:args += [str(schedule[0]),'0','0',str(schedule[1]),'0']
    return json.loads(subprocess.check_output(args,text=True))
def exact(before,result,seed,label):
    if any(before[k]!=result[k] for k in BASE_KEYS):raise SystemExit(f'C9C/C10C mismatch seed {seed} ({label})')
data=json.loads(data_path.read_text());rows=[]
for position,seed in enumerate(SEEDS):
    before=invoke(prior,seed);schedule=SCHEDULES[position%len(SCHEDULES)]
    start=time.perf_counter();result=invoke(candidate,seed,schedule);elapsed=time.perf_counter()-start
    replay=invoke(candidate,seed,SCHEDULES[(position+2)%len(SCHEDULES)])
    exact(before,result,seed,'selected schedule');exact(before,replay,seed,'alternate schedule')
    if result['result']!=0 or result['progress']!=1000 or result['status']!=2 or not result['published'] or not result['released']:
        raise SystemExit(f'C10C lifecycle failure seed {seed}')
    try:validate(data,result['records'])
    except Invalid as e:raise SystemExit(f'C10C/Python disagreement seed {seed}: {e}')
    records=result.pop('records');rows.append(result|{'seed':seed,'budget':schedule[0],'tick_increment':schedule[1],
      'host_seconds':elapsed,'record_sha256':hashlib.sha256(json.dumps(records,separators=(',',':')).encode()).hexdigest()})
    if position%16==15:print('completed',position+1,'of',len(SEEDS),flush=True)
stress=[]
for seed in range(a.stress_seeds):
    before=invoke(prior,seed);schedule=SCHEDULES[seed%len(SCHEDULES)];result=invoke(candidate,seed,schedule);exact(before,result,seed,'stress')
    records=result.pop('records')
    if result['result']==0:
        try:validate(data,records)
        except Invalid as e:raise SystemExit(f'C10C stress/Python disagreement seed {seed}: {e}')
    elif records:raise SystemExit(f'C10C stress exposed rejected records seed {seed}')
    if result['released']!=1 or result['invalidations']!=1 or result['publishes']!=(result['result']==0):
        raise SystemExit(f'C10C stress lifecycle mismatch seed {seed}')
    stress.append({'seed':seed,'result':result['result'],'attempt':result['attempt'],'attempts':result['attempts'],
      'steps':result['steps'],'callbacks':result['callbacks'],'max_steps_per_callback':result['max_steps_per_callback']})
    if seed%256==255:print('stress completed',seed+1,'of',a.stress_seeds,flush=True)
benchmarks={}
for name,defines in [('c9c_warm',['BENCH_C9C_WARM']),('c10c_budgeted',['BENCH_C10C'])]:
    exe=build/('bench-'+name);subprocess.run([*common,*('-D'+v for v in defines),str(ROOT/'tools/experiments/candidate_benchmark.c'),'-o',str(exe)],check=True)
    start=time.perf_counter();output=subprocess.check_output([str(exe),str(a.benchmark_repetitions)],text=True).strip()
    benchmarks[name]={'seconds':time.perf_counter()-start,'output':output}
if len({v['output'] for v in benchmarks.values()})!=1:raise SystemExit('benchmark digest mismatch')
report={'checkpoint':'C10C host','status':'experimental budgeted lifecycle adapter; no public/save identity',
 'scope':'C9C-exact callback schedules over 68 standard and 1024 stress seeds with publish/cleanup invariants',
 'schedules':[{'budget_ticks':x,'fake_tick_increment':y} for x,y in SCHEDULES],
 'seeds':SEEDS,'successes':len(rows),'exact_c9c_matches':len(rows),'schedule_independent_replays':len(rows),
 'independent_validations':len(rows),'first_attempt_successes':sum(r['attempt']==0 for r in rows),
 'max_attempts':max(r['attempts'] for r in rows),'host_seconds_total':sum(r['host_seconds'] for r in rows),
 'callbacks':{'min':min(r['callbacks'] for r in rows),'median':statistics.median(r['callbacks'] for r in rows),
  'max':max(r['callbacks'] for r in rows),'seed0':next(r['callbacks'] for r in rows if r['seed']==0),
  'seed42':next(r['callbacks'] for r in rows if r['seed']==42),
  'max_steps_per_callback':max(r['max_steps_per_callback'] for r in rows)},
 'cap3_stress':{'seeds':len(stress),'successes':sum(r['result']==0 for r in stress),
  'failures':sum(r['result']!=0 for r in stress),'exact_c9c_matches':len(stress),
  'independent_validations':sum(r['result']==0 for r in stress),
  'first_attempt_successes':sum(r['result']==0 and r['attempt']==0 for r in stress),
  'max_attempts':max((r['attempts'] for r in stress),default=0),
  'max_callbacks':max((r['callbacks'] for r in stress),default=0),
  'max_steps':max((r['steps'] for r in stress),default=0)},
 'lifecycle':{'successful_publish_exactly_once':all(r['publishes']==1 and r['published']==1 for r in rows),
  'successful_release_exactly_once':all(r['releases']==1 and r['released']==1 for r in rows),
  'invalidated_before_start':all(r['invalidations']==1 for r in rows),'terminal_progress':1000},
 'in_process_benchmark':benchmarks,'overhead_vs_c9c_warm':benchmarks['c10c_budgeted']['seconds']/benchmarks['c9c_warm']['seconds'],
 'host_work_bytes':rows[0]['work_bytes'],'host_job_bytes':rows[0]['job_bytes'],
 'input_sha256':hashlib.sha256(data_path.read_bytes()).hexdigest(),
 'c9c_core_sha256':hashlib.sha256((ROOT/'tools/experiments/c9c_candidate_core.inc').read_bytes()).hexdigest(),
 'c10b_core_sha256':hashlib.sha256((ROOT/'tools/experiments/c10b_candidate_core.inc').read_bytes()).hexdigest(),
 'c10c_core_sha256':hashlib.sha256((ROOT/'tools/experiments/c10c_scheduler_core.inc').read_bytes()).hexdigest(),
 'c10c_wrapper_sha256':hashlib.sha256((ROOT/'tools/experiments/c10c_candidate.c').read_bytes()).hexdigest(),
 'limitations':['Fake host ticks prove schedule independence, not a frame-time ceiling.','ARM probe supplies actual callback timing.',
  'Progress is monotonic attempt/pair completion, not an estimate of remaining CPU work.',
  'No graphical UI, save identity or production new-game hook exists.','Reference-model acceptance is not target-world completion.'],
 'results':rows}
(ROOT/'reports/c10c-feasibility.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps({k:v for k,v in report.items() if k!='results'},indent=2))
