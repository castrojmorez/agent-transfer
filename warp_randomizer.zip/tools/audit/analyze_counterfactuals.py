#!/usr/bin/env python3
"""Keep baseline partners fixed to separate validation effects from RNG divergence."""
import collections,copy,json,pathlib,sys
sys.path.insert(0,str(pathlib.Path(__file__).parent))
from diagnose_failures import BASE,RAW,BUILD,ROOT,SEEDS,closure

def classify(d,r):
    stages=closure(d,r['partner']);f=stages[-1]
    if r['construction']==3:
        available=[i for i,v in enumerate(d['nodes']) if v['active'] and v['rep']==v['name'] and r['partner'][i]==65535 and i in f['reached']]
        return 'frontier_restored' if available else 'no_source'
    if any(s['traps'] for s in stages):return 'trap'
    ni={n['name']:i for i,n in enumerate(d['nodes'])}
    return 'accepted' if all(ni[g] in f['reached'] for g in d['goals']) else 'objective'

def main():
    if "#define WR_ALGORITHM 2u" not in (ROOT/"include/warp_rando.h").read_text():
        raise SystemExit("Historical algorithm-2 investigation: run tools/audit/reproduce_algorithm2.py")
    variants={'baseline':copy.deepcopy(BASE),'weather_open':copy.deepcopy(BASE),
              'flash_upstream_closed':copy.deepcopy(BASE),'all_conditions_open':copy.deepcopy(BASE)}
    variants['flash_upstream_closed']['capabilities'].append('HOENN_FLASH_1')
    for e in variants['weather_open']['edges']:
        if e['requires']=='WEATHER_INSTITUTE':e['requires']=None
    for e in variants['flash_upstream_closed']['edges']:
        if e['from']=='E,24,68,0' and e['to']=='E,24,68,1':e['requires']='HOENN_FLASH_1'
    for e in variants['all_conditions_open']['edges']:e['requires']=None
    result={label:collections.Counter() for label in variants}
    for seed in SEEDS:
        for attempt in range(8):
            r=json.loads((BUILD/'baseline'/f'{seed}-{attempt}.json').read_text())
            for label,d in variants.items():result[label][classify(d,r)]+=1
    report={'method':'Re-evaluate identical baseline partner arrays; no RNG rerun',
      'counts':{label:dict(counts) for label,counts in result.items()}}
    # Verify the compact baseline witness is a closed directed pair even with all gates open.
    d=variants['all_conditions_open'];ni={n['name']:i for i,n in enumerate(d['nodes'])}
    r=json.loads((BUILD/'baseline/0-0.json').read_text());stage=closure(d,r['partner'])[-1]
    pair={ni['E,24,81,2'],ni['E,9,1,0']}
    assert all(stage['adj'][i] and stage['adj'][i]<=pair for i in pair)
    assert pair<=stage['reached'] and not pair&stage['home']
    report['permanent_pair_witness']={'seed':0,'attempt':0,'nodes':['E,24,81,2','E,9,1,0'],
      'reachable_even_with_all_conditions_open':True,'no_outgoing_edge_from_pair':True,
      'escape_paths_group_zero_based':34}
    (ROOT/'reports/fixed-mapping-counterfactuals.json').write_text(json.dumps(report,indent=2)+'\n')
    print(json.dumps(report,indent=2))
if __name__=='__main__':main()
