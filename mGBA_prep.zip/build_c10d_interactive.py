#!/usr/bin/env python3
"""Build a graphical-mGBA C10D test ROM from the pinned target checkout."""
import argparse
import json
import pathlib
import subprocess
import sys

ROOT = pathlib.Path(__file__).resolve().parents[2]

p = argparse.ArgumentParser(description=__doc__)
p.add_argument("target")
p.add_argument("prefix")
p.add_argument("output")
p.add_argument("--jobs", type=int, default=4)
a = p.parse_args()
target = pathlib.Path(a.target).resolve()
prefix = pathlib.Path(a.prefix).resolve()
output = pathlib.Path(a.output).resolve()
if output.suffix.lower() != ".gba":
    p.error("output must end in .gba")
if a.jobs < 1:
    p.error("jobs must be positive")

build = ROOT / "build/c10d-interactive"
build.mkdir(parents=True, exist_ok=True)
log = build / "headless-preflight.log"
command = [
    sys.executable,
    str(ROOT / "tools/audit/build_engine_proof.py"),
    str(target),
    str(prefix),
    "--mode", "1",
    "--c10d-probe",
    "--jobs", str(a.jobs),
    "--log", str(log),
]
subprocess.run(command, check=True)
output.parent.mkdir(parents=True, exist_ok=True)
objcopy = prefix / "usr/bin/arm-none-eabi-objcopy"
subprocess.run([str(objcopy), "-O", "binary",
                str(target / "pokeemerald-test.elf"), str(output)], check=True)
print(json.dumps({
    "output": str(output),
    "bytes": output.stat().st_size,
    "preflight_log": str(log),
    "instructions": "Open in graphical mGBA; observe two success runs, then press B during the third run.",
}))
