"""Independent acceptance over JSON rules and emitted records. No C state imports."""

class Invalid(ValueError):
    pass

def validate(data, records):
    nodes = {v['name']: v for v in data['nodes']}
    byid = {tuple(v['id']): v['name'] for v in nodes.values()}
    expected = {tuple(v['trigger']) for v in nodes.values() if v['active']}
    mapping = {}
    for row in records:
        k = tuple(row[:3])
        dest = tuple(row[3:])
        if k in mapping:
            raise Invalid('duplicate trigger')
        if dest not in byid:
            raise Invalid('invalid landing')
        mapping[k] = byid[dest]
    if set(mapping) != expected:
        raise Invalid('trigger coverage')
    travel = {}
    for name, v in nodes.items():
        if not v['active']:
            continue
        t = mapping[tuple(v['trigger'])]
        partner = nodes[t]
        if not partner['active'] or partner['rep'] != t or v['rep'] == t:
            raise Invalid('bad partner')
        if mapping[tuple(nodes[v['rep']]['trigger'])] != t:
            raise Invalid('inconsistent aliases')
        if mapping[tuple(partner['trigger'])] != v['rep']:
            raise Invalid('missing reverse pair')
        if v.get('tags', 0) & 1 and partner.get('tags', 0) & 2 or (v.get('tags', 0) & 2 and partner.get('tags', 0) & 1):
            raise Invalid('forbidden pairing')
        travel[name] = t

    def search(edges, start, reverse=False):
        seen = {start}
        todo = [start]
        while todo:
            current = todo.pop()
            for a, b in edges:
                if reverse:
                    a, b = (b, a)
                if a == current and b not in seen:
                    seen.add(b)
                    todo.append(b)
        return seen
    caps = set()
    stages = []
    while True:
        edges = list(travel.items()) + [(e['from'], e['to']) for e in data['edges'] if e.get('requires') is None or e['requires'] in caps]
        reached = search(edges, data['root'])
        home = search(edges, data['root'], True)
        if reached - home:
            raise Invalid('one-way trap: ' + ','.join(sorted(reached - home)))
        earned = {r['grant'] for r in data['rules'] if all((q['location'] in reached & home if 'location' in q else q['capability'] in caps for q in r['requires']))}
        stages.append({'reachable': sorted(reached), 'capabilities': sorted(caps)})
        if earned <= caps:
            break
        caps |= earned
    if not set(data['goals']) <= reached:
        raise Invalid('unreachable objective')
    return stages
import copy, hashlib, json, os, pathlib, subprocess, sys, tempfile, unittest
import build as compiler
ROOT = pathlib.Path(__file__).resolve().parent
HARNESS = r'''
#include "warp_rando.h"
#include "graph.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
/* This harness uses no heap. LeakSanitizer cannot enumerate processes in the
 * restricted host; ASan bounds and UBSan checks remain enabled. */
int __lsan_is_turned_off(void) { return 1; }
static struct WrWork work;
static struct WrActive active, restored;
int main(int argc,char **argv)
{
    struct WrIdentity id; int r,last=0; uint16_t i;
    id.seed=argc>1?(uint32_t)strtoul(argv[1],0,0):0;
    id.algorithm=WR_ALGORITHM;id.ruleset=1;memcpy(id.data,wr_graph.fingerprint,32);
    if(argc>2 && !strcmp(argv[2],"validate")) {
        unsigned a,b,c,d,e,f,n=0;
        while(scanf("%u %u %u %u %u %u",&a,&b,&c,&d,&e,&f)==6) {
            if(n==WR_MAX_NODES || a>127 || b>127 || c>127 || d>127 || e>127 || f>127) return 3;
            work.candidate[n].trigger=(struct WrKey){a,b,c};work.candidate[n].landing=(struct WrKey){d,e,f};n++;
        }
        r=wr_publish(&wr_graph,&id,work.candidate,n,&active,&work);
    } else r=wr_generate(&wr_graph,&id,argc>2?(uint16_t)strtoul(argv[2],0,0):8,&active,&work,&last);
    printf("{\"result\":%d,\"last_rejection\":%d,\"active\":%u,\"attempt\":%u,\"records\":[",r,last,active.valid,active.attempt);
    for(i=0;i<active.count;i++) {
        const struct WrRecord *v=&active.records[i];
        printf("%s[%u,%u,%u,%u,%u,%u]",i?",":"",v->trigger.group,v->trigger.map,v->trigger.warp,v->landing.group,v->landing.map,v->landing.warp);
    }
    printf("],\"attempts\":%u,\"rejection_counts\":[",work.attempts);
    for(i=0;i<12;i++) printf("%s%u",i?",":"",work.rejection_counts[i]);
    printf("],\"trap_nodes\":[");
    if(last==WR_TRAP) {
        int comma=0;
        for(i=0;i<wr_graph.n;i++) if(work.reached[i] && !work.home[i]) {
            printf("%s%u",comma?",":"",i);comma=1;
        }
    }
    printf("],\"work_bytes\":%zu,\"active_bytes\":%zu}\n",sizeof(work),sizeof(active));
    if(!r && active.count && !(argc>2 && !strcmp(argv[2],"validate"))) {
        uint8_t saved[WR_SAVE_BYTES];uint16_t saved_attempt;
        struct WrIdentity decoded;
        if(wr_encode(&active,saved) || wr_decode(&wr_graph,saved,&decoded,&saved_attempt)) return 10;
        if(wr_generate(&wr_graph,&decoded,(uint16_t)(saved_attempt+1),&restored,&work,&last)) return 11;
        if(restored.count!=active.count || restored.attempt!=active.attempt ||
           memcmp(restored.records,active.records,active.count*sizeof(active.records[0]))) return 12;
        {
            struct WrJob job;
            int step = wr_begin(&job, &wr_graph, &id, 8, &restored, &work);
            if (step != WR_PENDING || restored.valid) return 20;
            step = wr_advance(&job);
            if (step != WR_PENDING || restored.valid) return 21;
            wr_cancel(&job);
            if (restored.valid || wr_advance(&job) != WR_CANCELLED) return 22;
            step = wr_begin(&job, &wr_graph, &id, 8, &restored, &work);
            while (step == WR_PENDING) {
                if (restored.valid) return 23;
                step = wr_advance(&job);
            }
            if (step || restored.attempt != active.attempt
                || restored.count != active.count
                || memcmp(restored.records, active.records,
                          active.count * sizeof(active.records[0]))) return 24;
        }
        /* Every emitted physical source signature must normalize exactly. */
        #if WR_SOURCE_COUNT > 0
        for (i = 0; i < WR_SOURCE_COUNT; i++) {
            const struct WrSourceRoute *route = &wr_source_routes[i];
            struct WrKey out = {127,127,127}, before = out;
            if (!wr_source_normalize(wr_source_routes,
                  WR_SOURCE_COUNT,
                  &route->source, &route->expected, route->x, route->y,
                  route->elevation, &out) || memcmp(&out,&route->trigger,sizeof(out))) return 25;
            out = before;
            if (wr_source_normalize(wr_source_routes,
                  WR_SOURCE_COUNT,
                  &route->source, &route->expected, route->x ^ 1, route->y,
                  route->elevation, &out) || memcmp(&out,&before,sizeof(out))) return 26;
        }
        #endif
        /* Valid CRC with obsolete algorithm identity must still be rejected. */
        active.identity.algorithm--;
        if(wr_encode(&active,saved) || wr_decode(&wr_graph,saved,&decoded,&saved_attempt)!=WR_BAD_IDENTITY) return 14;
        active.identity.algorithm++;
        if(wr_encode(&active,saved)) return 15;
        saved[16]^=1;
        if(wr_decode(&wr_graph,saved,&decoded,&saved_attempt)!=WR_BAD_IDENTITY) return 13;
        struct WrKey k=active.records[0].trigger,old=k;
        if(wr_lookup(&active,&id,&k)!=1) return 4;
        id.ruleset++; k=old;
        if(wr_lookup(&active,&id,&k)!=-1 || memcmp(&k,&old,sizeof(k))) return 5;
        id.ruleset--; id.data[0]^=1;
        if(wr_lookup(&active,&id,&k)!=-1) return 6;
        id.data[0]^=1;
        if(wr_generate(&wr_graph,&id,0,&active,&work,&last)!=WR_RETRIES || active.valid || active.count) return 7;
        if(wr_lookup(&active,&id,&k)!=-1 || memcmp(&k,&old,sizeof(k))) return 8;
    } else if(r && (active.valid || active.count)) return 9;
    return 0;
}

'''

def model(n=2, active=True):
    return {'schema': 2, 'description': 'Synthetic diagnostic fixture, not Emerald map data', 'capabilities': [], 'nodes': [{'name': f'N{i:04}', 'id': [1, i // 128, i % 128], 'trigger': [2, i // 128, i % 128], 'rep': f'N{i:04}', 'active': active} for i in range(n)], 'edges': [], 'rules': [], 'root': 'N0000', 'goals': [f'N{n - 1:04}']}

def edge(d, a, b, cap=None):
    d['edges'].append({'from': f'N{a:04}', 'to': f'N{b:04}', 'requires': cap})

def rows(d, partners):
    out = {}
    for v in d['nodes']:
        if v['active']:
            target = d['nodes'][partners[int(v['rep'][1:])]]['id']
            out[tuple(v['trigger'])] = list(v['trigger']) + target
    return list(out.values())

class Suite(unittest.TestCase):

    @classmethod
    def setUpClass(cls):
        cls.temp = tempfile.TemporaryDirectory()
        cls.path = pathlib.Path(cls.temp.name)
        cls.cache = {}
        cls.results = []

    @classmethod
    def tearDownClass(cls):
        out = ROOT / 'verification.json'
        out.write_text(json.dumps(cls.results, indent=2) + '\n')
        cls.temp.cleanup()

    def run_core(self, d, seed=0, records=None, retries=8):
        d = copy.deepcopy(d)
        if 'source_routes' not in d:
            d['target_map_counts'] = [128] * 3
            d['source_routes'] = [dict(source=v['id'], expected=v['trigger'], trigger=v['trigger'], x=0, y=0, elevation=0) for v in d['nodes'] if v['active']]
        header = compiler.emit(d)
        digest = hashlib.sha256(header.encode()).hexdigest()
        directory = self.path / digest
        if digest not in self.cache:
            directory.mkdir()
            (directory / 'graph.h').write_text(header)
            (directory / 'harness.c').write_text(HARNESS)
            cmd = [os.environ.get('CC', 'cc'), '-std=c99', '-Wall', '-Wextra', '-Werror', '-pedantic', '-O1', '-g', '-I' + str(ROOT), '-I' + str(directory), str(ROOT / 'warp_rando.c'), str(directory / 'harness.c'), '-o', str(directory / 'run')]
            if os.environ.get('SANITIZE') == '1':
                cmd[1:1] = ['-fsanitize=address,undefined', '-fno-omit-frame-pointer', '-fno-pie', '-no-pie']
            p = subprocess.run(cmd, capture_output=True, text=True, timeout=45)
            self.assertEqual(p.returncode, 0, p.stderr)
            self.cache[digest] = True
        arg = 'validate' if records is not None else str(retries)
        p = subprocess.run([str(directory / 'run'), str(seed), arg], input=''.join((' '.join(map(str, r)) + '\n' for r in records or [])), capture_output=True, text=True, timeout=45)
        self.assertEqual(p.returncode, 0, p.stdout + p.stderr)
        result = json.loads(p.stdout)
        self.results.append({'case': self.id().split('.')[-1], 'seed': seed, 'result': result['result'], 'last_rejection': result['last_rejection'], 'attempt': result['attempt'], 'records': len(result['records']), 'active': result['active']})
        return result

    def accepted(self, d, records=None):
        r = self.run_core(d, records=records)
        self.assertEqual(r['result'], 0, r)
        return validate(d, r['records'])

    def rejected(self, d, records):
        with self.assertRaises(Invalid):
            validate(d, records)
        r = self.run_core(d, records=records)
        self.assertNotEqual(r['result'], 0)
        self.assertFalse(r['active'])

    def test_reciprocal_and_restart(self):
        d = model()
        first = self.run_core(d, seed=0)
        self.assertEqual(first['records'], [[2, 0, 0, 1, 0, 1], [2, 0, 1, 1, 0, 0]])
        for seed in [0, 1, 2, 17, 255, 256, 65535, 4294967295]:
            a = self.run_core(d, seed)
            b = self.run_core(d, seed)
            self.assertEqual(a, b)
            validate(d, a['records'])
        self.rejected(d, first['records'][:1])
        broken = copy.deepcopy(first['records'])
        broken[0][3:] = [100, 100, 100]
        self.rejected(d, broken)

    def test_grouped_both_sides_and_equivalent_alias(self):
        d = model(4)
        for member, rep in [(1, 0), (3, 2)]:
            d['nodes'][member]['rep'] = d['nodes'][rep]['name']
            d['nodes'][member]['trigger'] = d['nodes'][rep]['trigger'][:]
            edge(d, rep, member)
            edge(d, member, rep)
        r = self.run_core(d)
        self.assertEqual(r['result'], 0)
        self.assertEqual(len(r['records']), 2)
        validate(d, r['records'])

    def test_conflicting_aliases(self):
        d = model(4)
        d['nodes'][2]['trigger'] = d['nodes'][0]['trigger'][:]
        for i in range(1, 4):
            edge(d, 0, i)
            edge(d, i, 0)
        r = self.run_core(d)
        self.assertEqual(r['result'], 10)
        self.assertGreater(r['rejection_counts'][6], 0)
        self.assertFalse(r['records'])

    def test_wide_indices(self):
        d = model(902)
        for member, rep in [(256, 255), (842, 841)]:
            d['nodes'][member]['rep'] = d['nodes'][rep]['name']
        for i in range(1, 902):
            edge(d, 0, i)
            edge(d, i, 0)
        normalized = compiler.normalize(d)
        self.assertEqual(normalized['nodes'][256][2], 255)
        self.assertEqual(normalized['nodes'][842][2], 841)
        self.accepted(d)

    def test_odd_pool_and_no_source(self):
        r = self.run_core(model(3))
        self.assertEqual(r['last_rejection'], 2)
        self.assertFalse(r['active'])
        d = model(4)
        d['root'] = 'N0000'
        d['nodes'][0]['active'] = False
        d['nodes'][1]['active'] = False
        r = self.run_core(d)
        self.assertGreater(r['rejection_counts'][3], 0)
        self.assertFalse(r['active'])

    def test_forbidden_pair(self):
        d = model()
        d['nodes'][0]['tags'] = 1
        d['nodes'][1]['tags'] = 2
        self.rejected(d, rows(d, {0: 1, 1: 0}))
        self.assertGreater(self.run_core(d)['rejection_counts'][4], 0)

    def test_ninth_requirement_mutation(self):
        d = model(11, False)
        d['capabilities'] = ['WATERFALL']
        d['goals'] = ['N0010']
        for i in range(1, 9):
            edge(d, 0, i)
            edge(d, i, 0)
        edge(d, 0, 10, 'WATERFALL')
        edge(d, 10, 0)
        d['rules'] = [{'grant': 'WATERFALL', 'requires': [{'location': f'N{i:04}'} for i in range(1, 10)]}]
        self.assertEqual(len(compiler.normalize(d)['reqs']), 9)
        self.rejected(d, [])
        mutation = copy.deepcopy(d)
        mutation['rules'][0]['requires'].pop()
        self.accepted(mutation, [])
        edge(d, 0, 9)
        edge(d, 9, 0)
        self.accepted(d, [])

    def test_self_lock_and_disconnected_objective(self):
        d = model(2, False)
        d['capabilities'] = ['SURF']
        edge(d, 0, 1, 'SURF')
        edge(d, 1, 0)
        d['rules'] = [{'grant': 'SURF', 'requires': [{'location': 'N0001'}]}]
        self.rejected(d, [])
        d['rules'] = []
        d['edges'] = []
        self.rejected(d, [])

    def test_multiround_capability_derivations(self):
        d = model(4, False)
        d['capabilities'] = ['A', 'B', 'C']
        edge(d, 0, 1)
        edge(d, 1, 0)
        edge(d, 0, 2, 'B')
        edge(d, 2, 0)
        edge(d, 0, 3, 'C')
        edge(d, 3, 0)
        d['rules'] = [{'grant': 'A', 'requires': [{'location': 'N0001'}]}, {'grant': 'B', 'requires': [{'capability': 'A'}]}, {'grant': 'C', 'requires': [{'location': 'N0002'}]}, {'grant': 'C', 'requires': [{'location': 'N0003'}]}]
        stages = self.accepted(d, [])
        self.assertGreaterEqual(len(stages), 4)

    def test_directed_trap_and_escape(self):
        d = model(2, False)
        edge(d, 0, 1)
        self.rejected(d, [])
        d['capabilities'] = ['ROPE']
        edge(d, 1, 0, 'ROPE')
        self.rejected(d, [])
        d['edges'][-1]['requires'] = None
        self.accepted(d, [])

    def test_unsafe_item_collection_and_later_escape(self):
        d = model(3, False)
        d['goals'] = ['N0001']
        d['capabilities'] = ['ESCAPE']
        edge(d, 0, 1)
        edge(d, 1, 0)
        edge(d, 0, 2)
        edge(d, 2, 0, 'ESCAPE')
        d['rules'] = [{'grant': 'ESCAPE', 'requires': [{'location': 'N0002'}]}]
        self.rejected(d, [])
        d['rules'][0]['requires'] = [{'location': 'N0001'}]
        self.rejected(d, [])

    def test_fixed_travel_through_excluded_nodes(self):
        d = model(4)
        d['nodes'][1]['active'] = False
        d['nodes'][2]['active'] = False
        edge(d, 0, 1)
        edge(d, 1, 2)
        edge(d, 2, 3)
        edge(d, 3, 2)
        edge(d, 2, 1)
        edge(d, 1, 0)
        d['goals'] = ['N0002']
        self.accepted(d)

    def test_bad_input_and_determinism(self):
        d = model()
        self.assertEqual(compiler.normalize(d), compiler.normalize(json.loads(json.dumps(d))))
        for mutation in ['unknown', 'ref', 'group', 'overflow', 'mixed', 'bool', 'grant']:
            bad = copy.deepcopy(d)
            if mutation == 'unknown':
                edge(bad, 0, 1, 'TYPO')
            if mutation == 'ref':
                edge(bad, 0, 99)
            if mutation == 'group':
                bad['nodes'][0]['rep'] = 'N0001'
                bad['nodes'][1]['rep'] = 'N0000'
            if mutation == 'overflow':
                bad['nodes'][0]['id'][0] = 256
            if mutation == 'mixed':
                bad['nodes'][1]['active'] = False
                bad['nodes'][1]['trigger'] = bad['nodes'][0]['trigger'][:]
            if mutation == 'bool':
                bad['nodes'][0]['active'] = 1
            if mutation == 'grant':
                bad['rules'] = [{'grant': 'UNKNOWN', 'requires': []}]
            with self.subTest(mutation=mutation), self.assertRaises(ValueError):
                compiler.normalize(bad)

    def test_frontier_and_directed_sink_construction(self):
        d = model(10)
        for a, b in [(0, 1), (1, 0), (2, 3), (3, 2), (2, 4), (4, 2), (2, 5), (5, 2), (6, 7)]:
            edge(d, a, b)
        d['goals'] = [v['name'] for v in d['nodes']]
        for seed in [0, 1, 2, 17, 255, 4294967295]:
            r = self.run_core(d, seed=seed)
            self.assertEqual(r['result'], 0, r)
            validate(d, r['records'])

    def test_reference_world(self):
        data = json.loads((ROOT / 'world.json').read_text())
        self.assertEqual(len(data['source_routes']), 608)
        self.assertFalse(any((r['grant'] in {'WEATHER_INSTITUTE', 'HOENN_FLASH_1'} for r in data['rules'])))
        for seed in [0, 1, 2, 3, 7, 17, 42, 63, 255, 256, 65535, 4294967295]:
            with self.subTest(seed=seed):
                result = self.run_core(data, seed)
                self.assertEqual(result['result'], 0, result)
                validate(data, result['records'])
        bad = copy.deepcopy(data)
        bad['source_routes'].pop()
        with self.assertRaises(ValueError):
            compiler.emit(bad)
        bad = copy.deepcopy(data)
        bad['source_routes'][0]['trigger'] = [0, 0, 0]
        with self.assertRaises(ValueError):
            compiler.emit(bad)

    def test_zero_retries(self):
        r = self.run_core(model(), retries=0)
        self.assertEqual(r['result'], 10)
        self.assertFalse(r['records'])
if __name__ == '__main__':
    unittest.main(verbosity=2)
