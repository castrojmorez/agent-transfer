/* GPL-3.0-or-later. Simplified from the supplied Algorithm-3 core;
* bounded sampling follows its C7A experiment. See INTRODUCTION.md. */
#include "warp_rando.h"
#include <string.h>

/* 1. Keys, identity and immutable graph checks. */
static int keyeq(struct WrKey a, struct WrKey b)
{
    return a.group == b.group && a.map == b.map && a.warp == b.warp;
}

static int keycmp(struct WrKey a, struct WrKey b)
{
    if (a.group != b.group)
        return a.group < b.group ? -1 : 1;
    if (a.map != b.map)
        return a.map < b.map ? -1 : 1;
    return (a.warp > b.warp) - (a.warp < b.warp);
}

static int identityeq(const struct WrIdentity *a, const struct WrIdentity *b)
{
    return a->seed == b->seed && a->algorithm == b->algorithm && a->ruleset == b->ruleset &&
        !memcmp(a->data, b->data, 32);
}

static int identityok(const struct WrGraph *graph, const struct WrIdentity *i)
{
    return i->algorithm == WR_ALGORITHM && i->ruleset == 1 && !memcmp(i->data, graph->fingerprint, 32);
}

void wr_invalidate(struct WrActive *a)
{
    a->valid = 0;
    a->count = 0;
}

static int allowed(const struct WrNode *a, const struct WrNode *b)
{
    return !((a->tags & WR_NEEDS_RETURN && b->tags & WR_NO_RETURN) || (b->tags & WR_NEEDS_RETURN &&
        a->tags & WR_NO_RETURN));
}

int wr_graph_check(const struct WrGraph *graph)
{
    uint16_t i, j;
    if (!graph || !graph->n || graph->n > WR_MAX_NODES || graph->caps > WR_MAX_CAPS || graph->root >=
        graph->n || !graph->nodes || !graph->bounds || !graph->reverse_bounds || !graph->edges ||
        !graph->reverse_edges || !graph->rules || !graph->reqs || !graph->goals)
        return WR_BAD_DATA;
    if (graph->bounds[0] || graph->reverse_bounds[0] || graph->bounds[graph->n] != graph->edge_count ||
        graph->reverse_bounds[graph->n] != graph->edge_count)
        return WR_BAD_DATA;
    for (i=0;i<graph->n;i++)
    {
        const struct WrNode *v=&graph->nodes[i];
        if (v->rep >= graph->n || graph->nodes[v->rep].rep != v->rep || v->active !=
            graph->nodes[v->rep].active || v->active > 1 || v->tags > 3 || v->tags !=
            graph->nodes[v->rep].tags || graph->bounds[i]>graph->bounds[i+1] ||
            graph->reverse_bounds[i]>graph->reverse_bounds[i+1])
            return WR_BAD_DATA;
        for (j=0;j<i;j++)
            if (keyeq(v->id, graph->nodes[j].id) || (v->active != graph->nodes[j].active &&
                keyeq(v->trigger, graph->nodes[j].trigger)))
                return WR_BAD_DATA;
    }
    for (i=0;i<graph->edge_count;i++)
    {
        const struct WrEdge *e=&graph->edges[i], *r=&graph->reverse_edges[i];
        if (e->to>=graph->n || r->to>=graph->n || (e->cap!=WR_NONE && e->cap>=graph->caps) ||
            (r->cap!=WR_NONE && r->cap>=graph->caps))
            return WR_BAD_DATA;
    }
    /* Prove that the reverse adjacency supplied by the compiler is exact. */
    for (i=0;i<graph->n;i++)
        for (j=graph->bounds[i];j<graph->bounds[i+1];j++)
        {
            uint16_t k, hits=0, to=graph->edges[j].to;
            for (k=graph->reverse_bounds[to];k<graph->reverse_bounds[to+1];k++)
                if (graph->reverse_edges[k].to==i && graph->reverse_edges[k].cap==graph->edges[j].cap)
                    hits++;
            if (hits!=1)
                return WR_BAD_DATA;
        }
    for (i=0;i<graph->n;i++)
        for (j=graph->reverse_bounds[i];j<graph->reverse_bounds[i+1];j++)
        {
            uint16_t k, hits=0, to=graph->reverse_edges[j].to;
            for (k=graph->bounds[to];k<graph->bounds[to+1];k++)
                if (graph->edges[k].to==i && graph->edges[k].cap==graph->reverse_edges[j].cap)
                    hits++;
            if (hits!=1)
                return WR_BAD_DATA;
        }
    for (i=0;i<graph->rule_count;i++)
    {
        const struct WrRule *r=&graph->rules[i];
        if (r->grant>=graph->caps || (uint32_t)r->offset+r->count>graph->req_count)
            return WR_BAD_DATA;
    }
    for (i=0;i<graph->req_count;i++)
        if (graph->reqs[i].capability>1 || graph->reqs[i].index >= (graph->reqs[i].capability ?
            graph->caps:graph->n))
            return WR_BAD_DATA;
    for (i=0;i<graph->goal_count;i++)
        if (graph->goals[i]>=graph->n)
            return WR_BAD_DATA;
    return WR_OK;
}

/* 2. Translate canonical pairs into the table the engine will consume. */
int wr_emit(const struct WrGraph *graph, const uint16_t *p, struct WrRecord *out, uint16_t *count)
{
    uint16_t i, j, n=0;
    *count=0;
    if (wr_graph_check(graph))
        return WR_BAD_DATA;
    for (i=0;i<graph->n;i++)
        if (graph->nodes[i].active)
        {
            uint16_t r=graph->nodes[i].rep, t=p[r];
            struct WrRecord row;
            if (t>=graph->n || t==r || !graph->nodes[t].active || graph->nodes[t].rep!=t || p[t]!=r ||
                !allowed(&graph->nodes[r], &graph->nodes[t]))
                return WR_BAD_PAIR;
            row.trigger=graph->nodes[i].trigger;
            row.landing=graph->nodes[t].id;
            for (j=0;j<n;j++)
                if (keyeq(out[j].trigger, row.trigger))
                    break;
            if (j<n)
            {
                if (!keyeq(out[j].landing, row.landing))
                    return WR_CONFLICT;
            }
            else out[n++]=row;
        }
    /* Stable insertion sort; output has at most n physical triggers. */
    for (i=1;i<n;i++)
    {
        struct WrRecord row=out[i];
        j=i;
        while (j && keycmp(row.trigger, out[j-1].trigger)<0)
        {
            out[j]=out[j-1];
            j--;
        }
        out[j]=row;
    }
    *count=n;
    return WR_OK;
}

/* 3. Directed traversal and permanent-capability closure. */
static void traverse(const struct WrGraph *graph, struct WrWork *work, int reverse)
{
    uint16_t head=0, tail=0, i, v, t;
    uint8_t *seen=reverse?work->home:work->reached;
    const uint16_t *bounds=reverse?graph->reverse_bounds:graph->bounds;
    const struct WrEdge *edges=reverse?graph->reverse_edges:graph->edges;
    memset(seen, 0, graph->n);
    seen[graph->root]=1;
    work->queue[tail++]=graph->root;
    while (head<tail)
    {
        v=work->queue[head++];
        for (i=bounds[v];i<bounds[v+1];i++)
        {
            t=edges[i].to;
            if ((edges[i].cap==WR_NONE || work->caps[edges[i].cap]) && !seen[t])
            {
                seen[t]=1;
                work->queue[tail++]=t;
            }
        }
        if (reverse)
        {
            for (t=work->reverse_head[v];t!=WR_NONE;t=work->reverse_next[t])
                if (!seen[t])
                {
                    seen[t]=1;
                    work->queue[tail++]=t;
                }
        }
        else
        {
            t=work->destination[v];
            if (t!=WR_NONE && !seen[t])
            {
                seen[t]=1;
                work->queue[tail++]=t;
            }
        }
    }
}

static void reverse_warps(const struct WrGraph *graph, struct WrWork *work)
{
    uint16_t i, t;
    for (i=0;i<graph->n;i++)
        work->reverse_head[i]=WR_NONE;
    for (i=0;i<graph->n;i++)
    {
        t=work->destination[i];
        if (t!=WR_NONE)
        {
            work->reverse_next[i]=work->reverse_head[t];
            work->reverse_head[t]=i;
        }
    }
}

/* Fresh-state monotone closure. Only collect at locations already able to return
* to the anchor with current capabilities. This is deliberately conservative. */
static int closure_until(const struct WrGraph *graph, struct WrWork *work, int stop_unsafe)
{
    uint16_t i, j;
    int changed, unsafe=0;
    uint8_t next_caps[WR_MAX_CAPS];
    memset(work->caps, 0, graph->caps);
    reverse_warps(graph, work);
    do
    {
        changed=0;
        traverse(graph, work, 0);
        traverse(graph, work, 1);
        for (i=0;i<graph->n;i++)
            if (work->reached[i] && !work->home[i])
                unsafe=1;
        if (unsafe && stop_unsafe)
            return 1;
        memcpy(next_caps, work->caps, graph->caps);
        for (i=0;i<graph->rule_count;i++)
        {
            const struct WrRule *r=&graph->rules[i];
            int all=1;
            if (work->caps[r->grant])
                continue;
            for (j=0;j<r->count;j++)
            {
                const struct WrReq *q=&graph->reqs[r->offset+j];
                if (q->capability ? !work->caps[q->index] : !(work->reached[q->index] &&
                    work->home[q->index]))
                {
                    all=0;
                    break;
                }
            }
            if (all)
            {
                next_caps[r->grant]=1;
                changed=1;
            }
        }
        memcpy(work->caps, next_caps, graph->caps);
    }
    while (changed);
    return unsafe;
}

static int closure(const struct WrGraph *graph, struct WrWork *work)
{
    return closure_until(graph, work, 0);
}

/* 4. Accept the emitted table from fresh state, then publish it. */
int wr_validate(const struct WrGraph *graph, const struct WrRecord *table, uint16_t count, struct WrWork
    *work)
{
    uint16_t i, j, t;
    int result=wr_graph_check(graph);
    if (result || count>graph->n)
        return WR_BAD_DATA;
    for (i=0;i<count;i++)
    {
        int used=0;
        for (j=0;j<i;j++)
            if (keyeq(table[i].trigger, table[j].trigger))
                return WR_CONFLICT;
        for (j=0;j<graph->n;j++)
            if (graph->nodes[j].active && keyeq(table[i].trigger, graph->nodes[j].trigger))
                used=1;
        if (!used)
            return WR_COVERAGE;
    }
    for (i=0;i<graph->n;i++)
    {
        work->destination[i]=WR_NONE;
        work->partner[i]=WR_NONE;
        if (!graph->nodes[i].active)
            continue;
        for (j=0;j<count;j++)
            if (keyeq(table[j].trigger, graph->nodes[i].trigger))
                break;
        if (j==count)
            return WR_COVERAGE;
        for (t=0;t<graph->n;t++)
            if (keyeq(graph->nodes[t].id, table[j].landing))
                break;
        if (t==graph->n || !graph->nodes[t].active || graph->nodes[t].rep!=t)
            return WR_BAD_PAIR;
        work->destination[i]=t;
    }
    for (i=0;i<graph->n;i++)
        if (graph->nodes[i].active)
        {
            uint16_t r=graph->nodes[i].rep;
            t=work->destination[i];
            if (t==r || work->destination[r]!=t || work->destination[t]!=r || !allowed(&graph->nodes[r],
                &graph->nodes[t]))
                return WR_BAD_PAIR;
        }
    if (closure(graph, work))
        return WR_TRAP;
    for (i=0;i<graph->n;i++)
        if (work->reached[i] && !work->home[i])
            return WR_TRAP;
    for (i=0;i<graph->goal_count;i++)
        if (!work->reached[graph->goals[i]])
            return WR_OBJECTIVE;
    return WR_OK;
}

int wr_publish(const struct WrGraph *graph, const struct WrIdentity *id, const struct WrRecord *table,
    uint16_t count, struct WrActive *a, struct WrWork *work)
{
    int result;
    wr_invalidate(a);
    if (!identityok(graph, id))
        return WR_BAD_IDENTITY;
    result=wr_validate(graph, table, count, work);
    if (result)
        return result;
    memcpy(a->records, table, count*sizeof(*table));
    a->identity=*id;
    a->count=count;
    a->attempt=0;
    a->valid=1;
    return WR_OK;
}

/* 5. Deterministic construction and its small continuation record. */
static uint32_t rng(uint32_t *s)
{
    *s=*s*1664525u+1013904223u;
    return *s;
}

static uint16_t choose(uint32_t *s, uint16_t count)
{
    /* rejection sampling, including seed zero, without gameplay RNG */
    uint32_t r, threshold=(0u-(uint32_t)count)%count;
    do
    {
        r=rng(s);
    }
    while (r<threshold);
    return (uint16_t)(r%count);
}

/* Recompute from the partial pairing and stop at the FIRST unsafe capability
* stage. A later item must not hide an earlier return obligation. */
static int construction_state(const struct WrGraph *graph, struct WrWork *work)
{
    uint16_t i;
    for (i=0;i<graph->n;i++)
        work->destination[i]=graph->nodes[i].active?work->partner[graph->nodes[i].rep]:WR_NONE;
    return closure_until(graph, work, 1);
}

static int free_endpoint(const struct WrGraph *graph, const struct WrWork *work, uint16_t i)
{
    return graph->nodes[i].active && graph->nodes[i].rep==i && work->partner[i]==WR_NONE;
}

/* Every unsafe reached vertex must retain a route to an unpaired endpoint.
* Reverse multi-source traversal checks this without assuming symmetric walks. */
static int repairable(const struct WrGraph *graph, struct WrWork *work)
{
    uint16_t i, v, t, head=0, tail=0;
    memset(work->scratch, 0, graph->n);
    for (i=0;i<graph->n;i++)
        if (free_endpoint(graph, work, i) && work->reached[i])
        {
            work->scratch[i]=1;
            work->queue[tail++]=i;
        }
    while (head<tail)
    {
        v=work->queue[head++];
        for (i=graph->reverse_bounds[v];i<graph->reverse_bounds[v+1];i++)
        {
            const struct WrEdge *e=&graph->reverse_edges[i];
            t=e->to;
            if ((e->cap==WR_NONE || work->caps[e->cap]) && !work->scratch[t])
            {
                work->scratch[t]=1;
                work->queue[tail++]=t;
            }
        }
        for (t=work->reverse_head[v];t!=WR_NONE;t=work->reverse_next[t])
            if (!work->scratch[t])
            {
                work->scratch[t]=1;
                work->queue[tail++]=t;
            }
    }
    for (i=0;i<graph->n;i++)
        if (work->reached[i] && !work->home[i] && !work->scratch[i])
            return 0;
    return 1;
}

/* Start each retry from an empty pairing with a deterministic independent seed. */
static void start_attempt(struct WrJob *job)
{
    uint16_t i;
    job->left = 0;
    job->random_state = job->identity.seed + 0x9e3779b9u * job->attempt;
    for (i = 0; i < job->graph->n; i++)
    {
        job->work->partner[i] = WR_NONE;
        if (free_endpoint(job->graph, job->work, i))
            job->left++;
    }
    job->work->attempts++;
}

int wr_begin(struct WrJob *job, const struct WrGraph *graph, const struct WrIdentity *identity, uint16_t
    retries, struct WrActive *active, struct WrWork *work)
{
    memset(job, 0, sizeof(*job));
    memset(work, 0, sizeof(*work));
    wr_invalidate(active);
    job->graph = graph;
    job->active = active;
    job->work = work;
    job->identity = *identity;
    job->retries = retries;
    job->result = wr_graph_check(graph);
    if (job->result != WR_OK)
        return job->result;
    if (!identityok(graph, identity))
        return job->result = WR_BAD_IDENTITY;
    if (!retries)
        return job->result = WR_RETRIES;
    start_attempt(job);
    if (job->left % 2)
        return job->result = WR_ODD_POOL;
    return job->result = WR_PENDING;
}

/* Test three random partners, keeping the one that exposes the most free exits.
* The expensive operation is a fresh graph closure, not selecting a random door.
* The sample bounds trial COUNT, not elapsed time. Rejected attempts restart. */
static int pair_one(struct WrJob *job)
{
    const struct WrGraph *graph = job->graph;
    struct WrWork *work = job->work;
    uint16_t i, j, count = 0, source, target = WR_NONE, ties = 0;
    uint16_t limit;
    int best = -1;
    int unsafe = construction_state(graph, work);
    /* First repair a reached region that cannot return to the root. */
    for (i = 0; i < graph->n; i++)
    {
        if (free_endpoint(graph, work, i) && work->reached[i] && (unsafe ? !work->home[i] :
            work->home[i]))
            work->candidates[count++] = i;
    }
    if (!count)
        return unsafe ? WR_TRAP : WR_NO_SOURCE;
    source = work->candidates[choose(&job->random_state, count)];
    count = 0;
    for (i = 0; i < graph->n; i++)
    {
        if (free_endpoint(graph, work, i) && i != source && allowed(&graph->nodes[source],
            &graph->nodes[i]) && (!unsafe || work->home[i]))
            work->candidates[count++] = i;
    }
    limit = count < 3 ? count : 3;
    for (j = 0; j < limit; j++)
    {
        uint16_t pick = j + choose(&job->random_state, count - j);
        uint16_t trial = work->candidates[pick];
        uint16_t free_count = 0, safe_count = 0;
        int trial_unsafe, score;
        /* Partial Fisher-Yates: sample distinct candidates without replacement. */
        work->candidates[pick] = work->candidates[j];
        work->candidates[j] = trial;
        work->partner[source] = trial;
        work->partner[trial] = source;
        trial_unsafe = construction_state(graph, work);
        for (i = 0; i < graph->n; i++)
        {
            if (free_endpoint(graph, work, i) && work->reached[i])
            {
                free_count++;
                if (work->home[i])
                    safe_count++;
            }
        }
        score = free_count;
        if (job->left > 2 && !free_count)
            score = -1;
        else if (trial_unsafe && (!safe_count || !repairable(graph, work))) score = -1;
        work->partner[source] = WR_NONE;
        work->partner[trial] = WR_NONE;
        if (score < 0)
            continue;
        if (score > best)
        {
            best = score;
            target = trial;
            ties = 1;
        }
        else if (score == best && choose(&job->random_state, ++ties) == 0)
        {
            target = trial;
        }
    }
    if (target == WR_NONE)
        return WR_NO_PARTNER;
    work->partner[source] = target;
    work->partner[target] = source;
    job->left -= 2;
    return WR_OK;
}

int wr_advance(struct WrJob *job)
{
    uint16_t count = 0;
    int result;
    if (job->result != WR_PENDING)
        return job->result;
    if (job->left)
    {
        result = pair_one(job);
        if (result == WR_OK)
            return WR_PENDING;
    }
    else
    {
        /* Reconstruct and validate the actual emitted table before publication. */
        result = wr_emit(job->graph, job->work->partner, job->work->candidate, &count);
        if (result == WR_OK)
            result = wr_publish(job->graph, &job->identity, job->work->candidate, count, job->active,
                job->work);
        if (result == WR_OK)
        {
            job->active->attempt = job->attempt;
            return job->result = WR_OK;
        }
    }
    job->last_rejection = result;
    job->work->rejection_counts[result]++;
    if (++job->attempt < job->retries)
    {
        start_attempt(job);
        return WR_PENDING;
    }
    wr_invalidate(job->active);
    return job->result = WR_RETRIES;
}

void wr_cancel(struct WrJob *job)
{
    wr_invalidate(job->active);
    job->result = WR_CANCELLED;
}

/* Host convenience. On the game, call advance from a loading callback instead. */
int wr_generate(const struct WrGraph *graph, const struct WrIdentity *id, uint16_t retries, struct
    WrActive *active, struct WrWork *work, int *last)
{
    struct WrJob job;
    int result = wr_begin(&job, graph, id, retries, active, work);
    while (result == WR_PENDING)
        result = wr_advance(&job);
    *last = job.last_rejection ? job.last_rejection : result;
    return result;
}

/* 6. Gameplay lookup and explicitly encoded save identity. */
int wr_lookup(const struct WrActive *a, const struct WrIdentity *id, struct WrKey *requested)
{
    uint16_t i;
    if (!a->valid || !identityeq(&a->identity, id))
        return -1;
    for (i=0;i<a->count;i++)
        if (keyeq(a->records[i].trigger,*requested))
        {
            *requested=a->records[i].landing;
            return 1;
        }
    return 0;
}

static void put32(uint8_t *p, uint32_t v)
{
    p[0]=(uint8_t)v;
    p[1]=(uint8_t)(v>>8);
    p[2]=(uint8_t)(v>>16);
    p[3]=(uint8_t)(v>>24);
}

static uint32_t get32(const uint8_t *p)
{
    return (uint32_t)p[0]|((uint32_t)p[1]<<8)|((uint32_t)p[2]<<16)|((uint32_t)p[3]<<24);
}

static uint32_t crc32(const uint8_t *p, size_t n)
{
    uint32_t crc=UINT32_MAX;
    size_t i;
    unsigned b;
    for (i=0;i<n;i++)
    {
        crc^=p[i];
        for (b=0;b<8;b++)
            crc=(crc>>1)^(0xedb88320u & (0u-(crc&1u)));
    }
    return ~crc;
}

int wr_encode(const struct WrActive *a, uint8_t out[WR_SAVE_BYTES])
{
    if (!a->valid)
        return WR_BAD_IDENTITY;
    memset(out, 0, WR_SAVE_BYTES);
    memcpy(out,"WR06", 4);
    put32(out+4, a->identity.seed);
    put32(out+8, a->identity.algorithm);
    put32(out+12, a->identity.ruleset);
    memcpy(out+16, a->identity.data, 32);
    out[48]=(uint8_t)a->attempt;
    out[49]=(uint8_t)(a->attempt>>8);
    put32(out+52, crc32(out, 52));
    return WR_OK;
}

int wr_decode(const struct WrGraph *graph, const uint8_t in[WR_SAVE_BYTES], struct WrIdentity *id,
    uint16_t *attempt)
{
    struct WrIdentity candidate;
    if (memcmp(in,"WR06", 4) || in[50] || in[51] || crc32(in, 52)!=get32(in+52))
        return WR_BAD_IDENTITY;
    candidate.seed=get32(in+4);
    candidate.algorithm=get32(in+8);
    candidate.ruleset=get32(in+12);
    memcpy(candidate.data, in+16, 32);
    if (!identityok(graph, &candidate))
        return WR_BAD_IDENTITY;
    *id=candidate;
    *attempt=(uint16_t)(in[48]|((uint16_t)in[49]<<8));
    return WR_OK;
}

/* 7. Admit only known physical source events before trigger lookup. */
static int key_compare(const struct WrKey *a, const struct WrKey *b)
{
    if (a->group != b->group)
        return (int)a->group - b->group;
    if (a->map != b->map)
        return (int)a->map - b->map;
    return (int)a->warp - b->warp;
}

int wr_source_normalize(const struct WrSourceRoute *routes, size_t count, const struct WrKey *source,
    const struct WrKey *requested, uint16_t x, uint16_t y, uint8_t elevation, struct WrKey *out)
{
    size_t lo = 0, hi = count;
    const struct WrSourceRoute *row;
    if (!routes || !source || !requested || !out)
        return 0;
    while (lo < hi)
    {
        size_t mid = lo + (hi - lo) / 2;
        if (key_compare(&routes[mid].source, source) < 0)
            lo = mid + 1;
        else hi = mid;
    }
    if (lo == count)
        return 0;
    row = &routes[lo];
    if (key_compare(&row->source, source) || key_compare(&row->expected, requested) || row->x != x ||
        row->y != y || row->elevation != elevation)
        return 0;
    *out = row->trigger;
    return 1;
}

