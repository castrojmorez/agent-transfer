# A smaller warp randomizer

This project rearranges ordinary event warps in Pokémon Emerald Expansion: a door, cave entrance or staircase can lead somewhere different, while the chosen world remains reproducible from a seed. The intended destination is still **generation inside the game**. Python prepares the map description when developing the ROM; it does not generate each player's world.

This is a compact development core, not a finished playable randomizer. Its graph model passes the host checks described below. Its rewritten game adapter now compiles and links against the pinned target, and four headless mGBA test groups pass. Target timing exposes a major usability problem: generation takes about 64–102 seconds for the two measured seeds, with a roughly 6.4-second final callback pause. The actual starting sequence, progression interactions, safe arrival tiles and a Champion/credits run remain unproven.

Read this file for the reasoning, DOCS.md to follow and install the code, and FUTURE.md for the remaining design choices. These are the only three commentary documents.

## What was simplified

The supplied archive contained 372 files. It was both an implementation and a laboratory notebook: successive constructors, optimizations, generated indexes, emulator harnesses, historical patches, duplicated data and many checkpoint reports. Those records explain how the project developed, but they need not all be dependencies of the next implementation.

This edition has **eleven maintained files**:

| File | Purpose |
|---|---|
| INTRODUCTION.md | Goals, history and design rationale |
| DOCS.md | Code tutorial, commands and manual integration edits |
| FUTURE.md | Unfinished behavior and alternative implementations |
| world.json | One frozen graph plus target source signatures |
| build.py | Check that input and turn it into C arrays |
| warp_rando.h | Shared types and callable functions |
| warp_rando.c | Construction, acceptance, lookup and save identity |
| warp_game.c | Loading callback, game entry points and event adapter |
| test.py | Host harness and independent Python acceptance checks |
| target_test.c | Real-engine regression tests, including flash save and timing |
| LICENSE | Retained GPLv3 license text |

`warp_data.h` and `verification.json` are generated outputs, not additional sources to maintain. The package also includes integration.patch, the concrete target edits described in DOCS.md; apply the patch or the manual edits, not both. There is no package manager, third-party Python dependency, experiment include stack or runtime graph index generator.

This is deliberately a **pruned and rewritten derivative**, not a claim that every function was invented anew. It retains the supplied portable core's graph traversal, emission, acceptance and explicit save codec, expands their cramped formatting, and replaces the constructor lifecycle. It uses the earlier bounded partner-sampling idea without the later SCC, bitset, delta-propagation and nested scheduler layers. The compiler and independent validator are adapted from the supplied project. The game lifecycle is reduced to a single loading callback.

Some complexity was doing useful work. Removing it has a cost:

| Property | This edition |
|---|---|
| Generate a seed on the GBA | Preserved in C; compile-time development seed remains the default |
| Coupled doors and grouped physical entrances | Preserved |
| Conditional travel, chained capabilities, explicit goals | Preserved in the graph model |
| Early directed-trap rejection and frontier repair | Preserved |
| Source-aware static-event interception | Preserved using frozen target signatures |
| Save/reload world identity | Preserved with a new, incompatible format/algorithm identity |
| Old seed-to-layout identity | Not promised; use fresh saves |
| Old measured frame responsiveness | Not preserved; operations yield only between pairings |
| Historical provenance reports and experiment variants | Kept in the original attachment, not copied into this core |
| Automatic raw-upstream annotation reimport | Removed; edit the normalized world model directly |

## What the original external randomizer did

The supplied project's source analysis describes KittyPBoxx's UPR-based Java randomizer as two cooperating halves. This explanation is based on that delivered analysis and frozen inputs, not a fresh audit of today's upstream branches.

The external program reads annotated warps, flags, key locations and escape-path information. It treats the world as a graph, then connects entrances while taking account of reachability, disconnected components, return obligations and progression locations. It eventually emits remapping records for the ROM. Its priority system is more elaborate than a shuffled list of destinations.

The modified Speedchoice game supplies the other half: lookup, source normalization, arrival fixes, special travel behavior and script changes for map-randomizer mode. A graph generator does not automatically reproduce those game changes. Porting the Java algorithm to C alone was therefore never enough to make Expansion behave like the original randomizer.

One particularly confusing detail is that a legacy remapping record is keyed by the source door's **vanilla destination**, called its `trigger` here. It is not keyed directly by the door's own address. The adapter must first identify the physical source event, check its signature, and translate it into the reference trigger. This distinction explains why apparently harmless destination mismatches can matter.

## A small vocabulary

An **endpoint** is a physical warp event, identified by map group, map number and warp index. A **representative** is the chosen endpoint for a group: a two-tile doorway may have two physical events but should be randomized as one entrance. An **edge** describes repeatable directed travel between endpoints, commonly walking inside or between map areas. A **capability** is a permanent fact such as having the modeled requirements for Surf. A **rule** grants a capability when all its prerequisites hold.

The **root** is the graph's anchor, currently the reference Oldale endpoint. The **frontier** is the set of reachable representative endpoints that have not yet been paired. The frontier is what lets construction expand into more of the world.

A **coupled pair** means that leaving representative A arrives at B and leaving B arrives at A. It does not mean every walking route around A and B is reversible.

## Why “shuffle the doors” was not enough

### The last usable exit can disappear too soon

Imagine the connected starting region has three unassigned doors. Each is paired with a small room containing only its paired exit. All three pairings are individually reversible, but none introduces another unassigned exit. The constructor has spent its entire frontier while hundreds of entrances remain disconnected.

The historical diagnosis in the attachment found this behavior: progression leaves were favored ahead of regions that could keep construction expanding. Counting raw walking edges did not reliably predict how many distinct unpaired entrances a choice would expose.

The amendment is to **try a pairing and count its actual reachable free representatives**. Reject a choice that consumes the frontier before the pool is finished. Among a few acceptable trials, favor the choice that leaves the largest frontier.

### Reversible door pairs can still form a one-way trap

Suppose a ledge lets the player enter room A from outside. A's randomized exit leads to B, and B's leads back to A. The pair is perfectly coupled, but the player can only circulate between A and B. The ledge cannot be climbed in reverse.

The attachment gives a concrete example involving Sky Pillar F5 and the Slateport shipyard stairs. It reports that this failure could persist even with all modeled conditional travel opened. It was not fixed by casually renaming the Weather Institute or Flash conditions.

The amendment is to track **both reachability from the root and the ability to return to it**. During construction, a temporarily trapped region is allowed only while every reached unsafe vertex still has a route to a free endpoint that could repair it. The next pairing prioritizes that repair, connecting an unsafe reached endpoint toward a place that already has a route home.

This is a construction heuristic, not a proof that every partial layout can be completed. A final, fresh validation decides whether the completed layout is acceptable. Failure starts a new deterministic attempt; it never publishes a partial table.

## The actual algorithm

1. Start with no randomized pairings and no earned capabilities.
2. Follow currently available directed travel from the root. Separately follow reversed travel from the root to discover which places can return.
3. Earn capabilities only from locations that are both reachable and returning. Repeat until no new capability is earned, or stop at the first unsafe stage while constructing.
4. Choose a reached unpaired representative. If the current stage has a return problem, choose from the unsafe region first.
5. Sample up to three distinct compatible partners. Temporarily install each pair, recompute the graph state, and count the free exits it exposes. Reject exhausted-frontier and unrepairable-trap trials.
6. Commit the best trial, breaking equal scores with the dedicated random generator. Yield to the caller after this pairing.
7. When the pool is paired, expand groups into actual remap records, reject conflicting aliases, and validate those records from fresh state.
8. Publish only on success. Otherwise restart with a derived seed, up to eight attempts in the game adapter.

The three-trial policy is inherited from the supplied experiment's useful scheduling idea. It is easy to explain and avoids trying every possible partner at every step. It does not produce a uniform sample of all valid worlds, and eight attempts do not guarantee that every input seed succeeds.

“Yield” is an ordinary function return. The code saves a small job structure and the next callback resumes from it. There are no threads or coroutines. Each graph walk still completes synchronously, and final validation can be a large operation.

## What acceptance actually promises

At each modeled capability stage, every reachable endpoint must be able to return to the root with the capabilities available at that stage. Only safe reachable locations can grant new capabilities. All explicit goals must ultimately be reachable. Unknown conditions remain unavailable rather than silently becoming free travel.

This is deliberately strict. It rejects a room that contains its own escape item if entering the room is already unsafe before collecting that item. It can also reject a world with a valid winning route but an optional early trap. This policy is easier to reason about than assuming that players will always choose a safe order.

It is still a statement about an abstraction. Reachable gym doors do not prove beatable battles. Reachable item locations do not prove their scripts run correctly. A node address does not prove a safe landing tile. Permanently blocked unknown edges can conceal real-game routes into trouble. Special transitions left vanilla may change actual reachability in ways the graph does not describe.

The model's Oldale root also does not physically relocate the new player. That starting-sequence mismatch is an explicit integration blocker, not an implicit assumption that the ROM already handles it.

## Verification in this revision

The ordinary host suite passed 16 test groups, comprising 57 C harness cases. The same suite passed with AddressSanitizer and UndefinedBehaviorSanitizer. It includes directed traps, a self-locked capability, nine prerequisites, chained derivations, excluded fixed travel, grouped aliases, conflicting triggers, odd pools, exhausted retries, cancellation and deterministic restart.

Twelve bundled-world seeds passed independent Python validation: 0, 1, 2, 3, 7, 17, 42, 63, 255, 256, 65535 and 4294967295. Seeds 3, 42, 63 and 255 needed the second attempt. This exercises retry persistence as well as the first-attempt path. The harness also checks all 608 participating source signatures and rejects coordinate mismatches.

These are new host results. A follow-up retrieved the exact target commit and compiled both a normal ROM and the new target test ROM with ARM GCC 13.2.1. Four headless mGBA test groups pass: generation and flash Continue; all-source checks and selected real event-hook calls; cancellation; and allocation/corruption failure paths. See DOCS.md for the measured timings, memory figures, test commands and limitations. The largest pause occurs in the final emission/publication callback, so the simpler constructor is not ready for a responsive player-facing loading flow.

The old archive's 1,024-seed sweeps and frame budgets still do not transfer to this implementation. These new target checks are controlled engine tests, not a graphical playthrough, physical hardware test or Champion/credits run.

## Attribution and frozen inputs

The retained graph has 879 physical nodes, 512 active representatives, 1,394 fixed/conditional edges and 14 capability rules. The 608 participating physical sources expand into 532 unique trigger records in the tested worlds. Counts differ because grouped endpoints and shared triggers are different concepts.

The world model and source signatures are consolidated from `data/reference-normalized.json` and `data/target-source-routes.h` in the supplied archive. The target map counts come from its corresponding Expansion header. Available human-readable node labels are retained from its raw Warps.json. Source signatures and map counts now participate in the same SHA-256 input identity as the graph.

The supplied provenance pins were:

| Component | Commit |
|---|---|
| KittyPBoxx/upr-speedchoice-ex-gen9 | 5abfca86134872dbb3c54fa48e5920b6549cfb69 |
| KittyPBoxx/pokeemerald-ex-speedchoice-maprando-gen9 | f539267677ec3686c7f22bae2a63dc6f1a5267e9 |
| KittyPBoxx/Emerald-Ex-Map-Rando | f0966a668d3e7a7e937a519365cb1391d4a174a4 |
| rh-hideout/pokeemerald-expansion, expansion/1.17.0 | e8bd1cd7b03fc032ea37e3ecd38b379b5d01a1e7 |

Credit belongs to KittyPBoxx and Universal Pokémon Randomizer contributors for the reference design/data; RHH and pret contributors for the target engine; and the authors of the supplied project for the retained implementation and investigations. The derivative code is supplied under the project's GPLv3 terms; retain LICENSE and these credits. No ROM is included.
