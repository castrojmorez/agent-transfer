# Understanding and working on the code

Start with INTRODUCTION.md. Then read `pair_one`, `construction_state`, `closure_until` and `repairable` in warp_rando.c. Those four functions contain the central idea. The remaining code checks data, translates the result, manages its lifetime or connects it to the engine.

This folder is a replacement development workspace. It does not depend on the old archive's folders. Keep the original ZIP as history; do not combine its experiment files with this version.

## Run the host checks

Use Python 3.10+ and a C99 compiler named `cc` (or set `CC`). No Python packages are required. From this folder:

```sh
python3 build.py
python3 test.py
```

The first command checks world.json and writes warp_data.h. The second compiles temporary C executables, runs synthetic cases and the bundled-world sample, and writes verification.json. It creates temporary files with Python's temporary-directory facility and cleans them on exit. Each compilation/executable invocation has a 45-second timeout; tests are divided into small cases rather than one unbounded experiment.

On a compiler/platform supporting GCC-compatible sanitizers:

```sh
SANITIZE=1 python3 test.py
```

That command uses AddressSanitizer and UndefinedBehaviorSanitizer. The harness disables LeakSanitizer's exit inspection because the original restricted host could not enumerate processes; the portable core itself allocates no heap memory. This does not test the target adapter's allocations.

A returned status of zero means the tests passed. Merely finding verification.json does not mean a complete suite passed: the file records executed cases even if a later assertion failed. Read the test process's final result.

The compiler can also take explicit paths:

```sh
python3 build.py world.json warp_data.h
```

Do not hand-edit warp_data.h. It is a mechanical translation of the one maintained input.

## The data, with a concrete example

A world.json node has these fields:

| Field | Meaning |
|---|---|
| `name` | Human-searchable stable identifier, usually `E,group,map,warp` |
| `label` | Original descriptive map/door name, where supplied; for reading, not routing |
| `id` | Physical endpoint triple: map group, map index, warp-event index |
| `trigger` | Reference lookup key, usually the source's original destination |
| `rep` | Name of the representative for this entrance group |
| `active` | Whether this group participates in randomized pairing |
| `tags` | Bit 1: needs-return; bit 2: no-return; their forbidden combination is checked |

For example, a grouped doorway can have two nodes with different `id` values and the same `rep`. Both physical events must lead to the same chosen partner. The representative is a real endpoint, not a separate invented room.

An edge resembles:

```json
{"from": "E,0,0,0", "to": "E,0,0,1", "requires": null}
```

This example illustrates the schema; it is not an instruction to add that route. `null` means unconditional travel. A capability name means the edge opens after earning that capability. The reverse direction needs its own edge. Do not turn every edge into a two-way edge merely because most walking feels reversible.

A rule resembles:

```json
{
  "grant": "SURF",
  "requires": [
    {"location": "BADGE_LOCATION"},
    {"location": "HM_LOCATION"}
  ]
}
```

These illustrative names would need real declarations. Requirements within a rule are ANDed. Multiple rules granting the same capability provide alternatives: either rule is sufficient. A requirement can name an already earned `capability` instead of a `location`, supporting chains. Empty requirements deliberately mean an unconditional grant.

Rule labels and granted capability names are different namespaces in the original source. In this normalized model, `HOENN_FLASH_1` remains a declared condition without a provider, while the actual Flash rule grants `HOENN_FLASH`. `WEATHER_INSTITUTE` also has no provider. Their closure is deliberate retained policy. Do not silently strip suffixes or open these edges.

Excluded nodes are still in the graph. Excluding a warp from randomization does not remove its walking routes or certify that all of its vanilla transitions are modeled. The inherited fixed edges contain the resolvable excluded travel; unresolved destinations remain a limitation.

The `source_routes` section adds actual target event signatures: source triple, expected vanilla destination, reference trigger, x, y and elevation. This is the bridge between the target's event and the reference model. `target_map_counts` bounds map lookup before indexing the engine's map tables.

## What build.py does

`normalize` checks names, numeric limits, group consistency, participation collisions, capability references, rules and goals. It replaces names with small numeric indexes. Sorted nodes and canonical rule/edge ordering make the output deterministic.

`emit` writes static C arrays. Forward adjacency lets traversal quickly find outgoing edges. Reverse adjacency lets the same traversal find routes back to the root. `bounds[v]` through `bounds[v+1]` describe node v's slice of an edge array; this is just a compact substitute for an array of lists.

`emit_routes` verifies that the source table covers every participating physical node exactly once and agrees with its trigger. It also checks coordinate ranges and map-count bounds. It cannot inspect collision tiles or infer what a script does.

The SHA-256 fingerprint covers a canonical JSON serialization of the entire input, including source signatures, map counts and provenance. Whitespace and object-key order do not affect it. Array order and explanatory content can affect it. This intentionally errs toward rejecting an old save after an input edit. It does not automatically hash C code: bump the local algorithm version when algorithm semantics change.

## Reading the C types

Most functions take a pointer to immutable `WrGraph`, mutable `WrWork`, or published `WrActive`.

| Type | Lifetime and role |
|---|---|
| `WrGraph` | Read-only ROM description, generated from world.json |
| `WrWork` | Temporary arrays used while constructing or checking a layout |
| `WrActive` | Complete accepted mapping plus identity; lives while playing |
| `WrJob` | Small continuation record: current attempt, RNG state, remaining pool and pointers |
| `WrIdentity` | Seed, algorithm, ruleset and input fingerprint |
| `WrRecord` | One trigger triple and its landing triple |

The workspace is deliberately explicit. There are no hidden allocations in the portable core. The adapter allocates it on entering the loading screen and frees it on completion or failure. The active table remains allocated in EWRAM. Do not put WrWork on the GBA stack.

`WR_NONE` is the value 65535, meaning “no partner/destination/condition.” It is different from index zero, which is valid. The maintained limits are 1,024 nodes and 32 capabilities, enough for the frozen 879-node/16-capability model. Widening them changes memory use and needs a new target budget check.

Within traversal helpers, `i` and `j` are indexes, `v` is a vertex, `t` is a destination, and `r` is often a representative or rule. These are local loop names, not additional conceptual state.

## The constructor, one function at a time

`wr_begin` invalidates the active table, clears temporary work, checks graph/identity, and starts the first attempt. Callers supply valid, distinct job/work/active objects and keep them alive until completion. Graph and identity pointers must be valid. These are internal C APIs, not a parser for arbitrary pointers.

`start_attempt` assigns `WR_NONE` to every partner, counts active representatives, and derives the attempt RNG state. Attempt j starts from `seed + 0x9e3779b9*j`, modulo 2^32. An odd representative pool is rejected; there is no hidden self-pair to absorb it.

`wr_advance` calls `pair_one` if entrances remain. A successful pair returns `WR_PENDING`. On a subsequent call after the final pair, it emits and validates the table, then returns `WR_OK`. A failed trial sequence or final validation starts another attempt if any remain. Once terminal, additional calls return the terminal result.

`pair_one` first computes the current graph state. If anything reached cannot get home, it selects a free source in that unsafe region and restricts candidate partners to endpoints that can already get home. Otherwise it selects a reached safe source. A partner also has to pass the tag check.

The partial Fisher–Yates shuffle samples up to three distinct candidates. Each temporary pair is inserted, evaluated and removed. The score is the number of reachable unused representatives after that trial. Losing every free exit before completion is rejected. A temporarily unsafe result must leave a safe free endpoint and pass `repairable`. Reservoir-style tie breaking avoids always preferring the first equal-scoring candidate.

`construction_state` turns representative partners into physical travel: every active member uses its representative's partner. It then calls `closure_until` with “stop at the first unsafe stage.” This prevents an item earned later from concealing an earlier repair obligation.

`traverse` is a queue-based graph search. Forward mode fills `reached`; reverse mode fills `home`. A node belongs to `home` if there is a path from it back to the root. The reverse search starts at the root over reversed edges; it is not a search for a second special destination.

`closure_until` starts with no capabilities, performs both searches, and checks rules. It grants only from reached returning locations. New capabilities are collected into a separate next-state array, so one loop iteration represents one capability stage. It repeats until stable. Construction stops early on unsafe stages; final validation remembers any unsafe stage and rejects the world.

`repairable` searches backward from reached free representatives. Every currently reached unsafe vertex must be able to reach one of those exits. This test rules out already sealed sinks, but it does not solve all future constraints; retries are still necessary.

## Emission and acceptance are separate jobs

`wr_emit` expands canonical pairs to physical trigger records. If two sources share a trigger, they must request the same landing. Contradictory aliases fail. Records are sorted for stable output.

`wr_validate` consumes those records, not the constructor's optimistic partial reachability. It checks exact trigger coverage, valid representative landings, grouped consistency, reciprocal pairing and forbidden tags. It reconstructs the actual directed warp travel and performs fresh capability closure. A trap at any stage or an unreachable goal rejects the table.

`wr_publish` invalidates before checking, copies only a complete accepted table, and sets `valid` last. The graph checks are intentionally repeated on the portable emission/publication paths. They are easy to audit but expensive; eliminating proven redundancy is a possible later optimization.

`test.py` has a separate Python validator using sets and directed graph walks. It neither imports C closure state nor trusts the constructor's result code. Both implementations follow the same declared model, so agreement is evidence about implementation, not independent evidence that the model matches Pokémon's scripts.

## Lookup and save identity

`wr_source_normalize` binary-searches sorted physical source signatures and compares the expected destination, x, y and elevation. A mismatch leaves the output untouched. `wr_lookup` then checks active identity and searches for the normalized trigger. The table is small enough that a simple linear lookup is retained.

The save is 56 explicitly encoded bytes:

| Byte offset | Contents |
|---|---|
| 0–3 | `WR06` format marker |
| 4–7 | Seed |
| 8–11 | Local algorithm ID 6 |
| 12–15 | Ruleset 1 |
| 16–47 | SHA-256 input fingerprint |
| 48–49 | Successful zero-based attempt |
| 50–51 | Reserved zero bytes |
| 52–55 | CRC32 of bytes 0–51 |

Multibyte values are little-endian. The CRC detects accidental corruption; it is not authentication. The fingerprint identifies the input model, not a proof of gameplay safety. This local ID/format is not an upstream registration and does not migrate old Algorithm-3/5 saves.

Continue decodes identity, regenerates from the original seed, and checks that the successful attempt matches the saved attempt before entering the field. Corruption, a changed model or exhausted retries returns to title. A randomized save must never silently resume using an unrelated or vanilla table.

The target follow-up measured a 60-byte SaveBlock3 with this field under default configuration, passed its compile-time size assertion, and verified the identity through actual flash save/load. Recheck capacity if you enable other save features.

## Manual integration into a clean target

These are concrete manual edits for a **clean** Expansion 1.17.0 target at the commit in INTRODUCTION.md. They are not a patch to layer on top of the old C10/C11/proof wiring. Use a separate branch/worktree. These edits have now been applied to that exact target, compiled and linked. integration.patch contains the same edits plus a TESTING-only accessor for exercising the real static SetupWarp function.

This adapter is enabled by installing the following edits; there is no runtime enable/disable switch. Existing saves are rejected. Keep an ordinary build separately. Do not use these instructions on your only copy of a save.

### 1. Add three compiled inputs and one generated header

Run `python3 build.py`, then copy:

| This folder | Target checkout |
|---|---|
| warp_rando.h | include/warp_rando.h |
| warp_data.h | include/warp_data.h |
| warp_rando.c | src/warp_rando.c |
| warp_game.c | src/warp_game.c |

Only warp_game.c includes warp_data.h in the target, so the large static arrays are defined once. Ensure the target build discovers both new `.c` files. The host suite compiles only the portable core; it does not compile the engine adapter.

### 2. Reserve identity storage

At the end of `struct SaveBlock3` in `include/global.h`, before its closing brace, append:

```c
    // Compact warp randomizer: explicit identity, not a saved C struct.
    u8 warpRando[56];
```

Do not append the field twice. Default target size and flash serialization now pass the tests below. The engine's existing SaveBlock3 maximum remains the guard when other save features are enabled.

### 3. Wrap new game and Continue

In `src/overworld.c`, add includes:

```c
#include "warp_rando.h"
#include "title_screen.h"
```

Rename the existing `void CB2_NewGame(void)` implementation to `static void CB2_NewGameReady(void)`. Insert this wrapper before it:

```c
static void CB2_NewGameReady(void);

void CB2_NewGame(void)
{
    WarpRando_NewGame(CB2_NewGameReady, CB2_InitTitleScreen);
}
```

Inside the renamed implementation, immediately **after** `NewGameInitData();`, insert:

```c
    if (!WarpRando_Save(gSaveBlock3Ptr->warpRando))
    {
        SetMainCallback2(CB2_InitTitleScreen);
        return;
    }
```

Writing before NewGameInitData would let initialization erase the new identity. No special save hook is needed afterward if the target's normal flash save really serializes the appended field: the identity is constant throughout this world.

Similarly rename the existing `void CB2_ContinueSavedGame(void)` body to `static void CB2_ContinueSavedGameReady(void)`, and place this wrapper before it:

```c
static void CB2_ContinueSavedGameReady(void);

void CB2_ContinueSavedGame(void)
{
    WarpRando_Continue(gSaveBlock3Ptr->warpRando,
                       CB2_ContinueSavedGameReady,
                       CB2_InitTitleScreen);
}
```

Keep the existing bodies' other initialization steps. The loading adapter finishes first; only successful generation/reconstruction reaches those bodies. Generation remains inside the ROM. `WARP_RANDO_SEED` in warp_game.c is the development seed, as opposed to a finished seed-entry UI.

### 4. Intercept only the ordinary event path

In `src/field_control_avatar.c`, add `#include "warp_rando.h"`. In `SetupWarp`, locate the ordinary `else` branch which currently declares `const struct MapHeader *mapHeader;`, calls `SetWarpDestinationToMapWarp`, then updates the escape/dynamic warp state. Replace that branch's contents with:

```c
        const struct MapHeader *mapHeader;
        s8 destGroup = warpEvent->mapGroup;
        s8 destMap = warpEvent->mapNum;
        s8 destWarp = warpEvent->warpId;
        bool8 redirected = FALSE;

        if (!trainerHillMapId)
            redirected = WarpRando_Resolve(
                gSaveBlock1Ptr->location.mapGroup,
                gSaveBlock1Ptr->location.mapNum, warpEventId,
                warpEvent->x, warpEvent->y, warpEvent->elevation,
                &destGroup, &destMap, &destWarp);

        SetWarpDestinationToMapWarp(destGroup, destMap, destWarp);
        UpdateEscapeWarp(position->x, position->y);
        mapHeader = Overworld_GetMapHeaderByGroupAndId(destGroup, destMap);
        if (redirected)
        {
            if (destWarp >= 0 && destWarp < mapHeader->events->warpCount
                && mapHeader->events->warps[destWarp].mapNum == MAP_NUM(MAP_DYNAMIC))
                SetDynamicWarp(mapHeader->events->warps[destWarp].warpId,
                    gSaveBlock1Ptr->location.mapGroup,
                    gSaveBlock1Ptr->location.mapNum, warpEventId);
        }
        else
        {
            // Preserve this pinned target's existing vanilla branch.
            if (mapHeader->events->warps[warpEvent->warpId].mapNum == MAP_NUM(MAP_DYNAMIC))
                SetDynamicWarp(mapHeader->events->warps[warpEventId].warpId,
                    gSaveBlock1Ptr->location.mapGroup,
                    gSaveBlock1Ptr->location.mapNum, warpEventId);
        }
```

The apparently inconsistent `warpEventId` in the vanilla branch is copied from the clean target context supplied in the old proof patch. This rewrite intentionally does not certify or fix that unrelated engine behavior. If your target has changed that branch, preserve your target's own vanilla logic and review the difference explicitly.

Keep the dynamic-destination handling that precedes this branch intact. Do not hook the general destination setter: scripts, Dive, falls, escape actions and other special paths also call setters, and are outside this implementation's interception scope. The adapter bounds-checks a randomized landing before returning it.

There is no old proof arrival correction in this integration. The old four-door experiment's hard-coded coordinate fix was specific to that experiment and is not a general landing solution.

## The adapter lifecycle and its limitations

Start creates a simple loading window, allocates WrWork, and installs the generation callback. The first callback initializes the job; following callbacks advance one pairing. B is checked between operations. Success retains WrActive and frees temporary work; failure/cancel invalidates it and returns to the supplied title callback.

This does not guarantee one frame per callback. Graph checking, a trial's closure, and final acceptance are not internally resumable. A held B is noticed on the next callback, not halfway through a long operation. The pulse is an activity indicator, not a percentage or time estimate. A partial attempt can be discarded.

The new target measurements below confirm the consequence: about 64–102 seconds for the measured worlds and roughly 6.4 seconds in the final callback. Cancellation is delayed during that callback. These timings are unacceptable for a responsive loading flow. Use the alternatives in FUTURE.md before making that promise. Stack high-water and graphical responsiveness still need separate checks.

## A manageable development loop

Make one data or algorithm change at a time. Add a small synthetic test when it exposes a new correctness issue, run the host suite, then regenerate the header. For algorithm changes, change `WR_ALGORITHM` and the save marker/version policy deliberately. For data changes, the fingerprint changes automatically.

Then build the target, start a fresh save, try an ordinary door in both directions, save, power-cycle and Continue. Also hold B during generation, test a known second-attempt seed such as 42, and confirm an incompatible save returns to title. Check an excluded source and special transition to establish they still follow their expected vanilla behavior.

Treat source-coordinate agreement as the beginning of a map audit, not its end. Confirm arrival elevation, collisions, event activation and the real starting position. The supplied graph starts at Oldale while the normal engine starts through its vanilla sequence. Resolve that deliberately before interpreting a full-world playtest as a progression test.

Keep brief findings in the appropriate section of these three documents. Regenerate machine outputs when needed. You do not need a new checkpoint README for every experiment.

## Target verification follow-up

### Apply the tested integration

After copying the files in step 1 above, an alternative to the manual edits is:

```sh
# Run inside the clean, pinned target checkout. Replace this path with yours.
git apply --check /path/to/warp-randomizer/integration.patch
git apply /path/to/warp-randomizer/integration.patch
make -j4
```

Do not apply both methods. The patch changes only global.h, overworld.c and field_control_avatar.c. A TESTING-only accessor in the latter lets the regression call the actual SetupWarp implementation. It is absent from normal ROM code.

The patch was checked against clean copies of the three files from commit `e8bd1cd7b03fc032ea37e3ecd38b379b5d01a1e7`. No source from the older proof or C10/C11 runtime is required.

### Run the engine regression tests

Keep `WARP_RANDO_SEED` at its default zero for this suite. Copy target_test.c to `test/warp_compact.c` in the integrated target checkout, then run:

```sh
make -j4 TEST=1 \
  TEST_SRCS_IN="test/test_runner.c test/test_runner_battle.c test/test_runner_args.c test/test_test_runner.c test/warp_compact.c" \
  TESTS="WarpCompact:" check
```

This uses the target's own test framework and bundled mGBA runner. The test file contains four groups and expected hashes derived from independently host-validated layouts. Each group has a 300-second emulated timeout while pumping generation; loops also have a 5,000-callback limit. This is a targeted suite, not the entire game's battle test suite.

In the restricted test environment used here, `/dev/fd` process substitution and Hydra's temporary-file assumptions were unavailable. The build used the supplied original archive's build-without-dev-fd.patch to replace its two `cat - <(...)` suffixes with `{ cat && printf '.text\n\t.align\t2, 0\n'; }`. This is an environment-only Makefile workaround, not part of integration.patch.

The test ELF was built with the command above using `pokeemerald-test.elf` in place of `check`, then run with ordinary files under `build/`:

```sh
cp pokeemerald-test.elf build/compact-headless.elf
tools/patchelf/patchelf build/compact-headless.elf \
  gTestRunnerHeadless '\x01' gTestRunnerSkipIsFail '\x01' \
  gTestRunnerN '\x01' gTestRunnerI '\x00'
arm-none-eabi-objcopy -O binary build/compact-headless.elf build/compact-headless.gba
tools/mgba/mgba-rom-test -l15 -ClogLevel.gba.dma=16 -Rr0 build/compact-headless.gba
```

That emulator process also had a 300-second host wall-clock limit. This fallback runs the same ELF/tests in one process; it does not replace the engine with stubs. Standard environments can use the ordinary `make ... check` path.

### Observed results

The pinned target was compiled with ARM GCC 13.2.1, binutils 2.42 and newlib 4.4.0, using its normal Thumb/ARM7TDMI, `-O2`, `-mabi=apcs-gnu` flags, default EMERALD configuration and no LTO. The emulator was the pinned target's bundled Linux mGBA runner (documented upstream source commit `dbffb46c4e7d2e7a2cbed7c3488cece4c2176d4c`).

Both the normal ROM and test ELF link. All four target test groups pass. Specifically:

- Seed 0 generates the expected world, and seed 42 reproduces its successful second attempt.
- All 608 participating source signatures agree with actual compiled target events; all returned source/landing pairs match the host-derived digest. Coordinate mismatches do not redirect or modify the destination.
- The five normalized routes, an ordinary Oldale route, and three excluded sources exercise the real SetupWarp and WarpIntoMap path.
- Flash save/load preserves the appended identity; Continue regenerates the same world and save bytes. A corrupted envelope and a blank envelope refuse entry.
- B before initialization and B during generation cancel without publishing a table.
- Under deliberate heap pressure, allocation failure returns through the failure callback; temporary memory is recovered. Successful generation and Continue also restore the checked heap totals.

The source-data audit independently checked all 608 signatures and all 75 group counts against the target's map JSON. Source and destination identity still do not establish collision safety or story correctness.

| Target measurement | Observed value |
|---|---:|
| Normal ROM linked EWRAM use | 234,808 bytes of 262,144 |
| Normal ROM linked IWRAM use | 28,376 bytes of 32,768 |
| Normal ROM linked ROM region use | 26,797,932 bytes |
| WrWork, actual target ABI | 23,612 bytes, temporary heap allocation |
| WrActive, actual target ABI | 8,244 bytes, retained EWRAM |
| SaveBlock3 with default configuration | 60 bytes total |
| Seed 0 new generation | 258 callbacks; about 64.402 seconds |
| Seed 0 Continue reconstruction | 258 callbacks; about 64.406 seconds |
| Seed 42 Continue reconstruction | 511 callbacks; about 101.517 seconds |
| Longest measured callback | about 6.398 seconds |

These are **emulated GBA execution times**, not host wall-clock times. Tests use cascaded timers 2/3 at CPU/64, or 262,144 ticks/second. Total times include the VBlank waits between calls. The linked EWRAM figure already includes the engine heap reservation; the remaining 27,336 bytes are not a second independent measure of free heap. The tests check actual allocation success separately.

The longest pause occurs at callback index 257 of 258 for seed 0, and 510 of 511 for seed 42: the final emission/publication call. The recorded initial graph-check callback also takes about 1.642 seconds. Breaking only between pairs is therefore insufficient for responsive input. No claim of a per-frame bound, hardware timing, graphical observation or stack high-water measurement is made.

The central finding is **functional target checks pass, but loading performance is poor**. The follow-up does not change the constructor or relax its acceptance policy to hide that result. The remaining startup/root mismatch, special transitions and Champion/credits proof are also unchanged.
