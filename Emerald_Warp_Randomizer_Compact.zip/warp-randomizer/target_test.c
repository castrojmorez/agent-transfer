/* Target-only regression tests for the compact implementation.
 * Copy to target/test/warp_compact.c after applying integration.patch.
 * Run with the target's TESTS=WarpCompact: filter. See DOCS.md.
 * These expected hashes were independently obtained from the host core and
 * validated by test.py; they hash all 608 physical source/landing pairs. */
#include "global.h"
#include "test/test.h"
#include "test_runner.h"
#include "warp_rando.h"
#include "warp_data.h"
#include "main.h"
#include "malloc.h"
#include "overworld.h"
#include "fieldmap.h"
#include "load_save.h"
#include "save.h"
#include <string.h>

#define EXPECT_SOURCE_HASH_0 0x2aae3861u
#define EXPECT_SOURCE_HASH_42 0x1d5c1c6au

void WarpRando_TestSetupWarp(s8 warpId, struct MapPosition *position);
static MainCallback sReturn;
static u8 sSuccess, sFailure;

static void Success(void)
{
    sSuccess++;
    SetMainCallback2(sReturn);
}

static void Failure(void)
{
    sFailure++;
    SetMainCallback2(sReturn);
}

static u32 FreeBytes(void)
{
    const struct MemBlock *head = HeapHead(), *block = head;
    u32 total = 0;
    do {
        if (!block->allocated)
            total += block->size;
        block = block->next;
    } while (block != head);
    return total;
}

static u32 LargestBlock(void)
{
    const struct MemBlock *head = HeapHead(), *block = head;
    u32 largest = 0;
    do {
        if (!block->allocated && block->size > largest)
            largest = block->size;
        block = block->next;
    } while (block != head);
    return largest;
}

static u32 Clock(void)
{
    /* Tests own timers 2/3. Audio's timers 0/1 remain untouched. */
    u16 high, low;
    do {
        high = REG_TM3CNT_L;
        low = REG_TM2CNT_L;
    } while (high != REG_TM3CNT_L);
    return ((u32)high << 16) | low;
}

static void Begin(const u8 *save)
{
    sReturn = gMain.callback2;
    sSuccess = sFailure = 0;
    gMain.heldKeys = 0;
    if (save)
        WarpRando_Continue(save, Success, Failure);
    else
        WarpRando_NewGame(Success, Failure);
}

static void Pump(int cancelAt)
{
    u32 step = 0, maximum = 0, maximumStep = 0, began, total;
    u32 oldTimeout = gTestRunnerState.timeoutSeconds;
    gTestRunnerState.timeoutSeconds = 300;
    REG_TM2CNT_H = REG_TM3CNT_H = 0;
    REG_TM2CNT_L = REG_TM3CNT_L = 0;
    REG_TM3CNT_H = TIMER_ENABLE | TIMER_COUNTUP;
    REG_TM2CNT_H = TIMER_ENABLE | TIMER_64CLK;
    began = Clock();
    while (gMain.callback2 != Success && gMain.callback2 != Failure && step < 5000) {
        u32 before, elapsed;
        VBlankIntrWait();
        gMain.heldKeys = cancelAt >= 0 && step == (u32)cancelAt ? B_BUTTON : 0;
        before = Clock();
        gMain.callback2();
        elapsed = Clock() - before;
        if (elapsed > maximum) {
            maximum = elapsed;
            maximumStep = step;
        }
        step++;
    }
    total = Clock() - began;
    REG_TM2CNT_H = REG_TM3CNT_H = 0;
    gMain.heldKeys = 0;
    EXPECT(step < 5000);
    if (gMain.callback2 == Success || gMain.callback2 == Failure)
        gMain.callback2();
    gTestRunnerState.timeoutSeconds = oldTimeout;
    Test_MgbaPrintf("WRCOMPACT run steps=%d ticks=%d max_callback_ticks=%d max_step=%d success=%d failure=%d",
                    step, total, maximum, maximumStep, sSuccess, sFailure);
}

static u32 CheckAllSources(void)
{
    u16 i;
    u32 hash = 2166136261u;
    for (i = 0; i < WR_SOURCE_COUNT; i++) {
        const struct WrSourceRoute *r = &wr_source_routes[i];
        const struct MapHeader *map = Overworld_GetMapHeaderByGroupAndId(r->source.group, r->source.map);
        const struct WarpEvent *event = &map->events->warps[r->source.warp];
        s8 dg = event->mapGroup, dm = event->mapNum, dw = event->warpId;
        u8 bytes[6], j;
        EXPECT_EQ(event->x, r->x);
        EXPECT_EQ(event->y, r->y);
        EXPECT_EQ(event->elevation, r->elevation);
        EXPECT(WarpRando_Resolve(r->source.group, r->source.map, r->source.warp,
                                event->x, event->y, event->elevation, &dg, &dm, &dw));
        bytes[0] = r->source.group; bytes[1] = r->source.map; bytes[2] = r->source.warp;
        bytes[3] = dg; bytes[4] = dm; bytes[5] = dw;
        for (j = 0; j < 6; j++)
            hash = (hash ^ bytes[j]) * 16777619u;
        dg = event->mapGroup; dm = event->mapNum; dw = event->warpId;
        EXPECT(!WarpRando_Resolve(r->source.group, r->source.map, r->source.warp,
                                 event->x ^ 1, event->y, event->elevation, &dg, &dm, &dw));
        EXPECT_EQ(dg, event->mapGroup);
        EXPECT_EQ(dm, event->mapNum);
        EXPECT_EQ(dw, event->warpId);
    }
    return hash;
}

static void CheckEngine(struct WrKey source, bool8 allowed)
{
    const struct MapHeader *map = Overworld_GetMapHeaderByGroupAndId(source.group, source.map);
    const struct WarpEvent *event = &map->events->warps[source.warp];
    s8 dg = event->mapGroup, dm = event->mapNum, dw = event->warpId;
    struct MapPosition position;
    EXPECT_EQ(WarpRando_Resolve(source.group, source.map, source.warp,
                event->x, event->y, event->elevation, &dg, &dm, &dw), allowed);
    gSaveBlock1Ptr->location.mapGroup = source.group;
    gSaveBlock1Ptr->location.mapNum = source.map;
    gSaveBlock1Ptr->location.warpId = source.warp;
    gMapHeader = *map;
    position.x = event->x + MAP_OFFSET;
    position.y = event->y + MAP_OFFSET;
    position.elevation = event->elevation;
    WarpRando_TestSetupWarp(source.warp, &position);
    WarpIntoMap();
    EXPECT_EQ(gSaveBlock1Ptr->location.mapGroup, dg);
    EXPECT_EQ(gSaveBlock1Ptr->location.mapNum, dm);
    EXPECT_EQ(gSaveBlock1Ptr->location.warpId, dw);
}

TEST("WarpCompact: generation, source gates, actual event hook and flash Continue")
{
    u32 before = FreeBytes(), largest = LargestBlock();
    u8 save[WR_SAVE_BYTES], replay[WR_SAVE_BYTES];
    struct WrIdentity identity;
    u16 attempt, i;
    Begin(NULL);
    Pump(-1);
    EXPECT_EQ(sSuccess, 1);
    EXPECT_EQ(sFailure, 0);
    EXPECT_EQ(FreeBytes(), before);
    EXPECT_EQ(LargestBlock(), largest);
    EXPECT(WarpRando_Save(save));
    EXPECT_EQ(wr_decode(&wr_graph, save, &identity, &attempt), WR_OK);
    EXPECT_EQ(identity.seed, 0);
    EXPECT_EQ(attempt, 0);
    EXPECT_EQ(CheckAllSources(), EXPECT_SOURCE_HASH_0);
    for (i = 0; i < WR_SOURCE_COUNT; i++) {
        const struct WrSourceRoute *r = &wr_source_routes[i];
        if (memcmp(&r->expected, &r->trigger, sizeof(r->trigger)))
            CheckEngine(r->source, TRUE);
    }
    CheckEngine((struct WrKey){0,10,0}, TRUE);
    CheckEngine((struct WrKey){13,8,0}, FALSE);
    CheckEngine((struct WrKey){13,8,1}, FALSE);
    CheckEngine((struct WrKey){24,33,2}, FALSE);
    memcpy(gSaveBlock3Ptr->warpRando, save, sizeof(save));
    Save_ResetSaveCounters();
    EXPECT_EQ(TrySavingData(SAVE_NORMAL), SAVE_STATUS_OK);
    memset(gSaveBlock3Ptr->warpRando, 0, sizeof(save));
    EXPECT_EQ(LoadGameSave(SAVE_NORMAL), SAVE_STATUS_OK);
    EXPECT_EQ(memcmp(gSaveBlock3Ptr->warpRando, save, sizeof(save)), 0);
    Begin(gSaveBlock3Ptr->warpRando);
    Pump(-1);
    EXPECT_EQ(sSuccess, 1);
    EXPECT_EQ(sFailure, 0);
    EXPECT(WarpRando_Save(replay));
    EXPECT_EQ(memcmp(save, replay, sizeof(save)), 0);
    EXPECT_EQ(CheckAllSources(), EXPECT_SOURCE_HASH_0);
    EXPECT_EQ(FreeBytes(), before);
    Test_MgbaPrintf("WRCOMPACT verified sources=%d SaveBlock3=%d WrWork=%d WrActive=%d flash=1",
                    WR_SOURCE_COUNT, sizeof(struct SaveBlock3), sizeof(struct WrWork), sizeof(struct WrActive));
}

TEST("WarpCompact: cancellation before begin and mid-generation")
{
    u32 before = FreeBytes();
    u8 save[WR_SAVE_BYTES];
    Begin(NULL); Pump(0);
    EXPECT_EQ(sSuccess, 0); EXPECT_EQ(sFailure, 1);
    EXPECT(!WarpRando_Save(save));
    EXPECT_EQ(FreeBytes(), before);
    Begin(NULL); Pump(3);
    EXPECT_EQ(sSuccess, 0); EXPECT_EQ(sFailure, 1);
    EXPECT(!WarpRando_Save(save));
    EXPECT_EQ(FreeBytes(), before);
}

TEST("WarpCompact: allocation failure cleans up and rejects Continue corruption")
{
    u32 before = FreeBytes(), largest = LargestBlock();
    void *block = AllocZeroedUnchecked(largest - 10000);
    u8 bad[WR_SAVE_BYTES] = {0};
    EXPECT(block != NULL);
    Begin(NULL); Pump(-1);
    EXPECT_EQ(sSuccess, 0); EXPECT_EQ(sFailure, 1);
    EXPECT(!WarpRando_Save(bad));
    Free(block);
    EXPECT_EQ(FreeBytes(), before);
    EXPECT_EQ(LargestBlock(), largest);
    Begin(bad); Pump(-1);
    EXPECT_EQ(sSuccess, 0); EXPECT_EQ(sFailure, 1);
}

TEST("WarpCompact: seed 42 second-attempt identity and corruption rejection")
{
    /* Build a well-formed identity without retaining a second active table. */
    struct WrActive *envelope = AllocZeroedUnchecked(sizeof(*envelope));
    u8 saved[WR_SAVE_BYTES], actual[WR_SAVE_BYTES];
    u32 before;
    EXPECT(envelope != NULL);
    if (!envelope) return;
    envelope->valid = TRUE;
    envelope->identity.seed = 42;
    envelope->identity.algorithm = WR_ALGORITHM;
    envelope->identity.ruleset = 1;
    memcpy(envelope->identity.data, wr_graph.fingerprint, 32);
    envelope->attempt = 1;
    EXPECT_EQ(wr_encode(envelope, saved), WR_OK);
    Free(envelope);
    before = FreeBytes();
    Begin(saved); Pump(-1);
    EXPECT_EQ(sSuccess, 1); EXPECT_EQ(sFailure, 0);
    EXPECT(WarpRando_Save(actual));
    EXPECT_EQ(memcmp(saved, actual, sizeof(saved)), 0);
    EXPECT_EQ(CheckAllSources(), EXPECT_SOURCE_HASH_42);
    EXPECT_EQ(FreeBytes(), before);
    /* CRC damage must refuse entry without starting generation. */
    saved[16] ^= 1;
    Begin(saved); Pump(-1);
    EXPECT_EQ(sSuccess, 0); EXPECT_EQ(sFailure, 1);
    EXPECT(!WarpRando_Save(actual));
}
