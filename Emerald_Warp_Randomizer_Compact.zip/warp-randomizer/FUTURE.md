# What to improve next, and why

The purpose of this rewrite is to make the project small enough to reason about. The next changes should buy something concrete: a better match to the game, a demonstrated reduction in latency, or a clearer player experience. File count alone is not the objective. A second well-named helper can be cheaper to understand than a clever state machine hidden in one enormous function.

## The approach we chose

The constructor keeps a conservative progression model and simple fresh graph searches. It samples a few possible pairs, preserves the unused-exit frontier, repairs directed return obligations, and validates the emitted result independently. The engine adapter pauses between pairings and regenerates the world on Continue from a versioned identity.

This preserves the intention of on-device generation while dropping the historical optimization stack. It is a useful baseline for understanding and correctness experiments. It is not established as the best GBA implementation. Simpler source can require more CPU time and temporary memory than specialized code.

The most useful next milestone is a **small target-approved slice**, with a known starting position, safe arrivals, a short progression chain and a verified save/Continue cycle. Full Hoenn generation can remain a host regression while that smaller slice establishes the engine contract.

## Fix the model before trusting larger seed sweeps

The original audit reported 12 destination disagreements, one missing reference endpoint, 1,729 target-only events, two coordinate changes, and 13 unresolved excluded transitions. The later source-aware gate prevents known source/trigger confusion; it does not resolve all of those gameplay questions.

Use canonical map names and the target's map-group order to review each participating event. Numeric triples are compact runtime addresses, but fragile human identities. A future data compiler could accept map names and resolve numbers from the exact target checkout. That would eliminate some hand-maintained numeric risk while adding a modest build-time dependency.

A source signature should eventually include whatever actually matters to arrival: target event identity, coordinates, elevation, relevant collision/tile properties and any special arrival rule. A checksum of more files can detect change, but does not interpret it. Someone still needs to establish that the arrival is usable.

Choose a real starting contract. Either model the vanilla opening from its actual start or deliberately relocate the randomized mode after completing necessary tutorial setup. Verify party/control state and relevant scripts. Calling Oldale the graph root does not perform any of these actions.

Review capability providers against interactions, rather than marking a capability granted whenever a doorway is reached. Badges, HMs, story conversations and key items may have distinct prerequisites. The graph's current permanent-fact model handles AND prerequisites and OR alternatives, but not every restriction in the game.

Do not decide the Weather Institute or Flash behavior solely from names. Keep the current unavailable policy until target behavior is understood, then change the rule explicitly and start a new model identity. Also inspect actual routes that the conservative model omits: extra real travel can introduce access to an unmodeled trap, not merely help the player.

## Special transitions: separate questions, not one catch-all hook

A general warp setter does not tell us why the player is travelling or what state must be updated. Intercepting every call would make the code shorter while making its behavior much harder to understand. Give each family a declared policy.

| Transition | Questions before randomizing or modeling it |
|---|---|
| Scripted warps | Which script owns it? Is it repeatable? Does it set flags, move NPCs or assume a particular destination? |
| Dive/surface | Is a surface/underwater pair tied by coordinates? What capabilities, collision and return constraints apply? |
| Falls/holes/ledges | Is travel directed? Where can the player regain a safe exit? Is a remembered last warp involved? |
| Dynamic destinations | Which state chooses the destination? Does an arrival update the return slot? Can the same event mean different things later? |
| Escape Rope/Dig | Where are these allowed? Is the action repeatable, does it consume an item, and how is the escape destination remembered? |
| Teleport | Which heal location is remembered? Which maps allow the action? Does changing the last heal alter the solver state? |
| Whiteout | Which respawn scripts and recovery states apply? Is relying on defeat acceptable design? What resources are lost? |
| Ferries/Briney/cable car | What story flags, menus, vehicles or one-time sequences gate each route? Is the route symmetric? |
| Fly | Which destinations have been registered, where can Fly be used, and is it intended as a guaranteed recovery action? |

For each family, reasonable choices are: keep it vanilla and model its real effect; exclude its region from a supported preset; or implement a narrow explicit adapter. “Vanilla” is an implementation scope decision, not evidence that it is irrelevant to progression.

A truly repeatable fixed escape with known prerequisites can be an ordinary directed edge. A consumable escape is different. Treating a single Rope as an unlimited edge can produce a false safety proof. History-dependent teleport and whiteout destinations may require expanded state or a deliberately simplified mode rule.

## Progression and victory

The current rules assume permanent capabilities and repeatable travel. Consumable keys, mutually exclusive choices, one-time doors, disappearing NPCs and temporary restrictions do not fit that model automatically.

There are three practical approaches. First, intentionally simplify the randomized mode's story so the monotone model is true, and test each script change. Second, expand the solver state to include the relevant facts, accepting additional complexity and search cost. Third, restrict the supported preset to regions whose behavior already fits the simpler model. A small honest preset can be more useful than a full map with unsupported guarantees.

Champion completion needs a separate finish condition grounded in the engine. Reaching League room nodes or Steven's location is not equivalent to winning battles, triggering the Hall of Fame and seeing credits. Establish the intended badge/HM order, availability of required interactions, and a reproducible actual run. Combat balance is another constraint, not something doorway reachability proves.

Record the seed, model fingerprint, ROM build identity, significant progression steps, save/Continue observations and final outcome in a compact section of DOCS.md. Do not turn every run into another implementation layer.

## Ways to make generation simpler or faster

### 1. Use the measured baseline to choose an optimization

The follow-up ARM tests now show approximately 64 seconds for seed 0 and 102 seconds for seed 42, with the final emission/publication callback taking about 6.4 seconds. Initial graph checking also takes about 1.64 seconds in the measured cancellation run. This is a concrete performance problem, not just a hypothetical loss of frame guarantees.

Next, measure partner trials, repair checks, emission and final validation separately. Measure new game and Continue. Record peak temporary heap, retained EWRAM, stack margin and longest callback. Host times cannot establish these values.

The bounded sampler performs at most three partner trials per committed pair, but each trial may run many graph traversals. If P is the number of representatives and C the number of capability rounds, construction roughly repeats O(C·(V+E)) closure work O(P) times per attempt, with small fixed trial count. Alias emission and some checks also scan quadratically. The constants and GBA memory layout matter.

The new two-seed target timing sample does not establish a worst-case bound. The old 1,024-seed optimized results remain historical evidence for a different implementation. Once the target bottleneck is known, expand tests for that risk, rather than reflexively running very long random experiments.

### 2. Remove repeated immutable checks

The same graph is checked at begin, emission and publication. A deliberately narrow “already checked immutable graph” path could avoid repeating that work. Keep the public checked path for host fixtures and external tables. The trade-off is an extra trust distinction that must stay visible in function names and call sites.

This is likely easier to explain than reviving all incremental reachability machinery at once. Measure the isolated graph-check cost before assuming it is the main problem.

### 3. Precompute unconditional walking regions

Endpoints connected in both directions without requirements form strongly connected components. Within such a component every member can reach every other member. Collapsing those regions at build time can shrink runtime graph walks while preserving directed edges between regions.

This can be worthwhile if implemented as one documented transformation. Keep a physical-endpoint mapping for grouped doors, emission and source checks. A map is not automatically one component: ledges, walls and locked sections matter. Do not merge conditional connectivity before its prerequisites are available.

Python integer bitsets could make an offline prototype concise. A C bitset implementation may improve GBA speed, but adds representation details. Introduce it only with measured benefit and equivalence tests against this baseline.

### 4. Yield inside graph work

The current one-pair continuation is easy to understand but can stall. To obtain a genuine callback budget, traversal itself must be resumable: keep the queue position, current vertex/edge and closure phase in the job. Emission and final acceptance need the same treatment if they exceed the budget.

A fixed number of visited edges per callback is simpler than wall-clock admission logic, but still needs target measurements. A timer budget accommodates variable work yet introduces hardware ownership and timing details. Limit the state machine to the operations that actually exceed budget. The original archive contains one fully developed approach if this becomes the chosen priority.

### 5. Backtrack instead of restarting an entire attempt

Store a small stack of committed pairs and untried alternatives. When the frontier dies, undo a recent pair and choose another partner. This can salvage late failures, but makes deterministic replay, state restoration and bounded execution harder.

A very shallow rollback, with a clear maximum depth and search budget, may be an understandable compromise. It must restore RNG policy and construction state consistently. Do not turn “retry until it works” into an unbounded loading screen.

### 6. Use a region skeleton, then attach leaves

Construct a connected skeleton among regions with several free entrances before attaching one-exit interiors. This directly addresses frontier exhaustion and can be cheaper than trial closure after every choice.

The challenge is defining a region correctly under directed and conditional travel. A spanning tree over maps is insufficient. Return paths, capability gates and grouped entrances still require validation. A region approach could work particularly well for a deliberately restricted preset where those assumptions are verified.

### 7. Start from a known safe layout and perform validated swaps

Begin with a target-approved coupled topology. Repeatedly select two pairs and reconnect their endpoints, accepting a swap only if the full validator still passes. This has a simple rollback story and always retains a valid layout.

The current reference's vanilla topology is not established as a safe starting layout, and not every vanilla event is a symmetric pair. Even with a valid start, local swaps may explore a narrow portion of possible worlds and introduce substantial bias. Measure diversity as well as acceptance and runtime. It is an experiment worth comparing, not a guaranteed shortcut.

### 8. Move generation off-device

For maximum simplicity and responsiveness in the ROM, generate and validate one layout on the computer, then compile its table into ROM. Save a fingerprint of that exact table. The runtime becomes a small source-checked lookup, with no loading constructor or temporary workspace.

This changes the player-facing requirement: a new seed requires another build. It is therefore an alternative, not what this edition quietly does. A precomputed bank permits quick in-game selection but offers only finitely many worlds; hashing arbitrary seed text into a small bank does not create new layouts.

If the owner decides in-game generation is less important than simplicity, this is probably the largest architectural reduction available. Make that product decision explicitly.

### 9. Use a stronger offline solver as a reference

Constraint programming, SAT/SMT or systematic search can express pairing and reachability constraints more directly, especially for small fixtures. Such a solver can produce counterexamples, assess whether the greedy sampler rejects solvable inputs, or generate a trusted comparison corpus.

A solver dependency is rarely the most comprehensible GBA runtime. It also cannot rescue an inaccurate world model. Keep it an optional development experiment unless its benefit is clear.

## Improvements that are not algorithm changes

A seed-entry screen should distinguish the requested seed from the accepted retry. Keep gameplay RNG separate. Show an understandable failure message on exhausted attempts rather than simply returning to title. If timings permit, show honest attempt/pair progress; a retry means work can be discarded, so do not imply a guaranteed remaining duration.

Continue currently regenerates every time. Saving the entire accepted table trades save capacity for quicker loading and tighter preservation of layout identity. It still needs explicit encoding, integrity checking and version policy. Saving only a seed remains smaller, but makes algorithm compatibility part of loading.

A mode toggle needs a save policy. Disabling randomization while standing in a randomized world can silently change topology. Prefer a separate build or mode identity chosen at new game until this behavior is designed. Old save migration should be an explicit converter, not a relaxed version check.

For diagnostics, report a short route to the first trap and the missing goal or requirement. A failure with an explanation is more useful than thousands of counters. A generated spoiler mapping keyed by map names would also help manual door testing without changing runtime behavior.

## Keep the project understandable as it grows

Maintain one source of world data, one active constructor and one acceptance policy. Keep experiments on branches or outside the maintained folder. When an experiment wins, replace the old implementation and put the essential reasoning in these documents; do not retain every predecessor as a production include.

Never remove a safeguard merely because its reason is obscure. First reduce its failure to a small example. Conversely, a historical measurement does not need a permanent runtime abstraction just because it once mattered. The goal is a codebase where a reader can explain what each piece protects and what evidence supports it.
