/* Target adapter for the pinned expansion/1.17.0. GPL-3.0-or-later.
 * Generation runs on the GBA. One callback advances one pairing, NOT one frame
 * worth of work. Read DOCS.md before installing: ARM tests show multi-second callback stalls. */
#include "global.h"
#include "warp_rando.h"
#include "warp_data.h"
#include "main.h"
#include "malloc.h"
#include "bg.h"
#include "gpu_regs.h"
#include "menu.h"
#include "palette.h"
#include "sprite.h"
#include "text.h"
#include "text_window.h"
#include "window.h"
#include "overworld.h"
#include "constants/rgb.h"
#include <string.h>

/* Development seed. A future seed-entry screen can pass its value to Start.
 * Never use the gameplay RNG to make the individual pairing choices. */
#ifndef WARP_RANDO_SEED
#define WARP_RANDO_SEED 0u
#endif

EWRAM_DATA static struct WrActive sActive = {0};
EWRAM_DATA static struct WrJob sJob = {0};
EWRAM_DATA static struct WrWork *sWork = NULL;
EWRAM_DATA static MainCallback sSuccess = NULL;
EWRAM_DATA static MainCallback sFailure = NULL;
EWRAM_DATA static uint16_t sExpectedAttempt = 0;
EWRAM_DATA static bool8 sRestoring = FALSE;
EWRAM_DATA static bool8 sStarted = FALSE;

static const struct BgTemplate sBackground[] = {
    {.bg = 0, .charBaseIndex = 2, .mapBaseIndex = 31,
     .screenSize = 0, .paletteMode = 0, .priority = 0, .baseTile = 0},
};
static const struct WindowTemplate sWindow[] = {
    {.bg = 0, .tilemapLeft = 1, .tilemapTop = 5, .width = 28,
     .height = 8, .paletteNum = 14, .baseBlock = 20},
    DUMMY_WIN_TEMPLATE
};
static const u8 sMessage[] = _("BUILDING WORLD\nB: CANCEL\nMay pause while checking routes.");

static void VBlank(void)
{
    LoadOam();
    ProcessSpriteCopyRequests();
    TransferPlttBuffer();
}

static bool8 InitScreen(void)
{
    SetVBlankCallback(NULL);
    SetHBlankCallback(NULL);
    SetGpuReg(REG_OFFSET_DISPCNT, 0);
    DmaFill16(3, 0, VRAM, VRAM_SIZE);
    DmaFill32(3, 0, OAM, OAM_SIZE);
    DmaFill16(3, 0, PLTT, PLTT_SIZE);
    ResetSpriteData();
    ResetPaletteFade();
    ResetBgsAndClearDma3BusyFlags(0);
    InitBgsFromTemplates(0, sBackground, ARRAY_COUNT(sBackground));
    if (!InitWindows(sWindow))
        return FALSE;
    DeactivateAllTextPrinters();
    FillBgTilemapBufferRect_Palette0(0, 0, 0, 0,
                                    DISPLAY_TILE_WIDTH, DISPLAY_TILE_HEIGHT);
    LoadUserWindowBorderGfx(0, 1, BG_PLTT_ID(13));
    Menu_LoadStdPalAt(BG_PLTT_ID(14));
    FillWindowPixelBuffer(0, PIXEL_FILL(1));
    DrawStdFrameWithCustomTileAndPalette(0, FALSE, 1, 13);
    AddTextPrinterParameterized(0, FONT_SMALL, sMessage, 8, 5, TEXT_SKIP_DRAW, NULL);
    PutWindowTilemap(0);
    CopyWindowToVram(0, COPYWIN_FULL);
    SetBackdropFromColor(RGB_BLACK);
    SetGpuReg(REG_OFFSET_DISPCNT, DISPCNT_MODE_0 | DISPCNT_BG0_ON);
    SetGpuReg(REG_OFFSET_BLDCNT, 0);
    ShowBg(0);
    SetVBlankCallback(VBlank);
    return TRUE;
}

static void Finish(int result)
{
    MainCallback next = result == WR_OK ? sSuccess : sFailure;
    if (result != WR_OK)
        wr_invalidate(&sActive);
    if (sWork != NULL)
        Free(sWork);
    sWork = NULL;
    SetVBlankCallback(NULL);
    FreeAllWindowBuffers();
    HideBg(0);
    SetGpuReg(REG_OFFSET_DISPCNT, 0);
    SetMainCallback2(next);
}

static void Generate(void)
{
    int result;
    /* Cancellation is observed between operations, never during a graph walk. */
    if (JOY_HELD(B_BUTTON)) {
        wr_cancel(&sJob);
        Finish(WR_CANCELLED);
        return;
    }
    if (!sStarted) {
        /* The first screen has already had a chance to become visible. */
        result = wr_begin(&sJob, &wr_graph, &sActive.identity, 8, &sActive, sWork);
        sStarted = TRUE;
    } else {
        result = wr_advance(&sJob);
    }
    if (result == WR_OK && sRestoring && sActive.attempt != sExpectedAttempt)
        result = WR_BAD_IDENTITY;
    if (result != WR_PENDING) {
        Finish(result);
        return;
    }
    /* A pulse is activity only; retries can undo pairing progress. */
    FillWindowPixelRect(0, PIXEL_FILL((gMain.vblankCounter1 / 16) % 2 ? 4 : 2),
                        8, 58, 8, 4);
    CopyWindowToVram(0, COPYWIN_GFX);
    BuildOamBuffer();
    UpdatePaletteFade();
}

static void Start(const struct WrIdentity *identity, bool8 restoring,
                  uint16_t attempt, MainCallback success, MainCallback failure)
{
    if (sWork != NULL) {
        /* Entry points belong to new-game/Continue transitions, never the field. */
        return;
    }
    wr_invalidate(&sActive);
    sSuccess = success;
    sFailure = failure;
    sRestoring = restoring;
    sExpectedAttempt = attempt;
    sStarted = FALSE;
    sActive.identity = *identity;
    if (!InitScreen()) {
        Finish(WR_BAD_DATA);
        return;
    }
    sWork = AllocZeroedUnchecked(sizeof(*sWork));
    if (sWork == NULL) {
        Finish(WR_BAD_DATA);
        return;
    }
    /* Also initializes pointers needed if B is held before the first advance. */
    memset(&sJob, 0, sizeof(sJob));
    sJob.active = &sActive;
    SetMainCallback2(Generate);
}

void WarpRando_NewGame(MainCallback success, MainCallback failure)
{
    struct WrIdentity identity;
    identity.seed = WARP_RANDO_SEED;
    identity.algorithm = WR_ALGORITHM;
    identity.ruleset = 1;
    memcpy(identity.data, wr_graph.fingerprint, sizeof(identity.data));
    Start(&identity, FALSE, 0, success, failure);
}

void WarpRando_Continue(const uint8_t *save, MainCallback success, MainCallback failure)
{
    struct WrIdentity identity;
    uint16_t attempt;
    wr_invalidate(&sActive);
    if (wr_decode(&wr_graph, save, &identity, &attempt) != WR_OK || attempt >= 8) {
        SetMainCallback2(failure);
        return;
    }
    Start(&identity, TRUE, attempt, success, failure);
}

int WarpRando_Save(uint8_t *save)
{
    return wr_encode(&sActive, save) == WR_OK;
}

int WarpRando_Resolve(int sg, int sm, int sw, uint16_t x, uint16_t y,
                     uint8_t elevation, int8_t *dg, int8_t *dm, int8_t *dw)
{
    struct WrKey source, requested, normalized;
    const struct MapHeader *landing;
    if (sg < 0 || sg > 127 || sm < 0 || sm > 127 || sw < 0 || sw > 127
        || !dg || !dm || !dw || *dg < 0 || *dm < 0 || *dw < 0)
        return FALSE;
    source = (struct WrKey){sg, sm, sw};
    requested = (struct WrKey){*dg, *dm, *dw};
    if (!wr_source_normalize(wr_source_routes, WR_SOURCE_COUNT,
                             &source, &requested, x, y, elevation, &normalized))
        return FALSE;
    if (wr_lookup(&sActive, &sActive.identity, &normalized) != 1)
        return FALSE;
    if (normalized.group >= ARRAY_COUNT(wr_target_map_counts)
        || normalized.map >= wr_target_map_counts[normalized.group])
        return FALSE;
    landing = Overworld_GetMapHeaderByGroupAndId(normalized.group, normalized.map);
    if (landing->events == NULL || normalized.warp >= landing->events->warpCount)
        return FALSE;
    *dg = normalized.group;
    *dm = normalized.map;
    *dw = normalized.warp;
    return TRUE;
}
