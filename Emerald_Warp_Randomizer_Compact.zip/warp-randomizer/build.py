"""Strict normalized graph -> deterministic C99 data; Python standard library only."""
import argparse, hashlib, json, pathlib
NONE = 65535

def fail(message):
    raise ValueError(message)

def integer(v, lo, hi, label):
    if type(v) is not int or not lo <= v <= hi:
        fail(f'{label}: expected integer {lo}..{hi}, got {v!r}')
    return v

def key(v):
    if not isinstance(v, list) or len(v) != 3:
        fail(f'bad triple: {v!r}')
    return [integer(x, 0, 127, 'triple') for x in v]

def normalize(d):
    if d.get('schema') != 2:
        fail('schema must be 2')
    nodes = d['nodes']
    n = len(nodes)
    integer(n, 1, 1024, 'node count')
    ids = [x['name'] for x in nodes]
    if len(set(ids)) != n or any((not isinstance(x, str) or not x for x in ids)):
        fail('duplicate/invalid node name')
    if ids != sorted(ids):
        fail('nodes must be sorted by name')
    ni = {s: i for i, s in enumerate(ids)}
    caps = d['capabilities']
    integer(len(caps), 0, 32, 'capabilities')
    if caps != sorted(set(caps)) or any((not isinstance(x, str) for x in caps)):
        fail('capabilities must be unique sorted strings')
    ci = {s: i for i, s in enumerate(caps)}

    def ref(name):
        if name not in ni:
            fail(f'unknown node: {name}')
        return ni[name]

    def cap(name):
        if name is None:
            return NONE
        if name not in ci:
            fail(f'unknown requirement: {name}')
        return ci[name]
    outnodes = []
    seen = set()
    triggers = {}
    for v in nodes:
        k = tuple(key(v['id']))
        tr = tuple(key(v['trigger']))
        if k in seen:
            fail('duplicate physical endpoint')
        seen.add(k)
        if type(v['active']) is not bool:
            fail('active must be Boolean')
        tags = integer(v.get('tags', 0), 0, 3, 'tags')
        r = ref(v['rep'])
        if nodes[r]['rep'] != v['rep']:
            fail('representative is not canonical')
        if nodes[r]['active'] != v['active'] or nodes[r].get('tags', 0) != tags:
            fail('inconsistent group participation/tags')
        if tr in triggers and triggers[tr] != v['active']:
            fail('trigger shared by participating and excluded events')
        triggers[tr] = v['active']
        outnodes.append([list(k), list(tr), r, int(v['active']), tags])
    edges = sorted(set(((ref(e['from']), ref(e['to']), cap(e.get('requires'))) for e in d['edges'])))
    integer(len(edges), 0, 65534, 'edges')
    req = []
    rules = []
    for r in sorted(d['rules'], key=lambda r: json.dumps(r, sort_keys=True)):
        grant = cap(r['grant'])
        if grant == NONE:
            fail('rule needs grant')
        start = len(req)
        for q in r['requires']:
            if set(q) == {'location'}:
                req.append([ref(q['location']), 0])
            elif set(q) == {'capability'}:
                if q['capability'] is None:
                    fail('capability requirement cannot be null')
                req.append([cap(q['capability']), 1])
            else:
                fail(f'bad rule requirement {q}')
        rules.append([grant, start, len(req) - start])
    for name, value in [('requirements', len(req)), ('rules', len(rules)), ('goals', len(d['goals']))]:
        integer(value, 0, 65534, name)
    goals = sorted(set((ref(s) for s in d['goals'])))
    if not goals:
        fail('at least one explicit objective is required')
    digest = hashlib.sha256(json.dumps(d, sort_keys=True, separators=(',', ':')).encode()).hexdigest()
    return dict(nodes=outnodes, edges=edges, rules=rules, reqs=req, goals=goals, root=ref(d['root']), caps=len(caps), sha256=digest)

def emit(d):
    x = normalize(d)
    n = len(x['nodes'])

    def arr(ctype, name, rows):
        rows = list(rows)
        return f'static const {ctype} {name}[{max(1, len(rows))}] = {{\n' + ''.join(('    ' + s + ',\n' for s in rows or (['{0}'] if ctype.startswith('struct') else ['0']))) + '};\n'

    def triple(k):
        return '{' + ','.join(map(str, k)) + '}'
    out = '#ifndef WR_GENERATED_H\n#define WR_GENERATED_H\n#include "warp_rando.h"\n'
    out += f"/* schema 2; SHA-256 {x['sha256']}; no timestamp or paths */\n"
    out += arr('struct WrNode', 'wr_nodes', ('{' + triple(a) + ',' + triple(b) + f',{r},{active},{tags}' + '}' for a, b, r, active, tags in x['nodes']))
    for suffix, edges in [('', x['edges']), ('_reverse', sorted(((b, a, c) for a, b, c in x['edges'])))]:
        bounds = [sum((a < i for a, b, c in edges)) for i in range(n + 1)]
        out += arr('struct WrEdge', 'wr_edges' + suffix, ('{' + f'{b},{c}' + '}' for a, b, c in edges))
        out += arr('uint16_t', 'wr_bounds' + suffix, map(str, bounds))
    for typ, name in [('WrRule', 'rules'), ('WrReq', 'reqs')]:
        out += arr('struct ' + typ, 'wr_' + name, ('{' + ','.join(map(str, row)) + '}' for row in x[name]))
    out += arr('uint16_t', 'wr_goals', map(str, x['goals']))
    digest = ','.join((str(b) for b in bytes.fromhex(x['sha256'])))
    out += 'static const struct WrGraph wr_graph = {\n'
    out += f"    {n},{x['caps']},{len(x['edges'])},{len(x['rules'])},{len(x['reqs'])},{len(x['goals'])},{x['root']},\n"
    out += '    wr_nodes,wr_edges,wr_edges_reverse,wr_bounds,wr_bounds_reverse,wr_rules,wr_reqs,wr_goals,\n'
    out += '    {' + digest + '}\n};\n'
    out += emit_routes(d)
    out += '#endif\n'
    return out

def emit_routes(data):
    """Keep the source signature gate and graph in ONE fingerprinted input."""
    nodes = {tuple(v['id']): v for v in data['nodes'] if v['active']}
    routes = data.get('source_routes', [])
    counts = data.get('target_map_counts', [])
    if not counts or len(counts) > 128:
        fail('target needs 1..128 map groups')
    for count in counts:
        integer(count, 1, 128, 'target map count')
    seen = set()
    rows = []
    for route in sorted(routes, key=lambda r: r['source']):
        source = tuple(key(route['source']))
        expected = key(route['expected'])
        trigger = key(route['trigger'])
        if source in seen or source not in nodes:
            fail('duplicate or nonparticipating source route')
        if trigger != nodes[source]['trigger']:
            fail('source route does not match graph trigger')
        for group, map_id, warp in (source, expected):
            if group >= len(counts) or map_id >= counts[group]:
                fail('source signature exceeds target map counts')
        seen.add(source)
        x = integer(route['x'], 0, 65535, 'source x')
        y = integer(route['y'], 0, 65535, 'source y')
        elevation = integer(route['elevation'], 0, 255, 'elevation')
        triples = ','.join(('{' + ','.join(map(str, k)) + '}' for k in (source, expected, trigger)))
        rows.append('    {' + triples + f',{x},{y},{elevation}' + '},')
    if seen != set(nodes):
        fail('source routes must cover every participating physical endpoint')
    return 'static const struct WrSourceRoute wr_source_routes[] = {\n' + '\n'.join(rows or ['    {{0,0,0},{0,0,0},{0,0,0},0,0,0},']) + '\n};\n' + '#define WR_SOURCE_COUNT ' + str(len(rows)) + 'u\n' + 'static const uint8_t wr_target_map_counts[] = {' + ','.join(map(str, counts)) + '};\n'
if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('input', nargs='?', default='world.json')
    parser.add_argument('output', nargs='?', default='warp_data.h')
    args = parser.parse_args()
    try:
        text = emit(json.loads(pathlib.Path(args.input).read_text()))
        destination = pathlib.Path(args.output)
        temporary = destination.with_suffix(destination.suffix + '.tmp')
        temporary.write_text(text)
        temporary.replace(destination)
        print('Wrote', destination)
    except (ValueError, KeyError, TypeError) as error:
        parser.exit(1, f'error: {error}\n')
